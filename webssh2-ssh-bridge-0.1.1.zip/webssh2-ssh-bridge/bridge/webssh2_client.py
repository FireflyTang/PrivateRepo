"""v5.2.1 protocol adapter. No SSH client or target Linux address here."""
import asyncio
import base64
import posixpath
import time
import uuid
from urllib.parse import urlencode
from .logging_setup import event as log_event, failure, register_secret
from contextlib import suppress
import aiohttp
import socketio


class WebSSHError(Exception):
    def __init__(self, message, code='PROTOCOL_ERROR'):
        super().__init__(message)
        self.code = code


class ClosingSocketClient(socketio.AsyncClient):
    # Engine.IO schedules message callbacks. Ignore already queued binary
    # attachments after owner shutdown, when Socket.IO has reset its parser.
    async def _handle_eio_message(self, data):
        if not self.owner.closed:
            await super()._handle_eio_message(data)


class WebSSHClient:
    def __init__(self, config):
        self.config = config
        self.client_id = 'ws-' + uuid.uuid4().hex[:12]
        self.started = time.monotonic()
        self.bytes_in = 0
        self.bytes_out = 0
        self.http = None
        self.sio = None
        self.data = asyncio.Queue()
        self.files = asyncio.Queue()
        self.auth = asyncio.Queue()
        self.file_lock = asyncio.Lock()
        self.sftp_config = {}
        self.closed = False

    async def connect(self):
        cookie = self.config.cookie().strip()
        register_secret(cookie)
        for part in cookie.split(';'):
            if '=' in part:
                register_secret(part.split('=', 1)[1].strip())
        if not cookie or '\n' in cookie or '\r' in cookie:
            raise WebSSHError('webssh.cookie must contain a nonempty Cookie header line', 'AUTH')
        log_event('INFO', 'upstream.connect.start', client_id=self.client_id, origin=self.config.url,
              entry_path=self.config.entry_path, socketio_path=self.config.socket_path, namespace=self.config.namespace,
              transports=self.config.transports, tls_verify=self.config.tls_verify)
        self.http = aiohttp.ClientSession(cookie_jar=aiohttp.CookieJar(unsafe=True),
                headers={**self.config.headers, 'Cookie': cookie},
                connector=aiohttp.TCPConnector(ssl=self.config.tls_verify),
                timeout=aiohttp.ClientTimeout(total=self.config.http_timeout))
        self.sio = ClosingSocketClient(http_session=self.http, reconnection=False)
        self.sio.owner = self
        def on(name, callback):
            self.sio.on(self.config.events.get(name, name), callback, namespace=self.config.namespace)
        on('authentication', self._auth)
        on('data', self._data)
        on('ssherror', self._error)
        on('connection-error', lambda value: self._error(value.get('message', 'Backend connection failed')))
        on('disconnect', lambda *args: self._error('WebSSH2 disconnected'))
        on('sftp-status', self._status)
        for event in ('sftp-directory', 'sftp-stat-result', 'sftp-operation-result',
                      'sftp-upload-ready', 'sftp-upload-ack', 'sftp-download-ready',
                      'sftp-download-chunk', 'sftp-complete', 'sftp-error'):
            on(event, self._file_handler(event))
        try:
            # Visiting the page establishes WebSSH2's own session cookie.
            async with self.http.request(self.config.entry_method, self.config.url + self.config.entry_path,
                    params=self.config.entry_query, data=self.config.entry_form if self.config.entry_method == 'POST' else None,
                    allow_redirects=False) as response:
                log_event('INFO', 'upstream.http.result', client_id=self.client_id, status=response.status, redirect=response.headers.get('Location'))
                if response.status != 200:
                    raise WebSSHError('Website authentication failed or Cookie expired (HTTP %s)' % response.status, 'AUTH')
                await response.read()
            socket_url = self.config.url + ('?' + urlencode(self.config.query) if self.config.query else '')
            await self.sio.connect(socket_url, socketio_path=self.config.socket_path, auth=self.config.socket_auth or None,
                                   transports=self.config.transports, namespaces=[self.config.namespace], wait_timeout=self.config.connect_timeout)
            event = await asyncio.wait_for(self.auth.get(), self.config.connect_timeout)
            if isinstance(event, Exception):
                raise event
            if event.get('action') == 'request_auth':
                raise WebSSHError('Website did not provide SSH credentials; protocol adaptation required', 'AUTH')
            if not event.get('success'):
                raise WebSSHError('WebSSH2 authentication failed', 'AUTH')
            log_event('INFO', 'upstream.auth.success', client_id=self.client_id, duration_ms=round((time.monotonic()-self.started)*1000))
            return self
        except BaseException as error:
            failure('upstream.connect.failed', error, client_id=self.client_id)
            await self.close()
            raise

    def _data(self, value):
        data = value.encode() if isinstance(value, str) else bytes(value)
        self.bytes_in += len(data)
        if self.config.log_settings['terminal_data']:
            log_event('DEBUG', 'terminal.data', client_id=self.client_id, direction='receive', data_base64=base64.b64encode(data).decode(), bytes=len(data))
        self.data.put_nowait(data)

    def _auth(self, value):
        log_event('INFO', 'upstream.auth.result', client_id=self.client_id, action=value.get('action'), success=value.get('success'))
        self.auth.put_nowait(value)

    def _status(self, value):
        log_event('INFO', 'upstream.sftp.capabilities', client_id=self.client_id, enabled=value.get('enabled'), limits=value.get('config', {}))
        if value.get('enabled'):
            self.sftp_config = value.get('config', {})

    def _error(self, value):
        if not self.closed:
            log_event('WARNING', 'upstream.connection.error', client_id=self.client_id, message=str(value))
            error = WebSSHError(str(value))
            for queue in (self.auth, self.data, self.files):
                queue.put_nowait(error)

    def _file_handler(self, event):
        def handler(value):
            if self.config.log_settings['protocol_events']:
                self.trace('receive', event, value)
            self.files.put_nowait((event, value))
        return handler

    def trace(self, direction, name, value):
        fields = {'client_id': self.client_id, 'direction': direction, 'socket_event': name}
        if isinstance(value, dict):
            fields['payload_keys'] = list(value)
            for key in ('transferId', 'chunkIndex', 'bytesReceived', 'bytesTransferred'):
                if key in value:
                    fields[key] = value[key]
        log_event('DEBUG', 'protocol.event', **fields)

    async def emit(self, event, value):
        if not self.sio or not self.sio.connected:
            raise WebSSHError('WebSSH2 is not connected')
        if self.config.log_settings['protocol_events']:
            self.trace('send', event, value)
        if event == 'data':
            encoded = value.encode() if isinstance(value, str) else value
            self.bytes_out += len(encoded)
            if self.config.log_settings['terminal_data']:
                log_event('DEBUG', 'terminal.data', client_id=self.client_id, direction='send', data_base64=base64.b64encode(encoded).decode(), bytes=len(encoded))
        await self.sio.emit(self.config.events.get(event, event), value, namespace=self.config.namespace)

    async def terminal(self, term='xterm-256color', cols=80, rows=24):
        log_event('INFO', 'upstream.terminal.open', client_id=self.client_id, term=term, cols=cols, rows=rows)
        await self.emit('terminal', {'term': term, 'cols': cols, 'rows': rows})

    async def receive(self):
        value = await self.data.get()
        if isinstance(value, Exception):
            raise value
        return value

    async def _next(self, expected):
        while True:
            item = await asyncio.wait_for(self.files.get(), self.config.operation_timeout)
            if isinstance(item, Exception):
                raise item
            event, value = item
            if event == 'sftp-error':
                raise WebSSHError(value.get('message', 'SFTP failed'), value.get('code'))
            if event in expected:
                if value.get('error') or value.get('success') is False:
                    raise WebSSHError(value.get('error', 'Operation failed'))
                return event, value

    async def request(self, event, payload, response):
        async with self.file_lock:
            started = time.monotonic()
            log_event('INFO', 'sftp.operation.start', client_id=self.client_id, operation=event, path=payload.get('path'))
            try:
                await self.emit(event, payload)
                result = (await self._next({response}))[1]
                log_event('INFO', 'sftp.operation.complete', client_id=self.client_id, operation=event, duration_ms=round((time.monotonic()-started)*1000))
                return result
            except asyncio.TimeoutError:
                # A late response has no request ID and cannot be safely reused.
                await self.close()
                log_event('ERROR', 'sftp.operation.timeout', client_id=self.client_id, operation=event)
                raise WebSSHError('WebSSH2 operation timed out; start a new session')
            except Exception as error:
                log_event('WARNING', 'sftp.operation.failed', client_id=self.client_id, operation=event, error_type=type(error).__name__, error_code=getattr(error, 'code', None), message=str(error))
                raise

    async def stat(self, path):
        return (await self.request('sftp-stat', {'path': path}, 'sftp-stat-result'))['entry']

    async def list(self, path):
        return await self.request('sftp-list', {'path': path, 'showHidden': True}, 'sftp-directory')

    async def mkdir(self, path, mode=0o755):
        return await self.request('sftp-mkdir', {'path': path, 'mode': mode}, 'sftp-operation-result')

    async def delete(self, path):
        return await self.request('sftp-delete', {'path': path, 'recursive': False}, 'sftp-operation-result')

    async def upload(self, path, file, size, overwrite=True):
        if size > self.config.max_file:
            raise WebSSHError('Bridge file size limit exceeded', 'SFTP_FILE_TOO_LARGE')
        log_event('INFO', 'sftp.upload.start', client_id=self.client_id, path=path, bytes=size, overwrite=overwrite)
        async with self.file_lock:
            await self.emit('sftp-upload-start', {'remotePath': path, 'fileName': posixpath.basename(path),
                                                  'fileSize': size, 'overwrite': overwrite})
            _, ready = await self._next({'sftp-upload-ready'})
            transfer = ready['transferId']
            chunk_size = min(ready['chunkSize'], self.config.upload_chunk, 32768)
            file.seek(0)
            sent = 0
            index = 0
            try:
                while True:
                    data = file.read(chunk_size)
                    sent += len(data)
                    last = sent >= size
                    await self.emit('sftp-upload-chunk', {'transferId': transfer, 'chunkIndex': index,
                                    'data': base64.b64encode(data).decode(), 'isLast': last})
                    _, ack = await self._next({'sftp-upload-ack'})
                    if ack['transferId'] != transfer or ack['chunkIndex'] != index or ack['bytesReceived'] != sent:
                        raise WebSSHError('Upload acknowledgment mismatch')
                    if last:
                        _, complete = await self._next({'sftp-complete'})
                        if complete['transferId'] != transfer or complete['bytesTransferred'] != size:
                            raise WebSSHError('Incomplete upload')
                        log_event('INFO', 'sftp.upload.complete', client_id=self.client_id, transfer_id=transfer, path=path, bytes=size, chunks=index+1)
                        return
                    index += 1
            except BaseException as error:
                failure('sftp.upload.failed', error, client_id=self.client_id, transfer_id=transfer, bytes_sent=sent)
                with suppress(Exception):
                    await self.emit('sftp-upload-cancel', {'transferId': transfer})
                raise

    async def download(self, path, file):
        log_event('INFO', 'sftp.download.start', client_id=self.client_id, path=path)
        async with self.file_lock:
            await self.emit('sftp-download-start', {'remotePath': path})
            _, ready = await self._next({'sftp-download-ready'})
            transfer, size = ready['transferId'], ready['fileSize']
            total, index = 0, 0
            if size == 0:
                # v5.2.1 schedules no reads and emits no completion for empty files.
                await self.emit('sftp-download-cancel', {'transferId': transfer})
                import shlex
                from .exec_adapter import execute
                async with WebSSHClient(self.config) as check:
                    async def discard(data):
                        pass
                    status = await asyncio.wait_for(execute(check, 'test -f ' + shlex.quote(path) + ' && test -r ' + shlex.quote(path), discard), self.config.timeout)
                    if status:
                        raise WebSSHError('Empty file is not readable', 'SFTP_PERMISSION_DENIED')
                file.seek(0)
                file.truncate(0)
                log_event('INFO', 'sftp.download.complete', client_id=self.client_id, transfer_id=transfer, path=path, bytes=0, workaround='empty-file')
                return
            try:
                if size > self.config.max_file:
                    raise WebSSHError('Bridge file size limit exceeded', 'SFTP_FILE_TOO_LARGE')
                while True:
                    event, value = await self._next({'sftp-download-chunk', 'sftp-complete'})
                    if value['transferId'] != transfer:
                        raise WebSSHError('Download transfer mismatch')
                    if event == 'sftp-complete':
                        if total != size or value['bytesTransferred'] != size:
                            raise WebSSHError('Incomplete download')
                        file.seek(0)
                        log_event('INFO', 'sftp.download.complete', client_id=self.client_id, transfer_id=transfer, path=path, bytes=total, chunks=index)
                        return
                    if value['chunkIndex'] != index:
                        raise WebSSHError('Out-of-order download')
                    data = value['data']
                    if isinstance(data, dict) and data.get('type') == 'Buffer':
                        data = bytes(data['data'])
                    if not isinstance(data, bytes):
                        raise WebSSHError('Unexpected download encoding')
                    total += len(data)
                    if total > size:
                        raise WebSSHError('Download exceeds declared length')
                    file.write(data)
                    index += 1
            except BaseException as error:
                failure('sftp.download.failed', error, client_id=self.client_id, transfer_id=transfer, bytes_received=total)
                with suppress(Exception):
                    await self.emit('sftp-download-cancel', {'transferId': transfer})
                raise

    async def close(self):
        if self.closed:
            return
        self.closed = True
        log_event('INFO', 'upstream.closed', client_id=self.client_id, terminal_bytes_in=self.bytes_in, terminal_bytes_out=self.bytes_out, duration_ms=round((time.monotonic()-self.started)*1000))
        if self.sio:
            with suppress(Exception):
                await self.sio.disconnect()
        if self.http:
            await self.http.close()

    async def __aenter__(self):
        return await self.connect()

    async def __aexit__(self, *args):
        await self.close()
