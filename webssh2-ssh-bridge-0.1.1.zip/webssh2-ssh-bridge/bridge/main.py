import argparse
import asyncio
import fcntl
import os
import signal
from .config import Config
from .logging_setup import configure_logging, event, failure
from .ssh_server import serve


async def main(default_config=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=default_config)
    args = parser.parse_args()
    if default_config is not None:
        from pathlib import Path
        path = Path(args.config)
        if path.exists():
            path.chmod(0o600)
    config = Config(args.config)
    configure_logging(config)
    config.state.mkdir(parents=True, exist_ok=True, mode=0o700)
    lock = open(config.state / 'bridge.lock', 'w')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit('Bridge is already running')
    stopped = asyncio.Event()
    asyncio.get_running_loop().add_signal_handler(signal.SIGTERM, stopped.set)
    try:
        server = await serve(config)
        (config.state / 'bridge.pid').write_text(str(os.getpid()))
        (config.state / 'bridge.ready').write_text(str(os.getpid()))
        event('INFO', 'ssh.listening', host=config.host, port=config.port, username=config.username,
              password_enabled=bool(config.password), config_file=str(config.path))
        async with server:
            await stopped.wait()
    except Exception as error:
        failure('bridge.failed', error)
        raise SystemExit('Bridge failed; see private diagnostic log') from None
    finally:
        (config.state / 'bridge.pid').unlink(missing_ok=True)
        (config.state / 'bridge.ready').unlink(missing_ok=True)
        lock.close()
        event('INFO', 'bridge.stopped')


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
