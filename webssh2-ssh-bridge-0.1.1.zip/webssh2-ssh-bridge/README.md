# WebSSH2 SSH Bridge

一个 Python 项目。入口是 `main.py`，所有设置放在旁边的 `config.json`。
把网站中的 WebSSH2 转为可从其他机器访问的标准 SSH/SCP/SFTP 服务。

## 启动

需要 Python 3.9+，macOS 或 Linux。

```sh
pip install -r requirements.txt
# 编辑 config.json
python main.py
```

保持进程运行；Ctrl+C 停止。无需 Shell 管理脚本、Docker 或 Node。
日志写入 `logs/bridge.jsonl` 并自动轮转。主机密钥等运行文件自动生成在 `.state/`。

## 配置

最主要的字段：

| 字段 | 填什么 |
|---|---|
| ssh.host / port | SSH 监听地址和端口，默认 0.0.0.0:2222 |
| ssh.username / password | Agent 登录桥接服务的用户名、密码；空密码关闭密码认证 |
| ssh.authorized_keys | 可选的普通 OpenSSH 公钥列表文件 |
| webssh.url | 终端服务器 origin，例如 https://terminal.example |
| webssh.entry_path | 实际终端网页路径，例如 /ssh/host/ |
| webssh.socketio_path | Socket.IO 路径，例如 /ssh/socket.io/ |
| webssh.cookie | 已登录浏览器实际发送的 Cookie 值，不含 Cookie: 前缀 |
| webssh.headers | 必要的 Origin、Referer 等请求头 |
| webssh.namespace | 通常为 /，有自定义 namespace 时按抓包填写 |
| webssh.query / auth | 站点握手需要的额外参数；通常留空 |
| webssh.exec_timeout_seconds | 命令超时，默认 120 秒 |
| files.max_bytes | 单文件大小上限，默认 32 MiB |
| logging.level | INFO 或 DEBUG |
| logging.redact_secrets | 默认 false，按用户要求保留日志原文 |
| logging.command_text | 默认 true，记录完整命令 |

相对文件路径以 config.json 所在目录为基准。首次启动会将配置文件权限设为 0600。
Cookie 在新会话中自动重新读取；其他配置修改后重启 Python 进程。
发布包没有私人密码、Cookie 或密钥，需要填写自己的设置。

## 从网页获取接入信息

1. 正常登录网站并打开终端，在浏览器 F12 → Network 中找到 WS 请求；必要时刷新页面。
2. 如果终端在 iframe 内，查看 iframe src 或 Document 请求，找到真正的终端页面地址，不使用外层门户地址。
3. 假设 WS Request URL 为：

   `wss://terminal.example/apps/ssh/socket.io/?EIO=4&transport=websocket&sid=临时值`

   则 `webssh.url` 填 `https://terminal.example`，`socketio_path` 填 `/apps/ssh/socket.io/`。
   `sid`、`EIO`、`transport`、`t` 由客户端管理，不复制到 query。
4. 将 WS Request Headers 中的完整 Cookie 值填入 `webssh.cookie`；必要的 Origin/Referer 放入 headers。
5. 将实际终端页面的路径填入 entry_path。需要页面 query 或 POST 初始化时，使用 entry_query、entry_method、entry_form。
6. 当前支持 Engine.IO 4 / Socket.IO 协议。普通 WebSocket 或 EIO=3 不能直接套用；事件名可通过 events 改名，消息结构不同需要适配代码。

## Agent 使用

在 Agent 机器连接桥接机器的可达 IP：

```sh
ssh -p 2222 root@桥接机器IP 'whoami; pwd'
scp -P 2222 ./code.py root@桥接机器IP:/远端路径/code.py
sftp -P 2222 root@桥接机器IP
```

支持公钥和密码；只使用密码时按 SSH 提示输入已配置的密码。

命令 stdout/stderr 合并，exec stdin 为 /dev/null；复杂脚本先上传再执行。
每次命令是独立 shell，使用 `cd /目录 && 命令`。退出码正常传回，超时或断线后不要盲目重放有副作用的操作。
SCP 使用现代默认 SFTP 模式，不使用 -O 或 -p。文件上传在 CLOSE 时提交，默认重下载校验 SHA-256。
不支持端口转发、SFTP 符号链接/所有权/时间戳保留或 fsync。

已通过本地官方 WebSSH2 链路测试；真实内网仍需比对实际认证和协议。
