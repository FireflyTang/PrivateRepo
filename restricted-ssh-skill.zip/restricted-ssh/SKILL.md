---
name: restricted-ssh
description: 使用已连接的受限 SSH 执行远端命令、上传下载文件和完成开发任务。需要明确 SSH/SCP/SFTP 可用能力和调用限制时使用。
---

# 受限 SSH 使用说明

沿用已经连通的 SSH 地址、账号和认证方式。下面用 `HOST` 代指现有连接目标，无需重新配置连接。

## 可以用

- `ssh HOST '命令'`：执行命令、脚本、编译、测试，返回输出和退出码。
- 支持管道、引号、重定向；命令由远端 `sh` 执行，需要 Bash 时显式运行 `bash script.sh`。
- `scp 本地文件 HOST:/远端路径` 和 `scp HOST:/远端文件 本地路径`：上传、下载，包括二进制文件。
- `sftp HOST`：列目录、读写文件、查询属性、创建/删除目录、删除/重命名文件、修改权限。
- 独立命令可以并发；同一文件的写入按顺序进行。

## 不能用

- 向 SSH 命令传 stdin：不用 `ssh HOST < script.sh`、`cat script.sh | ssh HOST`、`ssh HOST 'bash -s'` 或向 SSH 输入 heredoc。
- 不依赖交互式提示或交互 shell 驱动自动化；复杂脚本先上传再执行。
- 不用 `scp -O`（旧 SCP）或 `scp -p`（保留文件属性）。
- 不支持端口转发、Agent Forwarding；不依赖 VS Code Remote SSH 或通过此服务做跳板。
- SFTP 不支持符号链接、修改所有者、保留时间戳、statvfs、fsync。这不限制通过远端命令执行当前账户有权限的普通文件操作。

## 常用操作

```sh
# 每条 SSH 命令是独立会话，工作目录要在同一次调用中指定
ssh HOST 'cd /absolute/project && make && sh ./test.sh'

# 在本地修改文件后上传；复杂脚本也这样处理
scp ./job.sh HOST:/absolute/project/job.sh
ssh HOST 'cd /absolute/project && sh ./job.sh > result.log 2>&1'
scp HOST:/absolute/project/result.log ./result.log
```

## 必须注意

- stdout/stderr 合并，按退出码判断是否成功，不按 stderr 是否为空判断。
- 文件使用 SCP/SFTP 传输，等待传输正常结束；不要通过命令输出通道传二进制文件。
- 默认命令超时 120 秒、单文件上限 32 MiB、并发会话上限 8；以实际服务配置和错误响应为准。
- 超时、中断或断线后，命令可能已经产生副作用，上传也可能留下部分文件。先检查结果，再决定重试，不自动重放有副作用的操作。
- 不保证断线后后台进程继续存活。
