# CPU 冻结工具与回执

`cpu-recovery-reproduce-v2.tar.gz` 及其 manifest 保存有限域导出所用冻结工具源码、编译配方、原命令与来源回执。`cpu-durable-recovery-supplement.tar.gz` 及其 manifest 保存后续持久化启动入口与证据。详见两压缩档内 README 和 `EXECUTION_CLOSEOUT.json`。

有限域产物是对原始回调流的有界解释，整体 native capture 仍未通过。完整原流和匹配环境不随本包；构造 fixture 验证工具，不能替代原始故障复现。直接查看已保存的小样本不需要运行模型，命令见 [复现说明](../REPRODUCTION.md)。
