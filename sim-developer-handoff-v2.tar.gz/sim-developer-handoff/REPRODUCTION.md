# 复现材料与迁移边界

本包保留三个原始终态复现档和对应 manifest：E1 repair-a2、官方 G1 repair-a1、官方 G2 repair-a2。内层档各有 `run/`，不要解到同一目录。各档原始绝对地址、SHA 和成员逐一见 `reproductions/*-manifest.json` 与 `evidence/*REPRODUCE_CLOSEOUT.json`、`E1_PACK_CLOSEOUT.json`。内层原始文件不修改，top/SQ/task 中存在绝对路径，随意解压到新位置不会自动成为可运行的模型环境。

```bash
mkdir -p unpack/E1 unpack/G1 unpack/G2 unpack/tools
for case in E1 G1 G2; do tar -xzf "reproductions/${case}-reproduce.tar.gz" -C "unpack/${case}"; done
tar -xzf tools/cpu-recovery-reproduce-v2.tar.gz -C unpack/tools
```

## 离线查看原异常样本（不运行模型）

从包根运行下面命令，调用封存工具的 `classify` 对四组原回调小样本重新分类。只需 Python 3 标准库，不需要 SDK，也不运行模型或读取大 raw。命令中的本机 tang 路径是示例，开发者可替换成自己获准使用的 Python 3。首次操作请按顺序展开两层工具包：

```bash
mkdir -p unpack/tools
tar -xzf tools/cpu-recovery-reproduce-v2.tar.gz -C unpack/tools
tar -xzf unpack/tools/cpu-recovery-reproduce-v2/sealed-tools-279d49b.tar.gz -C unpack/tools
/home/t00826093/miniforge3/envs/tang/bin/python - <<'PYTHON'
import json
import sys
sys.path.insert(0, 'unpack/tools/tools/scripts')
from callback_pairing_diagnostic import classify
with open('evidence/rv-send-continuation/RV_SEND_EXACT_SAMPLES.json', encoding='utf-8') as f:
    data = json.load(f)
assert len(data['groups']) == 4
for group in data['groups']:
    events = group['events']
    status, _ = classify([e for e in events if e['kind'] == 0],
                         [e for e in events if e['kind'] == 1])
    print(group['identity'], status)
    assert status == 'UNKNOWN_MISSING_ENDPOINT'
print('four groups: PASS')
PYTHON
```

实际用 tang 执行时四组均为 `UNKNOWN_MISSING_ENDPOINT`；这只验证保存的小样本分类，不能证明全流结果。

样本有原字段及 `entry_bytes_hex`、各字符串 hex、frame SHA；`evidence/G2_A2_EXACT_CALLBACK_SAMPLES.json` 另有精确回调样本；`FIRST_FAILURE_FRAMES.json` 是 END_LABEL PC 防护问题的原 frame，不能混同为 RV_SEND 问题。对应模型反汇编、静态链路和局限在 `evidence/rv-send-continuation/`。CPU 有限域导出的原始命令、原始终态与工具源码封存见 `tools/cpu-recovery-reproduce-v2.tar.gz` 和 `tools/cpu-durable-recovery-supplement.tar.gz`。其命令需要原完整流及精确来源绑定，不是上述小样本命令；补包里 fixture 只验证工具行为，不能当作原故障重现。

## 原模型重跑的具体入口及前提

记录中的原 G2 执行命令为（仅作历史依据，原目录含不可覆盖的冻结数据，不应直接在原目录重跑）：

```text
/home/t00826093/miniconda3/envs/tang/bin/python /home/t00826093/data/megamoe-smallbs/data/e1-e2-next-20261113/cases/sim-cann-g2/attempts/repair-20261114-a2/build/sim-tools/scripts/simulate.py --config /home/t00826093/data/megamoe-smallbs/data/e1-e2-next-20261113/cases/sim-cann-g2/attempts/repair-20261114-a2/build/run/config.json --run /home/t00826093/data/megamoe-smallbs/data/e1-e2-next-20261113/cases/sim-cann-g2/attempts/repair-20261114-a2/build/run --cann-env /home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/set_env.sh
```

证据：`evidence/G2_A2_FINAL_WORKFLOW.json`。G1 实际命令、G2 原日志在各自内层 `run/preparation/terminal-acceptance/actual-run/`；E1 在内层 `run/preparation/terminal-acceptance/ACTUAL_C2_DIAGNOSTIC_EVIDENCE.tar.gz` 的 `evidence/logs/workflow_run.json`。这些日志记录实际命令、环境、helper 及模型绑定和 traceback。三个清单顶层 `effective_runtime_present=false` 指顶层没有该文件；上述终态证据中另存了实际 launcher 的 `effective_runtime.json`，它也不等于对模型子进程环境的直接观测。

完整重跑需要自行取得与回执一致的 CANN 9.3.0-weekly.20261104.01、npusim/model/helper、相应 Linux ABI、编译器和用户有权使用的 Python 环境；所选 SDK 文件有部分被原档绑定，SDK 及其所有依赖并未整体随包。模型 SHA256 `856b25664cf01810bf3bb24bf5efd84752a5e1dc8dc1b7435bdcbc26a97a6115`，helper SHA256 `62a22b8c4e205bddfbb74ac80bb7f46617a6afd56eb977092ac023b376c7fea4`；实际模型/launcher/helper 的各项路径和绑定以档内 `camodel_binding.json`、`effective_runtime.json` 及 `callback_tee.json` 为准。G1/G2 所选 SDK 文件及 SHA 在 `evidence/G1_REPRODUCE_CLOSEOUT.json` 和内层 `OFFICIAL_SOURCE_SCOPE.json`。

迁移时使用已冻结的原公共工具与配置重新准备独立 run，并以公共 `case.py`、`upload_run.py`、`simulate.py` 工作流生成/部署其对应路径，核对生成 top/SQ/task 对新路径和同 ELF/镜像/输入的绑定；或者在隔离环境完整还原原绝对路径。保留原 ELF，不要在旧目录覆盖输出。这里未验证跨机重建命令，不宣称解包后可一键执行；绑定改变会形成新的复现实验，须重新验来源及结果。原官方档 source_scope 称未提供厂商源码的措辞过宽：有同族源码，但尚缺足以重建所选 ELF 的完整分支与构建配方；本次使用原 ELF，不以当前源码冒充原构建。

## 未随包的大流

大文件保留在 model1 的原记录路径。E1 tee 为 `.../cases/sim-e1-rank0/attempts/repair-20261114-a2/build/run/data/raw/callback-tee/callback-419440.bin`，15622956580 字节，SHA256 `d9d7b507a0af4dd1103991c49c01ddcd76efc1df5fc13866ce926c6d7b9d6da9`；G2 tee 为 `.../cases/sim-cann-g2/attempts/repair-20261114-a2/build/run/data/raw/callback-tee/callback-465141.bin`，12935887912 字节，SHA256 `32901207ce02476862c38380414f1dbc51e859fba5de4c87d40d5e2ae35c26e8`。省略号共同前缀为 `/home/t00826093/data/megamoe-smallbs/data/e1-e2-next-20261113`；完整路径和 G1 原 tee/DB 见 `evidence/*REPRODUCE_CLOSEOUT.json`。E1 DB 18358124544 字节；G1 tee 1534222336 字节，SHA256 `f08cfcdeafe15f006fabcb994623fa3c5614d38a0f72f396ff6c84d018587881`。原回执未提供的 DB SHA 或大小不得推定；需要完整流验收时另取原件并核对既有可用收据或重新计算，而非把本包的小样本当全量。

`evidence/helper/CPU_REPLAY.json` 是使用构造输入驱动真实 helper 的 CPU 旁证，不是原模型采集；旁边两份 ASM 对应 helper 覆写键和回调入口。
