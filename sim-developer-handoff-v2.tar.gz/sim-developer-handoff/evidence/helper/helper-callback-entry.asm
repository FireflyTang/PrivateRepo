
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/x86_64-linux/simulator/bin/libcannsim_helper.so:     file format elf64-x86-64


Disassembly of section .text:

000000000003aee0 <std::string::assign(std::string const&)@@Base+0x27090>:
   3aee0:	55                   	push   %rbp
   3aee1:	53                   	push   %rbx
   3aee2:	48 89 f5             	mov    %rsi,%rbp
   3aee5:	48 89 fb             	mov    %rdi,%rbx
   3aee8:	be 01 00 00 00       	mov    $0x1,%esi
   3aeed:	48 83 ec 08          	sub    $0x8,%rsp
   3aef1:	f0 48 0f c1 35 de 09 	lock xadd %rsi,0x309de(%rip)        # 6b8d8 <rtKernelLaunch@@Base+0x243c8>
   3aef8:	03 00 
   3aefa:	48 83 c6 01          	add    $0x1,%rsi
   3aefe:	48 83 fe 01          	cmp    $0x1,%rsi
   3af02:	74 27                	je     3af2b <std::string::assign(std::string const&)@@Base+0x270db>
   3af04:	48 89 f2             	mov    %rsi,%rdx
   3af07:	48 b9 43 78 b4 71 c4 	movabs $0xa7c5ac471b47843,%rcx
   3af0e:	5a 7c 0a 
   3af11:	48 c1 ea 05          	shr    $0x5,%rdx
   3af15:	48 89 d0             	mov    %rdx,%rax
   3af18:	48 f7 e1             	mul    %rcx
   3af1b:	48 c1 ea 07          	shr    $0x7,%rdx
   3af1f:	48 69 d2 a0 86 01 00 	imul   $0x186a0,%rdx,%rdx
   3af26:	48 39 d6             	cmp    %rdx,%rsi
   3af29:	75 0e                	jne    3af39 <std::string::assign(std::string const&)@@Base+0x270e9>
   3af2b:	48 8d 3d 43 81 01 00 	lea    0x18143(%rip),%rdi        # 53075 <rtKernelLaunch@@Base+0xbb65>
   3af32:	31 c0                	xor    %eax,%eax
   3af34:	e8 27 a0 fd ff       	call   14f60 <std::string::assign(std::string const&)@@Base+0x1110>
   3af39:	48 83 c4 08          	add    $0x8,%rsp
   3af3d:	48 89 ee             	mov    %rbp,%rsi
   3af40:	48 89 df             	mov    %rbx,%rdi
   3af43:	5b                   	pop    %rbx
   3af44:	5d                   	pop    %rbp
   3af45:	31 d2                	xor    %edx,%edx
   3af47:	e9 74 53 fd ff       	jmp    102c0 <cannsim_helper_start_launch@@Base+0x1390>
   3af4c:	0f 1f 40 00          	nopl   0x0(%rax)
   3af50:	55                   	push   %rbp
   3af51:	53                   	push   %rbx
   3af52:	48 89 f5             	mov    %rsi,%rbp
   3af55:	48 89 fb             	mov    %rdi,%rbx
   3af58:	be 01 00 00 00       	mov    $0x1,%esi
   3af5d:	48 83 ec 08          	sub    $0x8,%rsp
   3af61:	f0 48 0f c1 35 66 09 	lock xadd %rsi,0x30966(%rip)        # 6b8d0 <rtKernelLaunch@@Base+0x243c0>
   3af68:	03 00 
   3af6a:	48 83 c6 01          	add    $0x1,%rsi
   3af6e:	48 83 fe 01          	cmp    $0x1,%rsi
   3af72:	74 27                	je     3af9b <std::string::assign(std::string const&)@@Base+0x2714b>
   3af74:	48 89 f2             	mov    %rsi,%rdx
   3af77:	48 b9 43 78 b4 71 c4 	movabs $0xa7c5ac471b47843,%rcx
   3af7e:	5a 7c 0a 
   3af81:	48 c1 ea 05          	shr    $0x5,%rdx
   3af85:	48 89 d0             	mov    %rdx,%rax
   3af88:	48 f7 e1             	mul    %rcx
   3af8b:	48 c1 ea 07          	shr    $0x7,%rdx
   3af8f:	48 69 d2 a0 86 01 00 	imul   $0x186a0,%rdx,%rdx
   3af96:	48 39 d6             	cmp    %rdx,%rsi
   3af99:	75 0e                	jne    3afa9 <std::string::assign(std::string const&)@@Base+0x27159>
   3af9b:	48 8d 3d fe d6 01 00 	lea    0x1d6fe(%rip),%rdi        # 586a0 <rtKernelLaunch@@Base+0x11190>
   3afa2:	31 c0                	xor    %eax,%eax
   3afa4:	e8 b7 9f fd ff       	call   14f60 <std::string::assign(std::string const&)@@Base+0x1110>
   3afa9:	48 83 c4 08          	add    $0x8,%rsp
   3afad:	48 89 ee             	mov    %rbp,%rsi
   3afb0:	48 89 df             	mov    %rbx,%rdi
   3afb3:	5b                   	pop    %rbx
   3afb4:	5d                   	pop    %rbp
   3afb5:	ba 01 00 00 00       	mov    $0x1,%edx
   3afba:	e9 01 53 fd ff       	jmp    102c0 <cannsim_helper_start_launch@@Base+0x1390>
