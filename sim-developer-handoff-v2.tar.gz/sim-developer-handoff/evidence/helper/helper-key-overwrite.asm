
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/x86_64-linux/simulator/bin/libcannsim_helper.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000025f90 <std::string::assign(std::string const&)@@Base+0x12140>:
   25f90:	41 57                	push   %r15
   25f92:	41 56                	push   %r14
   25f94:	4c 8d 77 08          	lea    0x8(%rdi),%r14
   25f98:	41 55                	push   %r13
   25f9a:	41 54                	push   %r12
   25f9c:	49 89 fd             	mov    %rdi,%r13
   25f9f:	55                   	push   %rbp
   25fa0:	53                   	push   %rbx
   25fa1:	49 89 f4             	mov    %rsi,%r12
   25fa4:	48 83 ec 18          	sub    $0x18,%rsp
   25fa8:	48 83 3d 20 50 04 00 	cmpq   $0x0,0x45020(%rip)        # 6afd0 <rtKernelLaunch@@Base+0x23ac0>
   25faf:	00 
   25fb0:	74 10                	je     25fc2 <std::string::assign(std::string const&)@@Base+0x12172>
   25fb2:	4c 89 f7             	mov    %r14,%rdi
   25fb5:	e8 f6 06 fe ff       	call   66b0 <pthread_mutex_lock@plt>
   25fba:	85 c0                	test   %eax,%eax
   25fbc:	0f 85 e1 08 00 00    	jne    268a3 <std::string::assign(std::string const&)@@Base+0x12a53>
   25fc2:	41 80 bd c0 00 00 00 	cmpb   $0x0,0xc0(%r13)
   25fc9:	00 
   25fca:	74 44                	je     26010 <std::string::assign(std::string const&)@@Base+0x121c0>
   25fcc:	41 80 bd c2 00 00 00 	cmpb   $0x0,0xc2(%r13)
   25fd3:	00 
   25fd4:	41 c6 85 c1 00 00 00 	movb   $0x0,0xc1(%r13)
   25fdb:	00 
   25fdc:	0f 84 ce 01 00 00    	je     261b0 <std::string::assign(std::string const&)@@Base+0x12360>
   25fe2:	48 83 3d e6 4f 04 00 	cmpq   $0x0,0x44fe6(%rip)        # 6afd0 <rtKernelLaunch@@Base+0x23ac0>
   25fe9:	00 
   25fea:	0f 84 85 01 00 00    	je     26175 <std::string::assign(std::string const&)@@Base+0x12325>
   25ff0:	48 83 c4 18          	add    $0x18,%rsp
   25ff4:	4c 89 f7             	mov    %r14,%rdi
   25ff7:	5b                   	pop    %rbx
   25ff8:	5d                   	pop    %rbp
   25ff9:	41 5c                	pop    %r12
   25ffb:	41 5d                	pop    %r13
   25ffd:	41 5e                	pop    %r14
   25fff:	41 5f                	pop    %r15
   26001:	e9 5a 07 fe ff       	jmp    6760 <pthread_mutex_unlock@plt>
   26006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2600d:	00 00 00 
   26010:	41 8b 74 24 30       	mov    0x30(%r12),%esi
   26015:	41 8b 6c 24 2c       	mov    0x2c(%r12),%ebp
   2601a:	48 ba 00 00 00 00 80 	movabs $0x8000000000,%rdx
   26021:	00 00 00 
   26024:	41 8b 4c 24 28       	mov    0x28(%r12),%ecx
   26029:	41 8b 44 24 10       	mov    0x10(%r12),%eax
   2602e:	83 fe 01             	cmp    $0x1,%esi
   26031:	74 1b                	je     2604e <std::string::assign(std::string const&)@@Base+0x121fe>
   26033:	83 fe 02             	cmp    $0x2,%esi
   26036:	48 ba 00 00 00 00 40 	movabs $0x4000000000,%rdx
   2603d:	00 00 00 
   26040:	48 be 00 00 00 00 c0 	movabs $0xc000000000,%rsi
   26047:	00 00 00 
   2604a:	48 0f 44 d6          	cmove  %rsi,%rdx
   2604e:	48 c1 e5 20          	shl    $0x20,%rbp
   26052:	48 be 00 00 00 00 3f 	movabs $0x3f00000000,%rsi
   26059:	00 00 00 
   2605c:	48 c1 e0 28          	shl    $0x28,%rax
   26060:	48 21 f5             	and    %rsi,%rbp
   26063:	48 09 cd             	or     %rcx,%rbp
   26066:	48 b9 00 00 00 00 00 	movabs $0xff0000000000,%rcx
   2606d:	ff 00 00 
   26070:	48 21 c8             	and    %rcx,%rax
   26073:	48 09 c5             	or     %rax,%rbp
   26076:	48 09 d5             	or     %rdx,%rbp
   26079:	41 80 7c 24 40 00    	cmpb   $0x0,0x40(%r12)
   2607f:	0f 85 03 01 00 00    	jne    26188 <std::string::assign(std::string const&)@@Base+0x12338>
   26085:	49 83 85 a8 00 00 00 	addq   $0x1,0xa8(%r13)
   2608c:	01 
   2608d:	4d 8d 7d 68          	lea    0x68(%r13),%r15
   26091:	49 8b 77 08          	mov    0x8(%r15),%rsi
   26095:	31 d2                	xor    %edx,%edx
   26097:	48 89 e8             	mov    %rbp,%rax
   2609a:	48 f7 f6             	div    %rsi
   2609d:	49 8b 07             	mov    (%r15),%rax
   260a0:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
   260a4:	48 89 d7             	mov    %rdx,%rdi
   260a7:	48 85 c0             	test   %rax,%rax
   260aa:	0f 84 20 01 00 00    	je     261d0 <std::string::assign(std::string const&)@@Base+0x12380>
   260b0:	48 8b 18             	mov    (%rax),%rbx
   260b3:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
   260b7:	eb 28                	jmp    260e1 <std::string::assign(std::string const&)@@Base+0x12291>
   260b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   260c0:	48 8b 1b             	mov    (%rbx),%rbx
   260c3:	48 85 db             	test   %rbx,%rbx
   260c6:	0f 84 04 01 00 00    	je     261d0 <std::string::assign(std::string const&)@@Base+0x12380>
   260cc:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
   260d0:	31 d2                	xor    %edx,%edx
   260d2:	48 89 c8             	mov    %rcx,%rax
   260d5:	48 f7 f6             	div    %rsi
   260d8:	48 39 d7             	cmp    %rdx,%rdi
   260db:	0f 85 ef 00 00 00    	jne    261d0 <std::string::assign(std::string const&)@@Base+0x12380>
   260e1:	48 39 cd             	cmp    %rcx,%rbp
   260e4:	75 da                	jne    260c0 <std::string::assign(std::string const&)@@Base+0x12270>
   260e6:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
   260ea:	4c 89 e6             	mov    %r12,%rsi
   260ed:	e8 5e dd fe ff       	call   13e50 <std::string::assign(std::string const&)@@Base>
   260f2:	49 8d 74 24 08       	lea    0x8(%r12),%rsi
   260f7:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
   260fb:	e8 50 dd fe ff       	call   13e50 <std::string::assign(std::string const&)@@Base>
   26100:	41 8b 44 24 10       	mov    0x10(%r12),%eax
   26105:	49 8d 74 24 20       	lea    0x20(%r12),%rsi
   2610a:	48 8d 7b 30          	lea    0x30(%rbx),%rdi
   2610e:	89 43 20             	mov    %eax,0x20(%rbx)
   26111:	49 8b 44 24 18       	mov    0x18(%r12),%rax
   26116:	48 89 43 28          	mov    %rax,0x28(%rbx)
   2611a:	e8 31 dd fe ff       	call   13e50 <std::string::assign(std::string const&)@@Base>
   2611f:	41 8b 44 24 28       	mov    0x28(%r12),%eax
   26124:	49 8d 74 24 48       	lea    0x48(%r12),%rsi
   26129:	48 8d 7b 58          	lea    0x58(%rbx),%rdi
   2612d:	89 43 38             	mov    %eax,0x38(%rbx)
   26130:	41 8b 44 24 2c       	mov    0x2c(%r12),%eax
   26135:	89 43 3c             	mov    %eax,0x3c(%rbx)
   26138:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   2613d:	89 43 40             	mov    %eax,0x40(%rbx)
   26140:	49 8b 44 24 38       	mov    0x38(%r12),%rax
   26145:	48 89 43 48          	mov    %rax,0x48(%rbx)
   26149:	41 0f b6 44 24 40    	movzbl 0x40(%r12),%eax
   2614f:	88 43 50             	mov    %al,0x50(%rbx)
   26152:	e8 f9 dc fe ff       	call   13e50 <std::string::assign(std::string const&)@@Base>
   26157:	41 80 7c 24 40 00    	cmpb   $0x0,0x40(%r12)
   2615d:	74 41                	je     261a0 <std::string::assign(std::string const&)@@Base+0x12350>
   2615f:	49 83 85 b0 00 00 00 	addq   $0x1,0xb0(%r13)
   26166:	01 
   26167:	48 83 3d 61 4e 04 00 	cmpq   $0x0,0x44e61(%rip)        # 6afd0 <rtKernelLaunch@@Base+0x23ac0>
   2616e:	00 
   2616f:	0f 85 7b fe ff ff    	jne    25ff0 <std::string::assign(std::string const&)@@Base+0x121a0>
   26175:	48 83 c4 18          	add    $0x18,%rsp
   26179:	5b                   	pop    %rbx
   2617a:	5d                   	pop    %rbp
   2617b:	41 5c                	pop    %r12
   2617d:	41 5d                	pop    %r13
   2617f:	41 5e                	pop    %r14
   26181:	41 5f                	pop    %r15
   26183:	c3                   	ret
   26184:	0f 1f 40 00          	nopl   0x0(%rax)
   26188:	4d 8d 7d 30          	lea    0x30(%r13),%r15
   2618c:	49 83 85 a0 00 00 00 	addq   $0x1,0xa0(%r13)
   26193:	01 
   26194:	e9 f8 fe ff ff       	jmp    26091 <std::string::assign(std::string const&)@@Base+0x12241>
   26199:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   261a0:	49 83 85 b8 00 00 00 	addq   $0x1,0xb8(%r13)
   261a7:	01 
   261a8:	e9 35 fe ff ff       	jmp    25fe2 <std::string::assign(std::string const&)@@Base+0x12192>
   261ad:	0f 1f 00             	nopl   (%rax)
   261b0:	48 8d 3d 89 1f 03 00 	lea    0x31f89(%rip),%rdi        # 58140 <rtKernelLaunch@@Base+0x10c30>
   261b7:	31 c0                	xor    %eax,%eax
   261b9:	e8 a2 ed fe ff       	call   14f60 <std::string::assign(std::string const&)@@Base+0x1110>
   261be:	41 c6 85 c2 00 00 00 	movb   $0x1,0xc2(%r13)
   261c5:	01 
   261c6:	e9 17 fe ff ff       	jmp    25fe2 <std::string::assign(std::string const&)@@Base+0x12192>
   261cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
