
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013e8fc0 <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base>:
 13e8fc0:	41 55                	push   %r13
 13e8fc2:	41 54                	push   %r12
 13e8fc4:	49 89 d5             	mov    %rdx,%r13
 13e8fc7:	55                   	push   %rbp
 13e8fc8:	53                   	push   %rbx
 13e8fc9:	48 89 fd             	mov    %rdi,%rbp
 13e8fcc:	48 89 f3             	mov    %rsi,%rbx
 13e8fcf:	49 89 cc             	mov    %rcx,%r12
 13e8fd2:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
 13e8fd9:	48 8b 3e             	mov    (%rsi),%rdi
 13e8fdc:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13e8fe3:	00 00 
 13e8fe5:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
 13e8fec:	00 
 13e8fed:	31 c0                	xor    %eax,%eax
 13e8fef:	e8 7c 3f fa fe       	call   38cf70 <Isa::pipe() const@plt>
 13e8ff4:	83 f8 0f             	cmp    $0xf,%eax
 13e8ff7:	0f 84 b3 00 00 00    	je     13e90b0 <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xf0>
 13e8ffd:	83 f8 11             	cmp    $0x11,%eax
 13e9000:	0f 84 aa 00 00 00    	je     13e90b0 <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xf0>
 13e9006:	83 f8 0e             	cmp    $0xe,%eax
 13e9009:	74 65                	je     13e9070 <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb0>
 13e900b:	48 8b 9d d0 00 00 00 	mov    0xd0(%rbp),%rbx
 13e9012:	48 85 db             	test   %rbx,%rbx
 13e9015:	74 33                	je     13e904a <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x8a>
 13e9017:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
 13e901e:	00 
 13e901f:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
 13e9026:	00 
 13e9027:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 13e902e:	00 00 
 13e9030:	8b 6b 28             	mov    0x28(%rbx),%ebp
 13e9033:	44 0f b6 63 78       	movzbl 0x78(%rbx),%r12d
 13e9038:	83 fd 05             	cmp    $0x5,%ebp
 13e903b:	0f 8e 8f 00 00 00    	jle    13e90d0 <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x110>
 13e9041:	45 84 e4             	test   %r12b,%r12b
 13e9044:	0f 85 86 00 00 00    	jne    13e90d0 <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x110>
 13e904a:	48 8b 05 37 2f 79 00 	mov    0x792f37(%rip),%rax        # 1b7bf88 <stdout@GLIBC_2.2.5>
 13e9051:	48 8b 38             	mov    (%rax),%rdi
 13e9054:	e8 27 db fa fe       	call   396b80 <fflush@plt>
 13e9059:	48 8b 05 50 98 79 00 	mov    0x799850(%rip),%rax        # 1b828b0 <stderr@GLIBC_2.2.5>
 13e9060:	48 8b 38             	mov    (%rax),%rdi
 13e9063:	e8 18 db fa fe       	call   396b80 <fflush@plt>
 13e9068:	eb 18                	jmp    13e9082 <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xc2>
 13e906a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13e9070:	41 8b 75 00          	mov    0x0(%r13),%esi
 13e9074:	4c 89 e1             	mov    %r12,%rcx
 13e9077:	48 89 da             	mov    %rbx,%rdx
 13e907a:	48 89 ef             	mov    %rbp,%rdi
 13e907d:	e8 8e 89 f9 fe       	call   381a10 <PemRVecIDU::do_dispatch_pipe_su(unsigned int, std::shared_ptr<Isa>&, bool&)@plt>
 13e9082:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
 13e9089:	00 
 13e908a:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 13e9091:	00 00 
 13e9093:	0f 85 92 00 00 00    	jne    13e912b <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x16b>
 13e9099:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
 13e90a0:	5b                   	pop    %rbx
 13e90a1:	5d                   	pop    %rbp
 13e90a2:	41 5c                	pop    %r12
 13e90a4:	41 5d                	pop    %r13
 13e90a6:	c3                   	ret
 13e90a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 13e90ae:	00 00 
 13e90b0:	48 8b 85 48 01 00 00 	mov    0x148(%rbp),%rax
 13e90b7:	48 89 de             	mov    %rbx,%rsi
 13e90ba:	48 8b b8 00 01 00 00 	mov    0x100(%rax),%rdi
 13e90c1:	e8 7a ce f9 fe       	call   385f40 <TmINIPort<std::shared_ptr<Isa>, (FcType)0>::send(std::shared_ptr<Isa> const&)@plt>
 13e90c6:	41 88 04 24          	mov    %al,(%r12)
 13e90ca:	eb b6                	jmp    13e9082 <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xc2>
 13e90cc:	0f 1f 40 00          	nopl   0x0(%rax)
 13e90d0:	48 8b 73 08          	mov    0x8(%rbx),%rsi
 13e90d4:	4c 8d 6c 24 20       	lea    0x20(%rsp),%r13
 13e90d9:	48 83 ec 08          	sub    $0x8,%rsp
 13e90dd:	4c 8d 05 9a c2 37 00 	lea    0x37c29a(%rip),%r8        # 176537e <_fini@@Base+0xe65a>
 13e90e4:	41 b9 1b 00 00 00    	mov    $0x1b,%r9d
 13e90ea:	b9 05 00 00 00       	mov    $0x5,%ecx
 13e90ef:	4c 89 ef             	mov    %r13,%rdi
 13e90f2:	48 8b 56 e8          	mov    -0x18(%rsi),%rdx
 13e90f6:	ff 74 24 18          	push   0x18(%rsp)
 13e90fa:	ff 74 24 18          	push   0x18(%rsp)
 13e90fe:	ff 74 24 18          	push   0x18(%rsp)
 13e9102:	e8 49 48 fb fe       	call   39d950 <spdlog::details::log_msg::log_msg(spdlog::source_loc, fmt::v11::basic_string_view<char>, spdlog::level::level_enum, fmt::v11::basic_string_view<char>)@plt>
 13e9107:	48 83 c4 20          	add    $0x20,%rsp
 13e910b:	31 c9                	xor    %ecx,%ecx
 13e910d:	45 84 e4             	test   %r12b,%r12b
 13e9110:	0f 95 c1             	setne  %cl
 13e9113:	31 d2                	xor    %edx,%edx
 13e9115:	83 fd 05             	cmp    $0x5,%ebp
 13e9118:	0f 9e c2             	setle  %dl
 13e911b:	4c 89 ee             	mov    %r13,%rsi
 13e911e:	48 89 df             	mov    %rbx,%rdi
 13e9121:	e8 1a d4 fb fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 13e9126:	e9 1f ff ff ff       	jmp    13e904a <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x8a>
 13e912b:	e8 90 c5 fa fe       	call   3956c0 <__stack_chk_fail@plt>
