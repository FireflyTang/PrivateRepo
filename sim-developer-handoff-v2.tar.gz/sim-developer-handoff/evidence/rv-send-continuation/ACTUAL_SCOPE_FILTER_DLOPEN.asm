
/home/t00826093/.cache/npusim/libdlopen_scope_filter.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

00000000000011c0 <dlopen>:
    11c0:	f3 0f 1e fa          	endbr64
    11c4:	41 57                	push   %r15
    11c6:	41 56                	push   %r14
    11c8:	49 89 fe             	mov    %rdi,%r14
    11cb:	41 55                	push   %r13
    11cd:	41 89 f5             	mov    %esi,%r13d
    11d0:	41 54                	push   %r12
    11d2:	55                   	push   %rbp
    11d3:	53                   	push   %rbx
    11d4:	48 83 ec 18          	sub    $0x18,%rsp
    11d8:	48 83 3d 60 2e 00 00 	cmpq   $0x0,0x2e60(%rip)        # 4040 <real_dlopen>
    11df:	00 
    11e0:	0f 84 f0 00 00 00    	je     12d6 <dlopen+0x116>
    11e6:	41 f7 c5 00 01 00 00 	test   $0x100,%r13d
    11ed:	74 05                	je     11f4 <dlopen+0x34>
    11ef:	4d 85 f6             	test   %r14,%r14
    11f2:	75 1a                	jne    120e <dlopen+0x4e>
    11f4:	48 83 c4 18          	add    $0x18,%rsp
    11f8:	44 89 ee             	mov    %r13d,%esi
    11fb:	4c 89 f7             	mov    %r14,%rdi
    11fe:	5b                   	pop    %rbx
    11ff:	5d                   	pop    %rbp
    1200:	41 5c                	pop    %r12
    1202:	41 5d                	pop    %r13
    1204:	41 5e                	pop    %r14
    1206:	41 5f                	pop    %r15
    1208:	ff 25 32 2e 00 00    	jmp    *0x2e32(%rip)        # 4040 <real_dlopen>
    120e:	be 2f 00 00 00       	mov    $0x2f,%esi
    1213:	4c 89 f7             	mov    %r14,%rdi
    1216:	e8 b5 fe ff ff       	call   10d0 <strrchr@plt>
    121b:	48 8d 3d f2 0d 00 00 	lea    0xdf2(%rip),%rdi        # 2014 <_fini+0xccc>
    1222:	4c 8d 78 01          	lea    0x1(%rax),%r15
    1226:	48 85 c0             	test   %rax,%rax
    1229:	4d 0f 44 fe          	cmove  %r14,%r15
    122d:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
    1232:	e8 69 fe ff ff       	call   10a0 <getenv@plt>
    1237:	49 89 c4             	mov    %rax,%r12
    123a:	48 85 c0             	test   %rax,%rax
    123d:	74 07                	je     1246 <dlopen+0x86>
    123f:	0f b6 18             	movzbl (%rax),%ebx
    1242:	84 db                	test   %bl,%bl
    1244:	75 0c                	jne    1252 <dlopen+0x92>
    1246:	bb 6c 00 00 00       	mov    $0x6c,%ebx
    124b:	4c 8d 25 ae 0d 00 00 	lea    0xdae(%rip),%r12        # 2000 <_fini+0xcb8>
    1252:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    1257:	e8 64 fe ff ff       	call   10c0 <strlen@plt>
    125c:	49 89 c7             	mov    %rax,%r15
    125f:	90                   	nop
    1260:	84 db                	test   %bl,%bl
    1262:	74 90                	je     11f4 <dlopen+0x34>
    1264:	4c 89 e5             	mov    %r12,%rbp
    1267:	80 fb 3a             	cmp    $0x3a,%bl
    126a:	75 15                	jne    1281 <dlopen+0xc1>
    126c:	eb 52                	jmp    12c0 <dlopen+0x100>
    126e:	66 90                	xchg   %ax,%ax
    1270:	0f b6 5d 01          	movzbl 0x1(%rbp),%ebx
    1274:	48 83 c5 01          	add    $0x1,%rbp
    1278:	84 db                	test   %bl,%bl
    127a:	74 34                	je     12b0 <dlopen+0xf0>
    127c:	80 fb 3a             	cmp    $0x3a,%bl
    127f:	74 2f                	je     12b0 <dlopen+0xf0>
    1281:	80 fb 2c             	cmp    $0x2c,%bl
    1284:	75 ea                	jne    1270 <dlopen+0xb0>
    1286:	48 89 ea             	mov    %rbp,%rdx
    1289:	4c 29 e2             	sub    %r12,%rdx
    128c:	49 39 d7             	cmp    %rdx,%r15
    128f:	75 40                	jne    12d1 <dlopen+0x111>
    1291:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    1296:	4c 89 e7             	mov    %r12,%rdi
    1299:	e8 12 fe ff ff       	call   10b0 <strncmp@plt>
    129e:	85 c0                	test   %eax,%eax
    12a0:	74 68                	je     130a <dlopen+0x14a>
    12a2:	49 89 ec             	mov    %rbp,%r12
    12a5:	84 db                	test   %bl,%bl
    12a7:	75 1c                	jne    12c5 <dlopen+0x105>
    12a9:	0f b6 5d 00          	movzbl 0x0(%rbp),%ebx
    12ad:	eb b1                	jmp    1260 <dlopen+0xa0>
    12af:	90                   	nop
    12b0:	48 89 ea             	mov    %rbp,%rdx
    12b3:	4c 29 e2             	sub    %r12,%rdx
    12b6:	49 39 d7             	cmp    %rdx,%r15
    12b9:	75 e7                	jne    12a2 <dlopen+0xe2>
    12bb:	eb d4                	jmp    1291 <dlopen+0xd1>
    12bd:	0f 1f 00             	nopl   (%rax)
    12c0:	4d 85 ff             	test   %r15,%r15
    12c3:	74 45                	je     130a <dlopen+0x14a>
    12c5:	41 0f b6 5c 24 01    	movzbl 0x1(%r12),%ebx
    12cb:	49 83 c4 01          	add    $0x1,%r12
    12cf:	eb 8f                	jmp    1260 <dlopen+0xa0>
    12d1:	49 89 ec             	mov    %rbp,%r12
    12d4:	eb ef                	jmp    12c5 <dlopen+0x105>
    12d6:	48 8d 35 30 0d 00 00 	lea    0xd30(%rip),%rsi        # 200d <_fini+0xcc5>
    12dd:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    12e4:	e8 f7 fd ff ff       	call   10e0 <dlsym@plt>
    12e9:	48 89 05 50 2d 00 00 	mov    %rax,0x2d50(%rip)        # 4040 <real_dlopen>
    12f0:	48 85 c0             	test   %rax,%rax
    12f3:	0f 85 ed fe ff ff    	jne    11e6 <dlopen+0x26>
    12f9:	48 83 c4 18          	add    $0x18,%rsp
    12fd:	31 c0                	xor    %eax,%eax
    12ff:	5b                   	pop    %rbx
    1300:	5d                   	pop    %rbp
    1301:	41 5c                	pop    %r12
    1303:	41 5d                	pop    %r13
    1305:	41 5e                	pop    %r14
    1307:	41 5f                	pop    %r15
    1309:	c3                   	ret
    130a:	48 8d 3d 1c 0d 00 00 	lea    0xd1c(%rip),%rdi        # 202d <_fini+0xce5>
    1311:	e8 8a fd ff ff       	call   10a0 <getenv@plt>
    1316:	48 85 c0             	test   %rax,%rax
    1319:	74 20                	je     133b <dlopen+0x17b>
    131b:	48 8b 05 be 2c 00 00 	mov    0x2cbe(%rip),%rax        # 3fe0 <stderr@GLIBC_2.2.5>
    1322:	4c 89 f1             	mov    %r14,%rcx
    1325:	be 02 00 00 00       	mov    $0x2,%esi
    132a:	48 8d 15 17 0d 00 00 	lea    0xd17(%rip),%rdx        # 2048 <_fini+0xd00>
    1331:	48 8b 38             	mov    (%rax),%rdi
    1334:	31 c0                	xor    %eax,%eax
    1336:	e8 b5 fd ff ff       	call   10f0 <__fprintf_chk@plt>
    133b:	41 81 e5 ff fe ff ff 	and    $0xfffffeff,%r13d
    1342:	e9 ad fe ff ff       	jmp    11f4 <dlopen+0x34>

Disassembly of section .fini:
