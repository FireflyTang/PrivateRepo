
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013e1530 <PemRVecIDU::update_new_isa(std::shared_ptr<Isa>, std::shared_ptr<Isa>) const@@Base>:
 13e1530:	53                   	push   %rbx
 13e1531:	48 89 d3             	mov    %rdx,%rbx
 13e1534:	48 83 ec 40          	sub    $0x40,%rsp
 13e1538:	48 8b 36             	mov    (%rsi),%rsi
 13e153b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13e1542:	00 00 
 13e1544:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 13e1549:	31 c0                	xor    %eax,%eax
 13e154b:	48 8b 02             	mov    (%rdx),%rax
 13e154e:	48 89 e7             	mov    %rsp,%rdi
 13e1551:	8b 90 ec 02 00 00    	mov    0x2ec(%rax),%edx
 13e1557:	89 96 ec 02 00 00    	mov    %edx,0x2ec(%rsi)
 13e155d:	8b 90 e8 02 00 00    	mov    0x2e8(%rax),%edx
 13e1563:	8b 80 f0 02 00 00    	mov    0x2f0(%rax),%eax
 13e1569:	89 96 e8 02 00 00    	mov    %edx,0x2e8(%rsi)
 13e156f:	89 86 f0 02 00 00    	mov    %eax,0x2f0(%rsi)
 13e1575:	e8 06 50 fc fe       	call   3a6580 <Isa::get_rvec_isa_para()@plt>
 13e157a:	48 8b 33             	mov    (%rbx),%rsi
 13e157d:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
 13e1582:	e8 f9 4f fc fe       	call   3a6580 <Isa::get_rvec_isa_para()@plt>
 13e1587:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13e158c:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 13e1591:	8b 90 a4 02 00 00    	mov    0x2a4(%rax),%edx
 13e1597:	48 8b 04 24          	mov    (%rsp),%rax
 13e159b:	48 85 ff             	test   %rdi,%rdi
 13e159e:	89 90 a4 02 00 00    	mov    %edx,0x2a4(%rax)
 13e15a4:	74 05                	je     13e15ab <PemRVecIDU::update_new_isa(std::shared_ptr<Isa>, std::shared_ptr<Isa>) const@@Base+0x7b>
 13e15a6:	e8 e5 02 9b ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13e15ab:	48 8b 33             	mov    (%rbx),%rsi
 13e15ae:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
 13e15b3:	e8 c8 4f fc fe       	call   3a6580 <Isa::get_rvec_isa_para()@plt>
 13e15b8:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 13e15bd:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13e15c2:	48 8b 90 90 02 00 00 	mov    0x290(%rax),%rdx
 13e15c9:	48 8b 04 24          	mov    (%rsp),%rax
 13e15cd:	48 85 ff             	test   %rdi,%rdi
 13e15d0:	48 89 90 90 02 00 00 	mov    %rdx,0x290(%rax)
 13e15d7:	74 05                	je     13e15de <PemRVecIDU::update_new_isa(std::shared_ptr<Isa>, std::shared_ptr<Isa>) const@@Base+0xae>
 13e15d9:	e8 b2 02 9b ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13e15de:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 13e15e3:	48 85 ff             	test   %rdi,%rdi
 13e15e6:	74 05                	je     13e15ed <PemRVecIDU::update_new_isa(std::shared_ptr<Isa>, std::shared_ptr<Isa>) const@@Base+0xbd>
 13e15e8:	e8 a3 02 9b ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13e15ed:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 13e15f2:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 13e15f9:	00 00 
 13e15fb:	75 06                	jne    13e1603 <PemRVecIDU::update_new_isa(std::shared_ptr<Isa>, std::shared_ptr<Isa>) const@@Base+0xd3>
 13e15fd:	48                   	rex.W
 13e15fe:	83                   	.byte 0x83
 13e15ff:	c4                   	.byte 0xc4
