
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013e9310 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base>:
 13e9310:	41 57                	push   %r15
 13e9312:	41 56                	push   %r14
 13e9314:	49 89 ff             	mov    %rdi,%r15
 13e9317:	41 55                	push   %r13
 13e9319:	41 54                	push   %r12
 13e931b:	55                   	push   %rbp
 13e931c:	53                   	push   %rbx
 13e931d:	48 89 f5             	mov    %rsi,%rbp
 13e9320:	48 8d 35 03 14 37 00 	lea    0x371403(%rip),%rsi        # 175a72a <_fini@@Base+0x3a06>
 13e9327:	48 81 ec 58 02 00 00 	sub    $0x258,%rsp
 13e932e:	4c 8d 6c 24 60       	lea    0x60(%rsp),%r13
 13e9333:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
 13e9338:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13e933f:	00 00 
 13e9341:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
 13e9348:	00 
 13e9349:	31 c0                	xor    %eax,%eax
 13e934b:	4c 89 ea             	mov    %r13,%rdx
 13e934e:	e8 5d a1 fb fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 13e9353:	48 8b 75 00          	mov    0x0(%rbp),%rsi
 13e9357:	4c 89 ef             	mov    %r13,%rdi
 13e935a:	48 8b 1d 1f 38 79 00 	mov    0x79381f(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13e9361:	e8 1a d2 fb fe       	call   3a6580 <Isa::get_rvec_isa_para()@plt>
 13e9366:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
 13e936b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
 13e9370:	48 85 ff             	test   %rdi,%rdi
 13e9373:	8b 98 a4 02 00 00    	mov    0x2a4(%rax),%ebx
 13e9379:	74 05                	je     13e9380 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x70>
 13e937b:	e8 10 85 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13e9380:	83 fb 10             	cmp    $0x10,%ebx
 13e9383:	0f 84 a7 00 00 00    	je     13e9430 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x120>
 13e9389:	48 8b 15 a0 80 79 00 	mov    0x7980a0(%rip),%rdx        # 1b81430 <RVecIsaDefine::MEMBAR_TYPE_TAB@@Base-0x1b350>
 13e9390:	89 de                	mov    %ebx,%esi
 13e9392:	48 8b 02             	mov    (%rdx),%rax
 13e9395:	48 8b 52 08          	mov    0x8(%rdx),%rdx
 13e9399:	48 29 c2             	sub    %rax,%rdx
 13e939c:	48 c1 fa 03          	sar    $0x3,%rdx
 13e93a0:	48 39 d6             	cmp    %rdx,%rsi
 13e93a3:	0f 83 73 03 00 00    	jae    13e971c <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x40c>
 13e93a9:	48 8b 3c f0          	mov    (%rax,%rsi,8),%rdi
 13e93ad:	48 39 7c 24 30       	cmp    %rdi,0x30(%rsp)
 13e93b2:	74 7c                	je     13e9430 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x120>
 13e93b4:	48 83 ef 18          	sub    $0x18,%rdi
 13e93b8:	48 8b 1d c1 37 79 00 	mov    0x7937c1(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13e93bf:	e8 ac 47 ff ff       	call   13ddb70 <IDU_ARegHazard::reset()@@Base+0x60>
 13e93c4:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 13e93c9:	48 8b 1d b0 37 79 00 	mov    0x7937b0(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13e93d0:	48 8d 79 e8          	lea    -0x18(%rcx),%rdi
 13e93d4:	48 39 df             	cmp    %rbx,%rdi
 13e93d7:	0f 85 2b 03 00 00    	jne    13e9708 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x3f8>
 13e93dd:	4d 8b a7 d0 00 00 00 	mov    0xd0(%r15),%r12
 13e93e4:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 13e93e9:	4d 85 e4             	test   %r12,%r12
 13e93ec:	75 55                	jne    13e9443 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x133>
 13e93ee:	66 90                	xchg   %ax,%ax
 13e93f0:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 13e93f5:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13e93f9:	48 39 df             	cmp    %rbx,%rdi
 13e93fc:	0f 85 ce 02 00 00    	jne    13e96d0 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x3c0>
 13e9402:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
 13e9409:	00 
 13e940a:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 13e9411:	00 00 
 13e9413:	0f 85 18 03 00 00    	jne    13e9731 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x421>
 13e9419:	48 81 c4 58 02 00 00 	add    $0x258,%rsp
 13e9420:	5b                   	pop    %rbx
 13e9421:	5d                   	pop    %rbp
 13e9422:	41 5c                	pop    %r12
 13e9424:	41 5d                	pop    %r13
 13e9426:	41 5e                	pop    %r14
 13e9428:	41 5f                	pop    %r15
 13e942a:	c3                   	ret
 13e942b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 13e9430:	4d 8b a7 d0 00 00 00 	mov    0xd0(%r15),%r12
 13e9437:	48 8b 1d 42 37 79 00 	mov    0x793742(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13e943e:	4d 85 e4             	test   %r12,%r12
 13e9441:	74 ad                	je     13e93f0 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0xe0>
 13e9443:	4c 8b 35 b6 30 79 00 	mov    0x7930b6(%rip),%r14        # 1b7c500 <guard variable for IsaDefine::Instance()::get_instance@@Base-0x1f458>
 13e944a:	41 0f b6 06          	movzbl (%r14),%eax
 13e944e:	84 c0                	test   %al,%al
 13e9450:	0f 84 e2 00 00 00    	je     13e9538 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x228>
 13e9456:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
 13e945a:	e8 11 3b fa fe       	call   38cf70 <Isa::pipe() const@plt>
 13e945f:	48 8b 0d 52 48 79 00 	mov    0x794852(%rip),%rcx        # 1b7dcb8 <IsaDefine::Instance()::get_instance@@Base-0x1dca8>
 13e9466:	48 8b 91 b8 00 00 00 	mov    0xb8(%rcx),%rdx
 13e946d:	48 85 d2             	test   %rdx,%rdx
 13e9470:	0f 84 64 02 00 00    	je     13e96da <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x3ca>
 13e9476:	4c 8d b1 b0 00 00 00 	lea    0xb0(%rcx),%r14
 13e947d:	eb 0d                	jmp    13e948c <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x17c>
 13e947f:	90                   	nop
 13e9480:	49 89 d6             	mov    %rdx,%r14
 13e9483:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 13e9487:	48 85 d2             	test   %rdx,%rdx
 13e948a:	74 0e                	je     13e949a <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x18a>
 13e948c:	3b 42 20             	cmp    0x20(%rdx),%eax
 13e948f:	7e ef                	jle    13e9480 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x170>
 13e9491:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 13e9495:	48 85 d2             	test   %rdx,%rdx
 13e9498:	75 f2                	jne    13e948c <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x17c>
 13e949a:	48 8d 91 b0 00 00 00 	lea    0xb0(%rcx),%rdx
 13e94a1:	49 39 d6             	cmp    %rdx,%r14
 13e94a4:	0f 84 30 02 00 00    	je     13e96da <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x3ca>
 13e94aa:	41 3b 46 20          	cmp    0x20(%r14),%eax
 13e94ae:	0f 8c 26 02 00 00    	jl     13e96da <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x3ca>
 13e94b4:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
 13e94b8:	e8 b3 13 fa fe       	call   38a870 <Isa::pc() const@plt>
 13e94bd:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
 13e94c1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13e94c6:	e8 f5 65 fa fe       	call   38fac0 <Isa::id() const@plt>
 13e94cb:	48 8b 75 00          	mov    0x0(%rbp),%rsi
 13e94cf:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
 13e94d4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 13e94d9:	e8 c2 f1 f9 fe       	call   3886a0 <Isa::name_str() const@plt>
 13e94de:	4c 89 ff             	mov    %r15,%rdi
 13e94e1:	e8 ea 67 fa fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13e94e6:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
 13e94ed:	00 00 
 13e94ef:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
 13e94f6:	00 
 13e94f7:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
 13e94fe:	00 00 
 13e9500:	41 8b 6c 24 28       	mov    0x28(%r12),%ebp
 13e9505:	45 0f b6 7c 24 78    	movzbl 0x78(%r12),%r15d
 13e950b:	83 fd 02             	cmp    $0x2,%ebp
 13e950e:	7e 70                	jle    13e9580 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x270>
 13e9510:	45 84 ff             	test   %r15b,%r15b
 13e9513:	75 6b                	jne    13e9580 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x270>
 13e9515:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 13e951a:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13e951e:	48 39 df             	cmp    %rbx,%rdi
 13e9521:	0f 84 c9 fe ff ff    	je     13e93f0 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0xe0>
 13e9527:	e8 a4 45 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13e952c:	e9 bf fe ff ff       	jmp    13e93f0 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0xe0>
 13e9531:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13e9538:	4c 89 f7             	mov    %r14,%rdi
 13e953b:	e8 80 a4 fb fe       	call   3a39c0 <__cxa_guard_acquire@plt>
 13e9540:	85 c0                	test   %eax,%eax
 13e9542:	0f 84 0e ff ff ff    	je     13e9456 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x146>
 13e9548:	48 8b 3d 69 47 79 00 	mov    0x794769(%rip),%rdi        # 1b7dcb8 <IsaDefine::Instance()::get_instance@@Base-0x1dca8>
 13e954f:	e8 7c 91 fa fe       	call   3926d0 <IsaDefine::IsaDefine()@plt>
 13e9554:	4c 89 f7             	mov    %r14,%rdi
 13e9557:	e8 e4 2a fa fe       	call   38c040 <__cxa_guard_release@plt>
 13e955c:	48 8b 35 55 47 79 00 	mov    0x794755(%rip),%rsi        # 1b7dcb8 <IsaDefine::Instance()::get_instance@@Base-0x1dca8>
 13e9563:	48 8b 3d b6 99 79 00 	mov    0x7999b6(%rip),%rdi        # 1b82f20 <IsaDefine::~IsaDefine()@@Base+0xbf8740>
 13e956a:	48 8d 15 cf 7d 74 00 	lea    0x747dcf(%rip),%rdx        # 1b31340 <typeinfo name for std::bad_array_new_length@@Base+0x27f150>
 13e9571:	e8 8a 7a fa fe       	call   391000 <__cxa_atexit@plt>
 13e9576:	e9 db fe ff ff       	jmp    13e9456 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x146>
 13e957b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 13e9580:	48 8b 15 91 40 79 00 	mov    0x794091(%rip),%rdx        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 13e9587:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
 13e958e:	00 
 13e958f:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
 13e9596:	00 
 13e9597:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 13e959c:	48 c7 84 24 30 01 00 	movq   $0xfa,0x130(%rsp)
 13e95a3:	00 fa 00 00 00 
 13e95a8:	4c 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%r8
 13e95af:	00 
 13e95b0:	48 8d 35 b1 52 39 00 	lea    0x3952b1(%rip),%rsi        # 177e868 <_fini@@Base+0x27b44>
 13e95b7:	45 31 c9             	xor    %r9d,%r9d
 13e95ba:	b9 d4 4d d4 00       	mov    $0xd44dd4,%ecx
 13e95bf:	48 89 94 24 38 01 00 	mov    %rdx,0x138(%rsp)
 13e95c6:	00 
 13e95c7:	48 8d 57 20          	lea    0x20(%rdi),%rdx
 13e95cb:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
 13e95d2:	00 00 00 00 00 
 13e95d7:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
 13e95dc:	48 89 94 24 20 01 00 	mov    %rdx,0x120(%rsp)
 13e95e3:	00 
 13e95e4:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 13e95e8:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
 13e95ef:	00 
 13e95f0:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 13e95f5:	48 89 94 24 d8 00 00 	mov    %rdx,0xd8(%rsp)
 13e95fc:	00 
 13e95fd:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 13e9601:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 13e9608:	00 
 13e9609:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13e960e:	48 89 94 24 e8 00 00 	mov    %rdx,0xe8(%rsp)
 13e9615:	00 
 13e9616:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
 13e961d:	00 
 13e961e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 13e9623:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
 13e962a:	00 
 13e962b:	49 8b 46 28          	mov    0x28(%r14),%rax
 13e962f:	49 89 fe             	mov    %rdi,%r14
 13e9632:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 13e9636:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
 13e963d:	00 
 13e963e:	48 89 94 24 18 01 00 	mov    %rdx,0x118(%rsp)
 13e9645:	00 
 13e9646:	ba 62 00 00 00       	mov    $0x62,%edx
 13e964b:	e8 c0 a6 fb fe       	call   3a3d10 <fmt::v11::detail::vformat_to(fmt::v11::detail::buffer<char>&, fmt::v11::basic_string_view<char>, fmt::v11::basic_format_args<fmt::v11::context>, fmt::v11::detail::locale_ref)@plt>
 13e9650:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
 13e9655:	48 83 ec 08          	sub    $0x8,%rsp
 13e9659:	b9 02 00 00 00       	mov    $0x2,%ecx
 13e965e:	4c 89 ef             	mov    %r13,%rdi
 13e9661:	48 8b 56 e8          	mov    -0x18(%rsi),%rdx
 13e9665:	ff 74 24 58          	push   0x58(%rsp)
 13e9669:	ff 74 24 58          	push   0x58(%rsp)
 13e966d:	ff 74 24 58          	push   0x58(%rsp)
 13e9671:	4c 8b 84 24 40 01 00 	mov    0x140(%rsp),%r8
 13e9678:	00 
 13e9679:	4c 8b 8c 24 48 01 00 	mov    0x148(%rsp),%r9
 13e9680:	00 
 13e9681:	e8 ca 42 fb fe       	call   39d950 <spdlog::details::log_msg::log_msg(spdlog::source_loc, fmt::v11::basic_string_view<char>, spdlog::level::level_enum, fmt::v11::basic_string_view<char>)@plt>
 13e9686:	31 c9                	xor    %ecx,%ecx
 13e9688:	48 83 c4 20          	add    $0x20,%rsp
 13e968c:	45 84 ff             	test   %r15b,%r15b
 13e968f:	0f 95 c1             	setne  %cl
 13e9692:	31 d2                	xor    %edx,%edx
 13e9694:	83 fd 02             	cmp    $0x2,%ebp
 13e9697:	0f 9e c2             	setle  %dl
 13e969a:	4c 89 ee             	mov    %r13,%rsi
 13e969d:	4c 89 e7             	mov    %r12,%rdi
 13e96a0:	e8 9b ce fb fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 13e96a5:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
 13e96ac:	00 
 13e96ad:	4c 89 f0             	mov    %r14,%rax
 13e96b0:	48 83 c0 20          	add    $0x20,%rax
 13e96b4:	48 39 c7             	cmp    %rax,%rdi
 13e96b7:	0f 84 58 fe ff ff    	je     13e9515 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x205>
 13e96bd:	e8 be d8 fa fe       	call   396f80 <free@plt>
 13e96c2:	e9 4e fe ff ff       	jmp    13e9515 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x205>
 13e96c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 13e96ce:	00 00 
 13e96d0:	e8 fb 43 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13e96d5:	e9 28 fd ff ff       	jmp    13e9402 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0xf2>
 13e96da:	48 8d 3d bf d9 36 00 	lea    0x36d9bf(%rip),%rdi        # 17570a0 <_fini@@Base+0x37c>
 13e96e1:	e8 fa 30 fb fe       	call   39c7e0 <std::__throw_out_of_range(char const*)@plt>
 13e96e6:	48 89 c5             	mov    %rax,%rbp
 13e96e9:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 13e96ee:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13e96f2:	48 39 df             	cmp    %rbx,%rdi
 13e96f5:	74 05                	je     13e96fc <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x3ec>
 13e96f7:	e8 d4 43 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13e96fc:	48 89 ef             	mov    %rbp,%rdi
 13e96ff:	e8 7c 96 fb fe       	call   3a2d80 <_Unwind_Resume@plt>
 13e9704:	0f 1f 40 00          	nopl   0x0(%rax)
 13e9708:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13e970d:	e8 be 43 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13e9712:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 13e9717:	e9 c1 fc ff ff       	jmp    13e93dd <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0xcd>
 13e971c:	48 8d 3d d5 61 38 00 	lea    0x3861d5(%rip),%rdi        # 176f8f8 <_fini@@Base+0x18bd4>
 13e9723:	31 c0                	xor    %eax,%eax
 13e9725:	48 8b 1d 54 34 79 00 	mov    0x793454(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13e972c:	e8 9f 77 fa fe       	call   390ed0 <std::__throw_out_of_range_fmt(char const*, ...)@plt>
 13e9731:	e8 8a bf fa fe       	call   3956c0 <__stack_chk_fail@plt>
 13e9736:	48 89 c5             	mov    %rax,%rbp
 13e9739:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 13e973e:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13e9742:	48 39 df             	cmp    %rbx,%rdi
 13e9745:	74 a2                	je     13e96e9 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x3d9>
 13e9747:	e8 84 43 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13e974c:	eb 9b                	jmp    13e96e9 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x3d9>
 13e974e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 13e9753:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
 13e975a:	00 
 13e975b:	48 89 c5             	mov    %rax,%rbp
 13e975e:	49 89 d6             	mov    %rdx,%r14
 13e9761:	48 83 c1 20          	add    $0x20,%rcx
 13e9765:	48 39 cf             	cmp    %rcx,%rdi
 13e9768:	74 05                	je     13e976f <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x45f>
 13e976a:	e8 11 d8 fa fe       	call   396f80 <free@plt>
 13e976f:	49 83 ee 01          	sub    $0x1,%r14
 13e9773:	48 89 ef             	mov    %rbp,%rdi
 13e9776:	75 6b                	jne    13e97e3 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x4d3>
 13e9778:	e8 33 d6 f9 fe       	call   386db0 <__cxa_begin_catch@plt>
 13e977d:	48 8b 10             	mov    (%rax),%rdx
 13e9780:	48 89 c7             	mov    %rax,%rdi
 13e9783:	ff 52 10             	call   *0x10(%rdx)
 13e9786:	48 8d 54 24 2f       	lea    0x2f(%rsp),%rdx
 13e978b:	48 89 c6             	mov    %rax,%rsi
 13e978e:	4c 89 ef             	mov    %r13,%rdi
 13e9791:	e8 1a 9d fb fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 13e9796:	4c 89 ee             	mov    %r13,%rsi
 13e9799:	4c 89 e7             	mov    %r12,%rdi
 13e979c:	e8 7f b9 fa fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 13e97a1:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
 13e97a6:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13e97aa:	48 39 df             	cmp    %rbx,%rdi
 13e97ad:	74 05                	je     13e97b4 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x4a4>
 13e97af:	e8 1c 43 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13e97b4:	e8 a7 68 fb fe       	call   3a0060 <__cxa_end_catch@plt>
 13e97b9:	e9 57 fd ff ff       	jmp    13e9515 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x205>
 13e97be:	48 89 c5             	mov    %rax,%rbp
 13e97c1:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
 13e97c6:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13e97ca:	48 39 df             	cmp    %rbx,%rdi
 13e97cd:	74 05                	je     13e97d4 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x4c4>
 13e97cf:	e8 fc 42 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13e97d4:	e8 87 68 fb fe       	call   3a0060 <__cxa_end_catch@plt>
 13e97d9:	e9 5b ff ff ff       	jmp    13e9739 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x429>
 13e97de:	48 89 c5             	mov    %rax,%rbp
 13e97e1:	eb f1                	jmp    13e97d4 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x4c4>
 13e97e3:	e8 c8 d5 f9 fe       	call   386db0 <__cxa_begin_catch@plt>
 13e97e8:	48 8d 54 24 2f       	lea    0x2f(%rsp),%rdx
 13e97ed:	48 8d 35 fc 5f 38 00 	lea    0x385ffc(%rip),%rsi        # 176f7f0 <_fini@@Base+0x18acc>
 13e97f4:	4c 89 ef             	mov    %r13,%rdi
 13e97f7:	e8 b4 9c fb fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 13e97fc:	4c 89 ee             	mov    %r13,%rsi
 13e97ff:	4c 89 e7             	mov    %r12,%rdi
 13e9802:	e8 19 b9 fa fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 13e9807:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
 13e980c:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13e9810:	48 39 df             	cmp    %rbx,%rdi
 13e9813:	74 05                	je     13e981a <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x50a>
 13e9815:	e8 b6 42 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13e981a:	e8 d1 32 fb fe       	call   39caf0 <__cxa_rethrow@plt>
 13e981f:	48 89 c5             	mov    %rax,%rbp
 13e9822:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
 13e9827:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13e982b:	48 39 df             	cmp    %rbx,%rdi
 13e982e:	74 05                	je     13e9835 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x525>
 13e9830:	e8 9b 42 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13e9835:	e8 26 68 fb fe       	call   3a0060 <__cxa_end_catch@plt>
 13e983a:	e9 fa fe ff ff       	jmp    13e9739 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x429>
 13e983f:	48 89 c5             	mov    %rax,%rbp
 13e9842:	eb f1                	jmp    13e9835 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@@Base+0x525>
 13e9844:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 13e984b:	00 00 00 00 
 13e984f:	90                   	nop
