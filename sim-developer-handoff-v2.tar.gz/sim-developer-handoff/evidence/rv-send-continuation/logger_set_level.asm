
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000e7a570 <pem_log::set_log_level(unsigned int, unsigned int, unsigned int)@@Base>:
  e7a570:	55                   	push   %rbp
  e7a571:	53                   	push   %rbx
  e7a572:	89 f5                	mov    %esi,%ebp
  e7a574:	89 d3                	mov    %edx,%ebx
  e7a576:	48 83 ec 08          	sub    $0x8,%rsp
  e7a57a:	e8 f1 d6 50 ff       	call   387c70 <pem_log::get_log_level(unsigned int)@plt>
  e7a57f:	89 ef                	mov    %ebp,%edi
  e7a581:	89 05 e9 ba d0 00    	mov    %eax,0xd0bae9(%rip)        # 1b86070 <DvcConfig::GlobalConfig::core_ver_@@Base+0x70>
  e7a587:	e8 e4 d6 50 ff       	call   387c70 <pem_log::get_log_level(unsigned int)@plt>
  e7a58c:	89 df                	mov    %ebx,%edi
  e7a58e:	89 05 d8 ba d0 00    	mov    %eax,0xd0bad8(%rip)        # 1b8606c <DvcConfig::GlobalConfig::core_ver_@@Base+0x6c>
  e7a594:	e8 d7 d6 50 ff       	call   387c70 <pem_log::get_log_level(unsigned int)@plt>
  e7a599:	89 05 c9 ba d0 00    	mov    %eax,0xd0bac9(%rip)        # 1b86068 <DvcConfig::GlobalConfig::core_ver_@@Base+0x68>
  e7a59f:	48 83 c4 08          	add    $0x8,%rsp
  e7a5a3:	5b                   	pop    %rbx
  e7a5a4:	5d                   	pop    %rbp
  e7a5a5:	c3                   	ret
