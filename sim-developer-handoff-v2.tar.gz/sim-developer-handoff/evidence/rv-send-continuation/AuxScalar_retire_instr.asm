
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000001435240 <PemRVecAuxScalar::retire_instr()@@Base>:
 1435240:	41 56                	push   %r14
 1435242:	41 55                	push   %r13
 1435244:	41 54                	push   %r12
 1435246:	55                   	push   %rbp
 1435247:	53                   	push   %rbx
 1435248:	48 83 ec 20          	sub    $0x20,%rsp
 143524c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 1435253:	00 00 
 1435255:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 143525a:	31 c0                	xor    %eax,%eax
 143525c:	48 8b 87 b0 00 00 00 	mov    0xb0(%rdi),%rax
 1435263:	48 3b 87 d0 00 00 00 	cmp    0xd0(%rdi),%rax
 143526a:	0f 84 84 00 00 00    	je     14352f4 <PemRVecAuxScalar::retire_instr()@@Base+0xb4>
 1435270:	48 8b 68 08          	mov    0x8(%rax),%rbp
 1435274:	48 89 fb             	mov    %rdi,%rbx
 1435277:	4c 8b 20             	mov    (%rax),%r12
 143527a:	48 85 ed             	test   %rbp,%rbp
 143527d:	74 12                	je     1435291 <PemRVecAuxScalar::retire_instr()@@Base+0x51>
 143527f:	48 83 3d 49 f1 74 00 	cmpq   $0x0,0x74f149(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 1435286:	00 
 1435287:	0f 85 8b 00 00 00    	jne    1435318 <PemRVecAuxScalar::retire_instr()@@Base+0xd8>
 143528d:	83 45 08 01          	addl   $0x1,0x8(%rbp)
 1435291:	49 8b 3c 24          	mov    (%r12),%rdi
 1435295:	e8 06 f6 f4 fe       	call   3848a0 <Isa::name() const@plt>
 143529a:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 143529f:	0f 84 83 00 00 00    	je     1435328 <PemRVecAuxScalar::retire_instr()@@Base+0xe8>
 14352a5:	49 8b 3c 24          	mov    (%r12),%rdi
 14352a9:	e8 f2 f5 f4 fe       	call   3848a0 <Isa::name() const@plt>
 14352ae:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 14352b3:	0f 84 f7 00 00 00    	je     14353b0 <PemRVecAuxScalar::retire_instr()@@Base+0x170>
 14352b9:	41 80 7c 24 20 00    	cmpb   $0x0,0x20(%r12)
 14352bf:	74 7f                	je     1435340 <PemRVecAuxScalar::retire_instr()@@Base+0x100>
 14352c1:	41 80 7c 24 21 00    	cmpb   $0x0,0x21(%r12)
 14352c7:	49 89 e5             	mov    %rsp,%r13
 14352ca:	0f 85 d0 00 00 00    	jne    14353a0 <PemRVecAuxScalar::retire_instr()@@Base+0x160>
 14352d0:	48 8b bb c8 01 00 00 	mov    0x1c8(%rbx),%rdi
 14352d7:	4c 89 ee             	mov    %r13,%rsi
 14352da:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
 14352e1:	00 
 14352e2:	e8 39 1c f6 fe       	call   396f20 <tm_engine::TmEvent::notify_after(unsigned long const&)@plt>
 14352e7:	48 85 ed             	test   %rbp,%rbp
 14352ea:	74 08                	je     14352f4 <PemRVecAuxScalar::retire_instr()@@Base+0xb4>
 14352ec:	48 89 ef             	mov    %rbp,%rdi
 14352ef:	e8 9c c5 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 14352f4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 14352f9:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 1435300:	00 00 
 1435302:	0f 85 b5 01 00 00    	jne    14354bd <PemRVecAuxScalar::retire_instr()@@Base+0x27d>
 1435308:	48 83 c4 20          	add    $0x20,%rsp
 143530c:	5b                   	pop    %rbx
 143530d:	5d                   	pop    %rbp
 143530e:	41 5c                	pop    %r12
 1435310:	41 5d                	pop    %r13
 1435312:	41 5e                	pop    %r14
 1435314:	c3                   	ret
 1435315:	0f 1f 00             	nopl   (%rax)
 1435318:	f0 83 45 08 01       	lock addl $0x1,0x8(%rbp)
 143531d:	e9 6f ff ff ff       	jmp    1435291 <PemRVecAuxScalar::retire_instr()@@Base+0x51>
 1435322:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1435328:	4c 89 e6             	mov    %r12,%rsi
 143532b:	48 89 df             	mov    %rbx,%rdi
 143532e:	e8 bd 66 f5 fe       	call   38b9f0 <PemRVecAuxScalar::exec_membar(std::shared_ptr<Isa> const&) const@plt>
 1435333:	84 c0                	test   %al,%al
 1435335:	75 69                	jne    14353a0 <PemRVecAuxScalar::retire_instr()@@Base+0x160>
 1435337:	49 89 e5             	mov    %rsp,%r13
 143533a:	eb 94                	jmp    14352d0 <PemRVecAuxScalar::retire_instr()@@Base+0x90>
 143533c:	0f 1f 40 00          	nopl   0x0(%rax)
 1435340:	48 89 df             	mov    %rbx,%rdi
 1435343:	4d 8b 74 24 18       	mov    0x18(%r12),%r14
 1435348:	e8 83 a9 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 143534d:	49 39 c6             	cmp    %rax,%r14
 1435350:	49 89 e5             	mov    %rsp,%r13
 1435353:	0f 87 77 ff ff ff    	ja     14352d0 <PemRVecAuxScalar::retire_instr()@@Base+0x90>
 1435359:	4c 89 e6             	mov    %r12,%rsi
 143535c:	48 89 df             	mov    %rbx,%rdi
 143535f:	e8 3c e9 f5 fe       	call   393ca0 <PemRVecAuxScalar::retire_asu_instr(std::shared_ptr<Isa> const&)@plt>
 1435364:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
 143536b:	48 8b 93 b0 00 00 00 	mov    0xb0(%rbx),%rdx
 1435372:	48 83 e8 10          	sub    $0x10,%rax
 1435376:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
 143537a:	48 39 c2             	cmp    %rax,%rdx
 143537d:	0f 84 ea 00 00 00    	je     143546d <PemRVecAuxScalar::retire_instr()@@Base+0x22d>
 1435383:	48 85 ff             	test   %rdi,%rdi
 1435386:	74 05                	je     143538d <PemRVecAuxScalar::retire_instr()@@Base+0x14d>
 1435388:	e8 03 c5 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 143538d:	48 83 83 b0 00 00 00 	addq   $0x10,0xb0(%rbx)
 1435394:	10 
 1435395:	49 89 e5             	mov    %rsp,%r13
 1435398:	e9 33 ff ff ff       	jmp    14352d0 <PemRVecAuxScalar::retire_instr()@@Base+0x90>
 143539d:	0f 1f 00             	nopl   (%rax)
 14353a0:	4c 89 e6             	mov    %r12,%rsi
 14353a3:	48 89 df             	mov    %rbx,%rdi
 14353a6:	e8 05 7e f6 fe       	call   39d1b0 <PemRVecAuxScalar::release_multi_cycle_instr(std::shared_ptr<Isa> const&)@plt>
 14353ab:	eb 8a                	jmp    1435337 <PemRVecAuxScalar::retire_instr()@@Base+0xf7>
 14353ad:	0f 1f 00             	nopl   (%rax)
 14353b0:	4c 8b b3 80 01 00 00 	mov    0x180(%rbx),%r14
 14353b7:	49 89 e5             	mov    %rsp,%r13
 14353ba:	4c 89 e6             	mov    %r12,%rsi
 14353bd:	4c 89 ef             	mov    %r13,%rdi
 14353c0:	e8 1b d1 f6 fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 14353c5:	4c 89 ea             	mov    %r13,%rdx
 14353c8:	31 f6                	xor    %esi,%esi
 14353ca:	4c 89 f7             	mov    %r14,%rdi
 14353cd:	e8 ee a3 f5 fe       	call   38f7c0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@plt>
 14353d2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 14353d7:	48 85 ff             	test   %rdi,%rdi
 14353da:	74 05                	je     14353e1 <PemRVecAuxScalar::retire_instr()@@Base+0x1a1>
 14353dc:	e8 af c4 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 14353e1:	4c 89 e6             	mov    %r12,%rsi
 14353e4:	48 89 df             	mov    %rbx,%rdi
 14353e7:	e8 b4 e8 f5 fe       	call   393ca0 <PemRVecAuxScalar::retire_asu_instr(std::shared_ptr<Isa> const&)@plt>
 14353ec:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
 14353f3:	48 8b 93 b0 00 00 00 	mov    0xb0(%rbx),%rdx
 14353fa:	48 83 e8 10          	sub    $0x10,%rax
 14353fe:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
 1435402:	48 39 c2             	cmp    %rax,%rdx
 1435405:	74 19                	je     1435420 <PemRVecAuxScalar::retire_instr()@@Base+0x1e0>
 1435407:	48 85 ff             	test   %rdi,%rdi
 143540a:	74 05                	je     1435411 <PemRVecAuxScalar::retire_instr()@@Base+0x1d1>
 143540c:	e8 7f c4 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1435411:	48 83 83 b0 00 00 00 	addq   $0x10,0xb0(%rbx)
 1435418:	10 
 1435419:	e9 b2 fe ff ff       	jmp    14352d0 <PemRVecAuxScalar::retire_instr()@@Base+0x90>
 143541e:	66 90                	xchg   %ax,%ax
 1435420:	48 85 ff             	test   %rdi,%rdi
 1435423:	74 05                	je     143542a <PemRVecAuxScalar::retire_instr()@@Base+0x1ea>
 1435425:	e8 66 c4 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 143542a:	48 8b bb b8 00 00 00 	mov    0xb8(%rbx),%rdi
 1435431:	e8 ea cf f5 fe       	call   392420 <operator delete(void*)@plt>
 1435436:	48 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%rax
 143543d:	48 8d 50 08          	lea    0x8(%rax),%rdx
 1435441:	48 8b 40 08          	mov    0x8(%rax),%rax
 1435445:	48 89 93 c8 00 00 00 	mov    %rdx,0xc8(%rbx)
 143544c:	48 8d 90 00 02 00 00 	lea    0x200(%rax),%rdx
 1435453:	48 89 83 b8 00 00 00 	mov    %rax,0xb8(%rbx)
 143545a:	48 89 83 b0 00 00 00 	mov    %rax,0xb0(%rbx)
 1435461:	48 89 93 c0 00 00 00 	mov    %rdx,0xc0(%rbx)
 1435468:	e9 63 fe ff ff       	jmp    14352d0 <PemRVecAuxScalar::retire_instr()@@Base+0x90>
 143546d:	48 85 ff             	test   %rdi,%rdi
 1435470:	74 05                	je     1435477 <PemRVecAuxScalar::retire_instr()@@Base+0x237>
 1435472:	e8 19 c4 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1435477:	48 8b bb b8 00 00 00 	mov    0xb8(%rbx),%rdi
 143547e:	49 89 e5             	mov    %rsp,%r13
 1435481:	e8 9a cf f5 fe       	call   392420 <operator delete(void*)@plt>
 1435486:	48 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%rax
 143548d:	48 8d 50 08          	lea    0x8(%rax),%rdx
 1435491:	48 8b 40 08          	mov    0x8(%rax),%rax
 1435495:	48 89 93 c8 00 00 00 	mov    %rdx,0xc8(%rbx)
 143549c:	48 8d 90 00 02 00 00 	lea    0x200(%rax),%rdx
 14354a3:	48 89 83 b8 00 00 00 	mov    %rax,0xb8(%rbx)
 14354aa:	48 89 83 b0 00 00 00 	mov    %rax,0xb0(%rbx)
 14354b1:	48 89 93 c0 00 00 00 	mov    %rdx,0xc0(%rbx)
 14354b8:	e9 13 fe ff ff       	jmp    14352d0 <PemRVecAuxScalar::retire_instr()@@Base+0x90>
 14354bd:	e8 fe 01 f6 fe       	call   3956c0 <__stack_chk_fail@plt>
 14354c2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 14354c7:	48 89 c3             	mov    %rax,%rbx
 14354ca:	48 85 ff             	test   %rdi,%rdi
 14354cd:	74 05                	je     14354d4 <PemRVecAuxScalar::retire_instr()@@Base+0x294>
 14354cf:	e8 bc c3 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 14354d4:	48 85 ed             	test   %rbp,%rbp
 14354d7:	74 08                	je     14354e1 <PemRVecAuxScalar::retire_instr()@@Base+0x2a1>
 14354d9:	48 89 ef             	mov    %rbp,%rdi
 14354dc:	e8                   	.byte 0xe8
 14354dd:	af                   	scas   (%rdi),%eax
 14354de:	c3                   	ret
 14354df:	95                   	xchg   %eax,%ebp
