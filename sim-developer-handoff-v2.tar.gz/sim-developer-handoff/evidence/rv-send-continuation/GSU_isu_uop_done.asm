
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013c7630 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base>:
 13c7630:	41 56                	push   %r14
 13c7632:	41 55                	push   %r13
 13c7634:	41 54                	push   %r12
 13c7636:	55                   	push   %rbp
 13c7637:	48 89 f5             	mov    %rsi,%rbp
 13c763a:	53                   	push   %rbx
 13c763b:	48 89 fb             	mov    %rdi,%rbx
 13c763e:	48 83 ec 20          	sub    $0x20,%rsp
 13c7642:	4c 8b af 08 01 00 00 	mov    0x108(%rdi),%r13
 13c7649:	49 89 e4             	mov    %rsp,%r12
 13c764c:	4c 89 e7             	mov    %r12,%rdi
 13c764f:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13c7656:	00 00 
 13c7658:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 13c765d:	31 c0                	xor    %eax,%eax
 13c765f:	e8 cc f2 fb fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13c7664:	49 83 bd 48 03 00 00 	cmpq   $0x0,0x348(%r13)
 13c766b:	00 
 13c766c:	0f 84 ba 01 00 00    	je     13c782c <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x1fc>
 13c7672:	49 8d bd 38 03 00 00 	lea    0x338(%r13),%rdi
 13c7679:	4c 89 e6             	mov    %r12,%rsi
 13c767c:	41 ff 95 50 03 00 00 	call   *0x350(%r13)
 13c7683:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 13c7688:	48 85 ff             	test   %rdi,%rdi
 13c768b:	74 05                	je     13c7692 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x62>
 13c768d:	e8 fe a1 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c7692:	4c 8b ab 08 01 00 00 	mov    0x108(%rbx),%r13
 13c7699:	48 89 ee             	mov    %rbp,%rsi
 13c769c:	4c 89 e7             	mov    %r12,%rdi
 13c769f:	e8 8c f2 fb fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13c76a4:	49 83 bd 68 03 00 00 	cmpq   $0x0,0x368(%r13)
 13c76ab:	00 
 13c76ac:	0f 84 a0 01 00 00    	je     13c7852 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x222>
 13c76b2:	49 8d bd 58 03 00 00 	lea    0x358(%r13),%rdi
 13c76b9:	4c 89 e6             	mov    %r12,%rsi
 13c76bc:	41 ff 95 70 03 00 00 	call   *0x370(%r13)
 13c76c3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 13c76c8:	48 85 ff             	test   %rdi,%rdi
 13c76cb:	74 05                	je     13c76d2 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0xa2>
 13c76cd:	e8 be a1 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c76d2:	4c 8b ab 08 01 00 00 	mov    0x108(%rbx),%r13
 13c76d9:	48 89 ee             	mov    %rbp,%rsi
 13c76dc:	4c 89 e7             	mov    %r12,%rdi
 13c76df:	e8 4c f2 fb fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13c76e4:	49 83 bd 88 03 00 00 	cmpq   $0x0,0x388(%r13)
 13c76eb:	00 
 13c76ec:	0f 84 59 01 00 00    	je     13c784b <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x21b>
 13c76f2:	49 8d bd 78 03 00 00 	lea    0x378(%r13),%rdi
 13c76f9:	4c 89 e6             	mov    %r12,%rsi
 13c76fc:	41 ff 95 90 03 00 00 	call   *0x390(%r13)
 13c7703:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 13c7708:	48 85 ff             	test   %rdi,%rdi
 13c770b:	74 05                	je     13c7712 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0xe2>
 13c770d:	e8 7e a1 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c7712:	48 8b 75 00          	mov    0x0(%rbp),%rsi
 13c7716:	48 8b bb e8 00 00 00 	mov    0xe8(%rbx),%rdi
 13c771d:	e8 9e e1 fb fe       	call   3858c0 <PemRvecDepmgr::retire_instr(std::shared_ptr<Isa> const&)@plt>
 13c7722:	48 8b 45 00          	mov    0x0(%rbp),%rax
 13c7726:	48 8b 38             	mov    (%rax),%rdi
 13c7729:	e8 f2 d5 fd fe       	call   3a4d20 <Isa::update_exec_descr()@plt>
 13c772e:	48 8b 45 00          	mov    0x0(%rbp),%rax
 13c7732:	48 8b 38             	mov    (%rax),%rdi
 13c7735:	e8 76 98 fc fe       	call   390fb0 <Isa::update_decode_descr()@plt>
 13c773a:	48 8b 45 00          	mov    0x0(%rbp),%rax
 13c773e:	4c 8b 28             	mov    (%rax),%r13
 13c7741:	4c 89 ef             	mov    %r13,%rdi
 13c7744:	e8 27 31 fc fe       	call   38a870 <Isa::pc() const@plt>
 13c7749:	48 89 df             	mov    %rbx,%rdi
 13c774c:	49 89 c6             	mov    %rax,%r14
 13c774f:	e8 7c 85 fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13c7754:	49 8d 4d 10          	lea    0x10(%r13),%rcx
 13c7758:	48 83 ec 08          	sub    $0x8,%rsp
 13c775c:	8b bb e0 00 00 00    	mov    0xe0(%rbx),%edi
 13c7762:	8b b3 e4 00 00 00    	mov    0xe4(%rbx),%esi
 13c7768:	48 8d 93 20 01 00 00 	lea    0x120(%rbx),%rdx
 13c776f:	4d 8d 4d 08          	lea    0x8(%r13),%r9
 13c7773:	51                   	push   %rcx
 13c7774:	4d 89 f0             	mov    %r14,%r8
 13c7777:	48 89 c1             	mov    %rax,%rcx
 13c777a:	e8 21 e6 fc fe       	call   395da0 <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@plt>
 13c777f:	48 8b 45 00          	mov    0x0(%rbp),%rax
 13c7783:	48 8b bb 30 01 00 00 	mov    0x130(%rbx),%rdi
 13c778a:	48 8b 10             	mov    (%rax),%rdx
 13c778d:	48 8b 40 08          	mov    0x8(%rax),%rax
 13c7791:	48 85 c0             	test   %rax,%rax
 13c7794:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
 13c7799:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 13c779e:	5a                   	pop    %rdx
 13c779f:	59                   	pop    %rcx
 13c77a0:	74 0e                	je     13c77b0 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x180>
 13c77a2:	48 83 3d 26 cc 7b 00 	cmpq   $0x0,0x7bcc26(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 13c77a9:	00 
 13c77aa:	75 74                	jne    13c7820 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x1f0>
 13c77ac:	83 40 08 01          	addl   $0x1,0x8(%rax)
 13c77b0:	4c 89 e6             	mov    %r12,%rsi
 13c77b3:	e8 28 10 fd fe       	call   3987e0 <ExcpUnit::UpdateExcp(std::shared_ptr<Isa>)@plt>
 13c77b8:	84 c0                	test   %al,%al
 13c77ba:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 13c77bf:	74 4f                	je     13c7810 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x1e0>
 13c77c1:	80 bb 84 01 00 00 00 	cmpb   $0x0,0x184(%rbx)
 13c77c8:	74 46                	je     13c7810 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x1e0>
 13c77ca:	48 85 ff             	test   %rdi,%rdi
 13c77cd:	74 05                	je     13c77d4 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x1a4>
 13c77cf:	e8 bc a0 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c77d4:	48 8b 05 ad 47 7b 00 	mov    0x7b47ad(%rip),%rax        # 1b7bf88 <stdout@GLIBC_2.2.5>
 13c77db:	48 8b 38             	mov    (%rax),%rdi
 13c77de:	e8 9d f3 fc fe       	call   396b80 <fflush@plt>
 13c77e3:	48 8b 05 c6 b0 7b 00 	mov    0x7bb0c6(%rip),%rax        # 1b828b0 <stderr@GLIBC_2.2.5>
 13c77ea:	48 8b 38             	mov    (%rax),%rdi
 13c77ed:	e8 8e f3 fc fe       	call   396b80 <fflush@plt>
 13c77f2:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 13c77f7:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 13c77fe:	00 00 
 13c7800:	75 25                	jne    13c7827 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x1f7>
 13c7802:	48 83 c4 20          	add    $0x20,%rsp
 13c7806:	5b                   	pop    %rbx
 13c7807:	5d                   	pop    %rbp
 13c7808:	41 5c                	pop    %r12
 13c780a:	41 5d                	pop    %r13
 13c780c:	41 5e                	pop    %r14
 13c780e:	c3                   	ret
 13c780f:	90                   	nop
 13c7810:	48 85 ff             	test   %rdi,%rdi
 13c7813:	74 dd                	je     13c77f2 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x1c2>
 13c7815:	e8 76 a0 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c781a:	eb d6                	jmp    13c77f2 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x1c2>
 13c781c:	0f 1f 40 00          	nopl   0x0(%rax)
 13c7820:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 13c7825:	eb 89                	jmp    13c77b0 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x180>
 13c7827:	e8 94 de fc fe       	call   3956c0 <__stack_chk_fail@plt>
 13c782c:	e8 5f e8 fb fe       	call   386090 <std::__throw_bad_function_call()@plt>
 13c7831:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 13c7836:	48 89 c3             	mov    %rax,%rbx
 13c7839:	48 85 ff             	test   %rdi,%rdi
 13c783c:	74 05                	je     13c7843 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x213>
 13c783e:	e8 4d a0 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c7843:	48 89 df             	mov    %rbx,%rdi
 13c7846:	e8 35 b5 fd fe       	call   3a2d80 <_Unwind_Resume@plt>
 13c784b:	e8 40 e8 fb fe       	call   386090 <std::__throw_bad_function_call()@plt>
 13c7850:	eb df                	jmp    13c7831 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x201>
 13c7852:	e8 39 e8 fb fe       	call   386090 <std::__throw_bad_function_call()@plt>
 13c7857:	eb d8                	jmp    13c7831 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x201>
 13c7859:	eb d6                	jmp    13c7831 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@@Base+0x201>
 13c785b:	90                   	nop
 13c785c:	0f 1f 40 00          	nopl   0x0(%rax)
