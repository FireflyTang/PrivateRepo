
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

000000000146dc80 <RvecPV::run_ca_read_src_data_from_reg_to_isa(std::shared_ptr<Isa>&)@@Base>:
 146dc80:	41 55                	push   %r13
 146dc82:	41 54                	push   %r12
 146dc84:	55                   	push   %rbp
 146dc85:	53                   	push   %rbx
 146dc86:	48 89 f5             	mov    %rsi,%rbp
 146dc89:	48 89 fb             	mov    %rdi,%rbx
 146dc8c:	48 83 ec 28          	sub    $0x28,%rsp
 146dc90:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 146dc97:	00 00 
 146dc99:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 146dc9e:	31 c0                	xor    %eax,%eax
 146dca0:	e8 cb 3e f2 fe       	call   391b70 <RvecPV::read_regfile(std::shared_ptr<Isa> const&)@plt>
 146dca5:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
 146dca9:	e8 72 70 f3 fe       	call   3a4d20 <Isa::update_exec_descr()@plt>
 146dcae:	4c 8b 65 00          	mov    0x0(%rbp),%r12
 146dcb2:	4c 89 e7             	mov    %r12,%rdi
 146dcb5:	e8 b6 cb f1 fe       	call   38a870 <Isa::pc() const@plt>
 146dcba:	48 89 df             	mov    %rbx,%rdi
 146dcbd:	49 89 c5             	mov    %rax,%r13
 146dcc0:	e8 0b 20 f2 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 146dcc5:	49 8d 4c 24 10       	lea    0x10(%r12),%rcx
 146dcca:	48 83 ec 08          	sub    $0x8,%rsp
 146dcce:	8b b3 94 00 00 00    	mov    0x94(%rbx),%esi
 146dcd4:	8b bb 90 00 00 00    	mov    0x90(%rbx),%edi
 146dcda:	48 8d 93 b8 00 00 00 	lea    0xb8(%rbx),%rdx
 146dce1:	4d 8d 4c 24 08       	lea    0x8(%r12),%r9
 146dce6:	51                   	push   %rcx
 146dce7:	4d 89 e8             	mov    %r13,%r8
 146dcea:	48 89 c1             	mov    %rax,%rcx
 146dced:	e8 ae 35 f3 fe       	call   3a12a0 <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@plt>
 146dcf2:	48 8b 9b 40 01 00 00 	mov    0x140(%rbx),%rbx
 146dcf9:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
 146dcfe:	48 89 ee             	mov    %rbp,%rsi
 146dd01:	4c 89 e7             	mov    %r12,%rdi
 146dd04:	48 8b 03             	mov    (%rbx),%rax
 146dd07:	4c 8b 68 10          	mov    0x10(%rax),%r13
 146dd0b:	e8 d0 47 f3 fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 146dd10:	58                   	pop    %rax
 146dd11:	5a                   	pop    %rdx
 146dd12:	4c 89 e6             	mov    %r12,%rsi
 146dd15:	48 89 df             	mov    %rbx,%rdi
 146dd18:	41 ff d5             	call   *%r13
 146dd1b:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 146dd20:	48 85 ff             	test   %rdi,%rdi
 146dd23:	74 05                	je     146dd2a <RvecPV::run_ca_read_src_data_from_reg_to_isa(std::shared_ptr<Isa>&)@@Base+0xaa>
 146dd25:	e8 66 3b 92 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 146dd2a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 146dd2f:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 146dd36:	00 00 
 146dd38:	75 0b                	jne    146dd45 <RvecPV::run_ca_read_src_data_from_reg_to_isa(std::shared_ptr<Isa>&)@@Base+0xc5>
 146dd3a:	48 83 c4 28          	add    $0x28,%rsp
 146dd3e:	5b                   	pop    %rbx
 146dd3f:	5d                   	pop    %rbp
 146dd40:	41 5c                	pop    %r12
 146dd42:	41 5d                	pop    %r13
 146dd44:	c3                   	ret
 146dd45:	e8 76 79 f2 fe       	call   3956c0 <__stack_chk_fail@plt>
 146dd4a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 146dd4f:	48 89 c3             	mov    %rax,%rbx
 146dd52:	48 85 ff             	test   %rdi,%rdi
 146dd55:	74 05                	je     146dd5c <RvecPV::run_ca_read_src_data_from_reg_to_isa(std::shared_ptr<Isa>&)@@Base+0xdc>
 146dd57:	e8 34 3b 92 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 146dd5c:	48 89 df             	mov    %rbx,%rdi
 146dd5f:	e8 1c 50 f3 fe       	call   3a2d80 <_Unwind_Resume@plt>
 146dd64:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 146dd6b:	00 00 00 00 
 146dd6f:	90                   	nop
