
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

000000000152db20 <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base>:
 152db20:	41 57                	push   %r15
 152db22:	41 56                	push   %r14
 152db24:	41 55                	push   %r13
 152db26:	41 54                	push   %r12
 152db28:	49 89 fc             	mov    %rdi,%r12
 152db2b:	55                   	push   %rbp
 152db2c:	53                   	push   %rbx
 152db2d:	48 89 f5             	mov    %rsi,%rbp
 152db30:	48 83 ec 48          	sub    $0x48,%rsp
 152db34:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 152db3b:	00 00 
 152db3d:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 152db42:	31 c0                	xor    %eax,%eax
 152db44:	48 8b 06             	mov    (%rsi),%rax
 152db47:	48 8b 58 08          	mov    0x8(%rax),%rbx
 152db4b:	4c 8b 28             	mov    (%rax),%r13
 152db4e:	48 85 db             	test   %rbx,%rbx
 152db51:	74 12                	je     152db65 <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x45>
 152db53:	48 83 3d 75 68 65 00 	cmpq   $0x0,0x656875(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 152db5a:	00 
 152db5b:	0f 85 df 00 00 00    	jne    152dc40 <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x120>
 152db61:	83 43 08 01          	addl   $0x1,0x8(%rbx)
 152db65:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 152db6a:	48 89 ea             	mov    %rbp,%rdx
 152db6d:	4c 89 e7             	mov    %r12,%rdi
 152db70:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
 152db77:	00 00 
 152db79:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
 152db80:	00 00 
 152db82:	e8 19 72 e6 fe       	call   394da0 <PemRVecISU::get_iss_ent(std::shared_ptr<RVecISUEntry>&, std::shared_ptr<RVecUop> const&)@plt>
 152db87:	4c 8d 7c 24 18       	lea    0x18(%rsp),%r15
 152db8c:	48 8d 54 24 0f       	lea    0xf(%rsp),%rdx
 152db91:	48 8d 35 0e b3 23 00 	lea    0x23b30e(%rip),%rsi        # 1768ea6 <_fini@@Base+0x12182>
 152db98:	4c 89 ff             	mov    %r15,%rdi
 152db9b:	e8 10 59 e7 fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 152dba0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 152dba5:	4c 8d 74 24 10       	lea    0x10(%rsp),%r14
 152dbaa:	4c 89 f7             	mov    %r14,%rdi
 152dbad:	8b b0 d0 00 00 00    	mov    0xd0(%rax),%esi
 152dbb3:	e8 38 6d e7 fe       	call   3a48f0 <IsuUtil::que_str(IsuQueue)@plt>
 152dbb8:	4c 89 f9             	mov    %r15,%rcx
 152dbbb:	4c 89 f2             	mov    %r14,%rdx
 152dbbe:	48 89 ee             	mov    %rbp,%rsi
 152dbc1:	4c 89 e7             	mov    %r12,%rdi
 152dbc4:	e8 77 dd e5 fe       	call   38b940 <PemRVecISU::isu_log_lite(std::shared_ptr<RVecUop> const&, std::string const&, std::string const&)@plt>
 152dbc9:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 152dbce:	4c 8b 25 ab ef 64 00 	mov    0x64efab(%rip),%r12        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 152dbd5:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 152dbd9:	4c 39 e7             	cmp    %r12,%rdi
 152dbdc:	0f 85 8e 00 00 00    	jne    152dc70 <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x150>
 152dbe2:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 152dbe7:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 152dbeb:	4c 39 e7             	cmp    %r12,%rdi
 152dbee:	75 70                	jne    152dc60 <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x140>
 152dbf0:	4c 89 ef             	mov    %r13,%rdi
 152dbf3:	e8 a8 6c e5 fe       	call   3848a0 <Isa::name() const@plt>
 152dbf8:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 152dbfd:	74 51                	je     152dc50 <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x130>
 152dbff:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 152dc04:	48 85 ff             	test   %rdi,%rdi
 152dc07:	74 05                	je     152dc0e <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0xee>
 152dc09:	e8 82 3c 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152dc0e:	48 85 db             	test   %rbx,%rbx
 152dc11:	74 08                	je     152dc1b <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0xfb>
 152dc13:	48 89 df             	mov    %rbx,%rdi
 152dc16:	e8 75 3c 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152dc1b:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 152dc20:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 152dc27:	00 00 
 152dc29:	75 4f                	jne    152dc7a <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x15a>
 152dc2b:	48 83 c4 48          	add    $0x48,%rsp
 152dc2f:	5b                   	pop    %rbx
 152dc30:	5d                   	pop    %rbp
 152dc31:	41 5c                	pop    %r12
 152dc33:	41 5d                	pop    %r13
 152dc35:	41 5e                	pop    %r14
 152dc37:	41 5f                	pop    %r15
 152dc39:	c3                   	ret
 152dc3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 152dc40:	f0 83 43 08 01       	lock addl $0x1,0x8(%rbx)
 152dc45:	e9 1b ff ff ff       	jmp    152db65 <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x45>
 152dc4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 152dc50:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 152dc55:	48 89 ee             	mov    %rbp,%rsi
 152dc58:	e8 c3 ca e5 fe       	call   38a720 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@plt>
 152dc5d:	eb a0                	jmp    152dbff <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0xdf>
 152dc5f:	90                   	nop
 152dc60:	e8 fb 6e ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 152dc65:	eb 89                	jmp    152dbf0 <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0xd0>
 152dc67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 152dc6e:	00 00 
 152dc70:	e8 eb 6e ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 152dc75:	e9 68 ff ff ff       	jmp    152dbe2 <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0xc2>
 152dc7a:	e8 41 7a e6 fe       	call   3956c0 <__stack_chk_fail@plt>
 152dc7f:	48 89 c5             	mov    %rax,%rbp
 152dc82:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 152dc87:	4c 8b 25 f2 ee 64 00 	mov    0x64eef2(%rip),%r12        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 152dc8e:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 152dc92:	4c 39 e7             	cmp    %r12,%rdi
 152dc95:	74 05                	je     152dc9c <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x17c>
 152dc97:	e8 c4 6e ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 152dc9c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 152dca1:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 152dca5:	4c 39 e7             	cmp    %r12,%rdi
 152dca8:	74 05                	je     152dcaf <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x18f>
 152dcaa:	e8 b1 6e ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 152dcaf:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 152dcb4:	48 85 ff             	test   %rdi,%rdi
 152dcb7:	74 05                	je     152dcbe <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x19e>
 152dcb9:	e8 d2 3b 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152dcbe:	48 85 db             	test   %rbx,%rbx
 152dcc1:	74 08                	je     152dccb <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x1ab>
 152dcc3:	48 89 df             	mov    %rbx,%rdi
 152dcc6:	e8 c5 3b 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152dccb:	48 89 ef             	mov    %rbp,%rdi
 152dcce:	e8 ad 50 e7 fe       	call   3a2d80 <_Unwind_Resume@plt>
 152dcd3:	48 89 c5             	mov    %rax,%rbp
 152dcd6:	4c 8b 25 a3 ee 64 00 	mov    0x64eea3(%rip),%r12        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 152dcdd:	eb bd                	jmp    152dc9c <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x17c>
 152dcdf:	48 89 c5             	mov    %rax,%rbp
 152dce2:	eb cb                	jmp    152dcaf <PemRVecISU::retire_bar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x18f>
 152dce4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 152dceb:	00 00 00 00 
 152dcef:	90                   	nop
