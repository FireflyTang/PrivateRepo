
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

000000000152ae10 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base>:
 152ae10:	41 57                	push   %r15
 152ae12:	41 56                	push   %r14
 152ae14:	41 55                	push   %r13
 152ae16:	41 54                	push   %r12
 152ae18:	49 89 fd             	mov    %rdi,%r13
 152ae1b:	55                   	push   %rbp
 152ae1c:	53                   	push   %rbx
 152ae1d:	48 89 d5             	mov    %rdx,%rbp
 152ae20:	89 f3                	mov    %esi,%ebx
 152ae22:	48 83 ec 48          	sub    $0x48,%rsp
 152ae26:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 152ae2d:	00 00 
 152ae2f:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 152ae34:	31 c0                	xor    %eax,%eax
 152ae36:	48 8b 02             	mov    (%rdx),%rax
 152ae39:	48 8b 38             	mov    (%rax),%rdi
 152ae3c:	e8 5f 9a e5 fe       	call   3848a0 <Isa::name() const@plt>
 152ae41:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 152ae46:	0f 85 f4 00 00 00    	jne    152af40 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x130>
 152ae4c:	49 8b 85 78 03 00 00 	mov    0x378(%r13),%rax
 152ae53:	49 8d 8d 70 03 00 00 	lea    0x370(%r13),%rcx
 152ae5a:	48 89 ca             	mov    %rcx,%rdx
 152ae5d:	48 85 c0             	test   %rax,%rax
 152ae60:	75 3a                	jne    152ae9c <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x8c>
 152ae62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 152ae68:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 152ae6d:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 152ae74:	00 00 
 152ae76:	0f 85 68 04 00 00    	jne    152b2e4 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x4d4>
 152ae7c:	48 83 c4 48          	add    $0x48,%rsp
 152ae80:	5b                   	pop    %rbx
 152ae81:	5d                   	pop    %rbp
 152ae82:	41 5c                	pop    %r12
 152ae84:	41 5d                	pop    %r13
 152ae86:	41 5e                	pop    %r14
 152ae88:	41 5f                	pop    %r15
 152ae8a:	c3                   	ret
 152ae8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 152ae90:	48 89 c2             	mov    %rax,%rdx
 152ae93:	48 8b 40 10          	mov    0x10(%rax),%rax
 152ae97:	48 85 c0             	test   %rax,%rax
 152ae9a:	74 0e                	je     152aeaa <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x9a>
 152ae9c:	39 58 20             	cmp    %ebx,0x20(%rax)
 152ae9f:	7d ef                	jge    152ae90 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x80>
 152aea1:	48 8b 40 18          	mov    0x18(%rax),%rax
 152aea5:	48 85 c0             	test   %rax,%rax
 152aea8:	75 f2                	jne    152ae9c <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x8c>
 152aeaa:	48 39 d1             	cmp    %rdx,%rcx
 152aead:	74 b9                	je     152ae68 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x58>
 152aeaf:	39 5a 20             	cmp    %ebx,0x20(%rdx)
 152aeb2:	7f b4                	jg     152ae68 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x58>
 152aeb4:	48 8b 45 00          	mov    0x0(%rbp),%rax
 152aeb8:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
 152aebd:	4c 89 e7             	mov    %r12,%rdi
 152aec0:	48 8b 30             	mov    (%rax),%rsi
 152aec3:	e8 b8 b6 e7 fe       	call   3a6580 <Isa::get_rvec_isa_para()@plt>
 152aec8:	49 8b 85 d8 03 00 00 	mov    0x3d8(%r13),%rax
 152aecf:	49 8d b5 d0 03 00 00 	lea    0x3d0(%r13),%rsi
 152aed6:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 152aedb:	48 85 c0             	test   %rax,%rax
 152aede:	0f 84 c4 03 00 00    	je     152b2a8 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x498>
 152aee4:	8b 92 a4 02 00 00    	mov    0x2a4(%rdx),%edx
 152aeea:	48 89 f1             	mov    %rsi,%rcx
 152aeed:	eb 0d                	jmp    152aefc <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0xec>
 152aeef:	90                   	nop
 152aef0:	48 89 c1             	mov    %rax,%rcx
 152aef3:	48 8b 40 10          	mov    0x10(%rax),%rax
 152aef7:	48 85 c0             	test   %rax,%rax
 152aefa:	74 0e                	je     152af0a <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0xfa>
 152aefc:	3b 50 20             	cmp    0x20(%rax),%edx
 152aeff:	7e ef                	jle    152aef0 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0xe0>
 152af01:	48 8b 40 18          	mov    0x18(%rax),%rax
 152af05:	48 85 c0             	test   %rax,%rax
 152af08:	75 f2                	jne    152aefc <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0xec>
 152af0a:	48 39 f1             	cmp    %rsi,%rcx
 152af0d:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 152af12:	74 05                	je     152af19 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x109>
 152af14:	3b 51 20             	cmp    0x20(%rcx),%edx
 152af17:	7d 17                	jge    152af30 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x120>
 152af19:	48 85 ff             	test   %rdi,%rdi
 152af1c:	0f 84 46 ff ff ff    	je     152ae68 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x58>
 152af22:	e8 69 69 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152af27:	e9 3c ff ff ff       	jmp    152ae68 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x58>
 152af2c:	0f 1f 40 00          	nopl   0x0(%rax)
 152af30:	48 85 ff             	test   %rdi,%rdi
 152af33:	74 0b                	je     152af40 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x130>
 152af35:	e8 56 69 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152af3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 152af40:	48 8b 45 00          	mov    0x0(%rbp),%rax
 152af44:	48 8b 38             	mov    (%rax),%rdi
 152af47:	e8 54 99 e5 fe       	call   3848a0 <Isa::name() const@plt>
 152af4c:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 152af51:	0f 84 39 01 00 00    	je     152b090 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x280>
 152af57:	4c 8b 65 00          	mov    0x0(%rbp),%r12
 152af5b:	49 83 bc 24 c0 02 00 	cmpq   $0x0,0x2c0(%r12)
 152af62:	00 00 
 152af64:	0f 85 de 02 00 00    	jne    152b248 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x438>
 152af6a:	41 8b 84 24 d0 02 00 	mov    0x2d0(%r12),%eax
 152af71:	00 
 152af72:	49 8b 94 24 c8 02 00 	mov    0x2c8(%r12),%rdx
 152af79:	00 
 152af7a:	49 8d bc 24 c8 02 00 	lea    0x2c8(%r12),%rdi
 152af81:	00 
 152af82:	be 06 00 00 00       	mov    $0x6,%esi
 152af87:	49 89 94 24 d8 02 00 	mov    %rdx,0x2d8(%r12)
 152af8e:	00 
 152af8f:	41 89 84 24 e0 02 00 	mov    %eax,0x2e0(%r12)
 152af96:	00 
 152af97:	31 d2                	xor    %edx,%edx
 152af99:	e8 42 f8 e5 fe       	call   38a7e0 <std::vector<bool, std::allocator<bool> >::resize(unsigned long, bool)@plt>
 152af9e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
 152afa2:	be 06 00 00 00       	mov    $0x6,%esi
 152afa7:	8b 87 f8 02 00 00    	mov    0x2f8(%rdi),%eax
 152afad:	48 8b 97 f0 02 00 00 	mov    0x2f0(%rdi),%rdx
 152afb4:	48 81 c7 f0 02 00 00 	add    $0x2f0,%rdi
 152afbb:	48 89 57 10          	mov    %rdx,0x10(%rdi)
 152afbf:	89 47 18             	mov    %eax,0x18(%rdi)
 152afc2:	31 d2                	xor    %edx,%edx
 152afc4:	e8 17 f8 e5 fe       	call   38a7e0 <std::vector<bool, std::allocator<bool> >::resize(unsigned long, bool)@plt>
 152afc9:	48 8b 45 00          	mov    0x0(%rbp),%rax
 152afcd:	48 8b 38             	mov    (%rax),%rdi
 152afd0:	e8 cb 98 e5 fe       	call   3848a0 <Isa::name() const@plt>
 152afd5:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 152afda:	0f 84 08 01 00 00    	je     152b0e8 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x2d8>
 152afe0:	48 8b 45 00          	mov    0x0(%rbp),%rax
 152afe4:	48 8b 38             	mov    (%rax),%rdi
 152afe7:	e8 b4 98 e5 fe       	call   3848a0 <Isa::name() const@plt>
 152afec:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 152aff1:	0f 85 71 fe ff ff    	jne    152ae68 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x58>
 152aff7:	49 8b 85 a8 03 00 00 	mov    0x3a8(%r13),%rax
 152affe:	49 8d 95 a0 03 00 00 	lea    0x3a0(%r13),%rdx
 152b005:	48 85 c0             	test   %rax,%rax
 152b008:	0f 84 ca 02 00 00    	je     152b2d8 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x4c8>
 152b00e:	49 89 d5             	mov    %rdx,%r13
 152b011:	eb 11                	jmp    152b024 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x214>
 152b013:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 152b018:	49 89 c5             	mov    %rax,%r13
 152b01b:	48 8b 40 10          	mov    0x10(%rax),%rax
 152b01f:	48 85 c0             	test   %rax,%rax
 152b022:	74 0e                	je     152b032 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x222>
 152b024:	39 58 20             	cmp    %ebx,0x20(%rax)
 152b027:	7d ef                	jge    152b018 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x208>
 152b029:	48 8b 40 18          	mov    0x18(%rax),%rax
 152b02d:	48 85 c0             	test   %rax,%rax
 152b030:	75 f2                	jne    152b024 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x214>
 152b032:	49 39 d5             	cmp    %rdx,%r13
 152b035:	0f 84 9d 02 00 00    	je     152b2d8 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x4c8>
 152b03b:	41 39 5d 20          	cmp    %ebx,0x20(%r13)
 152b03f:	0f 8f 93 02 00 00    	jg     152b2d8 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x4c8>
 152b045:	49 8b 5d 40          	mov    0x40(%r13),%rbx
 152b049:	49 83 c5 30          	add    $0x30,%r13
 152b04d:	49 39 dd             	cmp    %rbx,%r13
 152b050:	0f 84 12 fe ff ff    	je     152ae68 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x58>
 152b056:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
 152b05b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 152b060:	8b 43 20             	mov    0x20(%rbx),%eax
 152b063:	4c 89 e6             	mov    %r12,%rsi
 152b066:	89 44 24 20          	mov    %eax,0x20(%rsp)
 152b06a:	48 8b 45 00          	mov    0x0(%rbp),%rax
 152b06e:	48 8d b8 98 02 00 00 	lea    0x298(%rax),%rdi
 152b075:	e8 f6 41 e7 fe       	call   39f270 <std::pair<std::_Rb_tree_iterator<InfFromISU>, bool> std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> >::_M_emplace_unique<InfFromISU&>(InfFromISU&)@plt>
 152b07a:	48 89 df             	mov    %rbx,%rdi
 152b07d:	e8 7e b5 e6 fe       	call   396600 <std::_Rb_tree_increment(std::_Rb_tree_node_base const*)@plt>
 152b082:	49 39 c5             	cmp    %rax,%r13
 152b085:	48 89 c3             	mov    %rax,%rbx
 152b088:	75 d6                	jne    152b060 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x250>
 152b08a:	e9 d9 fd ff ff       	jmp    152ae68 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x58>
 152b08f:	90                   	nop
 152b090:	49 8b 85 a8 03 00 00 	mov    0x3a8(%r13),%rax
 152b097:	49 8d 8d a0 03 00 00 	lea    0x3a0(%r13),%rcx
 152b09e:	48 89 ca             	mov    %rcx,%rdx
 152b0a1:	48 85 c0             	test   %rax,%rax
 152b0a4:	75 16                	jne    152b0bc <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x2ac>
 152b0a6:	e9 bd fd ff ff       	jmp    152ae68 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x58>
 152b0ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 152b0b0:	48 89 c2             	mov    %rax,%rdx
 152b0b3:	48 8b 40 10          	mov    0x10(%rax),%rax
 152b0b7:	48 85 c0             	test   %rax,%rax
 152b0ba:	74 0e                	je     152b0ca <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x2ba>
 152b0bc:	39 58 20             	cmp    %ebx,0x20(%rax)
 152b0bf:	7d ef                	jge    152b0b0 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x2a0>
 152b0c1:	48 8b 40 18          	mov    0x18(%rax),%rax
 152b0c5:	48 85 c0             	test   %rax,%rax
 152b0c8:	75 f2                	jne    152b0bc <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x2ac>
 152b0ca:	48 39 d1             	cmp    %rdx,%rcx
 152b0cd:	0f 84 95 fd ff ff    	je     152ae68 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x58>
 152b0d3:	39 5a 20             	cmp    %ebx,0x20(%rdx)
 152b0d6:	0f 8f 8c fd ff ff    	jg     152ae68 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x58>
 152b0dc:	e9 76 fe ff ff       	jmp    152af57 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x147>
 152b0e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 152b0e8:	48 8b 45 00          	mov    0x0(%rbp),%rax
 152b0ec:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
 152b0f1:	4c 89 e7             	mov    %r12,%rdi
 152b0f4:	48 8b 30             	mov    (%rax),%rsi
 152b0f7:	e8 84 b4 e7 fe       	call   3a6580 <Isa::get_rvec_isa_para()@plt>
 152b0fc:	49 8b 85 78 03 00 00 	mov    0x378(%r13),%rax
 152b103:	49 8d 95 70 03 00 00 	lea    0x370(%r13),%rdx
 152b10a:	48 85 c0             	test   %rax,%rax
 152b10d:	0f 84 83 01 00 00    	je     152b296 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x486>
 152b113:	48 89 d1             	mov    %rdx,%rcx
 152b116:	eb 14                	jmp    152b12c <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x31c>
 152b118:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 152b11f:	00 
 152b120:	48 89 c1             	mov    %rax,%rcx
 152b123:	48 8b 40 10          	mov    0x10(%rax),%rax
 152b127:	48 85 c0             	test   %rax,%rax
 152b12a:	74 0e                	je     152b13a <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x32a>
 152b12c:	39 58 20             	cmp    %ebx,0x20(%rax)
 152b12f:	7d ef                	jge    152b120 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x310>
 152b131:	48 8b 40 18          	mov    0x18(%rax),%rax
 152b135:	48 85 c0             	test   %rax,%rax
 152b138:	75 f2                	jne    152b12c <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x31c>
 152b13a:	48 39 d1             	cmp    %rdx,%rcx
 152b13d:	0f 84 53 01 00 00    	je     152b296 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x486>
 152b143:	39 59 20             	cmp    %ebx,0x20(%rcx)
 152b146:	0f 8f 4a 01 00 00    	jg     152b296 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x486>
 152b14c:	49 8b 85 d8 03 00 00 	mov    0x3d8(%r13),%rax
 152b153:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 152b158:	49 8d b5 d0 03 00 00 	lea    0x3d0(%r13),%rsi
 152b15f:	48 85 c0             	test   %rax,%rax
 152b162:	0f 84 4a 01 00 00    	je     152b2b2 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x4a2>
 152b168:	8b 92 a4 02 00 00    	mov    0x2a4(%rdx),%edx
 152b16e:	49 89 f6             	mov    %rsi,%r14
 152b171:	eb 11                	jmp    152b184 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x374>
 152b173:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 152b178:	49 89 c6             	mov    %rax,%r14
 152b17b:	48 8b 40 10          	mov    0x10(%rax),%rax
 152b17f:	48 85 c0             	test   %rax,%rax
 152b182:	74 0e                	je     152b192 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x382>
 152b184:	39 50 20             	cmp    %edx,0x20(%rax)
 152b187:	7d ef                	jge    152b178 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x368>
 152b189:	48 8b 40 18          	mov    0x18(%rax),%rax
 152b18d:	48 85 c0             	test   %rax,%rax
 152b190:	75 f2                	jne    152b184 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x374>
 152b192:	49 39 f6             	cmp    %rsi,%r14
 152b195:	0f 84 17 01 00 00    	je     152b2b2 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x4a2>
 152b19b:	41 3b 56 20          	cmp    0x20(%r14),%edx
 152b19f:	0f 8c 0d 01 00 00    	jl     152b2b2 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x4a2>
 152b1a5:	4c 8b 61 40          	mov    0x40(%rcx),%r12
 152b1a9:	48 8d 41 30          	lea    0x30(%rcx),%rax
 152b1ad:	48 89 04 24          	mov    %rax,(%rsp)
 152b1b1:	4c 39 e0             	cmp    %r12,%rax
 152b1b4:	74 74                	je     152b22a <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x41a>
 152b1b6:	48 8d 44 24 1c       	lea    0x1c(%rsp),%rax
 152b1bb:	4d 8d 7e 30          	lea    0x30(%r14),%r15
 152b1bf:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 152b1c4:	0f 1f 40 00          	nopl   0x0(%rax)
 152b1c8:	49 8b 46 38          	mov    0x38(%r14),%rax
 152b1cc:	41 8b 54 24 20       	mov    0x20(%r12),%edx
 152b1d1:	48 85 c0             	test   %rax,%rax
 152b1d4:	89 54 24 1c          	mov    %edx,0x1c(%rsp)
 152b1d8:	74 3f                	je     152b219 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x409>
 152b1da:	4c 89 f9             	mov    %r15,%rcx
 152b1dd:	eb 0d                	jmp    152b1ec <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x3dc>
 152b1df:	90                   	nop
 152b1e0:	48 89 c1             	mov    %rax,%rcx
 152b1e3:	48 8b 40 10          	mov    0x10(%rax),%rax
 152b1e7:	48 85 c0             	test   %rax,%rax
 152b1ea:	74 0e                	je     152b1fa <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x3ea>
 152b1ec:	3b 50 20             	cmp    0x20(%rax),%edx
 152b1ef:	7e ef                	jle    152b1e0 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x3d0>
 152b1f1:	48 8b 40 18          	mov    0x18(%rax),%rax
 152b1f5:	48 85 c0             	test   %rax,%rax
 152b1f8:	75 f2                	jne    152b1ec <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x3dc>
 152b1fa:	4c 39 f9             	cmp    %r15,%rcx
 152b1fd:	74 1a                	je     152b219 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x409>
 152b1ff:	3b 51 20             	cmp    0x20(%rcx),%edx
 152b202:	7c 15                	jl     152b219 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x409>
 152b204:	48 8b 45 00          	mov    0x0(%rbp),%rax
 152b208:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 152b20d:	48 8d b8 98 02 00 00 	lea    0x298(%rax),%rdi
 152b214:	e8 57 40 e7 fe       	call   39f270 <std::pair<std::_Rb_tree_iterator<InfFromISU>, bool> std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> >::_M_emplace_unique<InfFromISU&>(InfFromISU&)@plt>
 152b219:	4c 89 e7             	mov    %r12,%rdi
 152b21c:	e8 df b3 e6 fe       	call   396600 <std::_Rb_tree_increment(std::_Rb_tree_node_base const*)@plt>
 152b221:	48 39 04 24          	cmp    %rax,(%rsp)
 152b225:	49 89 c4             	mov    %rax,%r12
 152b228:	75 9e                	jne    152b1c8 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x3b8>
 152b22a:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 152b22f:	48 85 ff             	test   %rdi,%rdi
 152b232:	0f 84 a8 fd ff ff    	je     152afe0 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x1d0>
 152b238:	e8 53 66 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152b23d:	e9 9e fd ff ff       	jmp    152afe0 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x1d0>
 152b242:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 152b248:	49 8b b4 24 a8 02 00 	mov    0x2a8(%r12),%rsi
 152b24f:	00 
 152b250:	49 8d bc 24 98 02 00 	lea    0x298(%r12),%rdi
 152b257:	00 
 152b258:	e8 f3 63 e7 fe       	call   3a1650 <std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> >::_M_erase(std::_Rb_tree_node<InfFromISU>*)@plt>
 152b25d:	49 8d 84 24 a0 02 00 	lea    0x2a0(%r12),%rax
 152b264:	00 
 152b265:	49 c7 84 24 a8 02 00 	movq   $0x0,0x2a8(%r12)
 152b26c:	00 00 00 00 00 
 152b271:	49 c7 84 24 c0 02 00 	movq   $0x0,0x2c0(%r12)
 152b278:	00 00 00 00 00 
 152b27d:	49 89 84 24 b0 02 00 	mov    %rax,0x2b0(%r12)
 152b284:	00 
 152b285:	49 89 84 24 b8 02 00 	mov    %rax,0x2b8(%r12)
 152b28c:	00 
 152b28d:	4c 8b 65 00          	mov    0x0(%rbp),%r12
 152b291:	e9 d4 fc ff ff       	jmp    152af6a <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x15a>
 152b296:	48 8d 3d 03 be 22 00 	lea    0x22be03(%rip),%rdi        # 17570a0 <_fini@@Base+0x37c>
 152b29d:	e8 3e 15 e7 fe       	call   39c7e0 <std::__throw_out_of_range(char const*)@plt>
 152b2a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 152b2a8:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 152b2ad:	e9 67 fc ff ff       	jmp    152af19 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x109>
 152b2b2:	48 8d 3d e7 bd 22 00 	lea    0x22bde7(%rip),%rdi        # 17570a0 <_fini@@Base+0x37c>
 152b2b9:	e8 22 15 e7 fe       	call   39c7e0 <std::__throw_out_of_range(char const*)@plt>
 152b2be:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 152b2c3:	48 89 c3             	mov    %rax,%rbx
 152b2c6:	48 85 ff             	test   %rdi,%rdi
 152b2c9:	74 05                	je     152b2d0 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x4c0>
 152b2cb:	e8 c0 65 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152b2d0:	48 89 df             	mov    %rbx,%rdi
 152b2d3:	e8 a8 7a e7 fe       	call   3a2d80 <_Unwind_Resume@plt>
 152b2d8:	48 8d 3d c1 bd 22 00 	lea    0x22bdc1(%rip),%rdi        # 17570a0 <_fini@@Base+0x37c>
 152b2df:	e8 fc 14 e7 fe       	call   39c7e0 <std::__throw_out_of_range(char const*)@plt>
 152b2e4:	e8 d7 a3 e6 fe       	call   3956c0 <__stack_chk_fail@plt>
 152b2e9:	90                   	nop
 152b2ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
