
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

000000000152dcf0 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base>:
 152dcf0:	41 56                	push   %r14
 152dcf2:	41 55                	push   %r13
 152dcf4:	41 54                	push   %r12
 152dcf6:	55                   	push   %rbp
 152dcf7:	49 89 fc             	mov    %rdi,%r12
 152dcfa:	53                   	push   %rbx
 152dcfb:	48 89 f5             	mov    %rsi,%rbp
 152dcfe:	48 83 ec 40          	sub    $0x40,%rsp
 152dd02:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 152dd09:	00 00 
 152dd0b:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 152dd10:	31 c0                	xor    %eax,%eax
 152dd12:	48 8b 06             	mov    (%rsi),%rax
 152dd15:	48 8b 58 08          	mov    0x8(%rax),%rbx
 152dd19:	48 85 db             	test   %rbx,%rbx
 152dd1c:	74 12                	je     152dd30 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x40>
 152dd1e:	48 83 3d aa 66 65 00 	cmpq   $0x0,0x6566aa(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 152dd25:	00 
 152dd26:	0f 85 d4 00 00 00    	jne    152de00 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x110>
 152dd2c:	83 43 08 01          	addl   $0x1,0x8(%rbx)
 152dd30:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 152dd35:	48 89 ea             	mov    %rbp,%rdx
 152dd38:	4c 89 e7             	mov    %r12,%rdi
 152dd3b:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
 152dd42:	00 00 
 152dd44:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
 152dd4b:	00 00 
 152dd4d:	e8 4e 70 e6 fe       	call   394da0 <PemRVecISU::get_iss_ent(std::shared_ptr<RVecISUEntry>&, std::shared_ptr<RVecUop> const&)@plt>
 152dd52:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 152dd57:	48 89 ee             	mov    %rbp,%rsi
 152dd5a:	e8 91 26 e6 fe       	call   3903f0 <RVecISUEntry::retire_instr(std::shared_ptr<RVecUop> const&)@plt>
 152dd5f:	4c 8d 74 24 18       	lea    0x18(%rsp),%r14
 152dd64:	48 8d 54 24 0f       	lea    0xf(%rsp),%rdx
 152dd69:	48 8d 35 36 b1 23 00 	lea    0x23b136(%rip),%rsi        # 1768ea6 <_fini@@Base+0x12182>
 152dd70:	4c 89 f7             	mov    %r14,%rdi
 152dd73:	e8 38 57 e7 fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 152dd78:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 152dd7d:	4c 8d 6c 24 10       	lea    0x10(%rsp),%r13
 152dd82:	4c 89 ef             	mov    %r13,%rdi
 152dd85:	8b b0 d0 00 00 00    	mov    0xd0(%rax),%esi
 152dd8b:	e8 60 6b e7 fe       	call   3a48f0 <IsuUtil::que_str(IsuQueue)@plt>
 152dd90:	4c 89 f1             	mov    %r14,%rcx
 152dd93:	4c 89 ea             	mov    %r13,%rdx
 152dd96:	48 89 ee             	mov    %rbp,%rsi
 152dd99:	4c 89 e7             	mov    %r12,%rdi
 152dd9c:	e8 9f db e5 fe       	call   38b940 <PemRVecISU::isu_log_lite(std::shared_ptr<RVecUop> const&, std::string const&, std::string const&)@plt>
 152dda1:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 152dda6:	48 8b 2d d3 ed 64 00 	mov    0x64edd3(%rip),%rbp        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 152ddad:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 152ddb1:	48 39 ef             	cmp    %rbp,%rdi
 152ddb4:	75 6a                	jne    152de20 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x130>
 152ddb6:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 152ddbb:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 152ddbf:	48 39 ef             	cmp    %rbp,%rdi
 152ddc2:	75 4c                	jne    152de10 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x120>
 152ddc4:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 152ddc9:	48 85 ff             	test   %rdi,%rdi
 152ddcc:	74 05                	je     152ddd3 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0xe3>
 152ddce:	e8 bd 3a 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152ddd3:	48 85 db             	test   %rbx,%rbx
 152ddd6:	74 08                	je     152dde0 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0xf0>
 152ddd8:	48 89 df             	mov    %rbx,%rdi
 152dddb:	e8 b0 3a 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152dde0:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 152dde5:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 152ddec:	00 00 
 152ddee:	75 37                	jne    152de27 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x137>
 152ddf0:	48 83 c4 40          	add    $0x40,%rsp
 152ddf4:	5b                   	pop    %rbx
 152ddf5:	5d                   	pop    %rbp
 152ddf6:	41 5c                	pop    %r12
 152ddf8:	41 5d                	pop    %r13
 152ddfa:	41 5e                	pop    %r14
 152ddfc:	c3                   	ret
 152ddfd:	0f 1f 00             	nopl   (%rax)
 152de00:	f0 83 43 08 01       	lock addl $0x1,0x8(%rbx)
 152de05:	e9 26 ff ff ff       	jmp    152dd30 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x40>
 152de0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 152de10:	e8 4b 6d ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 152de15:	eb ad                	jmp    152ddc4 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0xd4>
 152de17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 152de1e:	00 00 
 152de20:	e8 3b 6d ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 152de25:	eb 8f                	jmp    152ddb6 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0xc6>
 152de27:	e8 94 78 e6 fe       	call   3956c0 <__stack_chk_fail@plt>
 152de2c:	49 89 c4             	mov    %rax,%r12
 152de2f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 152de34:	48 8b 2d 45 ed 64 00 	mov    0x64ed45(%rip),%rbp        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 152de3b:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 152de3f:	48 39 ef             	cmp    %rbp,%rdi
 152de42:	74 05                	je     152de49 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x159>
 152de44:	e8 17 6d ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 152de49:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 152de4e:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 152de52:	48 39 ef             	cmp    %rbp,%rdi
 152de55:	74 05                	je     152de5c <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x16c>
 152de57:	e8 04 6d ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 152de5c:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 152de61:	48 85 ff             	test   %rdi,%rdi
 152de64:	74 05                	je     152de6b <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x17b>
 152de66:	e8 25 3a 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152de6b:	48 85 db             	test   %rbx,%rbx
 152de6e:	74 08                	je     152de78 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x188>
 152de70:	48 89 df             	mov    %rbx,%rdi
 152de73:	e8 18 3a 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152de78:	4c 89 e7             	mov    %r12,%rdi
 152de7b:	e8 00 4f e7 fe       	call   3a2d80 <_Unwind_Resume@plt>
 152de80:	49 89 c4             	mov    %rax,%r12
 152de83:	48 8b 2d f6 ec 64 00 	mov    0x64ecf6(%rip),%rbp        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 152de8a:	eb bd                	jmp    152de49 <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x159>
 152de8c:	49 89 c4             	mov    %rax,%r12
 152de8f:	eb cb                	jmp    152de5c <PemRVecISU::retire_nonbar_instr(std::shared_ptr<RVecUop> const&)@@Base+0x16c>
 152de91:	90                   	nop
 152de92:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 152de99:	00 00 00 00 
 152de9d:	0f 1f 00             	nopl   (%rax)
