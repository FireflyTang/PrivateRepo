
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013b03f0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base>:
 13b03f0:	41 57                	push   %r15
 13b03f2:	41 56                	push   %r14
 13b03f4:	41 89 f6             	mov    %esi,%r14d
 13b03f7:	41 55                	push   %r13
 13b03f9:	41 54                	push   %r12
 13b03fb:	4c 8d af e0 02 00 00 	lea    0x2e0(%rdi),%r13
 13b0402:	55                   	push   %rbp
 13b0403:	53                   	push   %rbx
 13b0404:	48 89 fb             	mov    %rdi,%rbx
 13b0407:	49 89 d4             	mov    %rdx,%r12
 13b040a:	48 81 ec 38 02 00 00 	sub    $0x238,%rsp
 13b0411:	48 8b 3a             	mov    (%rdx),%rdi
 13b0414:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13b041b:	00 00 
 13b041d:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
 13b0424:	00 
 13b0425:	31 c0                	xor    %eax,%eax
 13b0427:	e8 94 f6 fd fe       	call   38fac0 <Isa::id() const@plt>
 13b042c:	48 8b 93 e8 02 00 00 	mov    0x2e8(%rbx),%rdx
 13b0433:	48 85 d2             	test   %rdx,%rdx
 13b0436:	0f 84 74 01 00 00    	je     13b05b0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x1c0>
 13b043c:	4c 89 e9             	mov    %r13,%rcx
 13b043f:	eb 13                	jmp    13b0454 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x64>
 13b0441:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13b0448:	48 89 d1             	mov    %rdx,%rcx
 13b044b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 13b044f:	48 85 d2             	test   %rdx,%rdx
 13b0452:	74 0f                	je     13b0463 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x73>
 13b0454:	48 3b 42 20          	cmp    0x20(%rdx),%rax
 13b0458:	76 ee                	jbe    13b0448 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x58>
 13b045a:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 13b045e:	48 85 d2             	test   %rdx,%rdx
 13b0461:	75 f1                	jne    13b0454 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x64>
 13b0463:	49 39 cd             	cmp    %rcx,%r13
 13b0466:	0f 84 44 01 00 00    	je     13b05b0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x1c0>
 13b046c:	48 3b 41 20          	cmp    0x20(%rcx),%rax
 13b0470:	0f 82 3a 01 00 00    	jb     13b05b0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x1c0>
 13b0476:	49 8b 3c 24          	mov    (%r12),%rdi
 13b047a:	e8 41 f6 fd fe       	call   38fac0 <Isa::id() const@plt>
 13b047f:	48 8b 93 e8 02 00 00 	mov    0x2e8(%rbx),%rdx
 13b0486:	48 85 d2             	test   %rdx,%rdx
 13b0489:	0f 84 50 04 00 00    	je     13b08df <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x4ef>
 13b048f:	4c 89 e9             	mov    %r13,%rcx
 13b0492:	eb 10                	jmp    13b04a4 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0xb4>
 13b0494:	0f 1f 40 00          	nopl   0x0(%rax)
 13b0498:	48 89 d1             	mov    %rdx,%rcx
 13b049b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 13b049f:	48 85 d2             	test   %rdx,%rdx
 13b04a2:	74 0f                	je     13b04b3 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0xc3>
 13b04a4:	48 3b 42 20          	cmp    0x20(%rdx),%rax
 13b04a8:	76 ee                	jbe    13b0498 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0xa8>
 13b04aa:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 13b04ae:	48 85 d2             	test   %rdx,%rdx
 13b04b1:	75 f1                	jne    13b04a4 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0xb4>
 13b04b3:	49 39 cd             	cmp    %rcx,%r13
 13b04b6:	0f 84 23 04 00 00    	je     13b08df <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x4ef>
 13b04bc:	48 3b 41 20          	cmp    0x20(%rcx),%rax
 13b04c0:	0f 82 19 04 00 00    	jb     13b08df <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x4ef>
 13b04c6:	4c 89 f0             	mov    %r14,%rax
 13b04c9:	48 8b ab 28 01 00 00 	mov    0x128(%rbx),%rbp
 13b04d0:	ba 01 00 00 00       	mov    $0x1,%edx
 13b04d5:	48 c1 e8 03          	shr    $0x3,%rax
 13b04d9:	25 f8 ff ff 1f       	and    $0x1ffffff8,%eax
 13b04de:	48 03 41 28          	add    0x28(%rcx),%rax
 13b04e2:	44 89 f1             	mov    %r14d,%ecx
 13b04e5:	48 d3 e2             	shl    %cl,%rdx
 13b04e8:	48 09 10             	or     %rdx,(%rax)
 13b04eb:	48 85 ed             	test   %rbp,%rbp
 13b04ee:	0f 84 8e 00 00 00    	je     13b0582 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x192>
 13b04f4:	49 8b 3c 24          	mov    (%r12),%rdi
 13b04f8:	e8 c3 f5 fd fe       	call   38fac0 <Isa::id() const@plt>
 13b04fd:	49 8b 34 24          	mov    (%r12),%rsi
 13b0501:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
 13b0506:	49 89 c5             	mov    %rax,%r13
 13b0509:	e8 92 81 fd fe       	call   3886a0 <Isa::name_str() const@plt>
 13b050e:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
 13b0513:	44 89 f6             	mov    %r14d,%esi
 13b0516:	e8 a5 69 fe fe       	call   396ec0 <PemRvecDepmgr::get_tgt_str(SMemBarUnit)@plt>
 13b051b:	48 89 df             	mov    %rbx,%rdi
 13b051e:	e8 ad f7 fd fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13b0523:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
 13b052a:	00 00 
 13b052c:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
 13b0533:	00 
 13b0534:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
 13b053b:	00 00 
 13b053d:	8b 5d 28             	mov    0x28(%rbp),%ebx
 13b0540:	44 0f b6 75 78       	movzbl 0x78(%rbp),%r14d
 13b0545:	83 fb 02             	cmp    $0x2,%ebx
 13b0548:	0f 8e 42 02 00 00    	jle    13b0790 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x3a0>
 13b054e:	45 84 f6             	test   %r14b,%r14b
 13b0551:	0f 85 39 02 00 00    	jne    13b0790 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x3a0>
 13b0557:	48 8b 1d 22 c6 7c 00 	mov    0x7cc622(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13b055e:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 13b0563:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13b0567:	48 39 df             	cmp    %rbx,%rdi
 13b056a:	0f 85 60 03 00 00    	jne    13b08d0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x4e0>
 13b0570:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 13b0575:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13b0579:	48 39 df             	cmp    %rbx,%rdi
 13b057c:	0f 85 3e 03 00 00    	jne    13b08c0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x4d0>
 13b0582:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
 13b0589:	00 
 13b058a:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 13b0591:	00 00 
 13b0593:	0f 85 41 03 00 00    	jne    13b08da <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x4ea>
 13b0599:	48 81 c4 38 02 00 00 	add    $0x238,%rsp
 13b05a0:	5b                   	pop    %rbx
 13b05a1:	5d                   	pop    %rbp
 13b05a2:	41 5c                	pop    %r12
 13b05a4:	41 5d                	pop    %r13
 13b05a6:	41 5e                	pop    %r14
 13b05a8:	41 5f                	pop    %r15
 13b05aa:	c3                   	ret
 13b05ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 13b05b0:	bf 08 00 00 00       	mov    $0x8,%edi
 13b05b5:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
 13b05bc:	00 00 
 13b05be:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
 13b05c5:	00 
 13b05c6:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
 13b05cd:	00 00 
 13b05cf:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
 13b05d6:	00 
 13b05d7:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
 13b05de:	00 00 
 13b05e0:	e8 7b 2c fe fe       	call   393260 <operator new(unsigned long)@plt>
 13b05e5:	49 8b 3c 24          	mov    (%r12),%rdi
 13b05e9:	48 8d 50 08          	lea    0x8(%rax),%rdx
 13b05ed:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
 13b05f4:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 13b05f9:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
 13b0600:	00 
 13b0601:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
 13b0606:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 13b060b:	c7 44 24 48 07 00 00 	movl   $0x7,0x48(%rsp)
 13b0612:	00 
 13b0613:	e8 a8 f4 fd fe       	call   38fac0 <Isa::id() const@plt>
 13b0618:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
 13b061d:	8b 54 24 48          	mov    0x48(%rsp),%edx
 13b0621:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
 13b0626:	48 2b 44 24 30       	sub    0x30(%rsp),%rax
 13b062b:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
 13b0632:	00 00 
 13b0634:	c7 44 24 70 00 00 00 	movl   $0x0,0x70(%rsp)
 13b063b:	00 
 13b063c:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
 13b0643:	00 00 
 13b0645:	c7 84 24 80 00 00 00 	movl   $0x0,0x80(%rsp)
 13b064c:	00 00 00 00 
 13b0650:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
 13b0657:	00 00 00 00 00 
 13b065c:	48 8d 2c c2          	lea    (%rdx,%rax,8),%rbp
 13b0660:	8b 44 24 38          	mov    0x38(%rsp),%eax
 13b0664:	48 29 c5             	sub    %rax,%rbp
 13b0667:	4c 8d 7d 3f          	lea    0x3f(%rbp),%r15
 13b066b:	4c 89 f8             	mov    %r15,%rax
 13b066e:	48 c1 e8 06          	shr    $0x6,%rax
 13b0672:	48 c1 e0 03          	shl    $0x3,%rax
 13b0676:	48 89 c7             	mov    %rax,%rdi
 13b0679:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13b067e:	e8 dd 2b fe fe       	call   393260 <operator new(unsigned long)@plt>
 13b0683:	48 89 c1             	mov    %rax,%rcx
 13b0686:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 13b068b:	c7 44 24 70 00 00 00 	movl   $0x0,0x70(%rsp)
 13b0692:	00 
 13b0693:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
 13b0698:	48 01 c8             	add    %rcx,%rax
 13b069b:	48 85 ed             	test   %rbp,%rbp
 13b069e:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
 13b06a5:	00 
 13b06a6:	48 89 e8             	mov    %rbp,%rax
 13b06a9:	4c 0f 49 fd          	cmovns %rbp,%r15
 13b06ad:	48 c1 f8 3f          	sar    $0x3f,%rax
 13b06b1:	49 c1 ff 06          	sar    $0x6,%r15
 13b06b5:	48 c1 e8 3a          	shr    $0x3a,%rax
 13b06b9:	4a 8d 14 f9          	lea    (%rcx,%r15,8),%rdx
 13b06bd:	48 01 c5             	add    %rax,%rbp
 13b06c0:	83 e5 3f             	and    $0x3f,%ebp
 13b06c3:	48 29 c5             	sub    %rax,%rbp
 13b06c6:	0f 88 e4 01 00 00    	js     13b08b0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x4c0>
 13b06cc:	89 ac 24 80 00 00 00 	mov    %ebp,0x80(%rsp)
 13b06d3:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
 13b06d8:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
 13b06dd:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
 13b06e2:	44 8b 44 24 48       	mov    0x48(%rsp),%r8d
 13b06e7:	49 89 ef             	mov    %rbp,%r15
 13b06ea:	49 29 f7             	sub    %rsi,%r15
 13b06ed:	48 39 f5             	cmp    %rsi,%rbp
 13b06f0:	74 18                	je     13b070a <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x31a>
 13b06f2:	48 89 cf             	mov    %rcx,%rdi
 13b06f5:	4c 89 fa             	mov    %r15,%rdx
 13b06f8:	44 89 44 24 08       	mov    %r8d,0x8(%rsp)
 13b06fd:	e8 5e f7 fe fe       	call   39fe60 <memmove@plt>
 13b0702:	44 8b 44 24 08       	mov    0x8(%rsp),%r8d
 13b0707:	48 89 c1             	mov    %rax,%rcx
 13b070a:	44 89 c7             	mov    %r8d,%edi
 13b070d:	4a 8d 34 39          	lea    (%rcx,%r15,1),%rsi
 13b0711:	48 85 ff             	test   %rdi,%rdi
 13b0714:	74 4b                	je     13b0761 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x371>
 13b0716:	31 c9                	xor    %ecx,%ecx
 13b0718:	41 b9 01 00 00 00    	mov    $0x1,%r9d
 13b071e:	eb 09                	jmp    13b0729 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x339>
 13b0720:	83 c1 01             	add    $0x1,%ecx
 13b0723:	48 83 ef 01          	sub    $0x1,%rdi
 13b0727:	74 38                	je     13b0761 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x371>
 13b0729:	4c 8b 06             	mov    (%rsi),%r8
 13b072c:	4c 89 ca             	mov    %r9,%rdx
 13b072f:	48 d3 e2             	shl    %cl,%rdx
 13b0732:	48 89 d0             	mov    %rdx,%rax
 13b0735:	4d 89 c2             	mov    %r8,%r10
 13b0738:	48 f7 d0             	not    %rax
 13b073b:	49 09 d2             	or     %rdx,%r10
 13b073e:	4c 21 c0             	and    %r8,%rax
 13b0741:	48 85 55 00          	test   %rdx,0x0(%rbp)
 13b0745:	49 0f 45 c2          	cmovne %r10,%rax
 13b0749:	83 f9 3f             	cmp    $0x3f,%ecx
 13b074c:	48 89 06             	mov    %rax,(%rsi)
 13b074f:	75 cf                	jne    13b0720 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x330>
 13b0751:	48 83 c5 08          	add    $0x8,%rbp
 13b0755:	48 83 c6 08          	add    $0x8,%rsi
 13b0759:	31 c9                	xor    %ecx,%ecx
 13b075b:	48 83 ef 01          	sub    $0x1,%rdi
 13b075f:	75 c8                	jne    13b0729 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x339>
 13b0761:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
 13b0766:	48 8d bb d8 02 00 00 	lea    0x2d8(%rbx),%rdi
 13b076d:	4c 89 fe             	mov    %r15,%rsi
 13b0770:	e8 9b 8b fe fe       	call   399310 <std::pair<std::_Rb_tree_iterator<std::pair<unsigned long const, std::vector<bool, std::allocator<bool> > > >, bool> std::_Rb_tree<unsigned long, std::pair<unsigned long const, std::vector<bool, std::allocator<bool> > >, std::_Select1st<std::pair<unsigned long const, std::vector<bool, std::allocator<bool> > > >, std::less<unsigned long>, std::allocator<std::pair<unsigned long const, std::vector<bool, std::allocator<bool> > > > >::_M_insert_unique<std::pair<unsigned long, std::vector<bool, std::allocator<bool> > > >(std::pair<unsigned long, std::vector<bool, std::allocator<bool> > >&&)@plt>
 13b0775:	49 8d 7f 08          	lea    0x8(%r15),%rdi
 13b0779:	e8 e2 f9 fe fe       	call   3a0160 <std::_Bvector_base<std::allocator<bool> >::_M_deallocate()@plt>
 13b077e:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
 13b0783:	e8 d8 f9 fe fe       	call   3a0160 <std::_Bvector_base<std::allocator<bool> >::_M_deallocate()@plt>
 13b0788:	e9 e9 fc ff ff       	jmp    13b0476 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x86>
 13b078d:	0f 1f 00             	nopl   (%rax)
 13b0790:	48 8b 15 81 ce 7c 00 	mov    0x7cce81(%rip),%rdx        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 13b0797:	4c 8d a4 24 00 01 00 	lea    0x100(%rsp),%r12
 13b079e:	00 
 13b079f:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
 13b07a6:	00 
 13b07a7:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 13b07ac:	48 c7 84 24 10 01 00 	movq   $0xfa,0x110(%rsp)
 13b07b3:	00 fa 00 00 00 
 13b07b8:	4c 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%r8
 13b07bf:	00 
 13b07c0:	48 8d 35 51 d7 3c 00 	lea    0x3cd751(%rip),%rsi        # 177df18 <_fini@@Base+0x271f4>
 13b07c7:	45 31 c9             	xor    %r9d,%r9d
 13b07ca:	b9 d4 4d 00 00       	mov    $0x4dd4,%ecx
 13b07cf:	48 89 94 24 18 01 00 	mov    %rdx,0x118(%rsp)
 13b07d6:	00 
 13b07d7:	49 8d 54 24 20       	lea    0x20(%r12),%rdx
 13b07dc:	4c 89 e7             	mov    %r12,%rdi
 13b07df:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
 13b07e6:	00 00 00 00 00 
 13b07eb:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
 13b07f0:	48 89 94 24 00 01 00 	mov    %rdx,0x100(%rsp)
 13b07f7:	00 
 13b07f8:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 13b07fc:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
 13b0803:	00 
 13b0804:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 13b0809:	48 89 94 24 d8 00 00 	mov    %rdx,0xd8(%rsp)
 13b0810:	00 
 13b0811:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 13b0815:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 13b081c:	00 
 13b081d:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
 13b0824:	00 
 13b0825:	48 89 94 24 e8 00 00 	mov    %rdx,0xe8(%rsp)
 13b082c:	00 
 13b082d:	ba 2c 00 00 00       	mov    $0x2c,%edx
 13b0832:	e8 d9 34 ff fe       	call   3a3d10 <fmt::v11::detail::vformat_to(fmt::v11::detail::buffer<char>&, fmt::v11::basic_string_view<char>, fmt::v11::basic_format_args<fmt::v11::context>, fmt::v11::detail::locale_ref)@plt>
 13b0837:	48 8b 75 08          	mov    0x8(%rbp),%rsi
 13b083b:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
 13b0840:	48 83 ec 08          	sub    $0x8,%rsp
 13b0844:	b9 02 00 00 00       	mov    $0x2,%ecx
 13b0849:	4c 89 ff             	mov    %r15,%rdi
 13b084c:	48 8b 56 e8          	mov    -0x18(%rsi),%rdx
 13b0850:	ff 74 24 48          	push   0x48(%rsp)
 13b0854:	ff 74 24 48          	push   0x48(%rsp)
 13b0858:	ff 74 24 48          	push   0x48(%rsp)
 13b085c:	4c 8b 84 24 20 01 00 	mov    0x120(%rsp),%r8
 13b0863:	00 
 13b0864:	4c 8b 8c 24 28 01 00 	mov    0x128(%rsp),%r9
 13b086b:	00 
 13b086c:	e8 df d0 fe fe       	call   39d950 <spdlog::details::log_msg::log_msg(spdlog::source_loc, fmt::v11::basic_string_view<char>, spdlog::level::level_enum, fmt::v11::basic_string_view<char>)@plt>
 13b0871:	31 c9                	xor    %ecx,%ecx
 13b0873:	48 83 c4 20          	add    $0x20,%rsp
 13b0877:	45 84 f6             	test   %r14b,%r14b
 13b087a:	0f 95 c1             	setne  %cl
 13b087d:	31 d2                	xor    %edx,%edx
 13b087f:	83 fb 02             	cmp    $0x2,%ebx
 13b0882:	0f 9e c2             	setle  %dl
 13b0885:	4c 89 fe             	mov    %r15,%rsi
 13b0888:	48 89 ef             	mov    %rbp,%rdi
 13b088b:	e8 b0 5c ff fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 13b0890:	48 8b bc 24 00 01 00 	mov    0x100(%rsp),%rdi
 13b0897:	00 
 13b0898:	49 83 c4 20          	add    $0x20,%r12
 13b089c:	4c 39 e7             	cmp    %r12,%rdi
 13b089f:	0f 84 b2 fc ff ff    	je     13b0557 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x167>
 13b08a5:	e8 d6 66 fe fe       	call   396f80 <free@plt>
 13b08aa:	e9 a8 fc ff ff       	jmp    13b0557 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x167>
 13b08af:	90                   	nop
 13b08b0:	48 83 c5 40          	add    $0x40,%rbp
 13b08b4:	48 83 ea 08          	sub    $0x8,%rdx
 13b08b8:	e9 0f fe ff ff       	jmp    13b06cc <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x2dc>
 13b08bd:	0f 1f 00             	nopl   (%rax)
 13b08c0:	e8 eb 5a ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13b08c5:	e9 b8 fc ff ff       	jmp    13b0582 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x192>
 13b08ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13b08d0:	e8 db 5a ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13b08d5:	e9 96 fc ff ff       	jmp    13b0570 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x180>
 13b08da:	e8 e1 4d fe fe       	call   3956c0 <__stack_chk_fail@plt>
 13b08df:	48 8d 3d ba 67 3a 00 	lea    0x3a67ba(%rip),%rdi        # 17570a0 <_fini@@Base+0x37c>
 13b08e6:	e8 f5 be fe fe       	call   39c7e0 <std::__throw_out_of_range(char const*)@plt>
 13b08eb:	48 8b 1d 8e c2 7c 00 	mov    0x7cc28e(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13b08f2:	48 89 c5             	mov    %rax,%rbp
 13b08f5:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 13b08fa:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13b08fe:	48 39 df             	cmp    %rbx,%rdi
 13b0901:	74 05                	je     13b0908 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x518>
 13b0903:	e8 a8 5a ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13b0908:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 13b090d:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13b0911:	48 39 df             	cmp    %rbx,%rdi
 13b0914:	74 05                	je     13b091b <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x52b>
 13b0916:	e8 95 5a ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13b091b:	48 89 ef             	mov    %rbp,%rdi
 13b091e:	e8 5d 24 ff fe       	call   3a2d80 <_Unwind_Resume@plt>
 13b0923:	49 8d 7f 08          	lea    0x8(%r15),%rdi
 13b0927:	48 89 c3             	mov    %rax,%rbx
 13b092a:	e8 31 f8 fe fe       	call   3a0160 <std::_Bvector_base<std::allocator<bool> >::_M_deallocate()@plt>
 13b092f:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
 13b0934:	e8 27 f8 fe fe       	call   3a0160 <std::_Bvector_base<std::allocator<bool> >::_M_deallocate()@plt>
 13b0939:	48 89 df             	mov    %rbx,%rdi
 13b093c:	e8 3f 24 ff fe       	call   3a2d80 <_Unwind_Resume@plt>
 13b0941:	48 89 c5             	mov    %rax,%rbp
 13b0944:	48 8b 1d 35 c2 7c 00 	mov    0x7cc235(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13b094b:	eb bb                	jmp    13b0908 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x518>
 13b094d:	48 89 c3             	mov    %rax,%rbx
 13b0950:	eb dd                	jmp    13b092f <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x53f>
 13b0952:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
 13b0957:	48 89 c3             	mov    %rax,%rbx
 13b095a:	e8 01 f8 fe fe       	call   3a0160 <std::_Bvector_base<std::allocator<bool> >::_M_deallocate()@plt>
 13b095f:	eb ce                	jmp    13b092f <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x53f>
 13b0961:	eb ea                	jmp    13b094d <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x55d>
 13b0963:	48 8b bc 24 00 01 00 	mov    0x100(%rsp),%rdi
 13b096a:	00 
 13b096b:	49 83 c4 20          	add    $0x20,%r12
 13b096f:	48 89 c3             	mov    %rax,%rbx
 13b0972:	49 89 d5             	mov    %rdx,%r13
 13b0975:	4c 39 e7             	cmp    %r12,%rdi
 13b0978:	74 05                	je     13b097f <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x58f>
 13b097a:	e8 01 66 fe fe       	call   396f80 <free@plt>
 13b097f:	49 83 ed 01          	sub    $0x1,%r13
 13b0983:	48 89 df             	mov    %rbx,%rdi
 13b0986:	0f 85 80 00 00 00    	jne    13b0a0c <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x61c>
 13b098c:	e8 1f 64 fd fe       	call   386db0 <__cxa_begin_catch@plt>
 13b0991:	48 8b 10             	mov    (%rax),%rdx
 13b0994:	48 89 c7             	mov    %rax,%rdi
 13b0997:	ff 52 10             	call   *0x10(%rdx)
 13b099a:	48 8d 54 24 1f       	lea    0x1f(%rsp),%rdx
 13b099f:	48 89 c6             	mov    %rax,%rsi
 13b09a2:	4c 89 ff             	mov    %r15,%rdi
 13b09a5:	e8 06 2b ff fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 13b09aa:	4c 89 fe             	mov    %r15,%rsi
 13b09ad:	48 89 ef             	mov    %rbp,%rdi
 13b09b0:	e8 6b 47 fe fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 13b09b5:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
 13b09ba:	48 8b 1d bf c1 7c 00 	mov    0x7cc1bf(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13b09c1:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13b09c5:	48 39 df             	cmp    %rbx,%rdi
 13b09c8:	74 05                	je     13b09cf <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x5df>
 13b09ca:	e8 e1 59 ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13b09cf:	e8 8c f6 fe fe       	call   3a0060 <__cxa_end_catch@plt>
 13b09d4:	e9 85 fb ff ff       	jmp    13b055e <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x16e>
 13b09d9:	48 89 c5             	mov    %rax,%rbp
 13b09dc:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
 13b09e1:	48 8b 1d 98 c1 7c 00 	mov    0x7cc198(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13b09e8:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13b09ec:	48 39 df             	cmp    %rbx,%rdi
 13b09ef:	74 05                	je     13b09f6 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x606>
 13b09f1:	e8 ba 59 ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13b09f6:	e8 65 f6 fe fe       	call   3a0060 <__cxa_end_catch@plt>
 13b09fb:	e9 f5 fe ff ff       	jmp    13b08f5 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x505>
 13b0a00:	48 89 c5             	mov    %rax,%rbp
 13b0a03:	48 8b 1d 76 c1 7c 00 	mov    0x7cc176(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13b0a0a:	eb ea                	jmp    13b09f6 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x606>
 13b0a0c:	e8 9f 63 fd fe       	call   386db0 <__cxa_begin_catch@plt>
 13b0a11:	48 8d 54 24 1f       	lea    0x1f(%rsp),%rdx
 13b0a16:	48 8d 35 d3 ed 3b 00 	lea    0x3bedd3(%rip),%rsi        # 176f7f0 <_fini@@Base+0x18acc>
 13b0a1d:	4c 89 ff             	mov    %r15,%rdi
 13b0a20:	48 8b 1d 59 c1 7c 00 	mov    0x7cc159(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13b0a27:	e8 84 2a ff fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 13b0a2c:	4c 89 fe             	mov    %r15,%rsi
 13b0a2f:	48 89 ef             	mov    %rbp,%rdi
 13b0a32:	e8 e9 46 fe fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 13b0a37:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
 13b0a3c:	48 8b 1d 3d c1 7c 00 	mov    0x7cc13d(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13b0a43:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13b0a47:	48 39 df             	cmp    %rbx,%rdi
 13b0a4a:	74 05                	je     13b0a51 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x661>
 13b0a4c:	e8 5f 59 ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13b0a51:	e8 9a c0 fe fe       	call   39caf0 <__cxa_rethrow@plt>
 13b0a56:	48 89 c5             	mov    %rax,%rbp
 13b0a59:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
 13b0a5e:	48 8b 1d 1b c1 7c 00 	mov    0x7cc11b(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13b0a65:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13b0a69:	48 39 df             	cmp    %rbx,%rdi
 13b0a6c:	74 05                	je     13b0a73 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x683>
 13b0a6e:	e8 3d 59 ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13b0a73:	e8 e8 f5 fe fe       	call   3a0060 <__cxa_end_catch@plt>
 13b0a78:	e9 78 fe ff ff       	jmp    13b08f5 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x505>
 13b0a7d:	48 89 c5             	mov    %rax,%rbp
 13b0a80:	eb f1                	jmp    13b0a73 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@@Base+0x683>
 13b0a82:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 13b0a89:	00 00 00 00 
 13b0a8d:	0f 1f 00             	nopl   (%rax)
