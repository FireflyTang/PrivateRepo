
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000001531480 <RVecIsuIntf::init()@@Base>:
 1531480:	41 57                	push   %r15
 1531482:	41 56                	push   %r14
 1531484:	4c 8d bf 98 03 00 00 	lea    0x398(%rdi),%r15
 153148b:	41 55                	push   %r13
 153148d:	41 54                	push   %r12
 153148f:	48 8d 15 37 7a 23 00 	lea    0x237a37(%rip),%rdx        # 1768ecd <_fini@@Base+0x121a9>
 1531496:	55                   	push   %rbp
 1531497:	53                   	push   %rbx
 1531498:	4c 8d af b0 03 00 00 	lea    0x3b0(%rdi),%r13
 153149f:	4c 89 fe             	mov    %r15,%rsi
 15314a2:	48 89 fb             	mov    %rdi,%rbx
 15314a5:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
 15314ac:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 15314b3:	00 00 
 15314b5:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
 15314bc:	00 
 15314bd:	31 c0                	xor    %eax,%eax
 15314bf:	48 8b 87 a0 03 00 00 	mov    0x3a0(%rdi),%rax
 15314c6:	48 8d ac 24 b8 00 00 	lea    0xb8(%rsp),%rbp
 15314cd:	00 
 15314ce:	4c 8d b4 24 b4 00 00 	lea    0xb4(%rsp),%r14
 15314d5:	00 
 15314d6:	48 89 ef             	mov    %rbp,%rdi
 15314d9:	44 8b a0 c4 00 00 00 	mov    0xc4(%rax),%r12d
 15314e0:	e8 cb cf e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 15314e5:	4c 8d 4c 24 24       	lea    0x24(%rsp),%r9
 15314ea:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
 15314ef:	4c 89 e9             	mov    %r13,%rcx
 15314f2:	41 c1 e4 02          	shl    $0x2,%r12d
 15314f6:	48 89 ea             	mov    %rbp,%rdx
 15314f9:	4c 89 f6             	mov    %r14,%rsi
 15314fc:	44 89 64 24 20       	mov    %r12d,0x20(%rsp)
 1531501:	4c 8d a4 24 c0 00 00 	lea    0xc0(%rsp),%r12
 1531508:	00 
 1531509:	c7 44 24 24 01 00 00 	movl   $0x1,0x24(%rsp)
 1531510:	00 
 1531511:	4c 89 e7             	mov    %r12,%rdi
 1531514:	e8 17 fe ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531519:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
 153151d:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531521:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531528:	00 00 
 153152a:	48 85 ff             	test   %rdi,%rdi
 153152d:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531534:	00 
 1531535:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
 1531539:	74 17                	je     1531552 <RVecIsuIntf::init()@@Base+0xd2>
 153153b:	e8 50 03 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531540:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531547:	00 
 1531548:	48 85 ff             	test   %rdi,%rdi
 153154b:	74 05                	je     1531552 <RVecIsuIntf::init()@@Base+0xd2>
 153154d:	e8 3e 03 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531552:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531559:	00 
 153155a:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 153155e:	48 3b 3d 1b b6 64 00 	cmp    0x64b61b(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531565:	0f 85 1d 0c 00 00    	jne    1532188 <RVecIsuIntf::init()@@Base+0xd08>
 153156b:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 1531572:	48 8d 15 61 79 23 00 	lea    0x237961(%rip),%rdx        # 1768eda <_fini@@Base+0x121b6>
 1531579:	4c 89 fe             	mov    %r15,%rsi
 153157c:	48 89 ef             	mov    %rbp,%rdi
 153157f:	8b 80 c8 00 00 00    	mov    0xc8(%rax),%eax
 1531585:	c1 e0 02             	shl    $0x2,%eax
 1531588:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 153158c:	e8 1f cf e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531591:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 1531595:	4c 8d 4c 24 2c       	lea    0x2c(%rsp),%r9
 153159a:	4c 8d 44 24 28       	lea    0x28(%rsp),%r8
 153159f:	4c 89 e9             	mov    %r13,%rcx
 15315a2:	48 89 ea             	mov    %rbp,%rdx
 15315a5:	4c 89 f6             	mov    %r14,%rsi
 15315a8:	4c 89 e7             	mov    %r12,%rdi
 15315ab:	c7 44 24 2c 01 00 00 	movl   $0x1,0x2c(%rsp)
 15315b2:	00 
 15315b3:	89 44 24 28          	mov    %eax,0x28(%rsp)
 15315b7:	e8 74 fd ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 15315bc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
 15315c0:	66 0f ef c9          	pxor   %xmm1,%xmm1
 15315c4:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 15315cb:	00 00 
 15315cd:	48 85 ff             	test   %rdi,%rdi
 15315d0:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 15315d7:	00 
 15315d8:	0f 11 43 58          	movups %xmm0,0x58(%rbx)
 15315dc:	74 17                	je     15315f5 <RVecIsuIntf::init()@@Base+0x175>
 15315de:	e8 ad 02 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15315e3:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 15315ea:	00 
 15315eb:	48 85 ff             	test   %rdi,%rdi
 15315ee:	74 05                	je     15315f5 <RVecIsuIntf::init()@@Base+0x175>
 15315f0:	e8 9b 02 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15315f5:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 15315fc:	00 
 15315fd:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1531601:	48 3b 3d 78 b5 64 00 	cmp    0x64b578(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531608:	0f 85 8a 0b 00 00    	jne    1532198 <RVecIsuIntf::init()@@Base+0xd18>
 153160e:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 1531615:	48 8d 15 cb 78 23 00 	lea    0x2378cb(%rip),%rdx        # 1768ee7 <_fini@@Base+0x121c3>
 153161c:	4c 89 fe             	mov    %r15,%rsi
 153161f:	48 89 ef             	mov    %rbp,%rdi
 1531622:	8b 80 cc 00 00 00    	mov    0xcc(%rax),%eax
 1531628:	c1 e0 02             	shl    $0x2,%eax
 153162b:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 153162f:	e8 7c ce e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531634:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 1531638:	4c 8d 4c 24 34       	lea    0x34(%rsp),%r9
 153163d:	4c 8d 44 24 30       	lea    0x30(%rsp),%r8
 1531642:	4c 89 e9             	mov    %r13,%rcx
 1531645:	48 89 ea             	mov    %rbp,%rdx
 1531648:	4c 89 f6             	mov    %r14,%rsi
 153164b:	4c 89 e7             	mov    %r12,%rdi
 153164e:	c7 44 24 34 01 00 00 	movl   $0x1,0x34(%rsp)
 1531655:	00 
 1531656:	89 44 24 30          	mov    %eax,0x30(%rsp)
 153165a:	e8 d1 fc ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 153165f:	48 8b 7b 70          	mov    0x70(%rbx),%rdi
 1531663:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531667:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 153166e:	00 00 
 1531670:	48 85 ff             	test   %rdi,%rdi
 1531673:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 153167a:	00 
 153167b:	0f 11 43 68          	movups %xmm0,0x68(%rbx)
 153167f:	74 17                	je     1531698 <RVecIsuIntf::init()@@Base+0x218>
 1531681:	e8 0a 02 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531686:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 153168d:	00 
 153168e:	48 85 ff             	test   %rdi,%rdi
 1531691:	74 05                	je     1531698 <RVecIsuIntf::init()@@Base+0x218>
 1531693:	e8 f8 01 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531698:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 153169f:	00 
 15316a0:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 15316a4:	48 3b 3d d5 b4 64 00 	cmp    0x64b4d5(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 15316ab:	0f 85 f7 0a 00 00    	jne    15321a8 <RVecIsuIntf::init()@@Base+0xd28>
 15316b1:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 15316b8:	48 8d 15 35 78 23 00 	lea    0x237835(%rip),%rdx        # 1768ef4 <_fini@@Base+0x121d0>
 15316bf:	4c 89 fe             	mov    %r15,%rsi
 15316c2:	48 89 ef             	mov    %rbp,%rdi
 15316c5:	8b 80 d0 00 00 00    	mov    0xd0(%rax),%eax
 15316cb:	c1 e0 02             	shl    $0x2,%eax
 15316ce:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 15316d2:	e8 d9 cd e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 15316d7:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 15316db:	4c 8d 4c 24 3c       	lea    0x3c(%rsp),%r9
 15316e0:	4c 8d 44 24 38       	lea    0x38(%rsp),%r8
 15316e5:	4c 89 e9             	mov    %r13,%rcx
 15316e8:	48 89 ea             	mov    %rbp,%rdx
 15316eb:	4c 89 f6             	mov    %r14,%rsi
 15316ee:	4c 89 e7             	mov    %r12,%rdi
 15316f1:	c7 44 24 3c 01 00 00 	movl   $0x1,0x3c(%rsp)
 15316f8:	00 
 15316f9:	89 44 24 38          	mov    %eax,0x38(%rsp)
 15316fd:	e8 2e fc ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531702:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
 1531709:	66 0f ef c9          	pxor   %xmm1,%xmm1
 153170d:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531714:	00 00 
 1531716:	48 85 ff             	test   %rdi,%rdi
 1531719:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531720:	00 
 1531721:	0f 11 43 78          	movups %xmm0,0x78(%rbx)
 1531725:	74 17                	je     153173e <RVecIsuIntf::init()@@Base+0x2be>
 1531727:	e8 64 01 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 153172c:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531733:	00 
 1531734:	48 85 ff             	test   %rdi,%rdi
 1531737:	74 05                	je     153173e <RVecIsuIntf::init()@@Base+0x2be>
 1531739:	e8 52 01 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 153173e:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531745:	00 
 1531746:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 153174a:	48 3b 3d 2f b4 64 00 	cmp    0x64b42f(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531751:	0f 85 61 0a 00 00    	jne    15321b8 <RVecIsuIntf::init()@@Base+0xd38>
 1531757:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 153175e:	48 8d 15 9d 77 23 00 	lea    0x23779d(%rip),%rdx        # 1768f02 <_fini@@Base+0x121de>
 1531765:	4c 89 fe             	mov    %r15,%rsi
 1531768:	48 89 ef             	mov    %rbp,%rdi
 153176b:	8b 80 d0 00 00 00    	mov    0xd0(%rax),%eax
 1531771:	c1 e0 02             	shl    $0x2,%eax
 1531774:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 1531778:	e8 33 cd e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 153177d:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 1531781:	4c 8d 4c 24 44       	lea    0x44(%rsp),%r9
 1531786:	4c 8d 44 24 40       	lea    0x40(%rsp),%r8
 153178b:	4c 89 e9             	mov    %r13,%rcx
 153178e:	48 89 ea             	mov    %rbp,%rdx
 1531791:	4c 89 f6             	mov    %r14,%rsi
 1531794:	4c 89 e7             	mov    %r12,%rdi
 1531797:	c7 44 24 44 01 00 00 	movl   $0x1,0x44(%rsp)
 153179e:	00 
 153179f:	89 44 24 40          	mov    %eax,0x40(%rsp)
 15317a3:	e8 88 fb ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 15317a8:	48 8b bb 90 00 00 00 	mov    0x90(%rbx),%rdi
 15317af:	66 0f ef c9          	pxor   %xmm1,%xmm1
 15317b3:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 15317ba:	00 00 
 15317bc:	48 85 ff             	test   %rdi,%rdi
 15317bf:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 15317c6:	00 
 15317c7:	0f 11 83 88 00 00 00 	movups %xmm0,0x88(%rbx)
 15317ce:	74 17                	je     15317e7 <RVecIsuIntf::init()@@Base+0x367>
 15317d0:	e8 bb 00 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15317d5:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 15317dc:	00 
 15317dd:	48 85 ff             	test   %rdi,%rdi
 15317e0:	74 05                	je     15317e7 <RVecIsuIntf::init()@@Base+0x367>
 15317e2:	e8 a9 00 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15317e7:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 15317ee:	00 
 15317ef:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 15317f3:	48 3b 3d 86 b3 64 00 	cmp    0x64b386(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 15317fa:	0f 85 c8 09 00 00    	jne    15321c8 <RVecIsuIntf::init()@@Base+0xd48>
 1531800:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 1531807:	48 8d 15 02 77 23 00 	lea    0x237702(%rip),%rdx        # 1768f10 <_fini@@Base+0x121ec>
 153180e:	4c 89 fe             	mov    %r15,%rsi
 1531811:	48 89 ef             	mov    %rbp,%rdi
 1531814:	8b 80 bc 00 00 00    	mov    0xbc(%rax),%eax
 153181a:	c1 e0 02             	shl    $0x2,%eax
 153181d:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 1531821:	e8 8a cc e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531826:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 153182a:	4c 8d 4c 24 4c       	lea    0x4c(%rsp),%r9
 153182f:	4c 8d 44 24 48       	lea    0x48(%rsp),%r8
 1531834:	4c 89 e9             	mov    %r13,%rcx
 1531837:	48 89 ea             	mov    %rbp,%rdx
 153183a:	4c 89 f6             	mov    %r14,%rsi
 153183d:	4c 89 e7             	mov    %r12,%rdi
 1531840:	c7 44 24 4c 01 00 00 	movl   $0x1,0x4c(%rsp)
 1531847:	00 
 1531848:	89 44 24 48          	mov    %eax,0x48(%rsp)
 153184c:	e8 df fa ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531851:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
 1531858:	66 0f ef c9          	pxor   %xmm1,%xmm1
 153185c:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531863:	00 00 
 1531865:	48 85 ff             	test   %rdi,%rdi
 1531868:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 153186f:	00 
 1531870:	0f 11 83 98 00 00 00 	movups %xmm0,0x98(%rbx)
 1531877:	74 17                	je     1531890 <RVecIsuIntf::init()@@Base+0x410>
 1531879:	e8 12 00 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 153187e:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531885:	00 
 1531886:	48 85 ff             	test   %rdi,%rdi
 1531889:	74 05                	je     1531890 <RVecIsuIntf::init()@@Base+0x410>
 153188b:	e8 00 00 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531890:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531897:	00 
 1531898:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 153189c:	48 3b 3d dd b2 64 00 	cmp    0x64b2dd(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 15318a3:	0f 85 2f 09 00 00    	jne    15321d8 <RVecIsuIntf::init()@@Base+0xd58>
 15318a9:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 15318b0:	48 8d 15 67 76 23 00 	lea    0x237667(%rip),%rdx        # 1768f1e <_fini@@Base+0x121fa>
 15318b7:	4c 89 fe             	mov    %r15,%rsi
 15318ba:	48 89 ef             	mov    %rbp,%rdi
 15318bd:	8b 80 bc 00 00 00    	mov    0xbc(%rax),%eax
 15318c3:	c1 e0 02             	shl    $0x2,%eax
 15318c6:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 15318ca:	e8 e1 cb e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 15318cf:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 15318d3:	4c 8d 4c 24 54       	lea    0x54(%rsp),%r9
 15318d8:	4c 8d 44 24 50       	lea    0x50(%rsp),%r8
 15318dd:	4c 89 e9             	mov    %r13,%rcx
 15318e0:	48 89 ea             	mov    %rbp,%rdx
 15318e3:	4c 89 f6             	mov    %r14,%rsi
 15318e6:	4c 89 e7             	mov    %r12,%rdi
 15318e9:	c7 44 24 54 01 00 00 	movl   $0x1,0x54(%rsp)
 15318f0:	00 
 15318f1:	89 44 24 50          	mov    %eax,0x50(%rsp)
 15318f5:	e8 36 fa ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 15318fa:	48 8b bb b0 00 00 00 	mov    0xb0(%rbx),%rdi
 1531901:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531905:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 153190c:	00 00 
 153190e:	48 85 ff             	test   %rdi,%rdi
 1531911:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531918:	00 
 1531919:	0f 11 83 a8 00 00 00 	movups %xmm0,0xa8(%rbx)
 1531920:	74 17                	je     1531939 <RVecIsuIntf::init()@@Base+0x4b9>
 1531922:	e8 69 ff 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531927:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 153192e:	00 
 153192f:	48 85 ff             	test   %rdi,%rdi
 1531932:	74 05                	je     1531939 <RVecIsuIntf::init()@@Base+0x4b9>
 1531934:	e8 57 ff 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531939:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531940:	00 
 1531941:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1531945:	48 3b 3d 34 b2 64 00 	cmp    0x64b234(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 153194c:	0f 85 96 08 00 00    	jne    15321e8 <RVecIsuIntf::init()@@Base+0xd68>
 1531952:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 1531959:	48 8d 15 cc 75 23 00 	lea    0x2375cc(%rip),%rdx        # 1768f2c <_fini@@Base+0x12208>
 1531960:	4c 89 fe             	mov    %r15,%rsi
 1531963:	48 89 ef             	mov    %rbp,%rdi
 1531966:	8b 80 bc 00 00 00    	mov    0xbc(%rax),%eax
 153196c:	c1 e0 02             	shl    $0x2,%eax
 153196f:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 1531973:	e8 38 cb e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531978:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 153197c:	4c 8d 4c 24 5c       	lea    0x5c(%rsp),%r9
 1531981:	4c 8d 44 24 58       	lea    0x58(%rsp),%r8
 1531986:	4c 89 e9             	mov    %r13,%rcx
 1531989:	48 89 ea             	mov    %rbp,%rdx
 153198c:	4c 89 f6             	mov    %r14,%rsi
 153198f:	4c 89 e7             	mov    %r12,%rdi
 1531992:	c7 44 24 5c 01 00 00 	movl   $0x1,0x5c(%rsp)
 1531999:	00 
 153199a:	89 44 24 58          	mov    %eax,0x58(%rsp)
 153199e:	e8 8d f9 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 15319a3:	48 8b bb c0 00 00 00 	mov    0xc0(%rbx),%rdi
 15319aa:	66 0f ef c9          	pxor   %xmm1,%xmm1
 15319ae:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 15319b5:	00 00 
 15319b7:	48 85 ff             	test   %rdi,%rdi
 15319ba:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 15319c1:	00 
 15319c2:	0f 11 83 b8 00 00 00 	movups %xmm0,0xb8(%rbx)
 15319c9:	74 17                	je     15319e2 <RVecIsuIntf::init()@@Base+0x562>
 15319cb:	e8 c0 fe 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15319d0:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 15319d7:	00 
 15319d8:	48 85 ff             	test   %rdi,%rdi
 15319db:	74 05                	je     15319e2 <RVecIsuIntf::init()@@Base+0x562>
 15319dd:	e8 ae fe 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15319e2:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 15319e9:	00 
 15319ea:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 15319ee:	48 3b 3d 8b b1 64 00 	cmp    0x64b18b(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 15319f5:	0f 85 fd 07 00 00    	jne    15321f8 <RVecIsuIntf::init()@@Base+0xd78>
 15319fb:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 1531a02:	48 8d 15 31 75 23 00 	lea    0x237531(%rip),%rdx        # 1768f3a <_fini@@Base+0x12216>
 1531a09:	4c 89 fe             	mov    %r15,%rsi
 1531a0c:	48 89 ef             	mov    %rbp,%rdi
 1531a0f:	8b 80 bc 00 00 00    	mov    0xbc(%rax),%eax
 1531a15:	c1 e0 02             	shl    $0x2,%eax
 1531a18:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 1531a1c:	e8 8f ca e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531a21:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 1531a25:	4c 8d 4c 24 64       	lea    0x64(%rsp),%r9
 1531a2a:	4c 8d 44 24 60       	lea    0x60(%rsp),%r8
 1531a2f:	4c 89 e9             	mov    %r13,%rcx
 1531a32:	48 89 ea             	mov    %rbp,%rdx
 1531a35:	4c 89 f6             	mov    %r14,%rsi
 1531a38:	4c 89 e7             	mov    %r12,%rdi
 1531a3b:	c7 44 24 64 01 00 00 	movl   $0x1,0x64(%rsp)
 1531a42:	00 
 1531a43:	89 44 24 60          	mov    %eax,0x60(%rsp)
 1531a47:	e8 e4 f8 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531a4c:	48 8b bb d0 00 00 00 	mov    0xd0(%rbx),%rdi
 1531a53:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531a57:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531a5e:	00 00 
 1531a60:	48 85 ff             	test   %rdi,%rdi
 1531a63:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531a6a:	00 
 1531a6b:	0f 11 83 c8 00 00 00 	movups %xmm0,0xc8(%rbx)
 1531a72:	74 17                	je     1531a8b <RVecIsuIntf::init()@@Base+0x60b>
 1531a74:	e8 17 fe 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531a79:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531a80:	00 
 1531a81:	48 85 ff             	test   %rdi,%rdi
 1531a84:	74 05                	je     1531a8b <RVecIsuIntf::init()@@Base+0x60b>
 1531a86:	e8 05 fe 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531a8b:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531a92:	00 
 1531a93:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1531a97:	48 3b 3d e2 b0 64 00 	cmp    0x64b0e2(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531a9e:	0f 85 64 07 00 00    	jne    1532208 <RVecIsuIntf::init()@@Base+0xd88>
 1531aa4:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 1531aab:	48 8d 15 96 74 23 00 	lea    0x237496(%rip),%rdx        # 1768f48 <_fini@@Base+0x12224>
 1531ab2:	4c 89 fe             	mov    %r15,%rsi
 1531ab5:	48 89 ef             	mov    %rbp,%rdi
 1531ab8:	8b 80 b0 00 00 00    	mov    0xb0(%rax),%eax
 1531abe:	c1 e0 02             	shl    $0x2,%eax
 1531ac1:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 1531ac5:	e8 e6 c9 e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531aca:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 1531ace:	4c 8d 4c 24 6c       	lea    0x6c(%rsp),%r9
 1531ad3:	4c 8d 44 24 68       	lea    0x68(%rsp),%r8
 1531ad8:	4c 89 e9             	mov    %r13,%rcx
 1531adb:	48 89 ea             	mov    %rbp,%rdx
 1531ade:	4c 89 f6             	mov    %r14,%rsi
 1531ae1:	4c 89 e7             	mov    %r12,%rdi
 1531ae4:	c7 44 24 6c 01 00 00 	movl   $0x1,0x6c(%rsp)
 1531aeb:	00 
 1531aec:	89 44 24 68          	mov    %eax,0x68(%rsp)
 1531af0:	e8 3b f8 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531af5:	48 8b bb e0 00 00 00 	mov    0xe0(%rbx),%rdi
 1531afc:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531b00:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531b07:	00 00 
 1531b09:	48 85 ff             	test   %rdi,%rdi
 1531b0c:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531b13:	00 
 1531b14:	0f 11 83 d8 00 00 00 	movups %xmm0,0xd8(%rbx)
 1531b1b:	74 17                	je     1531b34 <RVecIsuIntf::init()@@Base+0x6b4>
 1531b1d:	e8 6e fd 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531b22:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531b29:	00 
 1531b2a:	48 85 ff             	test   %rdi,%rdi
 1531b2d:	74 05                	je     1531b34 <RVecIsuIntf::init()@@Base+0x6b4>
 1531b2f:	e8 5c fd 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531b34:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531b3b:	00 
 1531b3c:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1531b40:	48 3b 3d 39 b0 64 00 	cmp    0x64b039(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531b47:	0f 85 cb 06 00 00    	jne    1532218 <RVecIsuIntf::init()@@Base+0xd98>
 1531b4d:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 1531b54:	48 8d 15 fb 73 23 00 	lea    0x2373fb(%rip),%rdx        # 1768f56 <_fini@@Base+0x12232>
 1531b5b:	4c 89 fe             	mov    %r15,%rsi
 1531b5e:	48 89 ef             	mov    %rbp,%rdi
 1531b61:	8b 80 b4 00 00 00    	mov    0xb4(%rax),%eax
 1531b67:	c1 e0 02             	shl    $0x2,%eax
 1531b6a:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 1531b6e:	e8 3d c9 e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531b73:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 1531b77:	4c 8d 4c 24 74       	lea    0x74(%rsp),%r9
 1531b7c:	4c 8d 44 24 70       	lea    0x70(%rsp),%r8
 1531b81:	4c 89 e9             	mov    %r13,%rcx
 1531b84:	48 89 ea             	mov    %rbp,%rdx
 1531b87:	4c 89 f6             	mov    %r14,%rsi
 1531b8a:	4c 89 e7             	mov    %r12,%rdi
 1531b8d:	c7 44 24 74 01 00 00 	movl   $0x1,0x74(%rsp)
 1531b94:	00 
 1531b95:	89 44 24 70          	mov    %eax,0x70(%rsp)
 1531b99:	e8 92 f7 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531b9e:	48 8b bb f0 00 00 00 	mov    0xf0(%rbx),%rdi
 1531ba5:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531ba9:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531bb0:	00 00 
 1531bb2:	48 85 ff             	test   %rdi,%rdi
 1531bb5:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531bbc:	00 
 1531bbd:	0f 11 83 e8 00 00 00 	movups %xmm0,0xe8(%rbx)
 1531bc4:	74 17                	je     1531bdd <RVecIsuIntf::init()@@Base+0x75d>
 1531bc6:	e8 c5 fc 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531bcb:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531bd2:	00 
 1531bd3:	48 85 ff             	test   %rdi,%rdi
 1531bd6:	74 05                	je     1531bdd <RVecIsuIntf::init()@@Base+0x75d>
 1531bd8:	e8 b3 fc 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531bdd:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531be4:	00 
 1531be5:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1531be9:	48 3b 3d 90 af 64 00 	cmp    0x64af90(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531bf0:	0f 85 32 06 00 00    	jne    1532228 <RVecIsuIntf::init()@@Base+0xda8>
 1531bf6:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 1531bfd:	48 8d 15 60 73 23 00 	lea    0x237360(%rip),%rdx        # 1768f64 <_fini@@Base+0x12240>
 1531c04:	4c 89 fe             	mov    %r15,%rsi
 1531c07:	48 89 ef             	mov    %rbp,%rdi
 1531c0a:	8b 80 b8 00 00 00    	mov    0xb8(%rax),%eax
 1531c10:	c1 e0 02             	shl    $0x2,%eax
 1531c13:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 1531c17:	e8 94 c8 e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531c1c:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 1531c20:	4c 8d 4c 24 7c       	lea    0x7c(%rsp),%r9
 1531c25:	4c 8d 44 24 78       	lea    0x78(%rsp),%r8
 1531c2a:	4c 89 e9             	mov    %r13,%rcx
 1531c2d:	48 89 ea             	mov    %rbp,%rdx
 1531c30:	4c 89 f6             	mov    %r14,%rsi
 1531c33:	4c 89 e7             	mov    %r12,%rdi
 1531c36:	c7 44 24 7c 01 00 00 	movl   $0x1,0x7c(%rsp)
 1531c3d:	00 
 1531c3e:	89 44 24 78          	mov    %eax,0x78(%rsp)
 1531c42:	e8 e9 f6 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531c47:	48 8b bb 00 01 00 00 	mov    0x100(%rbx),%rdi
 1531c4e:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531c52:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531c59:	00 00 
 1531c5b:	48 85 ff             	test   %rdi,%rdi
 1531c5e:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531c65:	00 
 1531c66:	0f 11 83 f8 00 00 00 	movups %xmm0,0xf8(%rbx)
 1531c6d:	74 17                	je     1531c86 <RVecIsuIntf::init()@@Base+0x806>
 1531c6f:	e8 1c fc 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531c74:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531c7b:	00 
 1531c7c:	48 85 ff             	test   %rdi,%rdi
 1531c7f:	74 05                	je     1531c86 <RVecIsuIntf::init()@@Base+0x806>
 1531c81:	e8 0a fc 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531c86:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531c8d:	00 
 1531c8e:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1531c92:	48 3b 3d e7 ae 64 00 	cmp    0x64aee7(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531c99:	0f 85 99 05 00 00    	jne    1532238 <RVecIsuIntf::init()@@Base+0xdb8>
 1531c9f:	48 8d 15 cb 72 23 00 	lea    0x2372cb(%rip),%rdx        # 1768f71 <_fini@@Base+0x1224d>
 1531ca6:	4c 89 fe             	mov    %r15,%rsi
 1531ca9:	48 89 ef             	mov    %rbp,%rdi
 1531cac:	e8 ff c7 e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531cb1:	4c 8d 8c 24 84 00 00 	lea    0x84(%rsp),%r9
 1531cb8:	00 
 1531cb9:	4c 8d 84 24 80 00 00 	lea    0x80(%rsp),%r8
 1531cc0:	00 
 1531cc1:	4c 89 e9             	mov    %r13,%rcx
 1531cc4:	48 89 ea             	mov    %rbp,%rdx
 1531cc7:	4c 89 f6             	mov    %r14,%rsi
 1531cca:	4c 89 e7             	mov    %r12,%rdi
 1531ccd:	c7 84 24 80 00 00 00 	movl   $0xffffffff,0x80(%rsp)
 1531cd4:	ff ff ff ff 
 1531cd8:	c7 84 24 84 00 00 00 	movl   $0x1,0x84(%rsp)
 1531cdf:	01 00 00 00 
 1531ce3:	e8 48 f6 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531ce8:	48 8b bb 10 01 00 00 	mov    0x110(%rbx),%rdi
 1531cef:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531cf3:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531cfa:	00 00 
 1531cfc:	48 85 ff             	test   %rdi,%rdi
 1531cff:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531d06:	00 
 1531d07:	0f 11 83 08 01 00 00 	movups %xmm0,0x108(%rbx)
 1531d0e:	74 17                	je     1531d27 <RVecIsuIntf::init()@@Base+0x8a7>
 1531d10:	e8 7b fb 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531d15:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531d1c:	00 
 1531d1d:	48 85 ff             	test   %rdi,%rdi
 1531d20:	74 05                	je     1531d27 <RVecIsuIntf::init()@@Base+0x8a7>
 1531d22:	e8 69 fb 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531d27:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531d2e:	00 
 1531d2f:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1531d33:	48 3b 3d 46 ae 64 00 	cmp    0x64ae46(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531d3a:	0f 85 08 05 00 00    	jne    1532248 <RVecIsuIntf::init()@@Base+0xdc8>
 1531d40:	48 8d 15 37 72 23 00 	lea    0x237237(%rip),%rdx        # 1768f7e <_fini@@Base+0x1225a>
 1531d47:	4c 89 fe             	mov    %r15,%rsi
 1531d4a:	48 89 ef             	mov    %rbp,%rdi
 1531d4d:	e8 5e c7 e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531d52:	4c 8d 8c 24 8c 00 00 	lea    0x8c(%rsp),%r9
 1531d59:	00 
 1531d5a:	4c 8d 84 24 88 00 00 	lea    0x88(%rsp),%r8
 1531d61:	00 
 1531d62:	4c 89 e9             	mov    %r13,%rcx
 1531d65:	48 89 ea             	mov    %rbp,%rdx
 1531d68:	4c 89 f6             	mov    %r14,%rsi
 1531d6b:	4c 89 e7             	mov    %r12,%rdi
 1531d6e:	c7 84 24 88 00 00 00 	movl   $0xffffffff,0x88(%rsp)
 1531d75:	ff ff ff ff 
 1531d79:	c7 84 24 8c 00 00 00 	movl   $0x1,0x8c(%rsp)
 1531d80:	01 00 00 00 
 1531d84:	e8 a7 f5 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531d89:	48 8b bb 20 01 00 00 	mov    0x120(%rbx),%rdi
 1531d90:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531d94:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531d9b:	00 00 
 1531d9d:	48 85 ff             	test   %rdi,%rdi
 1531da0:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531da7:	00 
 1531da8:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
 1531daf:	74 17                	je     1531dc8 <RVecIsuIntf::init()@@Base+0x948>
 1531db1:	e8 da fa 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531db6:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531dbd:	00 
 1531dbe:	48 85 ff             	test   %rdi,%rdi
 1531dc1:	74 05                	je     1531dc8 <RVecIsuIntf::init()@@Base+0x948>
 1531dc3:	e8 c8 fa 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531dc8:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531dcf:	00 
 1531dd0:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1531dd4:	48 3b 3d a5 ad 64 00 	cmp    0x64ada5(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531ddb:	0f 85 77 04 00 00    	jne    1532258 <RVecIsuIntf::init()@@Base+0xdd8>
 1531de1:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 1531de8:	48 8d 15 9c 71 23 00 	lea    0x23719c(%rip),%rdx        # 1768f8b <_fini@@Base+0x12267>
 1531def:	4c 89 fe             	mov    %r15,%rsi
 1531df2:	48 89 ef             	mov    %rbp,%rdi
 1531df5:	8b 80 c0 00 00 00    	mov    0xc0(%rax),%eax
 1531dfb:	c1 e0 02             	shl    $0x2,%eax
 1531dfe:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 1531e02:	e8 a9 c6 e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531e07:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 1531e0b:	4c 8d 8c 24 94 00 00 	lea    0x94(%rsp),%r9
 1531e12:	00 
 1531e13:	4c 8d 84 24 90 00 00 	lea    0x90(%rsp),%r8
 1531e1a:	00 
 1531e1b:	4c 89 e9             	mov    %r13,%rcx
 1531e1e:	48 89 ea             	mov    %rbp,%rdx
 1531e21:	4c 89 f6             	mov    %r14,%rsi
 1531e24:	4c 89 e7             	mov    %r12,%rdi
 1531e27:	c7 84 24 94 00 00 00 	movl   $0x1,0x94(%rsp)
 1531e2e:	01 00 00 00 
 1531e32:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
 1531e39:	e8 f2 f4 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531e3e:	48 8b bb 30 01 00 00 	mov    0x130(%rbx),%rdi
 1531e45:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531e49:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531e50:	00 00 
 1531e52:	48 85 ff             	test   %rdi,%rdi
 1531e55:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531e5c:	00 
 1531e5d:	0f 11 83 28 01 00 00 	movups %xmm0,0x128(%rbx)
 1531e64:	74 17                	je     1531e7d <RVecIsuIntf::init()@@Base+0x9fd>
 1531e66:	e8 25 fa 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531e6b:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531e72:	00 
 1531e73:	48 85 ff             	test   %rdi,%rdi
 1531e76:	74 05                	je     1531e7d <RVecIsuIntf::init()@@Base+0x9fd>
 1531e78:	e8 13 fa 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531e7d:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531e84:	00 
 1531e85:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1531e89:	48 3b 3d f0 ac 64 00 	cmp    0x64acf0(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531e90:	0f 85 d2 03 00 00    	jne    1532268 <RVecIsuIntf::init()@@Base+0xde8>
 1531e96:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 1531e9d:	48 8d 15 f4 70 23 00 	lea    0x2370f4(%rip),%rdx        # 1768f98 <_fini@@Base+0x12274>
 1531ea4:	4c 89 fe             	mov    %r15,%rsi
 1531ea7:	48 89 ef             	mov    %rbp,%rdi
 1531eaa:	8b 80 c0 00 00 00    	mov    0xc0(%rax),%eax
 1531eb0:	c1 e0 02             	shl    $0x2,%eax
 1531eb3:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 1531eb7:	e8 f4 c5 e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531ebc:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 1531ec0:	4c 8d 8c 24 9c 00 00 	lea    0x9c(%rsp),%r9
 1531ec7:	00 
 1531ec8:	4c 8d 84 24 98 00 00 	lea    0x98(%rsp),%r8
 1531ecf:	00 
 1531ed0:	4c 89 e9             	mov    %r13,%rcx
 1531ed3:	48 89 ea             	mov    %rbp,%rdx
 1531ed6:	4c 89 f6             	mov    %r14,%rsi
 1531ed9:	4c 89 e7             	mov    %r12,%rdi
 1531edc:	c7 84 24 9c 00 00 00 	movl   $0x1,0x9c(%rsp)
 1531ee3:	01 00 00 00 
 1531ee7:	89 84 24 98 00 00 00 	mov    %eax,0x98(%rsp)
 1531eee:	e8 3d f4 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531ef3:	48 8b bb 40 01 00 00 	mov    0x140(%rbx),%rdi
 1531efa:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531efe:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531f05:	00 00 
 1531f07:	48 85 ff             	test   %rdi,%rdi
 1531f0a:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531f11:	00 
 1531f12:	0f 11 83 38 01 00 00 	movups %xmm0,0x138(%rbx)
 1531f19:	74 17                	je     1531f32 <RVecIsuIntf::init()@@Base+0xab2>
 1531f1b:	e8 70 f9 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531f20:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531f27:	00 
 1531f28:	48 85 ff             	test   %rdi,%rdi
 1531f2b:	74 05                	je     1531f32 <RVecIsuIntf::init()@@Base+0xab2>
 1531f2d:	e8 5e f9 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531f32:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531f39:	00 
 1531f3a:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1531f3e:	48 3b 3d 3b ac 64 00 	cmp    0x64ac3b(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531f45:	0f 85 2d 03 00 00    	jne    1532278 <RVecIsuIntf::init()@@Base+0xdf8>
 1531f4b:	48 8d 15 53 70 23 00 	lea    0x237053(%rip),%rdx        # 1768fa5 <_fini@@Base+0x12281>
 1531f52:	4c 89 fe             	mov    %r15,%rsi
 1531f55:	48 89 ef             	mov    %rbp,%rdi
 1531f58:	e8 53 c5 e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1531f5d:	4c 8d 8c 24 a4 00 00 	lea    0xa4(%rsp),%r9
 1531f64:	00 
 1531f65:	4c 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%r8
 1531f6c:	00 
 1531f6d:	4c 89 e9             	mov    %r13,%rcx
 1531f70:	48 89 ea             	mov    %rbp,%rdx
 1531f73:	4c 89 f6             	mov    %r14,%rsi
 1531f76:	4c 89 e7             	mov    %r12,%rdi
 1531f79:	c7 84 24 a0 00 00 00 	movl   $0xffffffff,0xa0(%rsp)
 1531f80:	ff ff ff ff 
 1531f84:	c7 84 24 a4 00 00 00 	movl   $0x1,0xa4(%rsp)
 1531f8b:	01 00 00 00 
 1531f8f:	e8 9c f3 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1531f94:	48 8b bb 50 01 00 00 	mov    0x150(%rbx),%rdi
 1531f9b:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1531f9f:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 1531fa6:	00 00 
 1531fa8:	48 85 ff             	test   %rdi,%rdi
 1531fab:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1531fb2:	00 
 1531fb3:	0f 11 83 48 01 00 00 	movups %xmm0,0x148(%rbx)
 1531fba:	74 17                	je     1531fd3 <RVecIsuIntf::init()@@Base+0xb53>
 1531fbc:	e8 cf f8 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531fc1:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1531fc8:	00 
 1531fc9:	48 85 ff             	test   %rdi,%rdi
 1531fcc:	74 05                	je     1531fd3 <RVecIsuIntf::init()@@Base+0xb53>
 1531fce:	e8 bd f8 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1531fd3:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1531fda:	00 
 1531fdb:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1531fdf:	48 3b 3d 9a ab 64 00 	cmp    0x64ab9a(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1531fe6:	0f 85 9c 02 00 00    	jne    1532288 <RVecIsuIntf::init()@@Base+0xe08>
 1531fec:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 1531ff3:	48 8d 15 b8 6f 23 00 	lea    0x236fb8(%rip),%rdx        # 1768fb2 <_fini@@Base+0x1228e>
 1531ffa:	4c 89 fe             	mov    %r15,%rsi
 1531ffd:	48 89 ef             	mov    %rbp,%rdi
 1532000:	8b 80 bc 00 00 00    	mov    0xbc(%rax),%eax
 1532006:	c1 e0 02             	shl    $0x2,%eax
 1532009:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 153200d:	e8 9e c4 e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 1532012:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 1532016:	4c 8d 8c 24 ac 00 00 	lea    0xac(%rsp),%r9
 153201d:	00 
 153201e:	4c 8d 84 24 a8 00 00 	lea    0xa8(%rsp),%r8
 1532025:	00 
 1532026:	4c 89 e9             	mov    %r13,%rcx
 1532029:	48 89 ea             	mov    %rbp,%rdx
 153202c:	4c 89 f6             	mov    %r14,%rsi
 153202f:	4c 89 e7             	mov    %r12,%rdi
 1532032:	c7 84 24 ac 00 00 00 	movl   $0x1,0xac(%rsp)
 1532039:	01 00 00 00 
 153203d:	89 84 24 a8 00 00 00 	mov    %eax,0xa8(%rsp)
 1532044:	e8 e7 f2 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 1532049:	48 8b bb 60 01 00 00 	mov    0x160(%rbx),%rdi
 1532050:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1532054:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 153205b:	00 00 
 153205d:	48 85 ff             	test   %rdi,%rdi
 1532060:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1532067:	00 
 1532068:	0f 11 83 58 01 00 00 	movups %xmm0,0x158(%rbx)
 153206f:	74 17                	je     1532088 <RVecIsuIntf::init()@@Base+0xc08>
 1532071:	e8 1a f8 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1532076:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 153207d:	00 
 153207e:	48 85 ff             	test   %rdi,%rdi
 1532081:	74 05                	je     1532088 <RVecIsuIntf::init()@@Base+0xc08>
 1532083:	e8 08 f8 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1532088:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 153208f:	00 
 1532090:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1532094:	48 3b 3d e5 aa 64 00 	cmp    0x64aae5(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 153209b:	0f 85 f7 01 00 00    	jne    1532298 <RVecIsuIntf::init()@@Base+0xe18>
 15320a1:	48 8b 83 a0 03 00 00 	mov    0x3a0(%rbx),%rax
 15320a8:	48 8d 15 11 6f 23 00 	lea    0x236f11(%rip),%rdx        # 1768fc0 <_fini@@Base+0x1229c>
 15320af:	4c 89 fe             	mov    %r15,%rsi
 15320b2:	48 89 ef             	mov    %rbp,%rdi
 15320b5:	8b 80 bc 00 00 00    	mov    0xbc(%rax),%eax
 15320bb:	c1 e0 02             	shl    $0x2,%eax
 15320be:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 15320c2:	e8 e9 c3 e5 fe       	call   38e4b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> > std::operator+<char, std::char_traits<char>, std::allocator<char> >(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, char const*)@plt>
 15320c7:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 15320cb:	48 8d 74 24 1f       	lea    0x1f(%rsp),%rsi
 15320d0:	4c 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%r8
 15320d7:	00 
 15320d8:	4d 89 f1             	mov    %r14,%r9
 15320db:	4c 89 e9             	mov    %r13,%rcx
 15320de:	48 89 ea             	mov    %rbp,%rdx
 15320e1:	4c 89 e7             	mov    %r12,%rdi
 15320e4:	c7 84 24 b4 00 00 00 	movl   $0x1,0xb4(%rsp)
 15320eb:	01 00 00 00 
 15320ef:	89 84 24 b0 00 00 00 	mov    %eax,0xb0(%rsp)
 15320f6:	e8 35 f2 ff ff       	call   1531330 <PemRVecISU::recv_and_issue_instr()@@Base+0x2a0>
 15320fb:	48 8b bb 70 01 00 00 	mov    0x170(%rbx),%rdi
 1532102:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1532106:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
 153210d:	00 00 
 153210f:	48 85 ff             	test   %rdi,%rdi
 1532112:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
 1532119:	00 
 153211a:	0f 11 83 68 01 00 00 	movups %xmm0,0x168(%rbx)
 1532121:	74 17                	je     153213a <RVecIsuIntf::init()@@Base+0xcba>
 1532123:	e8 68 f7 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1532128:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 153212f:	00 
 1532130:	48 85 ff             	test   %rdi,%rdi
 1532133:	74 05                	je     153213a <RVecIsuIntf::init()@@Base+0xcba>
 1532135:	e8 56 f7 85 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 153213a:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 1532141:	00 
 1532142:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1532146:	48 3b 3d 33 aa 64 00 	cmp    0x64aa33(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 153214d:	0f 85 55 01 00 00    	jne    15322a8 <RVecIsuIntf::init()@@Base+0xe28>
 1532153:	48 89 df             	mov    %rbx,%rdi
 1532156:	e8 b5 12 e7 fe       	call   3a3410 <RVecIsuIntf::init_intf()@plt>
 153215b:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
 1532162:	00 
 1532163:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 153216a:	00 00 
 153216c:	0f 85 40 01 00 00    	jne    15322b2 <RVecIsuIntf::init()@@Base+0xe32>
 1532172:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
 1532179:	5b                   	pop    %rbx
 153217a:	5d                   	pop    %rbp
 153217b:	41 5c                	pop    %r12
 153217d:	41 5d                	pop    %r13
 153217f:	41 5e                	pop    %r14
 1532181:	41 5f                	pop    %r15
 1532183:	c3                   	ret
 1532184:	0f 1f 40 00          	nopl   0x0(%rax)
 1532188:	e8 d3 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153218d:	e9 d9 f3 ff ff       	jmp    153156b <RVecIsuIntf::init()@@Base+0xeb>
 1532192:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1532198:	e8 c3 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153219d:	e9 6c f4 ff ff       	jmp    153160e <RVecIsuIntf::init()@@Base+0x18e>
 15321a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 15321a8:	e8 b3 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 15321ad:	e9 ff f4 ff ff       	jmp    15316b1 <RVecIsuIntf::init()@@Base+0x231>
 15321b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 15321b8:	e8 a3 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 15321bd:	e9 95 f5 ff ff       	jmp    1531757 <RVecIsuIntf::init()@@Base+0x2d7>
 15321c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 15321c8:	e8 93 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 15321cd:	e9 2e f6 ff ff       	jmp    1531800 <RVecIsuIntf::init()@@Base+0x380>
 15321d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 15321d8:	e8 83 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 15321dd:	e9 c7 f6 ff ff       	jmp    15318a9 <RVecIsuIntf::init()@@Base+0x429>
 15321e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 15321e8:	e8 73 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 15321ed:	e9 60 f7 ff ff       	jmp    1531952 <RVecIsuIntf::init()@@Base+0x4d2>
 15321f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 15321f8:	e8 63 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 15321fd:	e9 f9 f7 ff ff       	jmp    15319fb <RVecIsuIntf::init()@@Base+0x57b>
 1532202:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1532208:	e8 53 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153220d:	e9 92 f8 ff ff       	jmp    1531aa4 <RVecIsuIntf::init()@@Base+0x624>
 1532212:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1532218:	e8 43 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153221d:	e9 2b f9 ff ff       	jmp    1531b4d <RVecIsuIntf::init()@@Base+0x6cd>
 1532222:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1532228:	e8 33 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153222d:	e9 c4 f9 ff ff       	jmp    1531bf6 <RVecIsuIntf::init()@@Base+0x776>
 1532232:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1532238:	e8 23 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153223d:	e9 5d fa ff ff       	jmp    1531c9f <RVecIsuIntf::init()@@Base+0x81f>
 1532242:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1532248:	e8 13 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153224d:	e9 ee fa ff ff       	jmp    1531d40 <RVecIsuIntf::init()@@Base+0x8c0>
 1532252:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1532258:	e8 03 29 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153225d:	e9 7f fb ff ff       	jmp    1531de1 <RVecIsuIntf::init()@@Base+0x961>
 1532262:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1532268:	e8 f3 28 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153226d:	e9 24 fc ff ff       	jmp    1531e96 <RVecIsuIntf::init()@@Base+0xa16>
 1532272:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1532278:	e8 e3 28 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153227d:	e9 c9 fc ff ff       	jmp    1531f4b <RVecIsuIntf::init()@@Base+0xacb>
 1532282:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1532288:	e8 d3 28 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153228d:	e9 5a fd ff ff       	jmp    1531fec <RVecIsuIntf::init()@@Base+0xb6c>
 1532292:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1532298:	e8 c3 28 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 153229d:	e9 ff fd ff ff       	jmp    15320a1 <RVecIsuIntf::init()@@Base+0xc21>
 15322a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 15322a8:	e8 b3 28 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 15322ad:	e9 a1 fe ff ff       	jmp    1532153 <RVecIsuIntf::init()@@Base+0xcd3>
 15322b2:	e8 09 34 e6 fe       	call   3956c0 <__stack_chk_fail@plt>
 15322b7:	48 89 c3             	mov    %rax,%rbx
 15322ba:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 15322c1:	00 
 15322c2:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 15322c6:	48 3b 3d b3 a8 64 00 	cmp    0x64a8b3(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 15322cd:	74 05                	je     15322d4 <RVecIsuIntf::init()@@Base+0xe54>
 15322cf:	e8 8c 28 ff ff       	call   1524b60 <PemRVecISU::reset()@@Base+0x3e0>
 15322d4:	48 89 df             	mov    %rbx,%rdi
 15322d7:	e8 a4 0a e7 fe       	call   3a2d80 <_Unwind_Resume@plt>
 15322dc:	eb d9                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322de:	eb d7                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322e0:	eb d5                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322e2:	eb d3                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322e4:	eb d1                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322e6:	eb cf                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322e8:	eb cd                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322ea:	eb cb                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322ec:	eb c9                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322ee:	eb c7                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322f0:	eb c5                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322f2:	eb c3                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322f4:	eb c1                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322f6:	eb bf                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322f8:	eb bd                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322fa:	eb bb                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322fc:	eb b9                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
 15322fe:	eb b7                	jmp    15322b7 <RVecIsuIntf::init()@@Base+0xe37>
