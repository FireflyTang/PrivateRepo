
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013adf70 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base>:
 13adf70:	55                   	push   %rbp
 13adf71:	48 89 e5             	mov    %rsp,%rbp
 13adf74:	41 57                	push   %r15
 13adf76:	41 56                	push   %r14
 13adf78:	41 55                	push   %r13
 13adf7a:	41 54                	push   %r12
 13adf7c:	49 89 ff             	mov    %rdi,%r15
 13adf7f:	53                   	push   %rbx
 13adf80:	48 8d 9f e0 02 00 00 	lea    0x2e0(%rdi),%rbx
 13adf87:	49 89 f4             	mov    %rsi,%r12
 13adf8a:	48 81 ec 18 02 00 00 	sub    $0x218,%rsp
 13adf91:	48 89 bd d8 fd ff ff 	mov    %rdi,-0x228(%rbp)
 13adf98:	48 8b 3e             	mov    (%rsi),%rdi
 13adf9b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13adfa2:	00 00 
 13adfa4:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 13adfa8:	31 c0                	xor    %eax,%eax
 13adfaa:	e8 11 1b fe fe       	call   38fac0 <Isa::id() const@plt>
 13adfaf:	49 8b 97 e8 02 00 00 	mov    0x2e8(%r15),%rdx
 13adfb6:	48 89 d9             	mov    %rbx,%rcx
 13adfb9:	48 85 d2             	test   %rdx,%rdx
 13adfbc:	75 0e                	jne    13adfcc <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x5c>
 13adfbe:	eb 26                	jmp    13adfe6 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x76>
 13adfc0:	48 89 d1             	mov    %rdx,%rcx
 13adfc3:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 13adfc7:	48 85 d2             	test   %rdx,%rdx
 13adfca:	74 0f                	je     13adfdb <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x6b>
 13adfcc:	48 3b 42 20          	cmp    0x20(%rdx),%rax
 13adfd0:	76 ee                	jbe    13adfc0 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x50>
 13adfd2:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 13adfd6:	48 85 d2             	test   %rdx,%rdx
 13adfd9:	75 f1                	jne    13adfcc <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x5c>
 13adfdb:	48 39 cb             	cmp    %rcx,%rbx
 13adfde:	74 06                	je     13adfe6 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x76>
 13adfe0:	48 39 41 20          	cmp    %rax,0x20(%rcx)
 13adfe4:	76 2a                	jbe    13ae010 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0xa0>
 13adfe6:	31 db                	xor    %ebx,%ebx
 13adfe8:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 13adfec:	64 48 33 34 25 28 00 	xor    %fs:0x28,%rsi
 13adff3:	00 00 
 13adff5:	89 d8                	mov    %ebx,%eax
 13adff7:	0f 85 c8 06 00 00    	jne    13ae6c5 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x755>
 13adffd:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
 13ae001:	5b                   	pop    %rbx
 13ae002:	41 5c                	pop    %r12
 13ae004:	41 5d                	pop    %r13
 13ae006:	41 5e                	pop    %r14
 13ae008:	41 5f                	pop    %r15
 13ae00a:	5d                   	pop    %rbp
 13ae00b:	c3                   	ret
 13ae00c:	0f 1f 40 00          	nopl   0x0(%rax)
 13ae010:	49 8b 3c 24          	mov    (%r12),%rdi
 13ae014:	e8 a7 1a fe fe       	call   38fac0 <Isa::id() const@plt>
 13ae019:	48 8b b5 d8 fd ff ff 	mov    -0x228(%rbp),%rsi
 13ae020:	48 8b 96 e8 02 00 00 	mov    0x2e8(%rsi),%rdx
 13ae027:	48 85 d2             	test   %rdx,%rdx
 13ae02a:	0f 84 e7 02 00 00    	je     13ae317 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x3a7>
 13ae030:	48 89 de             	mov    %rbx,%rsi
 13ae033:	eb 0f                	jmp    13ae044 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0xd4>
 13ae035:	0f 1f 00             	nopl   (%rax)
 13ae038:	48 89 d6             	mov    %rdx,%rsi
 13ae03b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 13ae03f:	48 85 d2             	test   %rdx,%rdx
 13ae042:	74 0f                	je     13ae053 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0xe3>
 13ae044:	48 3b 42 20          	cmp    0x20(%rdx),%rax
 13ae048:	76 ee                	jbe    13ae038 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0xc8>
 13ae04a:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 13ae04e:	48 85 d2             	test   %rdx,%rdx
 13ae051:	75 f1                	jne    13ae044 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0xd4>
 13ae053:	48 39 f3             	cmp    %rsi,%rbx
 13ae056:	0f 84 bb 02 00 00    	je     13ae317 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x3a7>
 13ae05c:	48 3b 46 20          	cmp    0x20(%rsi),%rax
 13ae060:	0f 82 b1 02 00 00    	jb     13ae317 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x3a7>
 13ae066:	48 8b 56 28          	mov    0x28(%rsi),%rdx
 13ae06a:	8b 4e 30             	mov    0x30(%rsi),%ecx
 13ae06d:	45 31 ed             	xor    %r13d,%r13d
 13ae070:	48 8b 7e 38          	mov    0x38(%rsi),%rdi
 13ae074:	8b 76 40             	mov    0x40(%rsi),%esi
 13ae077:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 13ae07d:	48 39 d7             	cmp    %rdx,%rdi
 13ae080:	0f 94 c3             	sete   %bl
 13ae083:	39 f1                	cmp    %esi,%ecx
 13ae085:	0f 94 c0             	sete   %al
 13ae088:	20 c3                	and    %al,%bl
 13ae08a:	75 2e                	jne    13ae0ba <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x14a>
 13ae08c:	4c 89 c0             	mov    %r8,%rax
 13ae08f:	48 d3 e0             	shl    %cl,%rax
 13ae092:	48 85 02             	test   %rax,(%rdx)
 13ae095:	0f 84 b5 01 00 00    	je     13ae250 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x2e0>
 13ae09b:	41 83 c5 01          	add    $0x1,%r13d
 13ae09f:	83 f9 3f             	cmp    $0x3f,%ecx
 13ae0a2:	0f 84 98 01 00 00    	je     13ae240 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x2d0>
 13ae0a8:	83 c1 01             	add    $0x1,%ecx
 13ae0ab:	48 39 d7             	cmp    %rdx,%rdi
 13ae0ae:	0f 94 c3             	sete   %bl
 13ae0b1:	39 f1                	cmp    %esi,%ecx
 13ae0b3:	0f 94 c0             	sete   %al
 13ae0b6:	20 c3                	and    %al,%bl
 13ae0b8:	74 d2                	je     13ae08c <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x11c>
 13ae0ba:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
 13ae0c1:	49 8b 3c 24          	mov    (%r12),%rdi
 13ae0c5:	4c 8b a8 28 01 00 00 	mov    0x128(%rax),%r13
 13ae0cc:	49 89 c6             	mov    %rax,%r14
 13ae0cf:	4d 85 ed             	test   %r13,%r13
 13ae0d2:	0f 84 8a 00 00 00    	je     13ae162 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x1f2>
 13ae0d8:	e8 e3 19 fe fe       	call   38fac0 <Isa::id() const@plt>
 13ae0dd:	49 8b 34 24          	mov    (%r12),%rsi
 13ae0e1:	48 8d bd e8 fd ff ff 	lea    -0x218(%rbp),%rdi
 13ae0e8:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 13ae0ef:	e8 ac a5 fd fe       	call   3886a0 <Isa::name_str() const@plt>
 13ae0f4:	48 8b bd d8 fd ff ff 	mov    -0x228(%rbp),%rdi
 13ae0fb:	e8 d0 1b fe fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13ae100:	48 c7 85 f0 fd ff ff 	movq   $0x0,-0x210(%rbp)
 13ae107:	00 00 00 00 
 13ae10b:	c7 85 f8 fd ff ff 00 	movl   $0x0,-0x208(%rbp)
 13ae112:	00 00 00 
 13ae115:	48 c7 85 00 fe ff ff 	movq   $0x0,-0x200(%rbp)
 13ae11c:	00 00 00 00 
 13ae120:	45 8b 75 28          	mov    0x28(%r13),%r14d
 13ae124:	45 0f b6 7d 78       	movzbl 0x78(%r13),%r15d
 13ae129:	41 83 fe 02          	cmp    $0x2,%r14d
 13ae12d:	0f 8e f5 01 00 00    	jle    13ae328 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x3b8>
 13ae133:	45 84 ff             	test   %r15b,%r15b
 13ae136:	0f 85 ec 01 00 00    	jne    13ae328 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x3b8>
 13ae13c:	4c 8b 35 3d ea 7c 00 	mov    0x7cea3d(%rip),%r14        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ae143:	48 8b 85 e8 fd ff ff 	mov    -0x218(%rbp),%rax
 13ae14a:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ae14e:	4c 39 f7             	cmp    %r14,%rdi
 13ae151:	0f 85 61 03 00 00    	jne    13ae4b8 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x548>
 13ae157:	49 8b 3c 24          	mov    (%r12),%rdi
 13ae15b:	4c 8b b5 d8 fd ff ff 	mov    -0x228(%rbp),%r14
 13ae162:	e8 59 19 fe fe       	call   38fac0 <Isa::id() const@plt>
 13ae167:	49 8b b6 18 03 00 00 	mov    0x318(%r14),%rsi
 13ae16e:	4d 8d ae 10 03 00 00 	lea    0x310(%r14),%r13
 13ae175:	48 85 f6             	test   %rsi,%rsi
 13ae178:	74 38                	je     13ae1b2 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x242>
 13ae17a:	4c 89 e9             	mov    %r13,%rcx
 13ae17d:	48 89 f2             	mov    %rsi,%rdx
 13ae180:	eb 12                	jmp    13ae194 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x224>
 13ae182:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13ae188:	48 89 d1             	mov    %rdx,%rcx
 13ae18b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 13ae18f:	48 85 d2             	test   %rdx,%rdx
 13ae192:	74 0f                	je     13ae1a3 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x233>
 13ae194:	48 3b 42 20          	cmp    0x20(%rdx),%rax
 13ae198:	76 ee                	jbe    13ae188 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x218>
 13ae19a:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 13ae19e:	48 85 d2             	test   %rdx,%rdx
 13ae1a1:	75 f1                	jne    13ae194 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x224>
 13ae1a3:	49 39 cd             	cmp    %rcx,%r13
 13ae1a6:	74 0a                	je     13ae1b2 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x242>
 13ae1a8:	48 3b 41 20          	cmp    0x20(%rcx),%rax
 13ae1ac:	0f 83 36 fe ff ff    	jae    13adfe8 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x78>
 13ae1b2:	4c 8b bd d8 fd ff ff 	mov    -0x228(%rbp),%r15
 13ae1b9:	4d 8d b7 08 03 00 00 	lea    0x308(%r15),%r14
 13ae1c0:	4c 89 f7             	mov    %r14,%rdi
 13ae1c3:	e8 b8 f8 fd fe       	call   38da80 <std::_Rb_tree<unsigned long, unsigned long, std::_Identity<unsigned long>, std::less<unsigned long>, std::allocator<unsigned long> >::_M_erase(std::_Rb_tree_node<unsigned long>*)@plt>
 13ae1c8:	49 8b 3c 24          	mov    (%r12),%rdi
 13ae1cc:	49 c7 87 18 03 00 00 	movq   $0x0,0x318(%r15)
 13ae1d3:	00 00 00 00 
 13ae1d7:	4d 89 af 20 03 00 00 	mov    %r13,0x320(%r15)
 13ae1de:	4d 89 af 28 03 00 00 	mov    %r13,0x328(%r15)
 13ae1e5:	49 c7 87 30 03 00 00 	movq   $0x0,0x330(%r15)
 13ae1ec:	00 00 00 00 
 13ae1f0:	e8 cb 18 fe fe       	call   38fac0 <Isa::id() const@plt>
 13ae1f5:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 13ae1fc:	48 8d 85 10 fe ff ff 	lea    -0x1f0(%rbp),%rax
 13ae203:	4c 89 f7             	mov    %r14,%rdi
 13ae206:	48 89 c6             	mov    %rax,%rsi
 13ae209:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 13ae210:	e8 2b 69 fe fe       	call   394b40 <std::pair<std::_Rb_tree_iterator<unsigned long>, bool> std::_Rb_tree<unsigned long, unsigned long, std::_Identity<unsigned long>, std::less<unsigned long>, std::allocator<unsigned long> >::_M_insert_unique<unsigned long>(unsigned long&&)@plt>
 13ae215:	41 8b 87 e0 03 00 00 	mov    0x3e0(%r15),%eax
 13ae21c:	85 c0                	test   %eax,%eax
 13ae21e:	0f 85 3a 02 00 00    	jne    13ae45e <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x4ee>
 13ae224:	48 8b bd d8 fd ff ff 	mov    -0x228(%rbp),%rdi
 13ae22b:	4c 89 e6             	mov    %r12,%rsi
 13ae22e:	e8 5d 07 ff fe       	call   39e990 <PemRvecDepmgr::notify_vfend(std::shared_ptr<Isa> const&)@plt>
 13ae233:	e9 b0 fd ff ff       	jmp    13adfe8 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x78>
 13ae238:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 13ae23f:	00 
 13ae240:	48 83 c2 08          	add    $0x8,%rdx
 13ae244:	31 c9                	xor    %ecx,%ecx
 13ae246:	e9 32 fe ff ff       	jmp    13ae07d <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x10d>
 13ae24b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 13ae250:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
 13ae257:	4c 8b b0 28 01 00 00 	mov    0x128(%rax),%r14
 13ae25e:	4d 85 f6             	test   %r14,%r14
 13ae261:	0f 84 7f fd ff ff    	je     13adfe6 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x76>
 13ae267:	49 8b 3c 24          	mov    (%r12),%rdi
 13ae26b:	4c 8d bd e8 fd ff ff 	lea    -0x218(%rbp),%r15
 13ae272:	e8 49 18 fe fe       	call   38fac0 <Isa::id() const@plt>
 13ae277:	49 8b 34 24          	mov    (%r12),%rsi
 13ae27b:	4c 8d a5 e0 fd ff ff 	lea    -0x220(%rbp),%r12
 13ae282:	4c 89 ff             	mov    %r15,%rdi
 13ae285:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 13ae28c:	e8 0f a4 fd fe       	call   3886a0 <Isa::name_str() const@plt>
 13ae291:	44 89 ee             	mov    %r13d,%esi
 13ae294:	4c 89 e7             	mov    %r12,%rdi
 13ae297:	e8 24 8c fe fe       	call   396ec0 <PemRvecDepmgr::get_tgt_str(SMemBarUnit)@plt>
 13ae29c:	48 8b bd d8 fd ff ff 	mov    -0x228(%rbp),%rdi
 13ae2a3:	e8 28 1a fe fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13ae2a8:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 13ae2af:	48 8d 85 10 fe ff ff 	lea    -0x1f0(%rbp),%rax
 13ae2b6:	48 83 ec 08          	sub    $0x8,%rsp
 13ae2ba:	48 8d 8d f0 fd ff ff 	lea    -0x210(%rbp),%rcx
 13ae2c1:	48 8d 35 68 fa 3c 00 	lea    0x3cfa68(%rip),%rsi        # 177dd30 <_fini@@Base+0x2700c>
 13ae2c8:	4d 89 f9             	mov    %r15,%r9
 13ae2cb:	50                   	push   %rax
 13ae2cc:	4d 89 e0             	mov    %r12,%r8
 13ae2cf:	ba 2f 00 00 00       	mov    $0x2f,%edx
 13ae2d4:	4c 89 f7             	mov    %r14,%rdi
 13ae2d7:	e8 24 19 fe fe       	call   38fc00 <void spdlog::logger::info<unsigned long, std::string, std::string, unsigned long>(fmt::v11::fstring<unsigned long, std::string, std::string, unsigned long>::t, unsigned long&&, std::string&&, std::string&&, unsigned long&&)@plt>
 13ae2dc:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 13ae2e3:	4c 8b 35 96 e8 7c 00 	mov    0x7ce896(%rip),%r14        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ae2ea:	5a                   	pop    %rdx
 13ae2eb:	59                   	pop    %rcx
 13ae2ec:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ae2f0:	4c 39 f7             	cmp    %r14,%rdi
 13ae2f3:	0f 85 5b 01 00 00    	jne    13ae454 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x4e4>
 13ae2f9:	48 8b 85 e8 fd ff ff 	mov    -0x218(%rbp),%rax
 13ae300:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ae304:	4c 39 f7             	cmp    %r14,%rdi
 13ae307:	0f 84 db fc ff ff    	je     13adfe8 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x78>
 13ae30d:	e8 9e 80 ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13ae312:	e9 d1 fc ff ff       	jmp    13adfe8 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x78>
 13ae317:	48 8d 3d 82 8d 3a 00 	lea    0x3a8d82(%rip),%rdi        # 17570a0 <_fini@@Base+0x37c>
 13ae31e:	e8 bd e4 fe fe       	call   39c7e0 <std::__throw_out_of_range(char const*)@plt>
 13ae323:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 13ae328:	48 8b 15 e9 f2 7c 00 	mov    0x7cf2e9(%rip),%rdx        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 13ae32f:	48 8d bd a0 fe ff ff 	lea    -0x160(%rbp),%rdi
 13ae336:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 13ae33d:	48 8b 85 e8 fd ff ff 	mov    -0x218(%rbp),%rax
 13ae344:	48 c7 85 b0 fe ff ff 	movq   $0xfa,-0x150(%rbp)
 13ae34b:	fa 00 00 00 
 13ae34f:	4c 8d 85 70 fe ff ff 	lea    -0x190(%rbp),%r8
 13ae356:	48 8d 35 03 fa 3c 00 	lea    0x3cfa03(%rip),%rsi        # 177dd60 <_fini@@Base+0x2703c>
 13ae35d:	45 31 c9             	xor    %r9d,%r9d
 13ae360:	b9 d4 04 00 00       	mov    $0x4d4,%ecx
 13ae365:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
 13ae36c:	48 8d 57 20          	lea    0x20(%rdi),%rdx
 13ae370:	48 c7 85 a8 fe ff ff 	movq   $0x0,-0x158(%rbp)
 13ae377:	00 00 00 00 
 13ae37b:	48 89 bd c8 fd ff ff 	mov    %rdi,-0x238(%rbp)
 13ae382:	48 89 95 a0 fe ff ff 	mov    %rdx,-0x160(%rbp)
 13ae389:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 13ae38d:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 13ae394:	48 8b 85 d0 fd ff ff 	mov    -0x230(%rbp),%rax
 13ae39b:	48 89 95 88 fe ff ff 	mov    %rdx,-0x178(%rbp)
 13ae3a2:	ba 2a 00 00 00       	mov    $0x2a,%edx
 13ae3a7:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 13ae3ae:	48 8d 85 10 fe ff ff 	lea    -0x1f0(%rbp),%rax
 13ae3b5:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 13ae3bc:	e8 4f 59 ff fe       	call   3a3d10 <fmt::v11::detail::vformat_to(fmt::v11::detail::buffer<char>&, fmt::v11::basic_string_view<char>, fmt::v11::basic_format_args<fmt::v11::context>, fmt::v11::detail::locale_ref)@plt>
 13ae3c1:	49 8b 75 08          	mov    0x8(%r13),%rsi
 13ae3c5:	48 8d 8d 10 fe ff ff 	lea    -0x1f0(%rbp),%rcx
 13ae3cc:	4c 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%r8
 13ae3d3:	4c 8b 8d a8 fe ff ff 	mov    -0x158(%rbp),%r9
 13ae3da:	48 83 ec 08          	sub    $0x8,%rsp
 13ae3de:	49 89 ca             	mov    %rcx,%r10
 13ae3e1:	b9 02 00 00 00       	mov    $0x2,%ecx
 13ae3e6:	48 8b 56 e8          	mov    -0x18(%rsi),%rdx
 13ae3ea:	ff b5 00 fe ff ff    	push   -0x200(%rbp)
 13ae3f0:	4c 89 d7             	mov    %r10,%rdi
 13ae3f3:	ff b5 f8 fd ff ff    	push   -0x208(%rbp)
 13ae3f9:	ff b5 f0 fd ff ff    	push   -0x210(%rbp)
 13ae3ff:	4c 89 95 d0 fd ff ff 	mov    %r10,-0x230(%rbp)
 13ae406:	e8 45 f5 fe fe       	call   39d950 <spdlog::details::log_msg::log_msg(spdlog::source_loc, fmt::v11::basic_string_view<char>, spdlog::level::level_enum, fmt::v11::basic_string_view<char>)@plt>
 13ae40b:	31 c9                	xor    %ecx,%ecx
 13ae40d:	48 83 c4 20          	add    $0x20,%rsp
 13ae411:	48 8b b5 d0 fd ff ff 	mov    -0x230(%rbp),%rsi
 13ae418:	45 84 ff             	test   %r15b,%r15b
 13ae41b:	4c 89 ef             	mov    %r13,%rdi
 13ae41e:	0f 95 c1             	setne  %cl
 13ae421:	31 d2                	xor    %edx,%edx
 13ae423:	41 83 fe 02          	cmp    $0x2,%r14d
 13ae427:	0f 9e c2             	setle  %dl
 13ae42a:	e8 11 81 ff fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 13ae42f:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
 13ae436:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
 13ae43d:	48 83 c0 20          	add    $0x20,%rax
 13ae441:	48 39 c7             	cmp    %rax,%rdi
 13ae444:	0f 84 f2 fc ff ff    	je     13ae13c <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x1cc>
 13ae44a:	e8 31 8b fe fe       	call   396f80 <free@plt>
 13ae44f:	e9 e8 fc ff ff       	jmp    13ae13c <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x1cc>
 13ae454:	e8 57 7f ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13ae459:	e9 9b fe ff ff       	jmp    13ae2f9 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x389>
 13ae45e:	49 8b 87 58 02 00 00 	mov    0x258(%r15),%rax
 13ae465:	49 8b bf 48 02 00 00 	mov    0x248(%r15),%rdi
 13ae46c:	48 89 85 c8 fd ff ff 	mov    %rax,-0x238(%rbp)
 13ae473:	48 83 e8 10          	sub    $0x10,%rax
 13ae477:	48 39 c7             	cmp    %rax,%rdi
 13ae47a:	74 46                	je     13ae4c2 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x552>
 13ae47c:	4c 89 e6             	mov    %r12,%rsi
 13ae47f:	e8 5c 40 ff fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ae484:	49 83 87 48 02 00 00 	addq   $0x10,0x248(%r15)
 13ae48b:	10 
 13ae48c:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
 13ae493:	48 8b b5 d0 fd ff ff 	mov    -0x230(%rbp),%rsi
 13ae49a:	48 8b b8 68 02 00 00 	mov    0x268(%rax),%rdi
 13ae4a1:	8b 80 e0 03 00 00    	mov    0x3e0(%rax),%eax
 13ae4a7:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 13ae4ae:	e8 6d 8a fe fe       	call   396f20 <tm_engine::TmEvent::notify_after(unsigned long const&)@plt>
 13ae4b3:	e9 30 fb ff ff       	jmp    13adfe8 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x78>
 13ae4b8:	e8 f3 7e ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13ae4bd:	e9 95 fc ff ff       	jmp    13ae157 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x1e7>
 13ae4c2:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
 13ae4c9:	4c 8b b0 60 02 00 00 	mov    0x260(%rax),%r14
 13ae4d0:	48 8b 88 18 02 00 00 	mov    0x218(%rax),%rcx
 13ae4d7:	4c 8b a8 20 02 00 00 	mov    0x220(%rax),%r13
 13ae4de:	4c 89 f0             	mov    %r14,%rax
 13ae4e1:	48 29 c8             	sub    %rcx,%rax
 13ae4e4:	4c 89 ef             	mov    %r13,%rdi
 13ae4e7:	48 c1 f8 03          	sar    $0x3,%rax
 13ae4eb:	48 29 c7             	sub    %rax,%rdi
 13ae4ee:	48 83 ff 01          	cmp    $0x1,%rdi
 13ae4f2:	76 5b                	jbe    13ae54f <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x5df>
 13ae4f4:	bf 00 02 00 00       	mov    $0x200,%edi
 13ae4f9:	e8 62 4d fe fe       	call   393260 <operator new(unsigned long)@plt>
 13ae4fe:	49 89 46 08          	mov    %rax,0x8(%r14)
 13ae502:	4c 8b b5 d8 fd ff ff 	mov    -0x228(%rbp),%r14
 13ae509:	4c 89 e6             	mov    %r12,%rsi
 13ae50c:	49 8b be 48 02 00 00 	mov    0x248(%r14),%rdi
 13ae513:	e8 c8 3f ff fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ae518:	49 8b 86 60 02 00 00 	mov    0x260(%r14),%rax
 13ae51f:	48 8d 50 08          	lea    0x8(%rax),%rdx
 13ae523:	48 8b 40 08          	mov    0x8(%rax),%rax
 13ae527:	49 89 96 60 02 00 00 	mov    %rdx,0x260(%r14)
 13ae52e:	48 8d 90 00 02 00 00 	lea    0x200(%rax),%rdx
 13ae535:	49 89 86 50 02 00 00 	mov    %rax,0x250(%r14)
 13ae53c:	49 89 86 48 02 00 00 	mov    %rax,0x248(%r14)
 13ae543:	49 89 96 58 02 00 00 	mov    %rdx,0x258(%r14)
 13ae54a:	e9 3d ff ff ff       	jmp    13ae48c <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x51c>
 13ae54f:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
 13ae556:	48 8b b0 40 02 00 00 	mov    0x240(%rax),%rsi
 13ae55d:	4c 89 f0             	mov    %r14,%rax
 13ae560:	48 29 f0             	sub    %rsi,%rax
 13ae563:	48 c1 f8 03          	sar    $0x3,%rax
 13ae567:	4c 8d 78 02          	lea    0x2(%rax),%r15
 13ae56b:	48 8d 78 01          	lea    0x1(%rax),%rdi
 13ae56f:	4b 8d 04 3f          	lea    (%r15,%r15,1),%rax
 13ae573:	48 89 bd c8 fd ff ff 	mov    %rdi,-0x238(%rbp)
 13ae57a:	49 39 c5             	cmp    %rax,%r13
 13ae57d:	0f 86 97 00 00 00    	jbe    13ae61a <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x6aa>
 13ae583:	4c 89 e8             	mov    %r13,%rax
 13ae586:	49 83 c6 08          	add    $0x8,%r14
 13ae58a:	4c 29 f8             	sub    %r15,%rax
 13ae58d:	4c 89 f2             	mov    %r14,%rdx
 13ae590:	48 d1 e8             	shr    $1,%rax
 13ae593:	48 29 f2             	sub    %rsi,%rdx
 13ae596:	4c 8d 3c c1          	lea    (%rcx,%rax,8),%r15
 13ae59a:	4c 39 fe             	cmp    %r15,%rsi
 13ae59d:	76 61                	jbe    13ae600 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x690>
 13ae59f:	49 39 f6             	cmp    %rsi,%r14
 13ae5a2:	74 08                	je     13ae5ac <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x63c>
 13ae5a4:	4c 89 ff             	mov    %r15,%rdi
 13ae5a7:	e8 b4 18 ff fe       	call   39fe60 <memmove@plt>
 13ae5ac:	48 8b bd d8 fd ff ff 	mov    -0x228(%rbp),%rdi
 13ae5b3:	49 8b 07             	mov    (%r15),%rax
 13ae5b6:	48 89 87 30 02 00 00 	mov    %rax,0x230(%rdi)
 13ae5bd:	48 05 00 02 00 00    	add    $0x200,%rax
 13ae5c3:	4c 89 bf 40 02 00 00 	mov    %r15,0x240(%rdi)
 13ae5ca:	48 89 87 38 02 00 00 	mov    %rax,0x238(%rdi)
 13ae5d1:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
 13ae5d8:	4d 8d 74 c7 f8       	lea    -0x8(%r15,%rax,8),%r14
 13ae5dd:	49 8b 06             	mov    (%r14),%rax
 13ae5e0:	4c 89 b7 60 02 00 00 	mov    %r14,0x260(%rdi)
 13ae5e7:	48 89 87 50 02 00 00 	mov    %rax,0x250(%rdi)
 13ae5ee:	48 05 00 02 00 00    	add    $0x200,%rax
 13ae5f4:	48 89 87 58 02 00 00 	mov    %rax,0x258(%rdi)
 13ae5fb:	e9 f4 fe ff ff       	jmp    13ae4f4 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x584>
 13ae600:	49 39 f6             	cmp    %rsi,%r14
 13ae603:	74 a7                	je     13ae5ac <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x63c>
 13ae605:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
 13ae60c:	49 8d 3c c7          	lea    (%r15,%rax,8),%rdi
 13ae610:	48 29 d7             	sub    %rdx,%rdi
 13ae613:	e8 48 18 ff fe       	call   39fe60 <memmove@plt>
 13ae618:	eb 92                	jmp    13ae5ac <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x63c>
 13ae61a:	4d 85 ed             	test   %r13,%r13
 13ae61d:	0f 84 97 00 00 00    	je     13ae6ba <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x74a>
 13ae623:	4d 01 ed             	add    %r13,%r13
 13ae626:	48 b8 ff ff ff ff ff 	movabs $0x1fffffffffffffff,%rax
 13ae62d:	ff ff 1f 
 13ae630:	49 83 c5 02          	add    $0x2,%r13
 13ae634:	49 39 c5             	cmp    %rax,%r13
 13ae637:	0f 87 c9 00 00 00    	ja     13ae706 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x796>
 13ae63d:	4a 8d 3c ed 00 00 00 	lea    0x0(,%r13,8),%rdi
 13ae644:	00 
 13ae645:	e8 16 4c fe fe       	call   393260 <operator new(unsigned long)@plt>
 13ae64a:	49 89 c6             	mov    %rax,%r14
 13ae64d:	4c 89 e8             	mov    %r13,%rax
 13ae650:	4c 29 f8             	sub    %r15,%rax
 13ae653:	48 d1 e8             	shr    $1,%rax
 13ae656:	4d 8d 3c c6          	lea    (%r14,%rax,8),%r15
 13ae65a:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
 13ae661:	48 8b b0 40 02 00 00 	mov    0x240(%rax),%rsi
 13ae668:	48 8b 80 60 02 00 00 	mov    0x260(%rax),%rax
 13ae66f:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 13ae676:	48 83 c0 08          	add    $0x8,%rax
 13ae67a:	48 89 c2             	mov    %rax,%rdx
 13ae67d:	48 29 f2             	sub    %rsi,%rdx
 13ae680:	48 39 f0             	cmp    %rsi,%rax
 13ae683:	74 08                	je     13ae68d <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x71d>
 13ae685:	4c 89 ff             	mov    %r15,%rdi
 13ae688:	e8 d3 17 ff fe       	call   39fe60 <memmove@plt>
 13ae68d:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
 13ae694:	48 8b b8 18 02 00 00 	mov    0x218(%rax),%rdi
 13ae69b:	e8 80 3d fe fe       	call   392420 <operator delete(void*)@plt>
 13ae6a0:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
 13ae6a7:	4c 89 b0 18 02 00 00 	mov    %r14,0x218(%rax)
 13ae6ae:	4c 89 a8 20 02 00 00 	mov    %r13,0x220(%rax)
 13ae6b5:	e9 f2 fe ff ff       	jmp    13ae5ac <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x63c>
 13ae6ba:	41 bd 03 00 00 00    	mov    $0x3,%r13d
 13ae6c0:	e9 78 ff ff ff       	jmp    13ae63d <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x6cd>
 13ae6c5:	e8 f6 6f fe fe       	call   3956c0 <__stack_chk_fail@plt>
 13ae6ca:	48 89 c3             	mov    %rax,%rbx
 13ae6cd:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 13ae6d4:	4c 8b 35 a5 e4 7c 00 	mov    0x7ce4a5(%rip),%r14        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ae6db:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ae6df:	4c 39 f7             	cmp    %r14,%rdi
 13ae6e2:	74 05                	je     13ae6e9 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x779>
 13ae6e4:	e8 c7 7c ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13ae6e9:	48 8b 85 e8 fd ff ff 	mov    -0x218(%rbp),%rax
 13ae6f0:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ae6f4:	4c 39 f7             	cmp    %r14,%rdi
 13ae6f7:	74 05                	je     13ae6fe <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x78e>
 13ae6f9:	e8 b2 7c ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13ae6fe:	48 89 df             	mov    %rbx,%rdi
 13ae701:	e8 7a 46 ff fe       	call   3a2d80 <_Unwind_Resume@plt>
 13ae706:	e8 25 78 fd fe       	call   385f30 <std::__throw_bad_alloc()@plt>
 13ae70b:	48 89 c3             	mov    %rax,%rbx
 13ae70e:	4c 8b 35 6b e4 7c 00 	mov    0x7ce46b(%rip),%r14        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ae715:	eb d2                	jmp    13ae6e9 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x779>
 13ae717:	eb f2                	jmp    13ae70b <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x79b>
 13ae719:	49 89 d6             	mov    %rdx,%r14
 13ae71c:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
 13ae723:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
 13ae72a:	49 89 c7             	mov    %rax,%r15
 13ae72d:	48 83 c2 20          	add    $0x20,%rdx
 13ae731:	48 39 d7             	cmp    %rdx,%rdi
 13ae734:	74 05                	je     13ae73b <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x7cb>
 13ae736:	e8 45 88 fe fe       	call   396f80 <free@plt>
 13ae73b:	49 83 ee 01          	sub    $0x1,%r14
 13ae73f:	4c 89 ff             	mov    %r15,%rdi
 13ae742:	0f 85 8d 00 00 00    	jne    13ae7d5 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x865>
 13ae748:	e8 63 86 fd fe       	call   386db0 <__cxa_begin_catch@plt>
 13ae74d:	48 8b 10             	mov    (%rax),%rdx
 13ae750:	48 89 c7             	mov    %rax,%rdi
 13ae753:	ff 52 10             	call   *0x10(%rdx)
 13ae756:	4c 8b b5 d0 fd ff ff 	mov    -0x230(%rbp),%r14
 13ae75d:	48 8d 95 e0 fd ff ff 	lea    -0x220(%rbp),%rdx
 13ae764:	48 89 c6             	mov    %rax,%rsi
 13ae767:	4c 89 f7             	mov    %r14,%rdi
 13ae76a:	e8 41 4d ff fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 13ae76f:	4c 89 f6             	mov    %r14,%rsi
 13ae772:	4c 89 ef             	mov    %r13,%rdi
 13ae775:	e8 a6 69 fe fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 13ae77a:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
 13ae781:	4c 8b 35 f8 e3 7c 00 	mov    0x7ce3f8(%rip),%r14        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ae788:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ae78c:	4c 39 f7             	cmp    %r14,%rdi
 13ae78f:	74 05                	je     13ae796 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x826>
 13ae791:	e8 1a 7c ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13ae796:	e8 c5 18 ff fe       	call   3a0060 <__cxa_end_catch@plt>
 13ae79b:	e9 a3 f9 ff ff       	jmp    13ae143 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x1d3>
 13ae7a0:	48 89 c3             	mov    %rax,%rbx
 13ae7a3:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
 13ae7aa:	4c 8b 35 cf e3 7c 00 	mov    0x7ce3cf(%rip),%r14        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ae7b1:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ae7b5:	4c 39 f7             	cmp    %r14,%rdi
 13ae7b8:	74 05                	je     13ae7bf <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x84f>
 13ae7ba:	e8 f1 7b ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13ae7bf:	e8 9c 18 ff fe       	call   3a0060 <__cxa_end_catch@plt>
 13ae7c4:	e9 20 ff ff ff       	jmp    13ae6e9 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x779>
 13ae7c9:	48 89 c3             	mov    %rax,%rbx
 13ae7cc:	4c 8b 35 ad e3 7c 00 	mov    0x7ce3ad(%rip),%r14        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ae7d3:	eb ea                	jmp    13ae7bf <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x84f>
 13ae7d5:	e8 d6 85 fd fe       	call   386db0 <__cxa_begin_catch@plt>
 13ae7da:	48 8b 9d d0 fd ff ff 	mov    -0x230(%rbp),%rbx
 13ae7e1:	48 8d 95 e0 fd ff ff 	lea    -0x220(%rbp),%rdx
 13ae7e8:	48 8d 35 01 10 3c 00 	lea    0x3c1001(%rip),%rsi        # 176f7f0 <_fini@@Base+0x18acc>
 13ae7ef:	4c 8b 35 8a e3 7c 00 	mov    0x7ce38a(%rip),%r14        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ae7f6:	48 89 df             	mov    %rbx,%rdi
 13ae7f9:	e8 b2 4c ff fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 13ae7fe:	48 89 de             	mov    %rbx,%rsi
 13ae801:	4c 89 ef             	mov    %r13,%rdi
 13ae804:	e8 17 69 fe fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 13ae809:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
 13ae810:	4c 8b 35 69 e3 7c 00 	mov    0x7ce369(%rip),%r14        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ae817:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ae81b:	4c 39 f7             	cmp    %r14,%rdi
 13ae81e:	74 05                	je     13ae825 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x8b5>
 13ae820:	e8 8b 7b ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13ae825:	e8 c6 e2 fe fe       	call   39caf0 <__cxa_rethrow@plt>
 13ae82a:	48 89 c3             	mov    %rax,%rbx
 13ae82d:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
 13ae834:	4c 8b 35 45 e3 7c 00 	mov    0x7ce345(%rip),%r14        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ae83b:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ae83f:	4c 39 f7             	cmp    %r14,%rdi
 13ae842:	74 05                	je     13ae849 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x8d9>
 13ae844:	e8 67 7b ff ff       	call   13a63b0 <PemRvecDepmgr::idle()@@Base+0x160>
 13ae849:	e8 12 18 ff fe       	call   3a0060 <__cxa_end_catch@plt>
 13ae84e:	e9 96 fe ff ff       	jmp    13ae6e9 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x779>
 13ae853:	48 89 c3             	mov    %rax,%rbx
 13ae856:	eb f1                	jmp    13ae849 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@@Base+0x8d9>
 13ae858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 13ae85f:	00 
