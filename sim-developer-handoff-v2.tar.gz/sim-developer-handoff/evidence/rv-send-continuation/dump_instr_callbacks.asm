
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000e7a5d0 <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base>:
  e7a5d0:	85 ff                	test   %edi,%edi
  e7a5d2:	74 4c                	je     e7a620 <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base+0x50>
  e7a5d4:	83 ff 01             	cmp    $0x1,%edi
  e7a5d7:	74 57                	je     e7a630 <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base+0x60>
  e7a5d9:	83 ff 02             	cmp    $0x2,%edi
  e7a5dc:	74 72                	je     e7a650 <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base+0x80>
  e7a5de:	83 ff 03             	cmp    $0x3,%edi
  e7a5e1:	74 5d                	je     e7a640 <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base+0x70>
  e7a5e3:	83 ff 04             	cmp    $0x4,%edi
  e7a5e6:	74 78                	je     e7a660 <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base+0x90>
  e7a5e8:	83 ff 05             	cmp    $0x5,%edi
  e7a5eb:	0f 84 9f 00 00 00    	je     e7a690 <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base+0xc0>
  e7a5f1:	83 ff 06             	cmp    $0x6,%edi
  e7a5f4:	0f 84 a6 00 00 00    	je     e7a6a0 <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base+0xd0>
  e7a5fa:	83 ff 07             	cmp    $0x7,%edi
  e7a5fd:	74 71                	je     e7a670 <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base+0xa0>
  e7a5ff:	83 ff 08             	cmp    $0x8,%edi
  e7a602:	0f 84 a8 00 00 00    	je     e7a6b0 <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base+0xe0>
  e7a608:	83 ff 09             	cmp    $0x9,%edi
  e7a60b:	0f 84 aa 00 00 00    	je     e7a6bb <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base+0xeb>
  e7a611:	83 ff 0a             	cmp    $0xa,%edi
  e7a614:	74 65                	je     e7a67b <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@@Base+0xab>
  e7a616:	f3 c3                	repz ret
  e7a618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  e7a61f:	00 
  e7a620:	48 8b 05 91 3d d0 00 	mov    0xd03d91(%rip),%rax        # 1b7e3b8 <pem_log::PemLogCb::instr_popped_log_cb@@Base-0xd6f8>
  e7a627:	48 89 30             	mov    %rsi,(%rax)
  e7a62a:	c3                   	ret
  e7a62b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  e7a630:	48 8b 05 c1 a2 d0 00 	mov    0xd0a2c1(%rip),%rax        # 1b848f8 <pem_log::PemLogCb::instr_log_cb@@Base-0x71b0>
  e7a637:	48 89 30             	mov    %rsi,(%rax)
  e7a63a:	c3                   	ret
  e7a63b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  e7a640:	48 8b 05 39 3b d0 00 	mov    0xd03b39(%rip),%rax        # 1b7e180 <pem_log::PemLogCb::icache_log_cb@@Base-0xd918>
  e7a647:	48 89 30             	mov    %rsi,(%rax)
  e7a64a:	c3                   	ret
  e7a64b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  e7a650:	48 8b 05 a1 b2 d0 00 	mov    0xd0b2a1(%rip),%rax        # 1b858f8 <pem_log::PemLogCb::mte_log_cb@@Base-0x61a8>
  e7a657:	48 89 30             	mov    %rsi,(%rax)
  e7a65a:	c3                   	ret
  e7a65b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  e7a660:	48 8b 05 a1 9a d0 00 	mov    0xd09aa1(%rip),%rax        # 1b84108 <pem_log::PemLogCb::ifu_log_cb@@Base-0x7988>
  e7a667:	48 89 30             	mov    %rsi,(%rax)
  e7a66a:	c3                   	ret
  e7a66b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  e7a670:	48 8b 05 09 19 d0 00 	mov    0xd01909(%rip),%rax        # 1b7bf80 <pem_log::PemLogCb::reg_access_log_cb@@Base-0xfaf8>
  e7a677:	48 89 30             	mov    %rsi,(%rax)
  e7a67a:	c3                   	ret
  e7a67b:	48 8b 05 9e 65 d0 00 	mov    0xd0659e(%rip),%rax        # 1b80c20 <pem_log::PemLogCb::pmu_log_cb@@Base-0xae40>
  e7a682:	48 89 30             	mov    %rsi,(%rax)
  e7a685:	c3                   	ret
  e7a686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  e7a68d:	00 00 00 
  e7a690:	48 8b 05 49 24 d0 00 	mov    0xd02449(%rip),%rax        # 1b7cae0 <pem_log::PemLogCb::mem_access_log_cb@@Base-0xefa8>
  e7a697:	48 89 30             	mov    %rsi,(%rax)
  e7a69a:	c3                   	ret
  e7a69b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  e7a6a0:	48 8b 05 e1 a2 d0 00 	mov    0xd0a2e1(%rip),%rax        # 1b84988 <pem_log::PemLogCb::ub_req_log_cb@@Base-0x70f8>
  e7a6a7:	48 89 30             	mov    %rsi,(%rax)
  e7a6aa:	c3                   	ret
  e7a6ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  e7a6b0:	48 8b 05 b1 6f d0 00 	mov    0xd06fb1(%rip),%rax        # 1b81668 <pem_log::PemLogCb::simd_perf_log_cb@@Base-0xa408>
  e7a6b7:	48 89 30             	mov    %rsi,(%rax)
  e7a6ba:	c3                   	ret
  e7a6bb:	48 8b 05 f6 b0 d0 00 	mov    0xd0b0f6(%rip),%rax        # 1b857b8 <pem_log::PemLogCb::ccu_issueq_log_cb@@Base-0x62b0>
  e7a6c2:	48 89 30             	mov    %rsi,(%rax)
  e7a6c5:	c3                   	ret
  e7a6c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  e7a6cd:	00 00 00 

0000000000e7a6d0 <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base>:
  e7a6d0:	55                   	push   %rbp
  e7a6d1:	53                   	push   %rbx
  e7a6d2:	48 83 ec 58          	sub    $0x58,%rsp
  e7a6d6:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  e7a6dd:	00 00 
  e7a6df:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  e7a6e4:	31 c0                	xor    %eax,%eax
  e7a6e6:	48 83 3a 00          	cmpq   $0x0,(%rdx)
  e7a6ea:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
  e7a6ef:	74 2f                	je     e7a720 <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x50>
  e7a6f1:	0f b6 05 50 14 d1 00 	movzbl 0xd11450(%rip),%eax        # 1b8bb48 <global_log_cfg_t::path@@Base+0x88>
  e7a6f8:	84 c0                	test   %al,%al
  e7a6fa:	75 3c                	jne    e7a738 <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x68>
  e7a6fc:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  e7a701:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
  e7a708:	00 00 
  e7a70a:	0f 85 af 00 00 00    	jne    e7a7bf <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0xef>
  e7a710:	48 83 c4 58          	add    $0x58,%rsp
  e7a714:	5b                   	pop    %rbx
  e7a715:	5d                   	pop    %rbp
  e7a716:	c3                   	ret
  e7a717:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  e7a71e:	00 00 
  e7a720:	48 8b 05 91 3c d0 00 	mov    0xd03c91(%rip),%rax        # 1b7e3b8 <pem_log::PemLogCb::instr_popped_log_cb@@Base-0xd6f8>
  e7a727:	48 83 38 00          	cmpq   $0x0,(%rax)
  e7a72b:	74 cf                	je     e7a6fc <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x2c>
  e7a72d:	0f b6 05 14 14 d1 00 	movzbl 0xd11414(%rip),%eax        # 1b8bb48 <global_log_cfg_t::path@@Base+0x88>
  e7a734:	84 c0                	test   %al,%al
  e7a736:	74 c4                	je     e7a6fc <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x2c>
  e7a738:	48 8b 02             	mov    (%rdx),%rax
  e7a73b:	89 3c 24             	mov    %edi,(%rsp)
  e7a73e:	89 74 24 04          	mov    %esi,0x4(%rsp)
  e7a742:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  e7a747:	48 8b 42 08          	mov    0x8(%rdx),%rax
  e7a74b:	48 85 c0             	test   %rax,%rax
  e7a74e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  e7a753:	74 0e                	je     e7a763 <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x93>
  e7a755:	48 83 3d 73 9c d0 00 	cmpq   $0x0,0xd09c73(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
  e7a75c:	00 
  e7a75d:	75 59                	jne    e7a7b8 <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0xe8>
  e7a75f:	83 40 08 01          	addl   $0x1,0x8(%rax)
  e7a763:	49 8b 39             	mov    (%r9),%rdi
  e7a766:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  e7a76b:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
  e7a770:	48 83 ef 18          	sub    $0x18,%rdi
  e7a774:	e8 27 f8 ff ff       	call   e79fa0 <DvcAttachLogCallback@@Base+0x6a0>
  e7a779:	48 8b 3b             	mov    (%rbx),%rdi
  e7a77c:	48 89 e3             	mov    %rsp,%rbx
  e7a77f:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  e7a784:	48 83 ef 18          	sub    $0x18,%rdi
  e7a788:	e8 13 f8 ff ff       	call   e79fa0 <DvcAttachLogCallback@@Base+0x6a0>
  e7a78d:	48 89 df             	mov    %rbx,%rdi
  e7a790:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  e7a795:	c6 44 24 38 01       	movb   $0x1,0x38(%rsp)
  e7a79a:	c6 44 24 39 00       	movb   $0x0,0x39(%rsp)
  e7a79f:	e8 fc f3 ff ff       	call   e79ba0 <DvcAttachLogCallback@@Base+0x2a0>
  e7a7a4:	48 89 df             	mov    %rbx,%rdi
  e7a7a7:	e8 b4 e0 50 ff       	call   388860 <pem_log::AsyncInstrLogEntry::~AsyncInstrLogEntry()@plt>
  e7a7ac:	e9 4b ff ff ff       	jmp    e7a6fc <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x2c>
  e7a7b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  e7a7b8:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
  e7a7bd:	eb a4                	jmp    e7a763 <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x93>
  e7a7bf:	e8 fc ae 51 ff       	call   3956c0 <__stack_chk_fail@plt>
  e7a7c4:	48 89 c5             	mov    %rax,%rbp
  e7a7c7:	48 89 df             	mov    %rbx,%rdi
  e7a7ca:	e8 91 e0 50 ff       	call   388860 <pem_log::AsyncInstrLogEntry::~AsyncInstrLogEntry()@plt>
  e7a7cf:	48 89 ef             	mov    %rbp,%rdi
  e7a7d2:	e8 a9 85 52 ff       	call   3a2d80 <_Unwind_Resume@plt>
  e7a7d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  e7a7de:	00 00 

0000000000e7a7e0 <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base>:
  e7a7e0:	55                   	push   %rbp
  e7a7e1:	53                   	push   %rbx
  e7a7e2:	48 83 ec 58          	sub    $0x58,%rsp
  e7a7e6:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  e7a7ed:	00 00 
  e7a7ef:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  e7a7f4:	31 c0                	xor    %eax,%eax
  e7a7f6:	48 83 3a 00          	cmpq   $0x0,(%rdx)
  e7a7fa:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
  e7a7ff:	74 2f                	je     e7a830 <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x50>
  e7a801:	0f b6 05 40 13 d1 00 	movzbl 0xd11340(%rip),%eax        # 1b8bb48 <global_log_cfg_t::path@@Base+0x88>
  e7a808:	84 c0                	test   %al,%al
  e7a80a:	75 3c                	jne    e7a848 <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x68>
  e7a80c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  e7a811:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
  e7a818:	00 00 
  e7a81a:	0f 85 af 00 00 00    	jne    e7a8cf <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0xef>
  e7a820:	48 83 c4 58          	add    $0x58,%rsp
  e7a824:	5b                   	pop    %rbx
  e7a825:	5d                   	pop    %rbp
  e7a826:	c3                   	ret
  e7a827:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  e7a82e:	00 00 
  e7a830:	48 8b 05 c1 a0 d0 00 	mov    0xd0a0c1(%rip),%rax        # 1b848f8 <pem_log::PemLogCb::instr_log_cb@@Base-0x71b0>
  e7a837:	48 83 38 00          	cmpq   $0x0,(%rax)
  e7a83b:	74 cf                	je     e7a80c <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x2c>
  e7a83d:	0f b6 05 04 13 d1 00 	movzbl 0xd11304(%rip),%eax        # 1b8bb48 <global_log_cfg_t::path@@Base+0x88>
  e7a844:	84 c0                	test   %al,%al
  e7a846:	74 c4                	je     e7a80c <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x2c>
  e7a848:	48 8b 02             	mov    (%rdx),%rax
  e7a84b:	89 3c 24             	mov    %edi,(%rsp)
  e7a84e:	89 74 24 04          	mov    %esi,0x4(%rsp)
  e7a852:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  e7a857:	48 8b 42 08          	mov    0x8(%rdx),%rax
  e7a85b:	48 85 c0             	test   %rax,%rax
  e7a85e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  e7a863:	74 0e                	je     e7a873 <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x93>
  e7a865:	48 83 3d 63 9b d0 00 	cmpq   $0x0,0xd09b63(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
  e7a86c:	00 
  e7a86d:	75 59                	jne    e7a8c8 <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0xe8>
  e7a86f:	83 40 08 01          	addl   $0x1,0x8(%rax)
  e7a873:	49 8b 39             	mov    (%r9),%rdi
  e7a876:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  e7a87b:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
  e7a880:	48 83 ef 18          	sub    $0x18,%rdi
  e7a884:	e8 17 f7 ff ff       	call   e79fa0 <DvcAttachLogCallback@@Base+0x6a0>
  e7a889:	48 8b 3b             	mov    (%rbx),%rdi
  e7a88c:	48 89 e3             	mov    %rsp,%rbx
  e7a88f:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  e7a894:	48 83 ef 18          	sub    $0x18,%rdi
  e7a898:	e8 03 f7 ff ff       	call   e79fa0 <DvcAttachLogCallback@@Base+0x6a0>
  e7a89d:	48 89 df             	mov    %rbx,%rdi
  e7a8a0:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  e7a8a5:	c6 44 24 38 00       	movb   $0x0,0x38(%rsp)
  e7a8aa:	c6 44 24 39 00       	movb   $0x0,0x39(%rsp)
  e7a8af:	e8 ec f2 ff ff       	call   e79ba0 <DvcAttachLogCallback@@Base+0x2a0>
  e7a8b4:	48 89 df             	mov    %rbx,%rdi
  e7a8b7:	e8 a4 df 50 ff       	call   388860 <pem_log::AsyncInstrLogEntry::~AsyncInstrLogEntry()@plt>
  e7a8bc:	e9 4b ff ff ff       	jmp    e7a80c <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x2c>
  e7a8c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  e7a8c8:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
  e7a8cd:	eb a4                	jmp    e7a873 <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@@Base+0x93>
  e7a8cf:	e8 ec ad 51 ff       	call   3956c0 <__stack_chk_fail@plt>
  e7a8d4:	48 89 c5             	mov    %rax,%rbp
  e7a8d7:	48 89 df             	mov    %rbx,%rdi
  e7a8da:	e8 81 df 50 ff       	call   388860 <pem_log::AsyncInstrLogEntry::~AsyncInstrLogEntry()@plt>
  e7a8df:	48 89 ef             	mov    %rbp,%rdi
  e7a8e2:	e8 99 84 52 ff       	call   3a2d80 <_Unwind_Resume@plt>
  e7a8e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  e7a8ee:	00 00 
