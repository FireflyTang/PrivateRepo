
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013c0630 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base>:
 13c0630:	41 57                	push   %r15
 13c0632:	41 56                	push   %r14
 13c0634:	41 55                	push   %r13
 13c0636:	41 54                	push   %r12
 13c0638:	55                   	push   %rbp
 13c0639:	53                   	push   %rbx
 13c063a:	48 89 f5             	mov    %rsi,%rbp
 13c063d:	48 89 fb             	mov    %rdi,%rbx
 13c0640:	48 81 ec 68 03 00 00 	sub    $0x368,%rsp
 13c0647:	48 8b bf 10 02 00 00 	mov    0x210(%rdi),%rdi
 13c064e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13c0655:	00 00 
 13c0657:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
 13c065e:	00 
 13c065f:	31 c0                	xor    %eax,%eax
 13c0661:	48 8b 06             	mov    (%rsi),%rax
 13c0664:	89 14 24             	mov    %edx,(%rsp)
 13c0667:	83 b8 6c 01 00 00 04 	cmpl   $0x4,0x16c(%rax)
 13c066e:	48 8b 10             	mov    (%rax),%rdx
 13c0671:	48 8b 40 08          	mov    0x8(%rax),%rax
 13c0675:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
 13c067a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
 13c067f:	0f 84 6b 01 00 00    	je     13c07f0 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x1c0>
 13c0685:	48 85 c0             	test   %rax,%rax
 13c0688:	74 13                	je     13c069d <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x6d>
 13c068a:	48 83 3d 3e 3d 7c 00 	cmpq   $0x0,0x7c3d3e(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 13c0691:	00 
 13c0692:	0f 84 a8 01 00 00    	je     13c0840 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x210>
 13c0698:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 13c069d:	4c 8d 64 24 50       	lea    0x50(%rsp),%r12
 13c06a2:	be 06 00 00 00       	mov    $0x6,%esi
 13c06a7:	4c 89 e2             	mov    %r12,%rdx
 13c06aa:	e8 11 f1 fc fe       	call   38f7c0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@plt>
 13c06af:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
 13c06b4:	48 85 ff             	test   %rdi,%rdi
 13c06b7:	74 05                	je     13c06be <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8e>
 13c06b9:	e8 d2 11 9d ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c06be:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
 13c06c5:	48 89 ee             	mov    %rbp,%rsi
 13c06c8:	48 8b b8 00 01 00 00 	mov    0x100(%rax),%rdi
 13c06cf:	e8 dc 02 fc fe       	call   3809b0 <TmINIPort<std::shared_ptr<RVecUop>, (FcType)0>::send(std::shared_ptr<RVecUop> const&)@plt>
 13c06d4:	48 8b 45 00          	mov    0x0(%rbp),%rax
 13c06d8:	4c 8b 78 08          	mov    0x8(%rax),%r15
 13c06dc:	48 8b 28             	mov    (%rax),%rbp
 13c06df:	4d 85 ff             	test   %r15,%r15
 13c06e2:	74 13                	je     13c06f7 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0xc7>
 13c06e4:	48 83 3d e4 3c 7c 00 	cmpq   $0x0,0x7c3ce4(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 13c06eb:	00 
 13c06ec:	0f 85 ee 00 00 00    	jne    13c07e0 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x1b0>
 13c06f2:	41 83 47 08 01       	addl   $0x1,0x8(%r15)
 13c06f7:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
 13c06fc:	48 89 ee             	mov    %rbp,%rsi
 13c06ff:	e8 7c 5e fe fe       	call   3a6580 <Isa::get_rvec_isa_para()@plt>
 13c0704:	4c 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%r14
 13c070b:	4d 85 f6             	test   %r14,%r14
 13c070e:	0f 84 81 00 00 00    	je     13c0795 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x165>
 13c0714:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
 13c0719:	4c 89 ef             	mov    %r13,%rdi
 13c071c:	e8 cf 16 fe fe       	call   3a1df0 <RvecIsaPara::get_ele_count()@plt>
 13c0721:	48 89 df             	mov    %rbx,%rdi
 13c0724:	89 44 24 08          	mov    %eax,0x8(%rsp)
 13c0728:	e8 a3 f5 fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13c072d:	48 89 ef             	mov    %rbp,%rdi
 13c0730:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 13c0735:	e8 36 a1 fc fe       	call   38a870 <Isa::pc() const@plt>
 13c073a:	48 89 ef             	mov    %rbp,%rdi
 13c073d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 13c0742:	e8 79 f3 fc fe       	call   38fac0 <Isa::id() const@plt>
 13c0747:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
 13c074c:	48 89 ee             	mov    %rbp,%rsi
 13c074f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 13c0754:	e8 47 7f fc fe       	call   3886a0 <Isa::name_str() const@plt>
 13c0759:	48 89 df             	mov    %rbx,%rdi
 13c075c:	e8 6f f5 fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13c0761:	41 8b 5e 28          	mov    0x28(%r14),%ebx
 13c0765:	41 0f b6 6e 78       	movzbl 0x78(%r14),%ebp
 13c076a:	83 fb 02             	cmp    $0x2,%ebx
 13c076d:	0f 8e ed 00 00 00    	jle    13c0860 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x230>
 13c0773:	40 84 ed             	test   %bpl,%bpl
 13c0776:	0f 85 e4 00 00 00    	jne    13c0860 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x230>
 13c077c:	48 8b 1d fd c3 7b 00 	mov    0x7bc3fd(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13c0783:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 13c0788:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13c078c:	48 39 df             	cmp    %rbx,%rdi
 13c078f:	0f 85 ab 02 00 00    	jne    13c0a40 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x410>
 13c0795:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
 13c079a:	48 85 ff             	test   %rdi,%rdi
 13c079d:	74 05                	je     13c07a4 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x174>
 13c079f:	e8 ec 10 9d ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c07a4:	4d 85 ff             	test   %r15,%r15
 13c07a7:	74 08                	je     13c07b1 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x181>
 13c07a9:	4c 89 ff             	mov    %r15,%rdi
 13c07ac:	e8 df 10 9d ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c07b1:	48 8b 84 24 58 03 00 	mov    0x358(%rsp),%rax
 13c07b8:	00 
 13c07b9:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 13c07c0:	00 00 
 13c07c2:	0f 85 48 07 00 00    	jne    13c0f10 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8e0>
 13c07c8:	48 81 c4 68 03 00 00 	add    $0x368,%rsp
 13c07cf:	5b                   	pop    %rbx
 13c07d0:	5d                   	pop    %rbp
 13c07d1:	41 5c                	pop    %r12
 13c07d3:	41 5d                	pop    %r13
 13c07d5:	41 5e                	pop    %r14
 13c07d7:	41 5f                	pop    %r15
 13c07d9:	c3                   	ret
 13c07da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13c07e0:	f0 41 83 47 08 01    	lock addl $0x1,0x8(%r15)
 13c07e6:	e9 0c ff ff ff       	jmp    13c06f7 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0xc7>
 13c07eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 13c07f0:	48 85 c0             	test   %rax,%rax
 13c07f3:	74 0e                	je     13c0803 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x1d3>
 13c07f5:	48 83 3d d3 3b 7c 00 	cmpq   $0x0,0x7c3bd3(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 13c07fc:	00 
 13c07fd:	75 51                	jne    13c0850 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x220>
 13c07ff:	83 40 08 01          	addl   $0x1,0x8(%rax)
 13c0803:	4c 8d 64 24 50       	lea    0x50(%rsp),%r12
 13c0808:	be 05 00 00 00       	mov    $0x5,%esi
 13c080d:	4c 89 e2             	mov    %r12,%rdx
 13c0810:	e8 ab ef fc fe       	call   38f7c0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@plt>
 13c0815:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
 13c081a:	48 85 ff             	test   %rdi,%rdi
 13c081d:	74 05                	je     13c0824 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x1f4>
 13c081f:	e8 6c 10 9d ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c0824:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
 13c082b:	48 89 ee             	mov    %rbp,%rsi
 13c082e:	48 8b b8 00 01 00 00 	mov    0x100(%rax),%rdi
 13c0835:	e8 76 01 fc fe       	call   3809b0 <TmINIPort<std::shared_ptr<RVecUop>, (FcType)0>::send(std::shared_ptr<RVecUop> const&)@plt>
 13c083a:	e9 95 fe ff ff       	jmp    13c06d4 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0xa4>
 13c083f:	90                   	nop
 13c0840:	83 40 08 01          	addl   $0x1,0x8(%rax)
 13c0844:	e9 54 fe ff ff       	jmp    13c069d <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x6d>
 13c0849:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13c0850:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 13c0855:	eb ac                	jmp    13c0803 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x1d3>
 13c0857:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 13c085e:	00 00 
 13c0860:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
 13c0867:	00 
 13c0868:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
 13c086f:	00 
 13c0870:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 13c0875:	48 c7 84 24 c0 00 00 	movq   $0xfa,0xc0(%rsp)
 13c087c:	00 fa 00 00 00 
 13c0881:	48 8b 0d 90 cd 7b 00 	mov    0x7bcd90(%rip),%rcx        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 13c0888:	48 8d 35 59 d7 3b 00 	lea    0x3bd759(%rip),%rsi        # 177dfe8 <_fini@@Base+0x272c4>
 13c088f:	48 8d 57 20          	lea    0x20(%rdi),%rdx
 13c0893:	45 31 c9             	xor    %r9d,%r9d
 13c0896:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
 13c089d:	00 00 00 00 00 
 13c08a2:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
 13c08a7:	48 89 94 24 b0 00 00 	mov    %rdx,0xb0(%rsp)
 13c08ae:	00 
 13c08af:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 13c08b3:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
 13c08ba:	00 
 13c08bb:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 13c08c0:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 13c08c7:	00 
 13c08c8:	48 b9 d4 44 44 24 02 	movabs $0x2244444d4,%rcx
 13c08cf:	00 00 00 
 13c08d2:	48 89 94 24 e8 01 00 	mov    %rdx,0x1e8(%rsp)
 13c08d9:	00 
 13c08da:	ba 7b 00 00 00       	mov    $0x7b,%edx
 13c08df:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
 13c08e6:	00 
 13c08e7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 13c08ec:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
 13c08f3:	00 
 13c08f4:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13c08f9:	48 83 c0 01          	add    $0x1,%rax
 13c08fd:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
 13c0904:	00 
 13c0905:	49 8b 85 b8 02 00 00 	mov    0x2b8(%r13),%rax
 13c090c:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
 13c0913:	00 
 13c0914:	49 8b 85 c0 02 00 00 	mov    0x2c0(%r13),%rax
 13c091b:	4c 8d ac 24 d0 01 00 	lea    0x1d0(%rsp),%r13
 13c0922:	00 
 13c0923:	4d 89 e8             	mov    %r13,%r8
 13c0926:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
 13c092d:	00 
 13c092e:	8b 44 24 08          	mov    0x8(%rsp),%eax
 13c0932:	89 84 24 40 02 00 00 	mov    %eax,0x240(%rsp)
 13c0939:	8b 04 24             	mov    (%rsp),%eax
 13c093c:	89 84 24 50 02 00 00 	mov    %eax,0x250(%rsp)
 13c0943:	e8 c8 33 fe fe       	call   3a3d10 <fmt::v11::detail::vformat_to(fmt::v11::detail::buffer<char>&, fmt::v11::basic_string_view<char>, fmt::v11::basic_format_args<fmt::v11::context>, fmt::v11::detail::locale_ref)@plt>
 13c0948:	49 8b 56 08          	mov    0x8(%r14),%rdx
 13c094c:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 13c0953:	00 
 13c0954:	48 8b 4a e8          	mov    -0x18(%rdx),%rcx
 13c0958:	48 89 04 24          	mov    %rax,(%rsp)
 13c095c:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
 13c0963:	00 
 13c0964:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
 13c0969:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
 13c096e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13c0973:	e8 68 03 fc fe       	call   380ce0 <std::chrono::_V2::system_clock::now()@plt>
 13c0978:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 13c097d:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
 13c0982:	c7 44 24 60 02 00 00 	movl   $0x2,0x60(%rsp)
 13c0989:	00 
 13c098a:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
 13c098f:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
 13c0994:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
 13c0999:	48 8d 3d 68 b1 7b 00 	lea    0x7bb168(%rip),%rdi        # 1b7bb08 <vtable for std::bad_array_new_length@@Base+0x13c48>
 13c09a0:	e8 2b 08 fe fe       	call   3a11d0 <__tls_get_addr@plt>
 13c09a5:	80 b8 e8 01 00 00 00 	cmpb   $0x0,0x1e8(%rax)
 13c09ac:	0f 84 ae 00 00 00    	je     13c0a60 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x430>
 13c09b2:	48 8b 80 f0 01 00 00 	mov    0x1f0(%rax),%rax
 13c09b9:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
 13c09be:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 13c09c3:	83 fb 02             	cmp    $0x2,%ebx
 13c09c6:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
 13c09cd:	00 00 
 13c09cf:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
 13c09d6:	00 00 00 00 00 
 13c09db:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
 13c09e2:	00 00 00 00 00 
 13c09e7:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
 13c09ee:	00 00 00 00 
 13c09f2:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
 13c09f9:	00 
 13c09fa:	48 8b 04 24          	mov    (%rsp),%rax
 13c09fe:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
 13c0a05:	00 00 00 00 00 
 13c0a0a:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
 13c0a11:	00 
 13c0a12:	7e 3c                	jle    13c0a50 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x420>
 13c0a14:	40 84 ed             	test   %bpl,%bpl
 13c0a17:	75 77                	jne    13c0a90 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x460>
 13c0a19:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 13c0a1e:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
 13c0a25:	00 
 13c0a26:	48 83 c0 20          	add    $0x20,%rax
 13c0a2a:	48 39 c7             	cmp    %rax,%rdi
 13c0a2d:	0f 84 49 fd ff ff    	je     13c077c <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x14c>
 13c0a33:	e8 48 65 fd fe       	call   396f80 <free@plt>
 13c0a38:	e9 3f fd ff ff       	jmp    13c077c <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x14c>
 13c0a3d:	0f 1f 00             	nopl   (%rax)
 13c0a40:	e8 bb e3 ff ff       	call   13bee00 <PemRVecExu::post_tick(bool)@@Base+0x70>
 13c0a45:	e9 4b fd ff ff       	jmp    13c0795 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x165>
 13c0a4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13c0a50:	49 8b 06             	mov    (%r14),%rax
 13c0a53:	4c 89 e6             	mov    %r12,%rsi
 13c0a56:	4c 89 f7             	mov    %r14,%rdi
 13c0a59:	ff 50 18             	call   *0x18(%rax)
 13c0a5c:	eb b6                	jmp    13c0a14 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x3e4>
 13c0a5e:	66 90                	xchg   %ax,%ax
 13c0a60:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 13c0a65:	bf ba 00 00 00       	mov    $0xba,%edi
 13c0a6a:	31 c0                	xor    %eax,%eax
 13c0a6c:	e8 8f 05 fc fe       	call   381000 <syscall@plt>
 13c0a71:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 13c0a76:	48 89 82 f0 01 00 00 	mov    %rax,0x1f0(%rdx)
 13c0a7d:	c6 82 e8 01 00 00 01 	movb   $0x1,0x1e8(%rdx)
 13c0a84:	e9 30 ff ff ff       	jmp    13c09b9 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x389>
 13c0a89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13c0a90:	48 8b 2d 39 39 7c 00 	mov    0x7c3939(%rip),%rbp        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 13c0a97:	49 8d 5e 50          	lea    0x50(%r14),%rbx
 13c0a9b:	48 85 ed             	test   %rbp,%rbp
 13c0a9e:	74 18                	je     13c0ab8 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x488>
 13c0aa0:	48 89 df             	mov    %rbx,%rdi
 13c0aa3:	e8 f8 c1 fd fe       	call   39cca0 <pthread_mutex_lock@plt>
 13c0aa8:	85 c0                	test   %eax,%eax
 13c0aaa:	74 0c                	je     13c0ab8 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x488>
 13c0aac:	89 c7                	mov    %eax,%edi
 13c0aae:	e8 ad 18 39 00       	call   1752360 <std::_V2::generic_category()@@Base+0x10>
 13c0ab3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 13c0ab8:	66 0f 6f 44 24 50    	movdqa 0x50(%rsp),%xmm0
 13c0abe:	49 8d 7d 60          	lea    0x60(%r13),%rdi
 13c0ac2:	48 8b 05 4f cb 7b 00 	mov    0x7bcb4f(%rip),%rax        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 13c0ac9:	48 c7 84 24 38 02 00 	movq   $0x0,0x238(%rsp)
 13c0ad0:	00 00 00 00 00 
 13c0ad5:	66 48 0f 7e c6       	movq   %xmm0,%rsi
 13c0ada:	48 c7 84 24 40 02 00 	movq   $0xfa,0x240(%rsp)
 13c0ae1:	00 fa 00 00 00 
 13c0ae6:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
 13c0aed:	00 
 13c0aee:	48 8b 94 24 d8 01 00 	mov    0x1d8(%rsp),%rdx
 13c0af5:	00 
 13c0af6:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
 13c0afd:	00 
 13c0afe:	49 8d 85 80 00 00 00 	lea    0x80(%r13),%rax
 13c0b05:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
 13c0b0b:	48 01 f2             	add    %rsi,%rdx
 13c0b0e:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
 13c0b15:	00 
 13c0b16:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
 13c0b1d:	00 
 13c0b1e:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
 13c0b24:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
 13c0b2b:	00 
 13c0b2c:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
 13c0b33:	00 00 
 13c0b35:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
 13c0b3c:	00 
 13c0b3d:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
 13c0b44:	00 00 
 13c0b46:	0f 29 84 24 10 02 00 	movaps %xmm0,0x210(%rsp)
 13c0b4d:	00 
 13c0b4e:	66 0f 6f 84 24 a0 00 	movdqa 0xa0(%rsp),%xmm0
 13c0b55:	00 00 
 13c0b57:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
 13c0b5e:	00 
 13c0b5f:	e8 dc 43 fc fe       	call   384f40 <void fmt::v11::detail::buffer<char>::append<char>(char const*, char const*)@plt>
 13c0b64:	49 8d 7d 60          	lea    0x60(%r13),%rdi
 13c0b68:	48 8b b4 24 20 02 00 	mov    0x220(%rsp),%rsi
 13c0b6f:	00 
 13c0b70:	48 8b 94 24 28 02 00 	mov    0x228(%rsp),%rdx
 13c0b77:	00 
 13c0b78:	48 01 f2             	add    %rsi,%rdx
 13c0b7b:	e8 c0 43 fc fe       	call   384f40 <void fmt::v11::detail::buffer<char>::append<char>(char const*, char const*)@plt>
 13c0b80:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
 13c0b87:	00 
 13c0b88:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
 13c0b8f:	00 
 13c0b90:	48 01 f8             	add    %rdi,%rax
 13c0b93:	49 83 be 80 00 00 00 	cmpq   $0x0,0x80(%r14)
 13c0b9a:	00 
 13c0b9b:	48 89 bc 24 d0 01 00 	mov    %rdi,0x1d0(%rsp)
 13c0ba2:	00 
 13c0ba3:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
 13c0baa:	00 
 13c0bab:	75 2b                	jne    13c0bd8 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x5a8>
 13c0bad:	49 8d 85 80 00 00 00 	lea    0x80(%r13),%rax
 13c0bb4:	48 39 c7             	cmp    %rax,%rdi
 13c0bb7:	74 05                	je     13c0bbe <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x58e>
 13c0bb9:	e8 c2 63 fd fe       	call   396f80 <free@plt>
 13c0bbe:	48 85 ed             	test   %rbp,%rbp
 13c0bc1:	0f 84 52 fe ff ff    	je     13c0a19 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x3e9>
 13c0bc7:	48 89 df             	mov    %rbx,%rdi
 13c0bca:	e8 d1 d2 fc fe       	call   38dea0 <pthread_mutex_unlock@plt>
 13c0bcf:	e9 45 fe ff ff       	jmp    13c0a19 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x3e9>
 13c0bd4:	0f 1f 40 00          	nopl   0x0(%rax)
 13c0bd8:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 13c0bdf:	66 0f 6f 84 24 d0 01 	movdqa 0x1d0(%rsp),%xmm0
 13c0be6:	00 00 
 13c0be8:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
 13c0bec:	49 c1 e4 07          	shl    $0x7,%r12
 13c0bf0:	4d 03 a6 a0 00 00 00 	add    0xa0(%r14),%r12
 13c0bf7:	41 0f 11 04 24       	movups %xmm0,(%r12)
 13c0bfc:	4d 39 ec             	cmp    %r13,%r12
 13c0bff:	66 0f 6f 84 24 e0 01 	movdqa 0x1e0(%rsp),%xmm0
 13c0c06:	00 00 
 13c0c08:	41 0f 11 44 24 10    	movups %xmm0,0x10(%r12)
 13c0c0e:	66 0f 6f 84 24 f0 01 	movdqa 0x1f0(%rsp),%xmm0
 13c0c15:	00 00 
 13c0c17:	41 0f 11 44 24 20    	movups %xmm0,0x20(%r12)
 13c0c1d:	66 0f 6f 84 24 00 02 	movdqa 0x200(%rsp),%xmm0
 13c0c24:	00 00 
 13c0c26:	41 0f 11 44 24 30    	movups %xmm0,0x30(%r12)
 13c0c2c:	66 0f 6f 84 24 10 02 	movdqa 0x210(%rsp),%xmm0
 13c0c33:	00 00 
 13c0c35:	41 0f 11 44 24 40    	movups %xmm0,0x40(%r12)
 13c0c3b:	66 0f 6f 84 24 20 02 	movdqa 0x220(%rsp),%xmm0
 13c0c42:	00 00 
 13c0c44:	41 0f 11 44 24 50    	movups %xmm0,0x50(%r12)
 13c0c4a:	0f 84 c5 02 00 00    	je     13c0f15 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8e5>
 13c0c50:	4d 8d 9c 24 80 00 00 	lea    0x80(%r12),%r11
 13c0c57:	00 
 13c0c58:	49 8b 7c 24 60       	mov    0x60(%r12),%rdi
 13c0c5d:	4c 39 df             	cmp    %r11,%rdi
 13c0c60:	74 0d                	je     13c0c6f <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x63f>
 13c0c62:	4c 89 1c 24          	mov    %r11,(%rsp)
 13c0c66:	e8 15 63 fd fe       	call   396f80 <free@plt>
 13c0c6b:	4c 8b 1c 24          	mov    (%rsp),%r11
 13c0c6f:	48 8b 84 24 30 02 00 	mov    0x230(%rsp),%rax
 13c0c76:	00 
 13c0c77:	49 8d 8d 80 00 00 00 	lea    0x80(%r13),%rcx
 13c0c7e:	4c 8b 94 24 38 02 00 	mov    0x238(%rsp),%r10
 13c0c85:	00 
 13c0c86:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
 13c0c8d:	00 
 13c0c8e:	48 39 c8             	cmp    %rcx,%rax
 13c0c91:	0f 84 bc 00 00 00    	je     13c0d53 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x723>
 13c0c97:	49 89 54 24 70       	mov    %rdx,0x70(%r12)
 13c0c9c:	49 89 44 24 60       	mov    %rax,0x60(%r12)
 13c0ca1:	48 c7 84 24 40 02 00 	movq   $0x0,0x240(%rsp)
 13c0ca8:	00 00 00 00 00 
 13c0cad:	48 c7 84 24 38 02 00 	movq   $0x0,0x238(%rsp)
 13c0cb4:	00 00 00 00 00 
 13c0cb9:	49 8b 54 24 70       	mov    0x70(%r12),%rdx
 13c0cbe:	48 89 8c 24 30 02 00 	mov    %rcx,0x230(%rsp)
 13c0cc5:	00 
 13c0cc6:	49 8d 7c 24 60       	lea    0x60(%r12),%rdi
 13c0ccb:	49 39 d2             	cmp    %rdx,%r10
 13c0cce:	76 15                	jbe    13c0ce5 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x6b5>
 13c0cd0:	4c 89 d6             	mov    %r10,%rsi
 13c0cd3:	4c 89 14 24          	mov    %r10,(%rsp)
 13c0cd7:	41 ff 54 24 78       	call   *0x78(%r12)
 13c0cdc:	49 8b 54 24 70       	mov    0x70(%r12),%rdx
 13c0ce1:	4c 8b 14 24          	mov    (%rsp),%r10
 13c0ce5:	49 39 d2             	cmp    %rdx,%r10
 13c0ce8:	48 89 d0             	mov    %rdx,%rax
 13c0ceb:	49 8b 8e 80 00 00 00 	mov    0x80(%r14),%rcx
 13c0cf2:	49 0f 46 c2          	cmovbe %r10,%rax
 13c0cf6:	31 d2                	xor    %edx,%edx
 13c0cf8:	49 89 44 24 68       	mov    %rax,0x68(%r12)
 13c0cfd:	49 8b 44 24 60       	mov    0x60(%r12),%rax
 13c0d02:	49 89 04 24          	mov    %rax,(%r12)
 13c0d06:	49 03 44 24 08       	add    0x8(%r12),%rax
 13c0d0b:	49 89 44 24 50       	mov    %rax,0x50(%r12)
 13c0d10:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 13c0d17:	48 83 c0 01          	add    $0x1,%rax
 13c0d1b:	48 f7 f1             	div    %rcx
 13c0d1e:	49 3b 96 88 00 00 00 	cmp    0x88(%r14),%rdx
 13c0d25:	49 89 96 90 00 00 00 	mov    %rdx,0x90(%r14)
 13c0d2c:	75 18                	jne    13c0d46 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x716>
 13c0d2e:	48 8d 42 01          	lea    0x1(%rdx),%rax
 13c0d32:	31 d2                	xor    %edx,%edx
 13c0d34:	49 83 86 98 00 00 00 	addq   $0x1,0x98(%r14)
 13c0d3b:	01 
 13c0d3c:	48 f7 f1             	div    %rcx
 13c0d3f:	49 89 96 88 00 00 00 	mov    %rdx,0x88(%r14)
 13c0d46:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
 13c0d4d:	00 
 13c0d4e:	e9 5a fe ff ff       	jmp    13c0bad <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x57d>
 13c0d53:	4a 8d 34 10          	lea    (%rax,%r10,1),%rsi
 13c0d57:	4d 89 5c 24 60       	mov    %r11,0x60(%r12)
 13c0d5c:	49 89 54 24 70       	mov    %rdx,0x70(%r12)
 13c0d61:	48 39 c6             	cmp    %rax,%rsi
 13c0d64:	0f 84 5c ff ff ff    	je     13c0cc6 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x696>
 13c0d6a:	48 89 f2             	mov    %rsi,%rdx
 13c0d6d:	49 8d 7c 24 60       	lea    0x60(%r12),%rdi
 13c0d72:	4c 29 ea             	sub    %r13,%rdx
 13c0d75:	4c 8d 4a 80          	lea    -0x80(%rdx),%r9
 13c0d79:	49 8d 94 24 90 00 00 	lea    0x90(%r12),%rdx
 13c0d80:	00 
 13c0d81:	48 39 d0             	cmp    %rdx,%rax
 13c0d84:	49 8d 95 90 00 00 00 	lea    0x90(%r13),%rdx
 13c0d8b:	0f 93 c1             	setae  %cl
 13c0d8e:	4c 39 da             	cmp    %r11,%rdx
 13c0d91:	0f 96 c2             	setbe  %dl
 13c0d94:	08 d1                	or     %dl,%cl
 13c0d96:	0f 84 51 01 00 00    	je     13c0eed <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8bd>
 13c0d9c:	49 83 f9 0f          	cmp    $0xf,%r9
 13c0da0:	0f 86 47 01 00 00    	jbe    13c0eed <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8bd>
 13c0da6:	4d 89 c8             	mov    %r9,%r8
 13c0da9:	31 d2                	xor    %edx,%edx
 13c0dab:	31 c9                	xor    %ecx,%ecx
 13c0dad:	49 c1 e8 04          	shr    $0x4,%r8
 13c0db1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13c0db8:	66 0f 6f 04 10       	movdqa (%rax,%rdx,1),%xmm0
 13c0dbd:	48 83 c1 01          	add    $0x1,%rcx
 13c0dc1:	0f 11 44 17 20       	movups %xmm0,0x20(%rdi,%rdx,1)
 13c0dc6:	48 83 c2 10          	add    $0x10,%rdx
 13c0dca:	4c 39 c1             	cmp    %r8,%rcx
 13c0dcd:	72 e9                	jb     13c0db8 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x788>
 13c0dcf:	4c 89 ca             	mov    %r9,%rdx
 13c0dd2:	48 83 e2 f0          	and    $0xfffffffffffffff0,%rdx
 13c0dd6:	48 01 d0             	add    %rdx,%rax
 13c0dd9:	4c 39 ca             	cmp    %r9,%rdx
 13c0ddc:	49 8d 0c 13          	lea    (%r11,%rdx,1),%rcx
 13c0de0:	0f 84 fd 00 00 00    	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0de6:	0f b6 10             	movzbl (%rax),%edx
 13c0de9:	88 11                	mov    %dl,(%rcx)
 13c0deb:	48 8d 50 01          	lea    0x1(%rax),%rdx
 13c0def:	48 39 d6             	cmp    %rdx,%rsi
 13c0df2:	0f 84 eb 00 00 00    	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0df8:	0f b6 50 01          	movzbl 0x1(%rax),%edx
 13c0dfc:	88 51 01             	mov    %dl,0x1(%rcx)
 13c0dff:	48 8d 50 02          	lea    0x2(%rax),%rdx
 13c0e03:	48 39 d6             	cmp    %rdx,%rsi
 13c0e06:	0f 84 d7 00 00 00    	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0e0c:	0f b6 50 02          	movzbl 0x2(%rax),%edx
 13c0e10:	88 51 02             	mov    %dl,0x2(%rcx)
 13c0e13:	48 8d 50 03          	lea    0x3(%rax),%rdx
 13c0e17:	48 39 d6             	cmp    %rdx,%rsi
 13c0e1a:	0f 84 c3 00 00 00    	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0e20:	0f b6 50 03          	movzbl 0x3(%rax),%edx
 13c0e24:	88 51 03             	mov    %dl,0x3(%rcx)
 13c0e27:	48 8d 50 04          	lea    0x4(%rax),%rdx
 13c0e2b:	48 39 d6             	cmp    %rdx,%rsi
 13c0e2e:	0f 84 af 00 00 00    	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0e34:	0f b6 50 04          	movzbl 0x4(%rax),%edx
 13c0e38:	88 51 04             	mov    %dl,0x4(%rcx)
 13c0e3b:	48 8d 50 05          	lea    0x5(%rax),%rdx
 13c0e3f:	48 39 d6             	cmp    %rdx,%rsi
 13c0e42:	0f 84 9b 00 00 00    	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0e48:	0f b6 50 05          	movzbl 0x5(%rax),%edx
 13c0e4c:	88 51 05             	mov    %dl,0x5(%rcx)
 13c0e4f:	48 8d 50 06          	lea    0x6(%rax),%rdx
 13c0e53:	48 39 d6             	cmp    %rdx,%rsi
 13c0e56:	0f 84 87 00 00 00    	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0e5c:	0f b6 50 06          	movzbl 0x6(%rax),%edx
 13c0e60:	88 51 06             	mov    %dl,0x6(%rcx)
 13c0e63:	48 8d 50 07          	lea    0x7(%rax),%rdx
 13c0e67:	48 39 d6             	cmp    %rdx,%rsi
 13c0e6a:	74 77                	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0e6c:	0f b6 50 07          	movzbl 0x7(%rax),%edx
 13c0e70:	88 51 07             	mov    %dl,0x7(%rcx)
 13c0e73:	48 8d 50 08          	lea    0x8(%rax),%rdx
 13c0e77:	48 39 d6             	cmp    %rdx,%rsi
 13c0e7a:	74 67                	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0e7c:	0f b6 50 08          	movzbl 0x8(%rax),%edx
 13c0e80:	88 51 08             	mov    %dl,0x8(%rcx)
 13c0e83:	48 8d 50 09          	lea    0x9(%rax),%rdx
 13c0e87:	48 39 d6             	cmp    %rdx,%rsi
 13c0e8a:	74 57                	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0e8c:	0f b6 50 09          	movzbl 0x9(%rax),%edx
 13c0e90:	88 51 09             	mov    %dl,0x9(%rcx)
 13c0e93:	48 8d 50 0a          	lea    0xa(%rax),%rdx
 13c0e97:	48 39 d6             	cmp    %rdx,%rsi
 13c0e9a:	74 47                	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0e9c:	0f b6 50 0a          	movzbl 0xa(%rax),%edx
 13c0ea0:	88 51 0a             	mov    %dl,0xa(%rcx)
 13c0ea3:	48 8d 50 0b          	lea    0xb(%rax),%rdx
 13c0ea7:	48 39 d6             	cmp    %rdx,%rsi
 13c0eaa:	74 37                	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0eac:	0f b6 50 0b          	movzbl 0xb(%rax),%edx
 13c0eb0:	88 51 0b             	mov    %dl,0xb(%rcx)
 13c0eb3:	48 8d 50 0c          	lea    0xc(%rax),%rdx
 13c0eb7:	48 39 d6             	cmp    %rdx,%rsi
 13c0eba:	74 27                	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0ebc:	0f b6 50 0c          	movzbl 0xc(%rax),%edx
 13c0ec0:	88 51 0c             	mov    %dl,0xc(%rcx)
 13c0ec3:	48 8d 50 0d          	lea    0xd(%rax),%rdx
 13c0ec7:	48 39 d6             	cmp    %rdx,%rsi
 13c0eca:	74 17                	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0ecc:	0f b6 50 0d          	movzbl 0xd(%rax),%edx
 13c0ed0:	88 51 0d             	mov    %dl,0xd(%rcx)
 13c0ed3:	48 8d 50 0e          	lea    0xe(%rax),%rdx
 13c0ed7:	48 39 d6             	cmp    %rdx,%rsi
 13c0eda:	74 07                	je     13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0edc:	0f b6 40 0e          	movzbl 0xe(%rax),%eax
 13c0ee0:	88 41 0e             	mov    %al,0xe(%rcx)
 13c0ee3:	49 8b 54 24 70       	mov    0x70(%r12),%rdx
 13c0ee8:	e9 de fd ff ff       	jmp    13c0ccb <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x69b>
 13c0eed:	4c 29 ee             	sub    %r13,%rsi
 13c0ef0:	49 8d 8d 80 00 00 00 	lea    0x80(%r13),%rcx
 13c0ef7:	31 c0                	xor    %eax,%eax
 13c0ef9:	48 83 c6 80          	add    $0xffffffffffffff80,%rsi
 13c0efd:	0f b6 14 01          	movzbl (%rcx,%rax,1),%edx
 13c0f01:	41 88 14 03          	mov    %dl,(%r11,%rax,1)
 13c0f05:	48 83 c0 01          	add    $0x1,%rax
 13c0f09:	48 39 f0             	cmp    %rsi,%rax
 13c0f0c:	75 ef                	jne    13c0efd <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8cd>
 13c0f0e:	eb d3                	jmp    13c0ee3 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x8b3>
 13c0f10:	e8 ab 47 fd fe       	call   3956c0 <__stack_chk_fail@plt>
 13c0f15:	48 8d 15 0e 98 39 00 	lea    0x39980e(%rip),%rdx        # 175a72a <_fini@@Base+0x3a06>
 13c0f1c:	48 8d 3d f8 3d 3a 00 	lea    0x3a3df8(%rip),%rdi        # 1764d1b <_fini@@Base+0xdff7>
 13c0f23:	be 58 03 00 00       	mov    $0x358,%esi
 13c0f28:	e8 f3 95 fc fe       	call   38a520 <fmt::v11::detail::assert_fail(char const*, int, char const*)@plt>
 13c0f2d:	48 89 c3             	mov    %rax,%rbx
 13c0f30:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
 13c0f35:	48 85 ff             	test   %rdi,%rdi
 13c0f38:	74 05                	je     13c0f3f <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x90f>
 13c0f3a:	e8 51 09 9d ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c0f3f:	4d 85 ff             	test   %r15,%r15
 13c0f42:	74 08                	je     13c0f4c <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x91c>
 13c0f44:	4c 89 ff             	mov    %r15,%rdi
 13c0f47:	e8 44 09 9d ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c0f4c:	48 89 df             	mov    %rbx,%rdi
 13c0f4f:	e8 2c 1e fe fe       	call   3a2d80 <_Unwind_Resume@plt>
 13c0f54:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
 13c0f59:	48 89 c3             	mov    %rax,%rbx
 13c0f5c:	48 85 ff             	test   %rdi,%rdi
 13c0f5f:	75 e6                	jne    13c0f47 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x917>
 13c0f61:	eb e9                	jmp    13c0f4c <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x91c>
 13c0f63:	eb ef                	jmp    13c0f54 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x924>
 13c0f65:	49 89 c5             	mov    %rax,%r13
 13c0f68:	48 89 d3             	mov    %rdx,%rbx
 13c0f6b:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
 13c0f70:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
 13c0f77:	00 
 13c0f78:	48 83 c1 20          	add    $0x20,%rcx
 13c0f7c:	48 39 cf             	cmp    %rcx,%rdi
 13c0f7f:	74 05                	je     13c0f86 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x956>
 13c0f81:	e8 fa 5f fd fe       	call   396f80 <free@plt>
 13c0f86:	48 83 eb 01          	sub    $0x1,%rbx
 13c0f8a:	4c 89 ef             	mov    %r13,%rdi
 13c0f8d:	0f 85 96 00 00 00    	jne    13c1029 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x9f9>
 13c0f93:	e8 18 5e fc fe       	call   386db0 <__cxa_begin_catch@plt>
 13c0f98:	48 8b 10             	mov    (%rax),%rdx
 13c0f9b:	48 89 c7             	mov    %rax,%rdi
 13c0f9e:	ff 52 10             	call   *0x10(%rdx)
 13c0fa1:	48 8d 54 24 37       	lea    0x37(%rsp),%rdx
 13c0fa6:	48 89 c6             	mov    %rax,%rsi
 13c0fa9:	4c 89 e7             	mov    %r12,%rdi
 13c0fac:	e8 ff 24 fe fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 13c0fb1:	4c 89 e6             	mov    %r12,%rsi
 13c0fb4:	4c 89 f7             	mov    %r14,%rdi
 13c0fb7:	e8 64 41 fd fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 13c0fbc:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
 13c0fc1:	48 8b 1d b8 bb 7b 00 	mov    0x7bbbb8(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13c0fc8:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13c0fcc:	48 39 df             	cmp    %rbx,%rdi
 13c0fcf:	74 05                	je     13c0fd6 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x9a6>
 13c0fd1:	e8 2a de ff ff       	call   13bee00 <PemRVecExu::post_tick(bool)@@Base+0x70>
 13c0fd6:	e8 85 f0 fd fe       	call   3a0060 <__cxa_end_catch@plt>
 13c0fdb:	e9 a3 f7 ff ff       	jmp    13c0783 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x153>
 13c0fe0:	48 89 c5             	mov    %rax,%rbp
 13c0fe3:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
 13c0fe8:	48 8b 1d 91 bb 7b 00 	mov    0x7bbb91(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13c0fef:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13c0ff3:	48 39 df             	cmp    %rbx,%rdi
 13c0ff6:	74 05                	je     13c0ffd <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x9cd>
 13c0ff8:	e8 03 de ff ff       	call   13bee00 <PemRVecExu::post_tick(bool)@@Base+0x70>
 13c0ffd:	e8 5e f0 fd fe       	call   3a0060 <__cxa_end_catch@plt>
 13c1002:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 13c1007:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13c100b:	48 39 df             	cmp    %rbx,%rdi
 13c100e:	74 05                	je     13c1015 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x9e5>
 13c1010:	e8 eb dd ff ff       	call   13bee00 <PemRVecExu::post_tick(bool)@@Base+0x70>
 13c1015:	48 89 eb             	mov    %rbp,%rbx
 13c1018:	e9 13 ff ff ff       	jmp    13c0f30 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x900>
 13c101d:	48 89 c5             	mov    %rax,%rbp
 13c1020:	48 8b 1d 59 bb 7b 00 	mov    0x7bbb59(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13c1027:	eb d4                	jmp    13c0ffd <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x9cd>
 13c1029:	e8 82 5d fc fe       	call   386db0 <__cxa_begin_catch@plt>
 13c102e:	48 8d 54 24 37       	lea    0x37(%rsp),%rdx
 13c1033:	48 8d 35 b6 e7 3a 00 	lea    0x3ae7b6(%rip),%rsi        # 176f7f0 <_fini@@Base+0x18acc>
 13c103a:	4c 89 e7             	mov    %r12,%rdi
 13c103d:	48 8b 1d 3c bb 7b 00 	mov    0x7bbb3c(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13c1044:	e8 67 24 fe fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 13c1049:	4c 89 e6             	mov    %r12,%rsi
 13c104c:	4c 89 f7             	mov    %r14,%rdi
 13c104f:	e8 cc 40 fd fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 13c1054:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
 13c1059:	48 8b 1d 20 bb 7b 00 	mov    0x7bbb20(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13c1060:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13c1064:	48 39 df             	cmp    %rbx,%rdi
 13c1067:	74 05                	je     13c106e <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0xa3e>
 13c1069:	e8 92 dd ff ff       	call   13bee00 <PemRVecExu::post_tick(bool)@@Base+0x70>
 13c106e:	e8 7d ba fd fe       	call   39caf0 <__cxa_rethrow@plt>
 13c1073:	48 89 c5             	mov    %rax,%rbp
 13c1076:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
 13c107b:	48 8b 1d fe ba 7b 00 	mov    0x7bbafe(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13c1082:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13c1086:	48 39 df             	cmp    %rbx,%rdi
 13c1089:	74 05                	je     13c1090 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0xa60>
 13c108b:	e8 70 dd ff ff       	call   13bee00 <PemRVecExu::post_tick(bool)@@Base+0x70>
 13c1090:	e8 cb ef fd fe       	call   3a0060 <__cxa_end_catch@plt>
 13c1095:	e9 68 ff ff ff       	jmp    13c1002 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x9d2>
 13c109a:	48 89 c5             	mov    %rax,%rbp
 13c109d:	eb f1                	jmp    13c1090 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0xa60>
 13c109f:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
 13c10a6:	00 
 13c10a7:	48 89 04 24          	mov    %rax,(%rsp)
 13c10ab:	49 8d 85 80 00 00 00 	lea    0x80(%r13),%rax
 13c10b2:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 13c10b7:	48 39 c7             	cmp    %rax,%rdi
 13c10ba:	74 05                	je     13c10c1 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0xa91>
 13c10bc:	e8 bf 5e fd fe       	call   396f80 <free@plt>
 13c10c1:	48 85 ed             	test   %rbp,%rbp
 13c10c4:	74 08                	je     13c10ce <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0xa9e>
 13c10c6:	48 89 df             	mov    %rbx,%rdi
 13c10c9:	e8 d2 cd fc fe       	call   38dea0 <pthread_mutex_unlock@plt>
 13c10ce:	4c 8b 2c 24          	mov    (%rsp),%r13
 13c10d2:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
 13c10d7:	e9 8f fe ff ff       	jmp    13c0f6b <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x93b>
 13c10dc:	48 89 c3             	mov    %rax,%rbx
 13c10df:	e9 5b fe ff ff       	jmp    13c0f3f <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x90f>
 13c10e4:	48 89 c5             	mov    %rax,%rbp
 13c10e7:	48 8b 1d 92 ba 7b 00 	mov    0x7bba92(%rip),%rbx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13c10ee:	e9 0f ff ff ff       	jmp    13c1002 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@@Base+0x9d2>
 13c10f3:	90                   	nop
 13c10f4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 13c10fb:	00 00 00 00 
 13c10ff:	90                   	nop
