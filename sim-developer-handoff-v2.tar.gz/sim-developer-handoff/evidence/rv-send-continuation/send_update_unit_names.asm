
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013a8590 <PemRvecDepmgr::get_tgt_str(SMemBarUnit)@@Base>:
 13a8590:	41 54                	push   %r12
 13a8592:	4c 8b 25 e7 45 7d 00 	mov    0x7d45e7(%rip),%r12        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13a8599:	83 fe 06             	cmp    $0x6,%esi
 13a859c:	55                   	push   %rbp
 13a859d:	53                   	push   %rbx
 13a859e:	48 89 fb             	mov    %rdi,%rbx
 13a85a1:	49 8d 44 24 18       	lea    0x18(%r12),%rax
 13a85a6:	48 89 07             	mov    %rax,(%rdi)
 13a85a9:	0f 87 c1 00 00 00    	ja     13a8670 <PemRvecDepmgr::get_tgt_str(SMemBarUnit)@@Base+0xe0>
 13a85af:	48 8d 15 ea af 46 00 	lea    0x46afea(%rip),%rdx        # 18135a0 <typeinfo name for std::_Sp_counted_ptr_inplace<VecPld, std::allocator<VecPld>, (__gnu_cxx::_Lock_policy)2>@@Base+0x1a60>
 13a85b6:	89 f6                	mov    %esi,%esi
 13a85b8:	48 63 04 b2          	movslq (%rdx,%rsi,4),%rax
 13a85bc:	48 01 d0             	add    %rdx,%rax
 13a85bf:	ff e0                	jmp    *%rax
 13a85c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13a85c8:	48 8d 35 01 19 3c 00 	lea    0x3c1901(%rip),%rsi        # 1769ed0 <_fini@@Base+0x131ac>
 13a85cf:	e8 ac 6e ff fe       	call   39f480 <std::string::operator=(char const*)@plt>
 13a85d4:	48 89 d8             	mov    %rbx,%rax
 13a85d7:	5b                   	pop    %rbx
 13a85d8:	5d                   	pop    %rbp
 13a85d9:	41 5c                	pop    %r12
 13a85db:	c3                   	ret
 13a85dc:	0f 1f 40 00          	nopl   0x0(%rax)
 13a85e0:	48 8d 35 f3 18 3c 00 	lea    0x3c18f3(%rip),%rsi        # 1769eda <_fini@@Base+0x131b6>
 13a85e7:	e8 94 6e ff fe       	call   39f480 <std::string::operator=(char const*)@plt>
 13a85ec:	48 89 d8             	mov    %rbx,%rax
 13a85ef:	5b                   	pop    %rbx
 13a85f0:	5d                   	pop    %rbp
 13a85f1:	41 5c                	pop    %r12
 13a85f3:	c3                   	ret
 13a85f4:	0f 1f 40 00          	nopl   0x0(%rax)
 13a85f8:	48 8d 35 cd c4 3b 00 	lea    0x3bc4cd(%rip),%rsi        # 1764acc <_fini@@Base+0xdda8>
 13a85ff:	e8 7c 6e ff fe       	call   39f480 <std::string::operator=(char const*)@plt>
 13a8604:	48 89 d8             	mov    %rbx,%rax
 13a8607:	5b                   	pop    %rbx
 13a8608:	5d                   	pop    %rbp
 13a8609:	41 5c                	pop    %r12
 13a860b:	c3                   	ret
 13a860c:	0f 1f 40 00          	nopl   0x0(%rax)
 13a8610:	48 8d 35 b7 57 3b 00 	lea    0x3b57b7(%rip),%rsi        # 175ddce <_fini@@Base+0x70aa>
 13a8617:	e8 64 6e ff fe       	call   39f480 <std::string::operator=(char const*)@plt>
 13a861c:	48 89 d8             	mov    %rbx,%rax
 13a861f:	5b                   	pop    %rbx
 13a8620:	5d                   	pop    %rbp
 13a8621:	41 5c                	pop    %r12
 13a8623:	c3                   	ret
 13a8624:	0f 1f 40 00          	nopl   0x0(%rax)
 13a8628:	48 8d 35 b7 58 3b 00 	lea    0x3b58b7(%rip),%rsi        # 175dee6 <_fini@@Base+0x71c2>
 13a862f:	e8 4c 6e ff fe       	call   39f480 <std::string::operator=(char const*)@plt>
 13a8634:	48 89 d8             	mov    %rbx,%rax
 13a8637:	5b                   	pop    %rbx
 13a8638:	5d                   	pop    %rbp
 13a8639:	41 5c                	pop    %r12
 13a863b:	c3                   	ret
 13a863c:	0f 1f 40 00          	nopl   0x0(%rax)
 13a8640:	48 8d 35 89 c4 3b 00 	lea    0x3bc489(%rip),%rsi        # 1764ad0 <_fini@@Base+0xddac>
 13a8647:	e8 34 6e ff fe       	call   39f480 <std::string::operator=(char const*)@plt>
 13a864c:	48 89 d8             	mov    %rbx,%rax
 13a864f:	5b                   	pop    %rbx
 13a8650:	5d                   	pop    %rbp
 13a8651:	41 5c                	pop    %r12
 13a8653:	c3                   	ret
 13a8654:	0f 1f 40 00          	nopl   0x0(%rax)
 13a8658:	48 8d 35 78 c4 3b 00 	lea    0x3bc478(%rip),%rsi        # 1764ad7 <_fini@@Base+0xddb3>
 13a865f:	e8 1c 6e ff fe       	call   39f480 <std::string::operator=(char const*)@plt>
 13a8664:	48 89 d8             	mov    %rbx,%rax
 13a8667:	5b                   	pop    %rbx
 13a8668:	5d                   	pop    %rbp
 13a8669:	41 5c                	pop    %r12
 13a866b:	c3                   	ret
 13a866c:	0f 1f 40 00          	nopl   0x0(%rax)
 13a8670:	48 8d 35 83 5d 3c 00 	lea    0x3c5d83(%rip),%rsi        # 176e3fa <_fini@@Base+0x176d6>
 13a8677:	e8 04 6e ff fe       	call   39f480 <std::string::operator=(char const*)@plt>
 13a867c:	48 89 d8             	mov    %rbx,%rax
 13a867f:	5b                   	pop    %rbx
 13a8680:	5d                   	pop    %rbp
 13a8681:	41 5c                	pop    %r12
 13a8683:	c3                   	ret
