
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000015382d0 <IsuUtil::que_str(IsuQueue)@@Base>:
 15382d0:	41 54                	push   %r12
 15382d2:	4c 8b 25 a7 48 64 00 	mov    0x6448a7(%rip),%r12        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 15382d9:	83 fe 04             	cmp    $0x4,%esi
 15382dc:	55                   	push   %rbp
 15382dd:	53                   	push   %rbx
 15382de:	48 89 fb             	mov    %rdi,%rbx
 15382e1:	49 8d 44 24 18       	lea    0x18(%r12),%rax
 15382e6:	48 89 07             	mov    %rax,(%rdi)
 15382e9:	0f 87 91 00 00 00    	ja     1538380 <IsuUtil::que_str(IsuQueue)@@Base+0xb0>
 15382ef:	48 8d 15 02 05 34 00 	lea    0x340502(%rip),%rdx        # 18787f8 <typeinfo name for PemRvecValuTb_V310_1982_VALUINFO081_DAVIDV130@@Base+0x41f18>
 15382f6:	89 f6                	mov    %esi,%esi
 15382f8:	48 63 04 b2          	movslq (%rdx,%rsi,4),%rax
 15382fc:	48 01 d0             	add    %rdx,%rax
 15382ff:	ff e0                	jmp    *%rax
 1538301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1538308:	48 8d 35 f8 0c 23 00 	lea    0x230cf8(%rip),%rsi        # 1769007 <_fini@@Base+0x122e3>
 153830f:	e8 6c 71 e6 fe       	call   39f480 <std::string::operator=(char const*)@plt>
 1538314:	48 89 d8             	mov    %rbx,%rax
 1538317:	5b                   	pop    %rbx
 1538318:	5d                   	pop    %rbp
 1538319:	41 5c                	pop    %r12
 153831b:	c3                   	ret
 153831c:	0f 1f 40 00          	nopl   0x0(%rax)
 1538320:	48 8d 35 e6 0c 23 00 	lea    0x230ce6(%rip),%rsi        # 176900d <_fini@@Base+0x122e9>
 1538327:	e8 54 71 e6 fe       	call   39f480 <std::string::operator=(char const*)@plt>
 153832c:	48 89 d8             	mov    %rbx,%rax
 153832f:	5b                   	pop    %rbx
 1538330:	5d                   	pop    %rbp
 1538331:	41 5c                	pop    %r12
 1538333:	c3                   	ret
 1538334:	0f 1f 40 00          	nopl   0x0(%rax)
 1538338:	48 8d 35 be 0c 23 00 	lea    0x230cbe(%rip),%rsi        # 1768ffd <_fini@@Base+0x122d9>
 153833f:	e8 3c 71 e6 fe       	call   39f480 <std::string::operator=(char const*)@plt>
 1538344:	48 89 d8             	mov    %rbx,%rax
 1538347:	5b                   	pop    %rbx
 1538348:	5d                   	pop    %rbp
 1538349:	41 5c                	pop    %r12
 153834b:	c3                   	ret
 153834c:	0f 1f 40 00          	nopl   0x0(%rax)
 1538350:	48 8d 35 ab 0c 23 00 	lea    0x230cab(%rip),%rsi        # 1769002 <_fini@@Base+0x122de>
 1538357:	e8 24 71 e6 fe       	call   39f480 <std::string::operator=(char const*)@plt>
 153835c:	48 89 d8             	mov    %rbx,%rax
 153835f:	5b                   	pop    %rbx
 1538360:	5d                   	pop    %rbp
 1538361:	41 5c                	pop    %r12
 1538363:	c3                   	ret
 1538364:	0f 1f 40 00          	nopl   0x0(%rax)
 1538368:	48 8d 35 89 0c 23 00 	lea    0x230c89(%rip),%rsi        # 1768ff8 <_fini@@Base+0x122d4>
 153836f:	e8 0c 71 e6 fe       	call   39f480 <std::string::operator=(char const*)@plt>
 1538374:	48 89 d8             	mov    %rbx,%rax
 1538377:	5b                   	pop    %rbx
 1538378:	5d                   	pop    %rbp
 1538379:	41 5c                	pop    %r12
 153837b:	c3                   	ret
 153837c:	0f 1f 40 00          	nopl   0x0(%rax)
 1538380:	48 8d 35 73 60 23 00 	lea    0x236073(%rip),%rsi        # 176e3fa <_fini@@Base+0x176d6>
 1538387:	e8 f4 70 e6 fe       	call   39f480 <std::string::operator=(char const*)@plt>
 153838c:	48 89 d8             	mov    %rbx,%rax
 153838f:	5b                   	pop    %rbx
