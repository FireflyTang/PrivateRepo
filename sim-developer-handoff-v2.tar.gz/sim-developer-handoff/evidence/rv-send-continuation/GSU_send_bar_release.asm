
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013ca0d0 <PemRVecGSU::send_bar_release()@@Base>:
 13ca0d0:	55                   	push   %rbp
 13ca0d1:	48 89 e5             	mov    %rsp,%rbp
 13ca0d4:	41 57                	push   %r15
 13ca0d6:	41 56                	push   %r14
 13ca0d8:	41 55                	push   %r13
 13ca0da:	41 54                	push   %r12
 13ca0dc:	53                   	push   %rbx
 13ca0dd:	48 83 ec 78          	sub    $0x78,%rsp
 13ca0e1:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13ca0e8:	00 00 
 13ca0ea:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 13ca0ee:	31 c0                	xor    %eax,%eax
 13ca0f0:	48 8b 87 88 02 00 00 	mov    0x288(%rdi),%rax
 13ca0f7:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 13ca0fe:	48 39 90 00 01 00 00 	cmp    %rdx,0x100(%rax)
 13ca105:	0f 84 a1 01 00 00    	je     13ca2ac <PemRVecGSU::send_bar_release()@@Base+0x1dc>
 13ca10b:	48 8d 45 88          	lea    -0x78(%rbp),%rax
 13ca10f:	4c 8d 75 a0          	lea    -0x60(%rbp),%r14
 13ca113:	4c 8d 7d 80          	lea    -0x80(%rbp),%r15
 13ca117:	48 89 fb             	mov    %rdi,%rbx
 13ca11a:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 13ca121:	48 8d 45 98          	lea    -0x68(%rbp),%rax
 13ca125:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
 13ca12c:	0f 1f 40 00          	nopl   0x0(%rax)
 13ca130:	48 89 df             	mov    %rbx,%rdi
 13ca133:	e8 98 5b fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13ca138:	49 89 c5             	mov    %rax,%r13
 13ca13b:	48 8b 83 88 02 00 00 	mov    0x288(%rbx),%rax
 13ca142:	48 8b b0 00 01 00 00 	mov    0x100(%rax),%rsi
 13ca149:	48 39 b0 20 01 00 00 	cmp    %rsi,0x120(%rax)
 13ca150:	0f 84 aa 01 00 00    	je     13ca300 <PemRVecGSU::send_bar_release()@@Base+0x230>
 13ca156:	4c 89 f7             	mov    %r14,%rdi
 13ca159:	e8 d2 c7 fb fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ca15e:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 13ca162:	8b 80 a0 00 00 00    	mov    0xa0(%rax),%eax
 13ca168:	83 e8 01             	sub    $0x1,%eax
 13ca16b:	49 39 c5             	cmp    %rax,%r13
 13ca16e:	0f 82 ef 01 00 00    	jb     13ca363 <PemRVecGSU::send_bar_release()@@Base+0x293>
 13ca174:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
 13ca178:	48 85 ff             	test   %rdi,%rdi
 13ca17b:	74 05                	je     13ca182 <PemRVecGSU::send_bar_release()@@Base+0xb2>
 13ca17d:	e8 0e 77 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ca182:	48 8b b3 88 02 00 00 	mov    0x288(%rbx),%rsi
 13ca189:	4c 89 f7             	mov    %r14,%rdi
 13ca18c:	e8 bf a0 fc fe       	call   394250 <TmQue<std::shared_ptr<RVecUop> >::pop_front()@plt>
 13ca191:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 13ca195:	4c 8b 20             	mov    (%rax),%r12
 13ca198:	48 8b 40 08          	mov    0x8(%rax),%rax
 13ca19c:	48 85 c0             	test   %rax,%rax
 13ca19f:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 13ca1a6:	74 13                	je     13ca1bb <PemRVecGSU::send_bar_release()@@Base+0xeb>
 13ca1a8:	48 83 3d 20 a2 7b 00 	cmpq   $0x0,0x7ba220(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 13ca1af:	00 
 13ca1b0:	0f 84 3a 01 00 00    	je     13ca2f0 <PemRVecGSU::send_bar_release()@@Base+0x220>
 13ca1b6:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 13ca1bb:	4c 8b ab d0 00 00 00 	mov    0xd0(%rbx),%r13
 13ca1c2:	4d 85 ed             	test   %r13,%r13
 13ca1c5:	0f 84 99 00 00 00    	je     13ca264 <PemRVecGSU::send_bar_release()@@Base+0x194>
 13ca1cb:	4c 89 e7             	mov    %r12,%rdi
 13ca1ce:	e8 9d 06 fc fe       	call   38a870 <Isa::pc() const@plt>
 13ca1d3:	4c 89 e7             	mov    %r12,%rdi
 13ca1d6:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 13ca1da:	e8 e1 58 fc fe       	call   38fac0 <Isa::id() const@plt>
 13ca1df:	4c 89 e6             	mov    %r12,%rsi
 13ca1e2:	4c 89 ff             	mov    %r15,%rdi
 13ca1e5:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 13ca1e9:	e8 b2 e4 fb fe       	call   3886a0 <Isa::name_str() const@plt>
 13ca1ee:	48 89 df             	mov    %rbx,%rdi
 13ca1f1:	e8 da 5a fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13ca1f6:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 13ca1fa:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 13ca1fe:	48 83 ec 08          	sub    $0x8,%rsp
 13ca202:	4c 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%r8
 13ca209:	ff b5 68 ff ff ff    	push   -0x98(%rbp)
 13ca20f:	48 8d 15 1a 3f 3b 00 	lea    0x3b3f1a(%rip),%rdx        # 177e130 <_fini@@Base+0x2740c>
 13ca216:	50                   	push   %rax
 13ca217:	c7 45 b8 00 00 00 00 	movl   $0x0,-0x48(%rbp)
 13ca21e:	4d 89 f9             	mov    %r15,%r9
 13ca221:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
 13ca228:	00 
 13ca229:	ff 75 c0             	push   -0x40(%rbp)
 13ca22c:	b9 41 00 00 00       	mov    $0x41,%ecx
 13ca231:	ff 75 b8             	push   -0x48(%rbp)
 13ca234:	6a 00                	push   $0x0
 13ca236:	be 02 00 00 00       	mov    $0x2,%esi
 13ca23b:	4c 89 ef             	mov    %r13,%rdi
 13ca23e:	48 c7 45 b0 00 00 00 	movq   $0x0,-0x50(%rbp)
 13ca245:	00 
 13ca246:	e8 55 bf fb fe       	call   3861a0 <void spdlog::logger::log_<unsigned long, std::string, unsigned long, unsigned long>(spdlog::source_loc, spdlog::level::level_enum, fmt::v11::basic_string_view<char>, unsigned long&&, std::string&&, unsigned long&&, unsigned long&&)@plt>
 13ca24b:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 13ca24f:	48 83 c4 30          	add    $0x30,%rsp
 13ca253:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ca257:	48 3b 3d 22 29 7b 00 	cmp    0x7b2922(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ca25e:	0f 85 1c 01 00 00    	jne    13ca380 <PemRVecGSU::send_bar_release()@@Base+0x2b0>
 13ca264:	4c 89 f6             	mov    %r14,%rsi
 13ca267:	48 89 df             	mov    %rbx,%rdi
 13ca26a:	e8 71 32 fd fe       	call   39d4e0 <PemRVecGSU::isu_uop_done(std::shared_ptr<RVecUop>&)@plt>
 13ca26f:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 13ca276:	48 85 c0             	test   %rax,%rax
 13ca279:	74 08                	je     13ca283 <PemRVecGSU::send_bar_release()@@Base+0x1b3>
 13ca27b:	48 89 c7             	mov    %rax,%rdi
 13ca27e:	e8 0d 76 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ca283:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
 13ca287:	48 85 ff             	test   %rdi,%rdi
 13ca28a:	74 44                	je     13ca2d0 <PemRVecGSU::send_bar_release()@@Base+0x200>
 13ca28c:	e8 ff 75 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ca291:	48 8b 83 88 02 00 00 	mov    0x288(%rbx),%rax
 13ca298:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 13ca29f:	48 39 90 00 01 00 00 	cmp    %rdx,0x100(%rax)
 13ca2a6:	0f 85 84 fe ff ff    	jne    13ca130 <PemRVecGSU::send_bar_release()@@Base+0x60>
 13ca2ac:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 13ca2b0:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 13ca2b7:	00 00 
 13ca2b9:	0f 85 cb 00 00 00    	jne    13ca38a <PemRVecGSU::send_bar_release()@@Base+0x2ba>
 13ca2bf:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
 13ca2c3:	5b                   	pop    %rbx
 13ca2c4:	41 5c                	pop    %r12
 13ca2c6:	41 5d                	pop    %r13
 13ca2c8:	41 5e                	pop    %r14
 13ca2ca:	41 5f                	pop    %r15
 13ca2cc:	5d                   	pop    %rbp
 13ca2cd:	c3                   	ret
 13ca2ce:	66 90                	xchg   %ax,%ax
 13ca2d0:	48 8b 83 88 02 00 00 	mov    0x288(%rbx),%rax
 13ca2d7:	48 8b 88 20 01 00 00 	mov    0x120(%rax),%rcx
 13ca2de:	48 39 88 00 01 00 00 	cmp    %rcx,0x100(%rax)
 13ca2e5:	0f 85 45 fe ff ff    	jne    13ca130 <PemRVecGSU::send_bar_release()@@Base+0x60>
 13ca2eb:	eb bf                	jmp    13ca2ac <PemRVecGSU::send_bar_release()@@Base+0x1dc>
 13ca2ed:	0f 1f 00             	nopl   (%rax)
 13ca2f0:	83 40 08 01          	addl   $0x1,0x8(%rax)
 13ca2f4:	e9 c2 fe ff ff       	jmp    13ca1bb <PemRVecGSU::send_bar_release()@@Base+0xeb>
 13ca2f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13ca300:	4c 8b 25 a9 85 7b 00 	mov    0x7b85a9(%rip),%r12        # 1b828b0 <stderr@GLIBC_2.2.5>
 13ca307:	4c 8b 48 20          	mov    0x20(%rax),%r9
 13ca30b:	4c 8d 05 68 c6 44 00 	lea    0x44c668(%rip),%r8        # 181697a <typeinfo name for std::_Sp_counted_ptr_inplace<PemRvecExuElements, std::allocator<PemRvecExuElements>, (__gnu_cxx::_Lock_policy)2>@@Base+0xefa>
 13ca312:	48 8d 15 54 ad 39 00 	lea    0x39ad54(%rip),%rdx        # 176506d <_fini@@Base+0xe349>
 13ca319:	48 8d 35 20 97 3a 00 	lea    0x3a9720(%rip),%rsi        # 1773a40 <_fini@@Base+0x1cd1c>
 13ca320:	b9 a0 00 00 00       	mov    $0xa0,%ecx
 13ca325:	31 c0                	xor    %eax,%eax
 13ca327:	49 8b 3c 24          	mov    (%r12),%rdi
 13ca32b:	e8 e0 1f fd fe       	call   39c310 <fprintf@plt>
 13ca330:	48 8b 05 51 1c 7b 00 	mov    0x7b1c51(%rip),%rax        # 1b7bf88 <stdout@GLIBC_2.2.5>
 13ca337:	48 8b 38             	mov    (%rax),%rdi
 13ca33a:	e8 41 c8 fc fe       	call   396b80 <fflush@plt>
 13ca33f:	49 8b 3c 24          	mov    (%r12),%rdi
 13ca343:	e8 38 c8 fc fe       	call   396b80 <fflush@plt>
 13ca348:	66 0f ef c0          	pxor   %xmm0,%xmm0
 13ca34c:	0f 29 45 a0          	movaps %xmm0,-0x60(%rbp)
 13ca350:	8b 04 25 a0 00 00 00 	mov    0xa0,%eax
 13ca357:	83 e8 01             	sub    $0x1,%eax
 13ca35a:	49 39 c5             	cmp    %rax,%r13
 13ca35d:	0f 83 1f fe ff ff    	jae    13ca182 <PemRVecGSU::send_bar_release()@@Base+0xb2>
 13ca363:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
 13ca367:	48 85 ff             	test   %rdi,%rdi
 13ca36a:	0f 84 3c ff ff ff    	je     13ca2ac <PemRVecGSU::send_bar_release()@@Base+0x1dc>
 13ca370:	e8 1b 75 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ca375:	e9 32 ff ff ff       	jmp    13ca2ac <PemRVecGSU::send_bar_release()@@Base+0x1dc>
 13ca37a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13ca380:	e8 cb ca ff ff       	call   13c6e50 <PemRVecGSU::build()@@Base+0x430>
 13ca385:	e9 da fe ff ff       	jmp    13ca264 <PemRVecGSU::send_bar_release()@@Base+0x194>
 13ca38a:	e8 31 b3 fc fe       	call   3956c0 <__stack_chk_fail@plt>
 13ca38f:	48 89 c3             	mov    %rax,%rbx
 13ca392:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 13ca396:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ca39a:	48 3b 3d df 27 7b 00 	cmp    0x7b27df(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ca3a1:	74 05                	je     13ca3a8 <PemRVecGSU::send_bar_release()@@Base+0x2d8>
 13ca3a3:	e8 a8 ca ff ff       	call   13c6e50 <PemRVecGSU::build()@@Base+0x430>
 13ca3a8:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 13ca3af:	48 85 c0             	test   %rax,%rax
 13ca3b2:	74 08                	je     13ca3bc <PemRVecGSU::send_bar_release()@@Base+0x2ec>
 13ca3b4:	48 89 c7             	mov    %rax,%rdi
 13ca3b7:	e8 d4 74 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ca3bc:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
 13ca3c0:	48 85 ff             	test   %rdi,%rdi
 13ca3c3:	74 05                	je     13ca3ca <PemRVecGSU::send_bar_release()@@Base+0x2fa>
 13ca3c5:	e8 c6 74 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ca3ca:	48 89 df             	mov    %rbx,%rdi
 13ca3cd:	e8 ae 89 fd fe       	call   3a2d80 <_Unwind_Resume@plt>
 13ca3d2:	48 89 c3             	mov    %rax,%rbx
 13ca3d5:	eb d1                	jmp    13ca3a8 <PemRVecGSU::send_bar_release()@@Base+0x2d8>
 13ca3d7:	90                   	nop
 13ca3d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 13ca3df:	00 
