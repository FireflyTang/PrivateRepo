
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000f910ff <IsaDefine::IsaDefine()@@Base+0x558f>:
  f910ff:	48 8d bb a8 00 00 00 	lea    0xa8(%rbx),%rdi
  f91106:	48 8d 35 63 d8 7c 00 	lea    0x7cd863(%rip),%rsi        # 175e970 <_fini@@Base+0x7c4c>
  f9110d:	4c 89 ea             	mov    %r13,%rdx
  f91110:	c7 84 24 c0 04 00 00 	movl   $0xd,0x4c0(%rsp)
  f91117:	0d 00 00 00 
  f9111b:	e8 90 23 41 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  f91120:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  f91125:	48 8d bb b8 00 00 00 	lea    0xb8(%rbx),%rdi
  f9112c:	48 8d 35 44 d8 7c 00 	lea    0x7cd844(%rip),%rsi        # 175e977 <_fini@@Base+0x7c53>
  f91133:	c7 84 24 d0 04 00 00 	movl   $0xe,0x4d0(%rsp)
  f9113a:	0e 00 00 00 
  f9113e:	e8 6d 23 41 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  f91143:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  f91148:	48 8d bb c8 00 00 00 	lea    0xc8(%rbx),%rdi
  f9114f:	48 8d 35 28 d8 7c 00 	lea    0x7cd828(%rip),%rsi        # 175e97e <_fini@@Base+0x7c5a>
  f91156:	c7 84 24 e0 04 00 00 	movl   $0xf,0x4e0(%rsp)
  f9115d:	0f 00 00 00 
  f91161:	e8 4a 23 41 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  f91166:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  f9116d:	00 
  f9116e:	48 8d bb d8 00 00 00 	lea    0xd8(%rbx),%rdi
  f91175:	48 8d 35 09 d8 7c 00 	lea    0x7cd809(%rip),%rsi        # 175e985 <_fini@@Base+0x7c61>
  f9117c:	c7 84 24 f0 04 00 00 	movl   $0x10,0x4f0(%rsp)
  f91183:	10 00 00 00 
  f91187:	e8 24 23 41 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  f9118c:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
  f91193:	00 
  f91194:	48 8d bb e8 00 00 00 	lea    0xe8(%rbx),%rdi
  f9119b:	48 8d 35 ea d7 7c 00 	lea    0x7cd7ea(%rip),%rsi        # 175e98c <_fini@@Base+0x7c68>
  f911a2:	c7 84 24 00 05 00 00 	movl   $0x11,0x500(%rsp)
  f911a9:	11 00 00 00 
  f911ad:	e8 fe 22 41 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
