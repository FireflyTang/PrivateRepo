
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000e7ccf0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x710>:
  e7ccf0:	55                   	push   %rbp
  e7ccf1:	48 89 e5             	mov    %rsp,%rbp
  e7ccf4:	41 57                	push   %r15
  e7ccf6:	41 56                	push   %r14
  e7ccf8:	41 55                	push   %r13
  e7ccfa:	41 54                	push   %r12
  e7ccfc:	49 89 f6             	mov    %rsi,%r14
  e7ccff:	53                   	push   %rbx
  e7cd00:	48 81 ec 98 01 00 00 	sub    $0x198,%rsp
  e7cd07:	48 89 bd 88 fe ff ff 	mov    %rdi,-0x178(%rbp)
  e7cd0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  e7cd15:	00 00 
  e7cd17:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
  e7cd1b:	31 c0                	xor    %eax,%eax
  e7cd1d:	8b 05 4d 93 d0 00    	mov    0xd0934d(%rip),%eax        # 1b86070 <DvcConfig::GlobalConfig::core_ver_@@Base+0x70>
  e7cd23:	3d ff 00 00 00       	cmp    $0xff,%eax
  e7cd28:	89 85 a8 fe ff ff    	mov    %eax,-0x158(%rbp)
  e7cd2e:	75 09                	jne    e7cd39 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x759>
  e7cd30:	8b 46 14             	mov    0x14(%rsi),%eax
  e7cd33:	89 85 a8 fe ff ff    	mov    %eax,-0x158(%rbp)
  e7cd39:	8b 1d 2d 93 d0 00    	mov    0xd0932d(%rip),%ebx        # 1b8606c <DvcConfig::GlobalConfig::core_ver_@@Base+0x6c>
  e7cd3f:	81 fb ff 00 00 00    	cmp    $0xff,%ebx
  e7cd45:	75 04                	jne    e7cd4b <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x76b>
  e7cd47:	41 8b 5e 10          	mov    0x10(%r14),%ebx
  e7cd4b:	8b 05 17 93 d0 00    	mov    0xd09317(%rip),%eax        # 1b86068 <DvcConfig::GlobalConfig::core_ver_@@Base+0x68>
  e7cd51:	3d ff 00 00 00       	cmp    $0xff,%eax
  e7cd56:	89 85 90 fe ff ff    	mov    %eax,-0x170(%rbp)
  e7cd5c:	75 0a                	jne    e7cd68 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x788>
  e7cd5e:	41 8b 46 18          	mov    0x18(%r14),%eax
  e7cd62:	89 85 90 fe ff ff    	mov    %eax,-0x170(%rbp)
  e7cd68:	80 3d 31 05 d1 00 00 	cmpb   $0x0,0xd10531(%rip)        # 1b8d2a0 <global_log_cfg_t::path@@Base+0x17e0>
  e7cd6f:	0f 84 5b 0a 00 00    	je     e7d7d0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x11f0>
  e7cd75:	48 8b 05 e4 92 d0 00 	mov    0xd092e4(%rip),%rax        # 1b86060 <DvcConfig::GlobalConfig::core_ver_@@Base+0x60>
  e7cd7c:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
  e7cd83:	8b 05 d3 92 d0 00    	mov    0xd092d3(%rip),%eax        # 1b8605c <DvcConfig::GlobalConfig::core_ver_@@Base+0x5c>
  e7cd89:	89 85 80 fe ff ff    	mov    %eax,-0x180(%rbp)
  e7cd8f:	bf 28 02 00 00       	mov    $0x228,%edi
  e7cd94:	e8 c7 64 51 ff       	call   393260 <operator new(unsigned long)@plt>
  e7cd99:	48 8d 0d a4 dd 8d 00 	lea    0x8ddda4(%rip),%rcx        # 175ab44 <_fini@@Base+0x3e20>
  e7cda0:	49 89 c7             	mov    %rax,%r15
  e7cda3:	48 8b 15 8e 02 d0 00 	mov    0xd0028e(%rip),%rdx        # 1b7d038 <vtable for spdlog::sinks::ansicolor_sink<spdlog::details::console_mutex>@@Base+0x35860>
  e7cdaa:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
  e7cdb1:	00 00 00 
  e7cdb4:	41 c7 47 18 00 00 00 	movl   $0x0,0x18(%r15)
  e7cdbb:	00 
  e7cdbc:	49 c7 47 28 03 00 00 	movq   $0x3,0x28(%r15)
  e7cdc3:	00 
  e7cdc4:	49 89 4f 20          	mov    %rcx,0x20(%r15)
  e7cdc8:	48 8d 0d ff dd 8d 00 	lea    0x8dddff(%rip),%rcx        # 175abce <_fini@@Base+0x3eaa>
  e7cdcf:	49 89 47 08          	mov    %rax,0x8(%r15)
  e7cdd3:	48 83 c2 10          	add    $0x10,%rdx
  e7cdd7:	48 8b 05 82 21 d0 00 	mov    0xd02182(%rip),%rax        # 1b7ef60 <vtable for std::_Sp_counted_ptr_inplace<spdlog::sinks::ansicolor_stdout_sink<spdlog::details::console_mutex>, std::allocator<spdlog::sinks::ansicolor_stdout_sink<spdlog::details::console_mutex> >, (__gnu_cxx::_Lock_policy)2>@@Base+0x37620>
  e7cdde:	49 c7 47 38 04 00 00 	movq   $0x4,0x38(%r15)
  e7cde5:	00 
  e7cde6:	49 89 4f 30          	mov    %rcx,0x30(%r15)
  e7cdea:	48 8d 0d 57 dd 8d 00 	lea    0x8ddd57(%rip),%rcx        # 175ab48 <_fini@@Base+0x3e24>
  e7cdf1:	49 89 57 10          	mov    %rdx,0x10(%r15)
  e7cdf5:	48 8d 15 6f dd 8d 00 	lea    0x8ddd6f(%rip),%rdx        # 175ab6b <_fini@@Base+0x3e47>
  e7cdfc:	49 c7 47 48 04 00 00 	movq   $0x4,0x48(%r15)
  e7ce03:	00 
  e7ce04:	49 c7 47 58 04 00 00 	movq   $0x4,0x58(%r15)
  e7ce0b:	00 
  e7ce0c:	49 89 4f 40          	mov    %rcx,0x40(%r15)
  e7ce10:	48 8d 0d 36 dd 8d 00 	lea    0x8ddd36(%rip),%rcx        # 175ab4d <_fini@@Base+0x3e29>
  e7ce17:	48 83 c0 10          	add    $0x10,%rax
  e7ce1b:	49 89 97 b0 00 00 00 	mov    %rdx,0xb0(%r15)
  e7ce22:	48 8d 15 4e dd 8d 00 	lea    0x8ddd4e(%rip),%rdx        # 175ab77 <_fini@@Base+0x3e53>
  e7ce29:	49 89 07             	mov    %rax,(%r15)
  e7ce2c:	49 89 4f 50          	mov    %rcx,0x50(%r15)
  e7ce30:	48 8d 0d 1b dd 8d 00 	lea    0x8ddd1b(%rip),%rcx        # 175ab52 <_fini@@Base+0x3e2e>
  e7ce37:	48 8b 05 4a f1 cf 00 	mov    0xcff14a(%rip),%rax        # 1b7bf88 <stdout@GLIBC_2.2.5>
  e7ce3e:	49 89 97 d0 00 00 00 	mov    %rdx,0xd0(%r15)
  e7ce45:	48 8d 15 37 dd 8d 00 	lea    0x8ddd37(%rip),%rdx        # 175ab83 <_fini@@Base+0x3e5f>
  e7ce4c:	49 c7 47 68 04 00 00 	movq   $0x4,0x68(%r15)
  e7ce53:	00 
  e7ce54:	49 89 4f 60          	mov    %rcx,0x60(%r15)
  e7ce58:	48 8d 0d f8 dc 8d 00 	lea    0x8ddcf8(%rip),%rcx        # 175ab57 <_fini@@Base+0x3e33>
  e7ce5f:	49 c7 47 78 04 00 00 	movq   $0x4,0x78(%r15)
  e7ce66:	00 
  e7ce67:	48 8b 00             	mov    (%rax),%rax
  e7ce6a:	49 c7 87 88 00 00 00 	movq   $0x4,0x88(%r15)
  e7ce71:	04 00 00 00 
  e7ce75:	48 8d 35 98 ef 8d 00 	lea    0x8def98(%rip),%rsi        # 175be14 <_fini@@Base+0x50f0>
  e7ce7c:	49 89 4f 70          	mov    %rcx,0x70(%r15)
  e7ce80:	48 8d 0d d5 dc 8d 00 	lea    0x8ddcd5(%rip),%rcx        # 175ab5c <_fini@@Base+0x3e38>
  e7ce87:	49 c7 87 98 00 00 00 	movq   $0x3,0x98(%r15)
  e7ce8e:	03 00 00 00 
  e7ce92:	49 c7 87 a8 00 00 00 	movq   $0x5,0xa8(%r15)
  e7ce99:	05 00 00 00 
  e7ce9d:	49 c7 87 b8 00 00 00 	movq   $0x5,0xb8(%r15)
  e7cea4:	05 00 00 00 
  e7cea8:	49 89 8f 80 00 00 00 	mov    %rcx,0x80(%r15)
  e7ceaf:	48 8d 0d ab dc 8d 00 	lea    0x8ddcab(%rip),%rcx        # 175ab61 <_fini@@Base+0x3e3d>
  e7ceb6:	49 c7 87 c8 00 00 00 	movq   $0x5,0xc8(%r15)
  e7cebd:	05 00 00 00 
  e7cec1:	49 c7 87 d8 00 00 00 	movq   $0x5,0xd8(%r15)
  e7cec8:	05 00 00 00 
  e7cecc:	49 89 8f 90 00 00 00 	mov    %rcx,0x90(%r15)
  e7ced3:	48 8d 0d 8b dc 8d 00 	lea    0x8ddc8b(%rip),%rcx        # 175ab65 <_fini@@Base+0x3e41>
  e7ceda:	49 89 8f a0 00 00 00 	mov    %rcx,0xa0(%r15)
  e7cee1:	48 8d 0d 89 dc 8d 00 	lea    0x8ddc89(%rip),%rcx        # 175ab71 <_fini@@Base+0x3e4d>
  e7cee8:	49 89 8f c0 00 00 00 	mov    %rcx,0xc0(%r15)
  e7ceef:	48 8d 0d 87 dc 8d 00 	lea    0x8ddc87(%rip),%rcx        # 175ab7d <_fini@@Base+0x3e59>
  e7cef6:	49 89 8f e0 00 00 00 	mov    %rcx,0xe0(%r15)
  e7cefd:	49 89 97 f0 00 00 00 	mov    %rdx,0xf0(%r15)
  e7cf04:	48 8d 0d 7e dc 8d 00 	lea    0x8ddc7e(%rip),%rcx        # 175ab89 <_fini@@Base+0x3e65>
  e7cf0b:	48 8d 15 7d dc 8d 00 	lea    0x8ddc7d(%rip),%rdx        # 175ab8f <_fini@@Base+0x3e6b>
  e7cf12:	49 89 87 d0 01 00 00 	mov    %rax,0x1d0(%r15)
  e7cf19:	48 8b 05 e0 ef cf 00 	mov    0xcfefe0(%rip),%rax        # 1b7bf00 <spdlog::details::console_mutex::mutex()::s_mutex@@Base-0x11600>
  e7cf20:	49 89 8f 00 01 00 00 	mov    %rcx,0x100(%r15)
  e7cf27:	48 8d 0d 67 dc 8d 00 	lea    0x8ddc67(%rip),%rcx        # 175ab95 <_fini@@Base+0x3e71>
  e7cf2e:	49 c7 87 e8 00 00 00 	movq   $0x5,0xe8(%r15)
  e7cf35:	05 00 00 00 
  e7cf39:	49 89 97 10 01 00 00 	mov    %rdx,0x110(%r15)
  e7cf40:	48 8d 15 90 dc 8d 00 	lea    0x8ddc90(%rip),%rdx        # 175abd7 <_fini@@Base+0x3eb3>
  e7cf47:	49 c7 87 f8 00 00 00 	movq   $0x5,0xf8(%r15)
  e7cf4e:	05 00 00 00 
  e7cf52:	49 89 8f 20 01 00 00 	mov    %rcx,0x120(%r15)
  e7cf59:	48 8d 0d 3b dc 8d 00 	lea    0x8ddc3b(%rip),%rcx        # 175ab9b <_fini@@Base+0x3e77>
  e7cf60:	49 89 87 d8 01 00 00 	mov    %rax,0x1d8(%r15)
  e7cf67:	49 89 97 30 01 00 00 	mov    %rdx,0x130(%r15)
  e7cf6e:	48 8d 15 2c dc 8d 00 	lea    0x8ddc2c(%rip),%rdx        # 175aba1 <_fini@@Base+0x3e7d>
  e7cf75:	48 8d 85 00 ff ff ff 	lea    -0x100(%rbp),%rax
  e7cf7c:	49 89 8f 40 01 00 00 	mov    %rcx,0x140(%r15)
  e7cf83:	48 8d 0d 1d dc 8d 00 	lea    0x8ddc1d(%rip),%rcx        # 175aba7 <_fini@@Base+0x3e83>
  e7cf8a:	49 c7 87 08 01 00 00 	movq   $0x5,0x108(%r15)
  e7cf91:	05 00 00 00 
  e7cf95:	49 89 97 50 01 00 00 	mov    %rdx,0x150(%r15)
  e7cf9c:	48 8d 15 0a dc 8d 00 	lea    0x8ddc0a(%rip),%rdx        # 175abad <_fini@@Base+0x3e89>
  e7cfa3:	48 89 c7             	mov    %rax,%rdi
  e7cfa6:	49 89 8f 60 01 00 00 	mov    %rcx,0x160(%r15)
  e7cfad:	48 8d 0d ff db 8d 00 	lea    0x8ddbff(%rip),%rcx        # 175abb3 <_fini@@Base+0x3e8f>
  e7cfb4:	49 c7 87 18 01 00 00 	movq   $0x5,0x118(%r15)
  e7cfbb:	05 00 00 00 
  e7cfbf:	49 89 97 70 01 00 00 	mov    %rdx,0x170(%r15)
  e7cfc6:	48 8d 15 ec db 8d 00 	lea    0x8ddbec(%rip),%rdx        # 175abb9 <_fini@@Base+0x3e95>
  e7cfcd:	49 c7 87 28 01 00 00 	movq   $0x5,0x128(%r15)
  e7cfd4:	05 00 00 00 
  e7cfd8:	49 89 8f 80 01 00 00 	mov    %rcx,0x180(%r15)
  e7cfdf:	48 8d 0d d9 db 8d 00 	lea    0x8ddbd9(%rip),%rcx        # 175abbf <_fini@@Base+0x3e9b>
  e7cfe6:	49 c7 87 38 01 00 00 	movq   $0x5,0x138(%r15)
  e7cfed:	05 00 00 00 
  e7cff1:	49 89 97 90 01 00 00 	mov    %rdx,0x190(%r15)
  e7cff8:	48 8d 15 ca db 8d 00 	lea    0x8ddbca(%rip),%rdx        # 175abc9 <_fini@@Base+0x3ea5>
  e7cfff:	49 c7 87 48 01 00 00 	movq   $0x5,0x148(%r15)
  e7d006:	05 00 00 00 
  e7d00a:	49 89 8f a0 01 00 00 	mov    %rcx,0x1a0(%r15)
  e7d011:	48 8d 0d bb db 8d 00 	lea    0x8ddbbb(%rip),%rcx        # 175abd3 <_fini@@Base+0x3eaf>
  e7d018:	49 c7 87 58 01 00 00 	movq   $0x5,0x158(%r15)
  e7d01f:	05 00 00 00 
  e7d023:	49 89 97 b0 01 00 00 	mov    %rdx,0x1b0(%r15)
  e7d02a:	48 8d 95 f8 fe ff ff 	lea    -0x108(%rbp),%rdx
  e7d031:	49 c7 87 68 01 00 00 	movq   $0x5,0x168(%r15)
  e7d038:	05 00 00 00 
  e7d03c:	49 c7 87 78 01 00 00 	movq   $0x5,0x178(%r15)
  e7d043:	05 00 00 00 
  e7d047:	49 c7 87 88 01 00 00 	movq   $0x5,0x188(%r15)
  e7d04e:	05 00 00 00 
  e7d052:	49 89 c5             	mov    %rax,%r13
  e7d055:	49 c7 87 98 01 00 00 	movq   $0x5,0x198(%r15)
  e7d05c:	05 00 00 00 
  e7d060:	49 c7 87 a8 01 00 00 	movq   $0x9,0x1a8(%r15)
  e7d067:	09 00 00 00 
  e7d06b:	49 c7 87 b8 01 00 00 	movq   $0x9,0x1b8(%r15)
  e7d072:	09 00 00 00 
  e7d076:	49 89 8f c0 01 00 00 	mov    %rcx,0x1c0(%r15)
  e7d07d:	49 c7 87 c8 01 00 00 	movq   $0x9,0x1c8(%r15)
  e7d084:	09 00 00 00 
  e7d088:	48 89 95 a0 fe ff ff 	mov    %rdx,-0x160(%rbp)
  e7d08f:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
  e7d096:	e8 15 64 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7d09b:	bf b0 00 00 00       	mov    $0xb0,%edi
  e7d0a0:	e8 bb 61 51 ff       	call   393260 <operator new(unsigned long)@plt>
  e7d0a5:	4c 89 ea             	mov    %r13,%rdx
  e7d0a8:	31 f6                	xor    %esi,%esi
  e7d0aa:	48 89 c7             	mov    %rax,%rdi
  e7d0ad:	49 89 c4             	mov    %rax,%r12
  e7d0b0:	e8 3b a4 50 ff       	call   3874f0 <spdlog::pattern_formatter::pattern_formatter(spdlog::pattern_time_type, std::string)@plt>
  e7d0b5:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
  e7d0bc:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d0c0:	48 3b 3d b9 fa cf 00 	cmp    0xcffab9(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d0c7:	0f 85 db 09 00 00    	jne    e7daa8 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x14c8>
  e7d0cd:	49 8d 87 f0 01 00 00 	lea    0x1f0(%r15),%rax
  e7d0d4:	49 8b bf d0 01 00 00 	mov    0x1d0(%r15),%rdi
  e7d0db:	4d 89 a7 e8 01 00 00 	mov    %r12,0x1e8(%r15)
  e7d0e2:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
  e7d0e9:	48 8b 05 90 fa cf 00 	mov    0xcffa90(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d0f0:	48 83 c0 18          	add    $0x18,%rax
  e7d0f4:	49 89 87 f0 01 00 00 	mov    %rax,0x1f0(%r15)
  e7d0fb:	49 89 87 f8 01 00 00 	mov    %rax,0x1f8(%r15)
  e7d102:	49 89 87 00 02 00 00 	mov    %rax,0x200(%r15)
  e7d109:	49 89 87 08 02 00 00 	mov    %rax,0x208(%r15)
  e7d110:	49 89 87 10 02 00 00 	mov    %rax,0x210(%r15)
  e7d117:	49 89 87 18 02 00 00 	mov    %rax,0x218(%r15)
  e7d11e:	49 89 87 20 02 00 00 	mov    %rax,0x220(%r15)
  e7d125:	e8 f6 71 51 ff       	call   394320 <fileno@plt>
  e7d12a:	89 c7                	mov    %eax,%edi
  e7d12c:	e8 cf 51 52 ff       	call   3a2300 <isatty@plt>
  e7d131:	85 c0                	test   %eax,%eax
  e7d133:	0f 85 c7 07 00 00    	jne    e7d900 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1320>
  e7d139:	49 8b bf 10 01 00 00 	mov    0x110(%r15),%rdi
  e7d140:	49 8b b7 18 01 00 00 	mov    0x118(%r15),%rsi
  e7d147:	41 88 87 e0 01 00 00 	mov    %al,0x1e0(%r15)
  e7d14e:	48 01 fe             	add    %rdi,%rsi
  e7d151:	e8 7a c8 ff ff       	call   e799d0 <DvcAttachLogCallback@@Base+0xd0>
  e7d156:	48 8b b5 98 fe ff ff 	mov    -0x168(%rbp),%rsi
  e7d15d:	49 8d bf f0 01 00 00 	lea    0x1f0(%r15),%rdi
  e7d164:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  e7d16b:	e8 00 5a 50 ff       	call   382b70 <std::string::swap(std::string&)@plt>
  e7d170:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
  e7d177:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d17b:	48 3b 3d fe f9 cf 00 	cmp    0xcff9fe(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d182:	0f 85 00 09 00 00    	jne    e7da88 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x14a8>
  e7d188:	49 8b bf 00 01 00 00 	mov    0x100(%r15),%rdi
  e7d18f:	49 8b b7 08 01 00 00 	mov    0x108(%r15),%rsi
  e7d196:	48 01 fe             	add    %rdi,%rsi
  e7d199:	e8 32 c8 ff ff       	call   e799d0 <DvcAttachLogCallback@@Base+0xd0>
  e7d19e:	48 8b b5 98 fe ff ff 	mov    -0x168(%rbp),%rsi
  e7d1a5:	49 8d bf f8 01 00 00 	lea    0x1f8(%r15),%rdi
  e7d1ac:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  e7d1b3:	e8 b8 59 50 ff       	call   382b70 <std::string::swap(std::string&)@plt>
  e7d1b8:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
  e7d1bf:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d1c3:	48 3b 3d b6 f9 cf 00 	cmp    0xcff9b6(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d1ca:	0f 85 c8 08 00 00    	jne    e7da98 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x14b8>
  e7d1d0:	49 8b bf c0 00 00 00 	mov    0xc0(%r15),%rdi
  e7d1d7:	49 8b b7 c8 00 00 00 	mov    0xc8(%r15),%rsi
  e7d1de:	48 01 fe             	add    %rdi,%rsi
  e7d1e1:	e8 ea c7 ff ff       	call   e799d0 <DvcAttachLogCallback@@Base+0xd0>
  e7d1e6:	48 8b b5 98 fe ff ff 	mov    -0x168(%rbp),%rsi
  e7d1ed:	49 8d bf 00 02 00 00 	lea    0x200(%r15),%rdi
  e7d1f4:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  e7d1fb:	e8 70 59 50 ff       	call   382b70 <std::string::swap(std::string&)@plt>
  e7d200:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
  e7d207:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d20b:	48 3b 3d 6e f9 cf 00 	cmp    0xcff96e(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d212:	0f 85 20 08 00 00    	jne    e7da38 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1458>
  e7d218:	49 8b bf a0 01 00 00 	mov    0x1a0(%r15),%rdi
  e7d21f:	49 8b b7 a8 01 00 00 	mov    0x1a8(%r15),%rsi
  e7d226:	48 01 fe             	add    %rdi,%rsi
  e7d229:	e8 a2 c7 ff ff       	call   e799d0 <DvcAttachLogCallback@@Base+0xd0>
  e7d22e:	48 8b b5 98 fe ff ff 	mov    -0x168(%rbp),%rsi
  e7d235:	49 8d bf 08 02 00 00 	lea    0x208(%r15),%rdi
  e7d23c:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  e7d243:	e8 28 59 50 ff       	call   382b70 <std::string::swap(std::string&)@plt>
  e7d248:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
  e7d24f:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d253:	48 3b 3d 26 f9 cf 00 	cmp    0xcff926(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d25a:	0f 85 e8 07 00 00    	jne    e7da48 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1468>
  e7d260:	49 8b bf b0 01 00 00 	mov    0x1b0(%r15),%rdi
  e7d267:	49 8b b7 b8 01 00 00 	mov    0x1b8(%r15),%rsi
  e7d26e:	48 01 fe             	add    %rdi,%rsi
  e7d271:	e8 5a c7 ff ff       	call   e799d0 <DvcAttachLogCallback@@Base+0xd0>
  e7d276:	48 8b b5 98 fe ff ff 	mov    -0x168(%rbp),%rsi
  e7d27d:	49 8d bf 10 02 00 00 	lea    0x210(%r15),%rdi
  e7d284:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  e7d28b:	e8 e0 58 50 ff       	call   382b70 <std::string::swap(std::string&)@plt>
  e7d290:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
  e7d297:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d29b:	48 3b 3d de f8 cf 00 	cmp    0xcff8de(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d2a2:	0f 85 b0 07 00 00    	jne    e7da58 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1478>
  e7d2a8:	49 8b bf c0 01 00 00 	mov    0x1c0(%r15),%rdi
  e7d2af:	49 8b b7 c8 01 00 00 	mov    0x1c8(%r15),%rsi
  e7d2b6:	48 01 fe             	add    %rdi,%rsi
  e7d2b9:	e8 12 c7 ff ff       	call   e799d0 <DvcAttachLogCallback@@Base+0xd0>
  e7d2be:	48 8b b5 98 fe ff ff 	mov    -0x168(%rbp),%rsi
  e7d2c5:	49 8d bf 18 02 00 00 	lea    0x218(%r15),%rdi
  e7d2cc:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  e7d2d3:	e8 98 58 50 ff       	call   382b70 <std::string::swap(std::string&)@plt>
  e7d2d8:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
  e7d2df:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d2e3:	48 3b 3d 96 f8 cf 00 	cmp    0xcff896(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d2ea:	0f 85 78 07 00 00    	jne    e7da68 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1488>
  e7d2f0:	49 8b 7f 20          	mov    0x20(%r15),%rdi
  e7d2f4:	49 8b 77 28          	mov    0x28(%r15),%rsi
  e7d2f8:	48 01 fe             	add    %rdi,%rsi
  e7d2fb:	e8 d0 c6 ff ff       	call   e799d0 <DvcAttachLogCallback@@Base+0xd0>
  e7d300:	48 8b b5 98 fe ff ff 	mov    -0x168(%rbp),%rsi
  e7d307:	49 8d bf 20 02 00 00 	lea    0x220(%r15),%rdi
  e7d30e:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  e7d315:	e8 56 58 50 ff       	call   382b70 <std::string::swap(std::string&)@plt>
  e7d31a:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
  e7d321:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d325:	48 3b 3d 54 f8 cf 00 	cmp    0xcff854(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d32c:	0f 85 46 07 00 00    	jne    e7da78 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1498>
  e7d332:	48 8b 05 bf 8b d0 00 	mov    0xd08bbf(%rip),%rax        # 1b85ef8 <vtable for spdlog::sinks::ansicolor_stdout_sink<spdlog::details::console_mutex>@@Base+0x3e6e0>
  e7d339:	48 8b 35 30 54 d0 00 	mov    0xd05430(%rip),%rsi        # 1b82770 <typeinfo for std::_Sp_make_shared_tag@@Base+0x3d918>
  e7d340:	4c 89 ff             	mov    %r15,%rdi
  e7d343:	48 83 c0 10          	add    $0x10,%rax
  e7d347:	49 89 47 10          	mov    %rax,0x10(%r15)
  e7d34b:	49 8b 07             	mov    (%r15),%rax
  e7d34e:	ff 50 20             	call   *0x20(%rax)
  e7d351:	83 fb 06             	cmp    $0x6,%ebx
  e7d354:	49 89 c5             	mov    %rax,%r13
  e7d357:	b8 06 00 00 00       	mov    $0x6,%eax
  e7d35c:	77 0a                	ja     e7d368 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0xd88>
  e7d35e:	48 8d 05 7b c1 91 00 	lea    0x91c17b(%rip),%rax        # 17994e0 <typeinfo name for std::_Sp_counted_ptr_inplace<VcvtInfo, std::allocator<VcvtInfo>, (__gnu_cxx::_Lock_policy)2>@@Base+0x100>
  e7d365:	8b 04 98             	mov    (%rax,%rbx,4),%eax
  e7d368:	48 8d 3d 6f bc 8e 00 	lea    0x8ebc6f(%rip),%rdi        # 1768fde <_fini@@Base+0x122ba>
  e7d36f:	41 89 45 08          	mov    %eax,0x8(%r13)
  e7d373:	e8 e8 7d 52 ff       	call   3a5160 <std::char_traits<char>::length(char const*)@plt>
  e7d378:	48 8d 35 5f bc 8e 00 	lea    0x8ebc5f(%rip),%rsi        # 1768fde <_fini@@Base+0x122ba>
  e7d37f:	31 d2                	xor    %edx,%edx
  e7d381:	48 89 c1             	mov    %rax,%rcx
  e7d384:	4c 89 f7             	mov    %r14,%rdi
  e7d387:	e8 74 d4 50 ff       	call   38a800 <std::string::find(char const*, unsigned long, unsigned long) const@plt>
  e7d38c:	48 8b 15 ed f7 cf 00 	mov    0xcff7ed(%rip),%rdx        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d393:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  e7d397:	48 8d 4a 18          	lea    0x18(%rdx),%rcx
  e7d39b:	49 89 cc             	mov    %rcx,%r12
  e7d39e:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
  e7d3a5:	75 0d                	jne    e7d3b4 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0xdd4>
  e7d3a7:	83 bd a8 fe ff ff 06 	cmpl   $0x6,-0x158(%rbp)
  e7d3ae:	0f 85 4c 04 00 00    	jne    e7d800 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1220>
  e7d3b4:	48 8b 05 15 70 d0 00 	mov    0xd07015(%rip),%rax        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
  e7d3bb:	48 85 c0             	test   %rax,%rax
  e7d3be:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
  e7d3c5:	0f 85 25 04 00 00    	jne    e7d7f0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1210>
  e7d3cb:	41 83 47 08 01       	addl   $0x1,0x8(%r15)
  e7d3d0:	bf c8 00 00 00       	mov    $0xc8,%edi
  e7d3d5:	e8 86 5e 51 ff       	call   393260 <operator new(unsigned long)@plt>
  e7d3da:	48 89 c3             	mov    %rax,%rbx
  e7d3dd:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
  e7d3e4:	00 00 00 
  e7d3e7:	49 8b 3e             	mov    (%r14),%rdi
  e7d3ea:	48 89 43 08          	mov    %rax,0x8(%rbx)
  e7d3ee:	48 8b 05 eb 53 d0 00 	mov    0xd053eb(%rip),%rax        # 1b827e0 <vtable for std::_Sp_counted_ptr_inplace<spdlog::logger, std::allocator<spdlog::logger>, (__gnu_cxx::_Lock_policy)2>@@Base+0x3c218>
  e7d3f5:	48 83 ef 18          	sub    $0x18,%rdi
  e7d3f9:	48 83 c0 10          	add    $0x10,%rax
  e7d3fd:	48 89 03             	mov    %rax,(%rbx)
  e7d400:	e8 9b cb ff ff       	call   e79fa0 <DvcAttachLogCallback@@Base+0x6a0>
  e7d405:	48 8b 15 a4 73 d0 00 	mov    0xd073a4(%rip),%rdx        # 1b847b0 <vtable for spdlog::logger@@Base+0x3ee00>
  e7d40c:	48 89 43 18          	mov    %rax,0x18(%rbx)
  e7d410:	bf 10 00 00 00       	mov    $0x10,%edi
  e7d415:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
  e7d41c:	00 
  e7d41d:	48 c7 43 28 00 00 00 	movq   $0x0,0x28(%rbx)
  e7d424:	00 
  e7d425:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
  e7d42c:	00 
  e7d42d:	48 83 c2 10          	add    $0x10,%rdx
  e7d431:	48 89 53 10          	mov    %rdx,0x10(%rbx)
  e7d435:	e8 26 5e 51 ff       	call   393260 <operator new(unsigned long)@plt>
  e7d43a:	48 83 bd a8 fe ff ff 	cmpq   $0x0,-0x158(%rbp)
  e7d441:	00 
  e7d442:	48 8d 50 10          	lea    0x10(%rax),%rdx
  e7d446:	48 89 43 20          	mov    %rax,0x20(%rbx)
  e7d44a:	4c 89 28             	mov    %r13,(%rax)
  e7d44d:	4c 89 78 08          	mov    %r15,0x8(%rax)
  e7d451:	48 89 53 30          	mov    %rdx,0x30(%rbx)
  e7d455:	0f 84 95 04 00 00    	je     e7d8f0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1310>
  e7d45b:	f0 41 83 47 08 01    	lock addl $0x1,0x8(%r15)
  e7d461:	48 b8 02 00 00 00 06 	movabs $0x600000002,%rax
  e7d468:	00 00 00 
  e7d46b:	66 0f ef c0          	pxor   %xmm0,%xmm0
  e7d46f:	48 89 43 38          	mov    %rax,0x38(%rbx)
  e7d473:	48 8b 03             	mov    (%rbx),%rax
  e7d476:	48 89 df             	mov    %rbx,%rdi
  e7d479:	48 89 53 28          	mov    %rdx,0x28(%rbx)
  e7d47d:	48 c7 43 50 00 00 00 	movq   $0x0,0x50(%rbx)
  e7d484:	00 
  e7d485:	0f 11 43 60          	movups %xmm0,0x60(%rbx)
  e7d489:	48 c7 83 80 00 00 00 	movq   $0x0,0x80(%rbx)
  e7d490:	00 00 00 00 
  e7d494:	c6 83 88 00 00 00 00 	movb   $0x0,0x88(%rbx)
  e7d49b:	0f 11 43 70          	movups %xmm0,0x70(%rbx)
  e7d49f:	48 c7 83 90 00 00 00 	movq   $0x0,0x90(%rbx)
  e7d4a6:	00 00 00 00 
  e7d4aa:	48 c7 83 98 00 00 00 	movq   $0x0,0x98(%rbx)
  e7d4b1:	00 00 00 00 
  e7d4b5:	48 c7 83 a0 00 00 00 	movq   $0x0,0xa0(%rbx)
  e7d4bc:	00 00 00 00 
  e7d4c0:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
  e7d4c7:	00 00 00 00 
  e7d4cb:	48 c7 83 b0 00 00 00 	movq   $0x0,0xb0(%rbx)
  e7d4d2:	00 00 00 00 
  e7d4d6:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
  e7d4dd:	00 00 00 00 
  e7d4e1:	48 c7 83 c0 00 00 00 	movq   $0x0,0xc0(%rbx)
  e7d4e8:	00 00 00 00 
  e7d4ec:	48 8b 35 7d 52 d0 00 	mov    0xd0527d(%rip),%rsi        # 1b82770 <typeinfo for std::_Sp_make_shared_tag@@Base+0x3d918>
  e7d4f3:	ff 50 20             	call   *0x20(%rax)
  e7d4f6:	4c 89 ff             	mov    %r15,%rdi
  e7d4f9:	49 89 c5             	mov    %rax,%r13
  e7d4fc:	e8 8f 43 f1 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
  e7d501:	41 c7 45 28 00 00 00 	movl   $0x0,0x28(%r13)
  e7d508:	00 
  e7d509:	0f ae f0             	mfence
  e7d50c:	48 83 bd a8 fe ff ff 	cmpq   $0x0,-0x158(%rbp)
  e7d513:	00 
  e7d514:	0f 84 46 04 00 00    	je     e7d960 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1380>
  e7d51a:	f0 83 43 08 01       	lock addl $0x1,0x8(%rbx)
  e7d51f:	4c 8b 35 e2 52 d0 00 	mov    0xd052e2(%rip),%r14        # 1b82808 <guard variable for spdlog::details::registry::instance()::s_instance@@Base-0xab80>
  e7d526:	41 0f b6 06          	movzbl (%r14),%eax
  e7d52a:	84 c0                	test   %al,%al
  e7d52c:	0f 84 4e 04 00 00    	je     e7d980 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x13a0>
  e7d532:	4c 8b 25 07 4e d0 00 	mov    0xd04e07(%rip),%r12        # 1b82340 <spdlog::details::registry::instance()::s_instance@@Base-0xb060>
  e7d539:	4c 89 e7             	mov    %r12,%rdi
  e7d53c:	e8 5f f7 51 ff       	call   39cca0 <pthread_mutex_lock@plt>
  e7d541:	85 c0                	test   %eax,%eax
  e7d543:	0f 85 2e 11 00 00    	jne    e7e677 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x2097>
  e7d549:	4d 8d 75 08          	lea    0x8(%r13),%r14
  e7d54d:	49 8d 7c 24 78       	lea    0x78(%r12),%rdi
  e7d552:	4c 89 f6             	mov    %r14,%rsi
  e7d555:	e8 d6 a2 50 ff       	call   387830 <std::_Hashtable<std::string, std::pair<std::string const, std::shared_ptr<spdlog::logger> >, std::allocator<std::pair<std::string const, std::shared_ptr<spdlog::logger> > >, std::__detail::_Select1st, std::equal_to<std::string>, std::hash<std::string>, std::__detail::_Mod_range_hashing, std::__detail::_Default_ranged_hash, std::__detail::_Prime_rehash_policy, std::__detail::_Hashtable_traits<true, false, true> >::find(std::string const&)@plt>
  e7d55a:	48 85 c0             	test   %rax,%rax
  e7d55d:	0f 85 1b 11 00 00    	jne    e7e67e <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x209e>
  e7d563:	49 8d 7c 24 78       	lea    0x78(%r12),%rdi
  e7d568:	4c 89 f6             	mov    %r14,%rsi
  e7d56b:	e8 40 35 50 ff       	call   380ab0 <std::__detail::_Map_base<std::string, std::pair<std::string const, std::shared_ptr<spdlog::logger> >, std::allocator<std::pair<std::string const, std::shared_ptr<spdlog::logger> > >, std::__detail::_Select1st, std::equal_to<std::string>, std::hash<std::string>, std::__detail::_Mod_range_hashing, std::__detail::_Default_ranged_hash, std::__detail::_Prime_rehash_policy, std::__detail::_Hashtable_traits<true, false, true>, true>::operator[](std::string const&)@plt>
  e7d570:	48 8b 78 08          	mov    0x8(%rax),%rdi
  e7d574:	4c 89 28             	mov    %r13,(%rax)
  e7d577:	48 89 58 08          	mov    %rbx,0x8(%rax)
  e7d57b:	48 85 ff             	test   %rdi,%rdi
  e7d57e:	74 05                	je     e7d585 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0xfa5>
  e7d580:	e8 0b 43 f1 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
  e7d585:	48 83 bd a8 fe ff ff 	cmpq   $0x0,-0x158(%rbp)
  e7d58c:	00 
  e7d58d:	74 08                	je     e7d597 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0xfb7>
  e7d58f:	4c 89 e7             	mov    %r12,%rdi
  e7d592:	e8 09 09 51 ff       	call   38dea0 <pthread_mutex_unlock@plt>
  e7d597:	83 bd 90 fe ff ff 06 	cmpl   $0x6,-0x170(%rbp)
  e7d59e:	b8 06 00 00 00       	mov    $0x6,%eax
  e7d5a3:	77 10                	ja     e7d5b5 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0xfd5>
  e7d5a5:	8b 95 90 fe ff ff    	mov    -0x170(%rbp),%edx
  e7d5ab:	48 8d 05 2e bf 91 00 	lea    0x91bf2e(%rip),%rax        # 17994e0 <typeinfo name for std::_Sp_counted_ptr_inplace<VcvtInfo, std::allocator<VcvtInfo>, (__gnu_cxx::_Lock_policy)2>@@Base+0x100>
  e7d5b2:	8b 04 90             	mov    (%rax,%rdx,4),%eax
  e7d5b5:	41 89 45 2c          	mov    %eax,0x2c(%r13)
  e7d5b9:	48 8d 95 d8 fe ff ff 	lea    -0x128(%rbp),%rdx
  e7d5c0:	48 8d bd e8 fe ff ff 	lea    -0x118(%rbp),%rdi
  e7d5c7:	48 8d 35 4c d2 8d 00 	lea    0x8dd24c(%rip),%rsi        # 175a81a <_fini@@Base+0x3af6>
  e7d5ce:	0f ae f0             	mfence
  e7d5d1:	e8 da 5e 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7d5d6:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
  e7d5dd:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
  e7d5e4:	48 8d 95 e0 fe ff ff 	lea    -0x120(%rbp),%rdx
  e7d5eb:	48 8d 35 22 e8 8d 00 	lea    0x8de822(%rip),%rsi        # 175be14 <_fini@@Base+0x50f0>
  e7d5f2:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
  e7d5f9:	48 8b 05 80 f5 cf 00 	mov    0xcff580(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d600:	48 83 c0 18          	add    $0x18,%rax
  e7d604:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
  e7d60b:	e8 a0 5e 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7d610:	4c 8b a5 98 fe ff ff 	mov    -0x168(%rbp),%r12
  e7d617:	66 0f ef c0          	pxor   %xmm0,%xmm0
  e7d61b:	bf b0 00 00 00       	mov    $0xb0,%edi
  e7d620:	48 c7 85 08 ff ff ff 	movq   $0x1,-0xf8(%rbp)
  e7d627:	01 00 00 00 
  e7d62b:	48 c7 85 10 ff ff ff 	movq   $0x0,-0xf0(%rbp)
  e7d632:	00 00 00 00 
  e7d636:	49 8d 44 24 30       	lea    0x30(%r12),%rax
  e7d63b:	0f 11 85 18 ff ff ff 	movups %xmm0,-0xe8(%rbp)
  e7d642:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  e7d649:	c7 85 20 ff ff ff 00 	movl   $0x3f800000,-0xe0(%rbp)
  e7d650:	00 80 3f 
  e7d653:	0f 11 85 28 ff ff ff 	movups %xmm0,-0xd8(%rbp)
  e7d65a:	e8 01 5c 51 ff       	call   393260 <operator new(unsigned long)@plt>
  e7d65f:	48 8d b5 f0 fe ff ff 	lea    -0x110(%rbp),%rsi
  e7d666:	4d 89 e0             	mov    %r12,%r8
  e7d669:	31 d2                	xor    %edx,%edx
  e7d66b:	48 89 c7             	mov    %rax,%rdi
  e7d66e:	49 89 c6             	mov    %rax,%r14
  e7d671:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
  e7d678:	e8 73 3a 52 ff       	call   3a10f0 <spdlog::pattern_formatter::pattern_formatter(std::string, spdlog::pattern_time_type, std::string, std::unordered_map<char, std::unique_ptr<spdlog::custom_flag_formatter, std::default_delete<spdlog::custom_flag_formatter> >, std::hash<char>, std::equal_to<char>, std::allocator<std::pair<char const, std::unique_ptr<spdlog::custom_flag_formatter, std::default_delete<spdlog::custom_flag_formatter> > > > >)@plt>
  e7d67d:	4c 89 e7             	mov    %r12,%rdi
  e7d680:	e8 1b 6c 51 ff       	call   3942a0 <std::_Hashtable<char, std::pair<char const, std::unique_ptr<spdlog::custom_flag_formatter, std::default_delete<spdlog::custom_flag_formatter> > >, std::allocator<std::pair<char const, std::unique_ptr<spdlog::custom_flag_formatter, std::default_delete<spdlog::custom_flag_formatter> > > >, std::__detail::_Select1st, std::equal_to<char>, std::hash<char>, std::__detail::_Mod_range_hashing, std::__detail::_Default_ranged_hash, std::__detail::_Prime_rehash_policy, std::__detail::_Hashtable_traits<false, false, true> >::~_Hashtable()@plt>
  e7d685:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  e7d68c:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d690:	48 3b 3d e9 f4 cf 00 	cmp    0xcff4e9(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d697:	0f 85 2b 04 00 00    	jne    e7dac8 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x14e8>
  e7d69d:	48 8b 85 f0 fe ff ff 	mov    -0x110(%rbp),%rax
  e7d6a4:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d6a8:	48 3b 3d d1 f4 cf 00 	cmp    0xcff4d1(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d6af:	0f 85 03 04 00 00    	jne    e7dab8 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x14d8>
  e7d6b5:	49 8b 45 10          	mov    0x10(%r13),%rax
  e7d6b9:	49 8b 55 18          	mov    0x18(%r13),%rdx
  e7d6bd:	48 39 c2             	cmp    %rax,%rdx
  e7d6c0:	0f 84 91 00 00 00    	je     e7d757 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1177>
  e7d6c6:	48 8d 48 10          	lea    0x10(%rax),%rcx
  e7d6ca:	48 39 ca             	cmp    %rcx,%rdx
  e7d6cd:	48 89 8d a8 fe ff ff 	mov    %rcx,-0x158(%rbp)
  e7d6d4:	75 25                	jne    e7d6fb <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x111b>
  e7d6d6:	e9 d5 06 00 00       	jmp    e7ddb0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x17d0>
  e7d6db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  e7d6e0:	48 8b 8d a8 fe ff ff 	mov    -0x158(%rbp),%rcx
  e7d6e7:	48 8d 51 10          	lea    0x10(%rcx),%rdx
  e7d6eb:	48 39 d0             	cmp    %rdx,%rax
  e7d6ee:	0f 84 34 02 00 00    	je     e7d928 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1348>
  e7d6f4:	48 89 95 a8 fe ff ff 	mov    %rdx,-0x158(%rbp)
  e7d6fb:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
  e7d702:	4c 89 f6             	mov    %r14,%rsi
  e7d705:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
  e7d70c:	4c 8b 60 f0          	mov    -0x10(%rax),%r12
  e7d710:	49 8b 04 24          	mov    (%r12),%rax
  e7d714:	48 8b 40 28          	mov    0x28(%rax),%rax
  e7d718:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
  e7d71f:	49 8b 06             	mov    (%r14),%rax
  e7d722:	ff 50 18             	call   *0x18(%rax)
  e7d725:	48 8b b5 a0 fe ff ff 	mov    -0x160(%rbp),%rsi
  e7d72c:	4c 89 e7             	mov    %r12,%rdi
  e7d72f:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
  e7d736:	ff d0                	call   *%rax
  e7d738:	48 8b bd f8 fe ff ff 	mov    -0x108(%rbp),%rdi
  e7d73f:	48 85 ff             	test   %rdi,%rdi
  e7d742:	74 06                	je     e7d74a <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x116a>
  e7d744:	48 8b 07             	mov    (%rdi),%rax
  e7d747:	ff 50 08             	call   *0x8(%rax)
  e7d74a:	49 8b 45 18          	mov    0x18(%r13),%rax
  e7d74e:	48 3b 85 a8 fe ff ff 	cmp    -0x158(%rbp),%rax
  e7d755:	75 89                	jne    e7d6e0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1100>
  e7d757:	49 8b 06             	mov    (%r14),%rax
  e7d75a:	4c 89 f7             	mov    %r14,%rdi
  e7d75d:	ff 50 08             	call   *0x8(%rax)
  e7d760:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
  e7d767:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d76b:	48 3b 3d 0e f4 cf 00 	cmp    0xcff40e(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d772:	0f 85 60 03 00 00    	jne    e7dad8 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x14f8>
  e7d778:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
  e7d77f:	4c 89 28             	mov    %r13,(%rax)
  e7d782:	48 89 58 08          	mov    %rbx,0x8(%rax)
  e7d786:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
  e7d78d:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d791:	48 3b 3d e8 f3 cf 00 	cmp    0xcff3e8(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d798:	0f 85 8a 02 00 00    	jne    e7da28 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1448>
  e7d79e:	4c 89 ff             	mov    %r15,%rdi
  e7d7a1:	e8 ea 40 f1 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
  e7d7a6:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
  e7d7aa:	64 48 33 0c 25 28 00 	xor    %fs:0x28,%rcx
  e7d7b1:	00 00 
  e7d7b3:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
  e7d7ba:	0f 85 7f 11 00 00    	jne    e7e93f <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x235f>
  e7d7c0:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
  e7d7c4:	5b                   	pop    %rbx
  e7d7c5:	41 5c                	pop    %r12
  e7d7c7:	41 5d                	pop    %r13
  e7d7c9:	41 5e                	pop    %r14
  e7d7cb:	41 5f                	pop    %r15
  e7d7cd:	5d                   	pop    %rbp
  e7d7ce:	c3                   	ret
  e7d7cf:	90                   	nop
  e7d7d0:	41 8b 46 1c          	mov    0x1c(%r14),%eax
  e7d7d4:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
  e7d7db:	41 8b 46 20          	mov    0x20(%r14),%eax
  e7d7df:	89 85 80 fe ff ff    	mov    %eax,-0x180(%rbp)
  e7d7e5:	e9 a5 f5 ff ff       	jmp    e7cd8f <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x7af>
  e7d7ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  e7d7f0:	f0 41 83 47 08 01    	lock addl $0x1,0x8(%r15)
  e7d7f6:	e9 d5 fb ff ff       	jmp    e7d3d0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0xdf0>
  e7d7fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  e7d800:	49 8d 5e 40          	lea    0x40(%r14),%rbx
  e7d804:	48 8d 35 1f cf 8d 00 	lea    0x8dcf1f(%rip),%rsi        # 175a72a <_fini@@Base+0x3a06>
  e7d80b:	48 89 df             	mov    %rbx,%rdi
  e7d80e:	e8 3d 9a 50 ff       	call   387250 <std::string::compare(char const*) const@plt>
  e7d813:	85 c0                	test   %eax,%eax
  e7d815:	0f 84 99 fb ff ff    	je     e7d3b4 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0xdd4>
  e7d81b:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
  e7d822:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
  e7d829:	48 89 df             	mov    %rbx,%rdi
  e7d82c:	4c 89 a5 c0 fe ff ff 	mov    %r12,-0x140(%rbp)
  e7d833:	4c 89 a5 c8 fe ff ff 	mov    %r12,-0x138(%rbp)
  e7d83a:	48 89 c2             	mov    %rax,%rdx
  e7d83d:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
  e7d844:	e8 f7 90 51 ff       	call   396940 <PemUtils::GetCanonicalPath(std::string const&, std::string&, std::string&)@plt>
  e7d849:	84 c0                	test   %al,%al
  e7d84b:	41 89 c4             	mov    %eax,%r12d
  e7d84e:	0f 85 94 02 00 00    	jne    e7dae8 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1508>
  e7d854:	48 8b 05 55 50 d0 00 	mov    0xd05055(%rip),%rax        # 1b828b0 <stderr@GLIBC_2.2.5>
  e7d85b:	48 83 ec 08          	sub    $0x8,%rsp
  e7d85f:	4c 8d 0d ba bc 91 00 	lea    0x91bcba(%rip),%r9        # 1799520 <typeinfo name for std::_Sp_counted_ptr_inplace<VcvtInfo, std::allocator<VcvtInfo>, (__gnu_cxx::_Lock_policy)2>@@Base+0x140>
  e7d866:	41 ff 76 40          	push   0x40(%r14)
  e7d86a:	48 8d 0d 2a d2 8d 00 	lea    0x8dd22a(%rip),%rcx        # 175aa9b <_fini@@Base+0x3d77>
  e7d871:	48 8d 15 92 cd 8d 00 	lea    0x8dcd92(%rip),%rdx        # 175a60a <_fini@@Base+0x38e6>
  e7d878:	48 8d 35 c9 2c 8f 00 	lea    0x8f2cc9(%rip),%rsi        # 1770548 <_fini@@Base+0x19824>
  e7d87f:	41 b8 cf 00 00 00    	mov    $0xcf,%r8d
  e7d885:	48 8b 38             	mov    (%rax),%rdi
  e7d888:	31 c0                	xor    %eax,%eax
  e7d88a:	e8 81 ea 51 ff       	call   39c310 <fprintf@plt>
  e7d88f:	5e                   	pop    %rsi
  e7d890:	5f                   	pop    %rdi
  e7d891:	31 db                	xor    %ebx,%ebx
  e7d893:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
  e7d89a:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d89e:	48 3b 3d db f2 cf 00 	cmp    0xcff2db(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d8a5:	0f 85 78 0a 00 00    	jne    e7e323 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1d43>
  e7d8ab:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
  e7d8b2:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7d8b6:	48 3b 3d c3 f2 cf 00 	cmp    0xcff2c3(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7d8bd:	0f 85 56 0a 00 00    	jne    e7e319 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1d39>
  e7d8c3:	45 84 e4             	test   %r12b,%r12b
  e7d8c6:	0f 85 ca 05 00 00    	jne    e7de96 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x18b6>
  e7d8cc:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
  e7d8d3:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  e7d8da:	48 c7 40 08 00 00 00 	movq   $0x0,0x8(%rax)
  e7d8e1:	00 
  e7d8e2:	e9 9f fe ff ff       	jmp    e7d786 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x11a6>
  e7d8e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  e7d8ee:	00 00 
  e7d8f0:	41 83 47 08 01       	addl   $0x1,0x8(%r15)
  e7d8f5:	e9 67 fb ff ff       	jmp    e7d461 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0xe81>
  e7d8fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
