
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000001550080 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base>:
 1550080:	41 57                	push   %r15
 1550082:	41 56                	push   %r14
 1550084:	4d 89 c6             	mov    %r8,%r14
 1550087:	41 55                	push   %r13
 1550089:	41 54                	push   %r12
 155008b:	49 89 fc             	mov    %rdi,%r12
 155008e:	55                   	push   %rbp
 155008f:	53                   	push   %rbx
 1550090:	48 89 cd             	mov    %rcx,%rbp
 1550093:	48 83 ec 48          	sub    $0x48,%rsp
 1550097:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 155009e:	00 00 
 15500a0:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 15500a5:	31 c0                	xor    %eax,%eax
 15500a7:	48 8b 01             	mov    (%rcx),%rax
 15500aa:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 15500af:	48 89 34 24          	mov    %rsi,(%rsp)
 15500b3:	c6 80 74 01 00 00 00 	movb   $0x0,0x174(%rax)
 15500ba:	e8 11 fc e3 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 15500bf:	48 8b 55 00          	mov    0x0(%rbp),%rdx
 15500c3:	48 89 82 80 00 00 00 	mov    %rax,0x80(%rdx)
 15500ca:	41 8b 84 24 d0 00 00 	mov    0xd0(%r12),%eax
 15500d1:	00 
 15500d2:	83 f8 02             	cmp    $0x2,%eax
 15500d5:	0f 84 a5 02 00 00    	je     1550380 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x300>
 15500db:	83 e8 03             	sub    $0x3,%eax
 15500de:	83 f8 01             	cmp    $0x1,%eax
 15500e1:	0f 86 f1 01 00 00    	jbe    15502d8 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x258>
 15500e7:	48 8b 3a             	mov    (%rdx),%rdi
 15500ea:	41 bf 01 00 00 00    	mov    $0x1,%r15d
 15500f0:	e8 ab 47 e3 fe       	call   3848a0 <Isa::name() const@plt>
 15500f5:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 15500fa:	74 15                	je     1550111 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x91>
 15500fc:	48 8b 45 00          	mov    0x0(%rbp),%rax
 1550100:	48 8b 38             	mov    (%rax),%rdi
 1550103:	e8 98 47 e3 fe       	call   3848a0 <Isa::name() const@plt>
 1550108:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 155010d:	41 0f 94 c7          	sete   %r15b
 1550111:	41 8b 84 24 d0 00 00 	mov    0xd0(%r12),%eax
 1550118:	00 
 1550119:	48 8b 55 00          	mov    0x0(%rbp),%rdx
 155011d:	85 c0                	test   %eax,%eax
 155011f:	8b 9a 6c 01 00 00    	mov    0x16c(%rdx),%ebx
 1550125:	0f 84 65 02 00 00    	je     1550390 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x310>
 155012b:	8d 50 fd             	lea    -0x3(%rax),%edx
 155012e:	83 fa 01             	cmp    $0x1,%edx
 1550131:	0f 86 80 02 00 00    	jbe    15503b7 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x337>
 1550137:	83 e8 01             	sub    $0x1,%eax
 155013a:	83 f8 01             	cmp    $0x1,%eax
 155013d:	77 23                	ja     1550162 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xe2>
 155013f:	83 eb 04             	sub    $0x4,%ebx
 1550142:	83 fb 01             	cmp    $0x1,%ebx
 1550145:	77 09                	ja     1550150 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xd0>
 1550147:	45 84 ff             	test   %r15b,%r15b
 155014a:	0f 84 b8 02 00 00    	je     1550408 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x388>
 1550150:	49 8b 84 24 c0 00 00 	mov    0xc0(%r12),%rax
 1550157:	00 
 1550158:	80 78 60 00          	cmpb   $0x0,0x60(%rax)
 155015c:	0f 85 b6 01 00 00    	jne    1550318 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x298>
 1550162:	49 8b 1e             	mov    (%r14),%rbx
 1550165:	83 03 01             	addl   $0x1,(%rbx)
 1550168:	48 8b 7b 18          	mov    0x18(%rbx),%rdi
 155016c:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
 1550170:	0f 84 f2 01 00 00    	je     1550368 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x2e8>
 1550176:	48 89 ee             	mov    %rbp,%rsi
 1550179:	e8 b2 67 e3 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 155017e:	48 83 43 18 10       	addq   $0x10,0x18(%rbx)
 1550183:	49 8b 84 24 b0 01 00 	mov    0x1b0(%r12),%rax
 155018a:	00 
 155018b:	48 89 ee             	mov    %rbp,%rsi
 155018e:	4c 89 e7             	mov    %r12,%rdi
 1550191:	83 40 28 01          	addl   $0x1,0x28(%rax)
 1550195:	e8 a6 6f e3 fe       	call   387140 <RVecISUEntry::update_isu_checkers(std::shared_ptr<RVecUop> const&)@plt>
 155019a:	49 8b 9c 24 c0 01 00 	mov    0x1c0(%r12),%rbx
 15501a1:	00 
 15501a2:	4d 8b b4 24 c8 01 00 	mov    0x1c8(%r12),%r14
 15501a9:	00 
 15501aa:	4c 39 f3             	cmp    %r14,%rbx
 15501ad:	0f 84 f2 00 00 00    	je     15502a5 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x225>
 15501b3:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
 15501b8:	4c 8d 6c 24 20       	lea    0x20(%rsp),%r13
 15501bd:	48 89 04 24          	mov    %rax,(%rsp)
 15501c1:	eb 2f                	jmp    15501f2 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x172>
 15501c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 15501c8:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 15501cd:	4c 89 ee             	mov    %r13,%rsi
 15501d0:	ff d2                	call   *%rdx
 15501d2:	84 c0                	test   %al,%al
 15501d4:	75 52                	jne    1550228 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x1a8>
 15501d6:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 15501db:	48 85 ff             	test   %rdi,%rdi
 15501de:	74 05                	je     15501e5 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x165>
 15501e0:	e8 ab 16 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15501e5:	48 83 c3 10          	add    $0x10,%rbx
 15501e9:	49 39 de             	cmp    %rbx,%r14
 15501ec:	0f 84 b3 00 00 00    	je     15502a5 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x225>
 15501f2:	48 8b 3b             	mov    (%rbx),%rdi
 15501f5:	48 8b 07             	mov    (%rdi),%rax
 15501f8:	48 8b 10             	mov    (%rax),%rdx
 15501fb:	48 8b 45 00          	mov    0x0(%rbp),%rax
 15501ff:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 1550204:	48 8b 45 08          	mov    0x8(%rbp),%rax
 1550208:	48 85 c0             	test   %rax,%rax
 155020b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 1550210:	74 bb                	je     15501cd <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x14d>
 1550212:	48 83 3d b6 41 63 00 	cmpq   $0x0,0x6341b6(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 1550219:	00 
 155021a:	75 ac                	jne    15501c8 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x148>
 155021c:	83 40 08 01          	addl   $0x1,0x8(%rax)
 1550220:	eb ab                	jmp    15501cd <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x14d>
 1550222:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1550228:	4c 8b 3b             	mov    (%rbx),%r15
 155022b:	48 8b 3c 24          	mov    (%rsp),%rdi
 155022f:	48 89 ee             	mov    %rbp,%rsi
 1550232:	49 8b 07             	mov    (%r15),%rax
 1550235:	48 8b 40 08          	mov    0x8(%rax),%rax
 1550239:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 155023e:	e8 ed 66 e3 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 1550243:	48 8b 34 24          	mov    (%rsp),%rsi
 1550247:	4c 89 ff             	mov    %r15,%rdi
 155024a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 155024f:	ff d0                	call   *%rax
 1550251:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 1550256:	41 89 c7             	mov    %eax,%r15d
 1550259:	48 85 ff             	test   %rdi,%rdi
 155025c:	74 05                	je     1550263 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x1e3>
 155025e:	e8 2d 16 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1550263:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 1550268:	48 85 ff             	test   %rdi,%rdi
 155026b:	74 05                	je     1550272 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x1f2>
 155026d:	e8 1e 16 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1550272:	45 84 ff             	test   %r15b,%r15b
 1550275:	0f 84 6a ff ff ff    	je     15501e5 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x165>
 155027b:	48 8b 45 00          	mov    0x0(%rbp),%rax
 155027f:	48 8b 38             	mov    (%rax),%rdi
 1550282:	e8 39 f8 e3 fe       	call   38fac0 <Isa::id() const@plt>
 1550287:	49 89 c5             	mov    %rax,%r13
 155028a:	48 8b 03             	mov    (%rbx),%rax
 155028d:	48 8b 40 20          	mov    0x20(%rax),%rax
 1550291:	48 8b 00             	mov    (%rax),%rax
 1550294:	48 8b 38             	mov    (%rax),%rdi
 1550297:	e8 24 f8 e3 fe       	call   38fac0 <Isa::id() const@plt>
 155029c:	49 39 c5             	cmp    %rax,%r13
 155029f:	0f 84 bb 01 00 00    	je     1550460 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x3e0>
 15502a5:	48 89 ee             	mov    %rbp,%rsi
 15502a8:	4c 89 e7             	mov    %r12,%rdi
 15502ab:	e8 c0 13 e5 fe       	call   3a1670 <RVecISUEntry::post_issue_uop_log(std::shared_ptr<RVecUop>&)@plt>
 15502b0:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 15502b5:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 15502bc:	00 00 
 15502be:	0f 85 bb 02 00 00    	jne    155057f <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x4ff>
 15502c4:	48 83 c4 48          	add    $0x48,%rsp
 15502c8:	5b                   	pop    %rbx
 15502c9:	5d                   	pop    %rbp
 15502ca:	41 5c                	pop    %r12
 15502cc:	41 5d                	pop    %r13
 15502ce:	41 5e                	pop    %r14
 15502d0:	41 5f                	pop    %r15
 15502d2:	c3                   	ret
 15502d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 15502d8:	49 8b 94 24 c0 00 00 	mov    0xc0(%r12),%rdx
 15502df:	00 
 15502e0:	41 8b 84 24 08 01 00 	mov    0x108(%r12),%eax
 15502e7:	00 
 15502e8:	4c 8d 6c 24 20       	lea    0x20(%rsp),%r13
 15502ed:	49 8b bc 24 f8 01 00 	mov    0x1f8(%r12),%rdi
 15502f4:	00 
 15502f5:	4c 89 ee             	mov    %r13,%rsi
 15502f8:	03 42 5c             	add    0x5c(%rdx),%eax
 15502fb:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 1550300:	e8 1b 6c e4 fe       	call   396f20 <tm_engine::TmEvent::notify_after(unsigned long const&)@plt>
 1550305:	48 8b 55 00          	mov    0x0(%rbp),%rdx
 1550309:	c6 82 1e 03 00 00 01 	movb   $0x1,0x31e(%rdx)
 1550310:	e9 d2 fd ff ff       	jmp    15500e7 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x67>
 1550315:	0f 1f 00             	nopl   (%rax)
 1550318:	4c 8d 6c 24 20       	lea    0x20(%rsp),%r13
 155031d:	48 89 ee             	mov    %rbp,%rsi
 1550320:	4c 89 ef             	mov    %r13,%rdi
 1550323:	e8 08 66 e3 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 1550328:	4c 89 ee             	mov    %r13,%rsi
 155032b:	4c 89 e7             	mov    %r12,%rdi
 155032e:	e8 9d 60 e4 fe       	call   3963d0 <RVecISUEntry::get_release_time(std::shared_ptr<RVecUop>)@plt>
 1550333:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 1550338:	48 8b 55 00          	mov    0x0(%rbp),%rdx
 155033c:	48 85 ff             	test   %rdi,%rdi
 155033f:	48 89 82 20 03 00 00 	mov    %rax,0x320(%rdx)
 1550346:	0f 84 16 fe ff ff    	je     1550162 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xe2>
 155034c:	e8 3f 15 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1550351:	49 8b 1e             	mov    (%r14),%rbx
 1550354:	83 03 01             	addl   $0x1,(%rbx)
 1550357:	48 8b 7b 18          	mov    0x18(%rbx),%rdi
 155035b:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
 155035f:	0f 85 11 fe ff ff    	jne    1550176 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xf6>
 1550365:	0f 1f 00             	nopl   (%rax)
 1550368:	48 83 c3 10          	add    $0x10,%rbx
 155036c:	48 89 fe             	mov    %rdi,%rsi
 155036f:	48 89 ea             	mov    %rbp,%rdx
 1550372:	48 89 df             	mov    %rbx,%rdi
 1550375:	e8 66 f0 e3 fe       	call   38f3e0 <void std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > >::_M_realloc_insert<std::shared_ptr<RVecUop> const&>(__gnu_cxx::__normal_iterator<std::shared_ptr<RVecUop>*, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > > >, std::shared_ptr<RVecUop> const&)@plt>
 155037a:	e9 04 fe ff ff       	jmp    1550183 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x103>
 155037f:	90                   	nop
 1550380:	c6 82 1d 03 00 00 01 	movb   $0x1,0x31d(%rdx)
 1550387:	e9 5b fd ff ff       	jmp    15500e7 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x67>
 155038c:	0f 1f 40 00          	nopl   0x0(%rax)
 1550390:	48 8b 3a             	mov    (%rdx),%rdi
 1550393:	e8 08 45 e3 fe       	call   3848a0 <Isa::name() const@plt>
 1550398:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 155039d:	0f 85 4d 01 00 00    	jne    15504f0 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x470>
 15503a3:	41 8b 84 24 d0 00 00 	mov    0xd0(%r12),%eax
 15503aa:	00 
 15503ab:	8d 50 fd             	lea    -0x3(%rax),%edx
 15503ae:	83 fa 01             	cmp    $0x1,%edx
 15503b1:	0f 87 80 fd ff ff    	ja     1550137 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb7>
 15503b7:	48 8b 45 00          	mov    0x0(%rbp),%rax
 15503bb:	4c 8d 6c 24 20       	lea    0x20(%rsp),%r13
 15503c0:	48 89 ee             	mov    %rbp,%rsi
 15503c3:	4c 89 ef             	mov    %r13,%rdi
 15503c6:	c6 80 1e 03 00 00 01 	movb   $0x1,0x31e(%rax)
 15503cd:	e8 5e 65 e3 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 15503d2:	4c 89 ee             	mov    %r13,%rsi
 15503d5:	4c 89 e7             	mov    %r12,%rdi
 15503d8:	e8 f3 5f e4 fe       	call   3963d0 <RVecISUEntry::get_release_time(std::shared_ptr<RVecUop>)@plt>
 15503dd:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 15503e2:	48 8b 55 00          	mov    0x0(%rbp),%rdx
 15503e6:	48 85 ff             	test   %rdi,%rdi
 15503e9:	48 89 82 28 03 00 00 	mov    %rax,0x328(%rdx)
 15503f0:	74 05                	je     15503f7 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x377>
 15503f2:	e8 99 14 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15503f7:	41 8b 84 24 d0 00 00 	mov    0xd0(%r12),%eax
 15503fe:	00 
 15503ff:	e9 33 fd ff ff       	jmp    1550137 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb7>
 1550404:	0f 1f 40 00          	nopl   0x0(%rax)
 1550408:	4c 8d 6c 24 20       	lea    0x20(%rsp),%r13
 155040d:	48 89 ee             	mov    %rbp,%rsi
 1550410:	4c 89 ef             	mov    %r13,%rdi
 1550413:	e8 18 65 e3 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 1550418:	4c 89 ee             	mov    %r13,%rsi
 155041b:	4c 89 e7             	mov    %r12,%rdi
 155041e:	e8 ad 5f e4 fe       	call   3963d0 <RVecISUEntry::get_release_time(std::shared_ptr<RVecUop>)@plt>
 1550423:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 1550428:	48 8b 55 00          	mov    0x0(%rbp),%rdx
 155042c:	48 85 ff             	test   %rdi,%rdi
 155042f:	48 89 82 20 03 00 00 	mov    %rax,0x320(%rdx)
 1550436:	0f 84 14 fd ff ff    	je     1550150 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xd0>
 155043c:	e8 4f 14 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1550441:	49 8b 84 24 c0 00 00 	mov    0xc0(%r12),%rax
 1550448:	00 
 1550449:	80 78 60 00          	cmpb   $0x0,0x60(%rax)
 155044d:	0f 84 0f fd ff ff    	je     1550162 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xe2>
 1550453:	e9 c0 fe ff ff       	jmp    1550318 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x298>
 1550458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 155045f:	00 
 1550460:	4c 8b 33             	mov    (%rbx),%r14
 1550463:	49 8b 56 28          	mov    0x28(%r14),%rdx
 1550467:	49 8b 46 20          	mov    0x20(%r14),%rax
 155046b:	48 39 c2             	cmp    %rax,%rdx
 155046e:	0f 84 dd 00 00 00    	je     1550551 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x4d1>
 1550474:	48 8d 58 10          	lea    0x10(%rax),%rbx
 1550478:	48 39 d3             	cmp    %rdx,%rbx
 155047b:	74 4d                	je     15504ca <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x44a>
 155047d:	48 89 d0             	mov    %rdx,%rax
 1550480:	48 29 d8             	sub    %rbx,%rax
 1550483:	49 89 c5             	mov    %rax,%r13
 1550486:	49 c1 fd 04          	sar    $0x4,%r13
 155048a:	48 85 c0             	test   %rax,%rax
 155048d:	7e 3b                	jle    15504ca <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x44a>
 155048f:	90                   	nop
 1550490:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
 1550494:	48 8b 13             	mov    (%rbx),%rdx
 1550497:	48 8b 43 08          	mov    0x8(%rbx),%rax
 155049b:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
 15504a2:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
 15504a9:	00 
 15504aa:	48 85 ff             	test   %rdi,%rdi
 15504ad:	48 89 53 f0          	mov    %rdx,-0x10(%rbx)
 15504b1:	48 89 43 f8          	mov    %rax,-0x8(%rbx)
 15504b5:	74 05                	je     15504bc <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x43c>
 15504b7:	e8 d4 13 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15504bc:	48 83 c3 10          	add    $0x10,%rbx
 15504c0:	49 83 ed 01          	sub    $0x1,%r13
 15504c4:	75 ca                	jne    1550490 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x410>
 15504c6:	49 8b 56 28          	mov    0x28(%r14),%rdx
 15504ca:	48 8b 7a f8          	mov    -0x8(%rdx),%rdi
 15504ce:	48 8d 42 f0          	lea    -0x10(%rdx),%rax
 15504d2:	49 89 46 28          	mov    %rax,0x28(%r14)
 15504d6:	48 85 ff             	test   %rdi,%rdi
 15504d9:	0f 84 c6 fd ff ff    	je     15502a5 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x225>
 15504df:	e8 ac 13 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15504e4:	e9 bc fd ff ff       	jmp    15502a5 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x225>
 15504e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 15504f0:	48 8b 04 24          	mov    (%rsp),%rax
 15504f4:	48 8b 10             	mov    (%rax),%rdx
 15504f7:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 15504fc:	44 8b 28             	mov    (%rax),%r13d
 15504ff:	44 3b aa 90 00 00 00 	cmp    0x90(%rdx),%r13d
 1550506:	72 26                	jb     155052e <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x4ae>
 1550508:	48 8b 05 79 ba 62 00 	mov    0x62ba79(%rip),%rax        # 1b7bf88 <stdout@GLIBC_2.2.5>
 155050f:	48 89 14 24          	mov    %rdx,(%rsp)
 1550513:	48 8b 38             	mov    (%rax),%rdi
 1550516:	e8 65 66 e4 fe       	call   396b80 <fflush@plt>
 155051b:	48 8b 05 8e 23 63 00 	mov    0x63238e(%rip),%rax        # 1b828b0 <stderr@GLIBC_2.2.5>
 1550522:	48 8b 38             	mov    (%rax),%rdi
 1550525:	e8 56 66 e4 fe       	call   396b80 <fflush@plt>
 155052a:	48 8b 14 24          	mov    (%rsp),%rdx
 155052e:	48 8b 82 00 01 00 00 	mov    0x100(%rdx),%rax
 1550535:	42 c7 04 a8 02 00 00 	movl   $0x2,(%rax,%r13,4)
 155053c:	00 
 155053d:	49 8b 06             	mov    (%r14),%rax
 1550540:	83 40 04 01          	addl   $0x1,0x4(%rax)
 1550544:	41 8b 84 24 d0 00 00 	mov    0xd0(%r12),%eax
 155054b:	00 
 155054c:	e9 5a fe ff ff       	jmp    15503ab <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x32b>
 1550551:	48 8b 05 30 ba 62 00 	mov    0x62ba30(%rip),%rax        # 1b7bf88 <stdout@GLIBC_2.2.5>
 1550558:	48 8b 38             	mov    (%rax),%rdi
 155055b:	e8 20 66 e4 fe       	call   396b80 <fflush@plt>
 1550560:	48 8b 05 49 23 63 00 	mov    0x632349(%rip),%rax        # 1b828b0 <stderr@GLIBC_2.2.5>
 1550567:	48 8b 38             	mov    (%rax),%rdi
 155056a:	e8 11 66 e4 fe       	call   396b80 <fflush@plt>
 155056f:	4c 8b 33             	mov    (%rbx),%r14
 1550572:	49 8b 46 20          	mov    0x20(%r14),%rax
 1550576:	49 8b 56 28          	mov    0x28(%r14),%rdx
 155057a:	e9 f5 fe ff ff       	jmp    1550474 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x3f4>
 155057f:	e8 3c 51 e4 fe       	call   3956c0 <__stack_chk_fail@plt>
 1550584:	48 89 c3             	mov    %rax,%rbx
 1550587:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 155058c:	48 85 ff             	test   %rdi,%rdi
 155058f:	74 05                	je     1550596 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x516>
 1550591:	e8 fa 12 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1550596:	48 89 df             	mov    %rbx,%rdi
 1550599:	e8 e2 27 e5 fe       	call   3a2d80 <_Unwind_Resume@plt>
 155059e:	eb e4                	jmp    1550584 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x504>
