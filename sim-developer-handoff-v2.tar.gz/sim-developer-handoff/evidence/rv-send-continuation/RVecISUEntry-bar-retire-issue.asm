
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000015535b0 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base>:
 15535b0:	41 57                	push   %r15
 15535b2:	41 56                	push   %r14
 15535b4:	41 55                	push   %r13
 15535b6:	41 54                	push   %r12
 15535b8:	49 89 f4             	mov    %rsi,%r12
 15535bb:	55                   	push   %rbp
 15535bc:	53                   	push   %rbx
 15535bd:	48 89 fb             	mov    %rdi,%rbx
 15535c0:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
 15535c7:	48 8b 36             	mov    (%rsi),%rsi
 15535ca:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
 15535cf:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 15535d6:	00 00 
 15535d8:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
 15535df:	00 
 15535e0:	31 c0                	xor    %eax,%eax
 15535e2:	e8 f9 ee e4 fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 15535e7:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 15535ec:	e8 cf c4 e3 fe       	call   38fac0 <Isa::id() const@plt>
 15535f1:	48 8b bb 20 01 00 00 	mov    0x120(%rbx),%rdi
 15535f8:	31 d2                	xor    %edx,%edx
 15535fa:	49 89 c0             	mov    %rax,%r8
 15535fd:	48 f7 f7             	div    %rdi
 1553600:	48 8b 83 18 01 00 00 	mov    0x118(%rbx),%rax
 1553607:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
 155360b:	49 89 d1             	mov    %rdx,%r9
 155360e:	48 85 c0             	test   %rax,%rax
 1553611:	0f 84 46 02 00 00    	je     155385d <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x2ad>
 1553617:	48 8b 08             	mov    (%rax),%rcx
 155361a:	48 8b 71 08          	mov    0x8(%rcx),%rsi
 155361e:	eb 21                	jmp    1553641 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x91>
 1553620:	48 8b 09             	mov    (%rcx),%rcx
 1553623:	48 85 c9             	test   %rcx,%rcx
 1553626:	0f 84 31 02 00 00    	je     155385d <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x2ad>
 155362c:	48 8b 71 08          	mov    0x8(%rcx),%rsi
 1553630:	31 d2                	xor    %edx,%edx
 1553632:	48 89 f0             	mov    %rsi,%rax
 1553635:	48 f7 f7             	div    %rdi
 1553638:	49 39 d1             	cmp    %rdx,%r9
 155363b:	0f 85 1c 02 00 00    	jne    155385d <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x2ad>
 1553641:	49 39 f0             	cmp    %rsi,%r8
 1553644:	75 da                	jne    1553620 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x70>
 1553646:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 155364b:	e8 70 c4 e3 fe       	call   38fac0 <Isa::id() const@plt>
 1553650:	48 8b bb 20 01 00 00 	mov    0x120(%rbx),%rdi
 1553657:	31 d2                	xor    %edx,%edx
 1553659:	49 89 c0             	mov    %rax,%r8
 155365c:	48 f7 f7             	div    %rdi
 155365f:	48 8b 83 18 01 00 00 	mov    0x118(%rbx),%rax
 1553666:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
 155366a:	49 89 d1             	mov    %rdx,%r9
 155366d:	48 85 c0             	test   %rax,%rax
 1553670:	0f 84 17 09 00 00    	je     1553f8d <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x9dd>
 1553676:	48 8b 30             	mov    (%rax),%rsi
 1553679:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
 155367d:	eb 22                	jmp    15536a1 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0xf1>
 155367f:	90                   	nop
 1553680:	48 8b 36             	mov    (%rsi),%rsi
 1553683:	48 85 f6             	test   %rsi,%rsi
 1553686:	0f 84 01 09 00 00    	je     1553f8d <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x9dd>
 155368c:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
 1553690:	31 d2                	xor    %edx,%edx
 1553692:	48 89 c8             	mov    %rcx,%rax
 1553695:	48 f7 f7             	div    %rdi
 1553698:	49 39 d1             	cmp    %rdx,%r9
 155369b:	0f 85 ec 08 00 00    	jne    1553f8d <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x9dd>
 15536a1:	49 39 c8             	cmp    %rcx,%r8
 15536a4:	75 da                	jne    1553680 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0xd0>
 15536a6:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
 15536ab:	48 83 c6 10          	add    $0x10,%rsi
 15536af:	e8 7c 32 e3 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 15536b4:	49 8b 04 24          	mov    (%r12),%rax
 15536b8:	48 8b 6c 24 50       	mov    0x50(%rsp),%rbp
 15536bd:	be 01 00 00 00       	mov    $0x1,%esi
 15536c2:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
 15536c7:	8b 90 6c 01 00 00    	mov    0x16c(%rax),%edx
 15536cd:	48 89 d0             	mov    %rdx,%rax
 15536d0:	89 d1                	mov    %edx,%ecx
 15536d2:	48 c1 e8 03          	shr    $0x3,%rax
 15536d6:	48 d3 e6             	shl    %cl,%rsi
 15536d9:	25 f8 ff ff 1f       	and    $0x1ffffff8,%eax
 15536de:	48 03 85 f0 02 00 00 	add    0x2f0(%rbp),%rax
 15536e5:	48 09 30             	or     %rsi,(%rax)
 15536e8:	48 89 de             	mov    %rbx,%rsi
 15536eb:	e8 10 09 e4 fe       	call   394000 <RVecISUEntry::get_tgt_str(InfFromISU) const@plt>
 15536f0:	4c 8b a3 b0 00 00 00 	mov    0xb0(%rbx),%r12
 15536f7:	48 8b 05 82 94 62 00 	mov    0x629482(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 15536fe:	4d 85 e4             	test   %r12,%r12
 1553701:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1553706:	0f 84 d0 00 00 00    	je     15537dc <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x22c>
 155370c:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 1553711:	e8 5a 71 e3 fe       	call   38a870 <Isa::pc() const@plt>
 1553716:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 155371b:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 1553720:	48 8b 05 59 94 62 00 	mov    0x629459(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1553727:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 155372c:	e8 8f c3 e3 fe       	call   38fac0 <Isa::id() const@plt>
 1553731:	49 89 c6             	mov    %rax,%r14
 1553734:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
 1553739:	48 8b 05 40 94 62 00 	mov    0x629440(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1553740:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
 1553747:	00 
 1553748:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 155374d:	e8 4e 4f e3 fe       	call   3886a0 <Isa::name_str() const@plt>
 1553752:	8b 93 d0 00 00 00    	mov    0xd0(%rbx),%edx
 1553758:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
 155375d:	48 89 de             	mov    %rbx,%rsi
 1553760:	e8 0b 2e e3 fe       	call   386570 <RVecISUEntry::get_que_str(IsuQueue) const@plt>
 1553765:	48 89 df             	mov    %rbx,%rdi
 1553768:	e8 63 c5 e3 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 155376d:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
 1553774:	00 00 
 1553776:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
 155377d:	00 
 155377e:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
 1553785:	00 00 
 1553787:	45 8b 6c 24 28       	mov    0x28(%r12),%r13d
 155378c:	45 0f b6 7c 24 78    	movzbl 0x78(%r12),%r15d
 1553792:	41 83 fd 02          	cmp    $0x2,%r13d
 1553796:	0f 8e 04 02 00 00    	jle    15539a0 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x3f0>
 155379c:	45 84 ff             	test   %r15b,%r15b
 155379f:	0f 85 fb 01 00 00    	jne    15539a0 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x3f0>
 15537a5:	48 8b 05 d4 93 62 00 	mov    0x6293d4(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 15537ac:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 15537b1:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 15537b6:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 15537ba:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 15537bf:	0f 85 92 04 00 00    	jne    1553c57 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x6a7>
 15537c5:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 15537cc:	00 
 15537cd:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 15537d1:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 15537d6:	0f 85 67 04 00 00    	jne    1553c43 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x693>
 15537dc:	48 8b 85 b0 02 00 00 	mov    0x2b0(%rbp),%rax
 15537e3:	4c 8d a5 a0 02 00 00 	lea    0x2a0(%rbp),%r12
 15537ea:	49 39 c4             	cmp    %rax,%r12
 15537ed:	0f 84 a5 00 00 00    	je     1553898 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x2e8>
 15537f3:	4c 8b bd f0 02 00 00 	mov    0x2f0(%rbp),%r15
 15537fa:	41 bd 01 00 00 00    	mov    $0x1,%r13d
 1553800:	41 be 01 00 00 00    	mov    $0x1,%r14d
 1553806:	31 ed                	xor    %ebp,%ebp
 1553808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 155380f:	00 
 1553810:	8b 50 20             	mov    0x20(%rax),%edx
 1553813:	4c 89 f7             	mov    %r14,%rdi
 1553816:	48 89 d1             	mov    %rdx,%rcx
 1553819:	48 c1 ea 06          	shr    $0x6,%rdx
 155381d:	48 d3 e7             	shl    %cl,%rdi
 1553820:	49 85 3c d7          	test   %rdi,(%r15,%rdx,8)
 1553824:	48 89 c7             	mov    %rax,%rdi
 1553827:	44 0f 44 ed          	cmove  %ebp,%r13d
 155382b:	e8 d0 2d e4 fe       	call   396600 <std::_Rb_tree_increment(std::_Rb_tree_node_base const*)@plt>
 1553830:	49 39 c4             	cmp    %rax,%r12
 1553833:	75 db                	jne    1553810 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x260>
 1553835:	45 84 ed             	test   %r13b,%r13b
 1553838:	75 5e                	jne    1553898 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x2e8>
 155383a:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 155383f:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553843:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 1553848:	0f 85 a8 02 00 00    	jne    1553af6 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x546>
 155384e:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
 1553853:	48 85 ff             	test   %rdi,%rdi
 1553856:	74 05                	je     155385d <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x2ad>
 1553858:	e8 33 e0 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 155385d:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
 1553862:	48 85 ff             	test   %rdi,%rdi
 1553865:	74 05                	je     155386c <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x2bc>
 1553867:	e8 24 e0 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 155386c:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
 1553873:	00 
 1553874:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 155387b:	00 00 
 155387d:	0f 85 e8 03 00 00    	jne    1553c6b <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x6bb>
 1553883:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
 155388a:	5b                   	pop    %rbx
 155388b:	5d                   	pop    %rbp
 155388c:	41 5c                	pop    %r12
 155388e:	41 5d                	pop    %r13
 1553890:	41 5e                	pop    %r14
 1553892:	41 5f                	pop    %r15
 1553894:	c3                   	ret
 1553895:	0f 1f 00             	nopl   (%rax)
 1553898:	48 8b ab b0 00 00 00 	mov    0xb0(%rbx),%rbp
 155389f:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
 15538a4:	48 85 ed             	test   %rbp,%rbp
 15538a7:	c6 80 19 03 00 00 01 	movb   $0x1,0x319(%rax)
 15538ae:	0f 84 ad 00 00 00    	je     1553961 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x3b1>
 15538b4:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 15538b9:	e8 b2 6f e3 fe       	call   38a870 <Isa::pc() const@plt>
 15538be:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 15538c3:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 15538c8:	e8 f3 c1 e3 fe       	call   38fac0 <Isa::id() const@plt>
 15538cd:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
 15538d2:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
 15538d7:	49 89 c6             	mov    %rax,%r14
 15538da:	e8 c1 4d e3 fe       	call   3886a0 <Isa::name_str() const@plt>
 15538df:	8b 93 d0 00 00 00    	mov    0xd0(%rbx),%edx
 15538e5:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
 15538ea:	48 89 de             	mov    %rbx,%rsi
 15538ed:	e8 7e 2c e3 fe       	call   386570 <RVecISUEntry::get_que_str(IsuQueue) const@plt>
 15538f2:	48 89 df             	mov    %rbx,%rdi
 15538f5:	e8 d6 c3 e3 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 15538fa:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
 1553901:	00 00 00 00 00 
 1553906:	c7 84 24 88 00 00 00 	movl   $0x0,0x88(%rsp)
 155390d:	00 00 00 00 
 1553911:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
 1553918:	00 00 00 00 00 
 155391d:	44 8b 7d 28          	mov    0x28(%rbp),%r15d
 1553921:	44 0f b6 65 78       	movzbl 0x78(%rbp),%r12d
 1553926:	41 83 ff 02          	cmp    $0x2,%r15d
 155392a:	0f 8e d0 01 00 00    	jle    1553b00 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x550>
 1553930:	45 84 e4             	test   %r12b,%r12b
 1553933:	0f 85 c7 01 00 00    	jne    1553b00 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x550>
 1553939:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 155393e:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553942:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 1553947:	0f 85 14 03 00 00    	jne    1553c61 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x6b1>
 155394d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 1553952:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553956:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 155395b:	0f 85 ec 02 00 00    	jne    1553c4d <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x69d>
 1553961:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
 1553968:	80 78 60 00          	cmpb   $0x0,0x60(%rax)
 155396c:	0f 84 c8 fe ff ff    	je     155383a <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x28a>
 1553972:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
 1553978:	85 c0                	test   %eax,%eax
 155397a:	0f 84 ba fe ff ff    	je     155383a <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x28a>
 1553980:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 1553985:	e8 36 c1 e3 fe       	call   38fac0 <Isa::id() const@plt>
 155398a:	48 8d bb 18 01 00 00 	lea    0x118(%rbx),%rdi
 1553991:	48 89 c6             	mov    %rax,%rsi
 1553994:	e8 97 41 ff ff       	call   1547b30 <RVecISUEntry::push_pmu(std::shared_ptr<RVecUop> const&, int)@@Base+0x6b0>
 1553999:	e9 9c fe ff ff       	jmp    155383a <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x28a>
 155399e:	66 90                	xchg   %ax,%ax
 15539a0:	48 8b 15 71 9c 62 00 	mov    0x629c71(%rip),%rdx        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 15539a7:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
 15539ae:	00 
 15539af:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
 15539b6:	00 
 15539b7:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 15539bc:	48 c7 84 24 70 01 00 	movq   $0xfa,0x170(%rsp)
 15539c3:	00 fa 00 00 00 
 15539c8:	4c 8d 84 24 00 01 00 	lea    0x100(%rsp),%r8
 15539cf:	00 
 15539d0:	48 8d 35 d9 dd 22 00 	lea    0x22ddd9(%rip),%rsi        # 17817b0 <_fini@@Base+0x2aa8c>
 15539d7:	45 31 c9             	xor    %r9d,%r9d
 15539da:	b9 d4 4d d4 00       	mov    $0xd44dd4,%ecx
 15539df:	48 89 94 24 78 01 00 	mov    %rdx,0x178(%rsp)
 15539e6:	00 
 15539e7:	48 8d 57 20          	lea    0x20(%rdi),%rdx
 15539eb:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
 15539f2:	00 00 00 00 00 
 15539f7:	48 89 94 24 60 01 00 	mov    %rdx,0x160(%rsp)
 15539fe:	00 
 15539ff:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 1553a03:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
 1553a0a:	00 
 1553a0b:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 1553a12:	00 
 1553a13:	48 89 94 24 18 01 00 	mov    %rdx,0x118(%rsp)
 1553a1a:	00 
 1553a1b:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 1553a1f:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
 1553a26:	00 
 1553a27:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 1553a2c:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
 1553a33:	00 
 1553a34:	4c 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%r14
 1553a3b:	00 
 1553a3c:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
 1553a41:	48 89 94 24 28 01 00 	mov    %rdx,0x128(%rsp)
 1553a48:	00 
 1553a49:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
 1553a50:	00 
 1553a51:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 1553a56:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 1553a5a:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
 1553a61:	00 
 1553a62:	48 89 94 24 58 01 00 	mov    %rdx,0x158(%rsp)
 1553a69:	00 
 1553a6a:	ba 50 00 00 00       	mov    $0x50,%edx
 1553a6f:	e8 9c 02 e5 fe       	call   3a3d10 <fmt::v11::detail::vformat_to(fmt::v11::detail::buffer<char>&, fmt::v11::basic_string_view<char>, fmt::v11::basic_format_args<fmt::v11::context>, fmt::v11::detail::locale_ref)@plt>
 1553a74:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
 1553a79:	4c 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%r14
 1553a80:	00 
 1553a81:	48 83 ec 08          	sub    $0x8,%rsp
 1553a85:	b9 02 00 00 00       	mov    $0x2,%ecx
 1553a8a:	4c 89 f7             	mov    %r14,%rdi
 1553a8d:	48 8b 56 e8          	mov    -0x18(%rsi),%rdx
 1553a91:	ff 74 24 78          	push   0x78(%rsp)
 1553a95:	ff 74 24 78          	push   0x78(%rsp)
 1553a99:	ff 74 24 78          	push   0x78(%rsp)
 1553a9d:	4c 8b 84 24 80 01 00 	mov    0x180(%rsp),%r8
 1553aa4:	00 
 1553aa5:	4c 8b 8c 24 88 01 00 	mov    0x188(%rsp),%r9
 1553aac:	00 
 1553aad:	e8 9e 9e e4 fe       	call   39d950 <spdlog::details::log_msg::log_msg(spdlog::source_loc, fmt::v11::basic_string_view<char>, spdlog::level::level_enum, fmt::v11::basic_string_view<char>)@plt>
 1553ab2:	31 c9                	xor    %ecx,%ecx
 1553ab4:	48 83 c4 20          	add    $0x20,%rsp
 1553ab8:	45 84 ff             	test   %r15b,%r15b
 1553abb:	0f 95 c1             	setne  %cl
 1553abe:	31 d2                	xor    %edx,%edx
 1553ac0:	41 83 fd 02          	cmp    $0x2,%r13d
 1553ac4:	0f 9e c2             	setle  %dl
 1553ac7:	4c 89 f6             	mov    %r14,%rsi
 1553aca:	4c 89 e7             	mov    %r12,%rdi
 1553acd:	e8 6e 2a e5 fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 1553ad2:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 1553ad7:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
 1553ade:	00 
 1553adf:	48 83 c0 20          	add    $0x20,%rax
 1553ae3:	48 39 c7             	cmp    %rax,%rdi
 1553ae6:	0f 84 b9 fc ff ff    	je     15537a5 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x1f5>
 1553aec:	e8 8f 34 e4 fe       	call   396f80 <free@plt>
 1553af1:	e9 af fc ff ff       	jmp    15537a5 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x1f5>
 1553af6:	e8 e5 26 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553afb:	e9 4e fd ff ff       	jmp    155384e <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x29e>
 1553b00:	48 8b 15 11 9b 62 00 	mov    0x629b11(%rip),%rdx        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 1553b07:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
 1553b0e:	00 
 1553b0f:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
 1553b16:	00 
 1553b17:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 1553b1c:	48 c7 84 24 70 01 00 	movq   $0xfa,0x170(%rsp)
 1553b23:	00 fa 00 00 00 
 1553b28:	4c 8d 84 24 00 01 00 	lea    0x100(%rsp),%r8
 1553b2f:	00 
 1553b30:	48 8d 35 d1 dc 22 00 	lea    0x22dcd1(%rip),%rsi        # 1781808 <_fini@@Base+0x2aae4>
 1553b37:	45 31 c9             	xor    %r9d,%r9d
 1553b3a:	b9 d4 4d 04 00       	mov    $0x44dd4,%ecx
 1553b3f:	48 89 94 24 78 01 00 	mov    %rdx,0x178(%rsp)
 1553b46:	00 
 1553b47:	48 8d 57 20          	lea    0x20(%rdi),%rdx
 1553b4b:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
 1553b52:	00 00 00 00 00 
 1553b57:	49 89 fd             	mov    %rdi,%r13
 1553b5a:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
 1553b5f:	48 89 94 24 60 01 00 	mov    %rdx,0x160(%rsp)
 1553b66:	00 
 1553b67:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 1553b6b:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
 1553b72:	00 
 1553b73:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 1553b78:	48 89 94 24 18 01 00 	mov    %rdx,0x118(%rsp)
 1553b7f:	00 
 1553b80:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 1553b84:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
 1553b8b:	00 
 1553b8c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 1553b91:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
 1553b98:	00 
 1553b99:	4c 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%r14
 1553ba0:	00 
 1553ba1:	48 89 94 24 28 01 00 	mov    %rdx,0x128(%rsp)
 1553ba8:	00 
 1553ba9:	ba 47 00 00 00       	mov    $0x47,%edx
 1553bae:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
 1553bb5:	00 
 1553bb6:	e8 55 01 e5 fe       	call   3a3d10 <fmt::v11::detail::vformat_to(fmt::v11::detail::buffer<char>&, fmt::v11::basic_string_view<char>, fmt::v11::basic_format_args<fmt::v11::context>, fmt::v11::detail::locale_ref)@plt>
 1553bbb:	48 8b 75 08          	mov    0x8(%rbp),%rsi
 1553bbf:	4c 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%r14
 1553bc6:	00 
 1553bc7:	48 83 ec 08          	sub    $0x8,%rsp
 1553bcb:	b9 02 00 00 00       	mov    $0x2,%ecx
 1553bd0:	4c 89 f7             	mov    %r14,%rdi
 1553bd3:	48 8b 56 e8          	mov    -0x18(%rsi),%rdx
 1553bd7:	ff b4 24 98 00 00 00 	push   0x98(%rsp)
 1553bde:	ff b4 24 98 00 00 00 	push   0x98(%rsp)
 1553be5:	ff b4 24 98 00 00 00 	push   0x98(%rsp)
 1553bec:	4c 8b 84 24 80 01 00 	mov    0x180(%rsp),%r8
 1553bf3:	00 
 1553bf4:	4c 8b 8c 24 88 01 00 	mov    0x188(%rsp),%r9
 1553bfb:	00 
 1553bfc:	e8 4f 9d e4 fe       	call   39d950 <spdlog::details::log_msg::log_msg(spdlog::source_loc, fmt::v11::basic_string_view<char>, spdlog::level::level_enum, fmt::v11::basic_string_view<char>)@plt>
 1553c01:	31 c9                	xor    %ecx,%ecx
 1553c03:	48 83 c4 20          	add    $0x20,%rsp
 1553c07:	45 84 e4             	test   %r12b,%r12b
 1553c0a:	0f 95 c1             	setne  %cl
 1553c0d:	31 d2                	xor    %edx,%edx
 1553c0f:	41 83 ff 02          	cmp    $0x2,%r15d
 1553c13:	0f 9e c2             	setle  %dl
 1553c16:	4c 89 f6             	mov    %r14,%rsi
 1553c19:	48 89 ef             	mov    %rbp,%rdi
 1553c1c:	e8 1f 29 e5 fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 1553c21:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
 1553c28:	00 
 1553c29:	4c 89 e8             	mov    %r13,%rax
 1553c2c:	48 83 c0 20          	add    $0x20,%rax
 1553c30:	48 39 c7             	cmp    %rax,%rdi
 1553c33:	0f 84 00 fd ff ff    	je     1553939 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x389>
 1553c39:	e8 42 33 e4 fe       	call   396f80 <free@plt>
 1553c3e:	e9 f6 fc ff ff       	jmp    1553939 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x389>
 1553c43:	e8 98 25 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553c48:	e9 8f fb ff ff       	jmp    15537dc <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x22c>
 1553c4d:	e8 8e 25 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553c52:	e9 0a fd ff ff       	jmp    1553961 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x3b1>
 1553c57:	e8 84 25 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553c5c:	e9 64 fb ff ff       	jmp    15537c5 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x215>
 1553c61:	e8 7a 25 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553c66:	e9 e2 fc ff ff       	jmp    155394d <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x39d>
 1553c6b:	e8 50 1a e4 fe       	call   3956c0 <__stack_chk_fail@plt>
 1553c70:	48 89 c3             	mov    %rax,%rbx
 1553c73:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 1553c78:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553c7c:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 1553c81:	74 05                	je     1553c88 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x6d8>
 1553c83:	e8 58 25 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553c88:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
 1553c8d:	48 85 ff             	test   %rdi,%rdi
 1553c90:	74 05                	je     1553c97 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x6e7>
 1553c92:	e8 f9 db 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1553c97:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
 1553c9c:	48 85 ff             	test   %rdi,%rdi
 1553c9f:	74 05                	je     1553ca6 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x6f6>
 1553ca1:	e8 ea db 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1553ca6:	48 89 df             	mov    %rbx,%rdi
 1553ca9:	e8 d2 f0 e4 fe       	call   3a2d80 <_Unwind_Resume@plt>
 1553cae:	48 89 c3             	mov    %rax,%rbx
 1553cb1:	48 8b 05 c8 8e 62 00 	mov    0x628ec8(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1553cb8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1553cbd:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 1553cc4:	00 
 1553cc5:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553cc9:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 1553cce:	74 a3                	je     1553c73 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x6c3>
 1553cd0:	e8 0b 25 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553cd5:	eb 9c                	jmp    1553c73 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x6c3>
 1553cd7:	49 89 c5             	mov    %rax,%r13
 1553cda:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 1553cdf:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
 1553ce6:	00 
 1553ce7:	49 89 d7             	mov    %rdx,%r15
 1553cea:	48 83 c0 20          	add    $0x20,%rax
 1553cee:	48 39 c7             	cmp    %rax,%rdi
 1553cf1:	74 05                	je     1553cf8 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x748>
 1553cf3:	e8 88 32 e4 fe       	call   396f80 <free@plt>
 1553cf8:	49 83 ef 01          	sub    $0x1,%r15
 1553cfc:	4c 89 ef             	mov    %r13,%rdi
 1553cff:	0f 85 ae 00 00 00    	jne    1553db3 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x803>
 1553d05:	e8 a6 30 e3 fe       	call   386db0 <__cxa_begin_catch@plt>
 1553d0a:	48 8b 10             	mov    (%rax),%rdx
 1553d0d:	48 89 c7             	mov    %rax,%rdi
 1553d10:	ff 52 10             	call   *0x10(%rdx)
 1553d13:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
 1553d18:	48 89 c6             	mov    %rax,%rsi
 1553d1b:	4c 89 f7             	mov    %r14,%rdi
 1553d1e:	e8 8d f7 e4 fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 1553d23:	4c 89 f6             	mov    %r14,%rsi
 1553d26:	4c 89 e7             	mov    %r12,%rdi
 1553d29:	e8 f2 13 e4 fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 1553d2e:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
 1553d35:	00 
 1553d36:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553d3a:	48 8b 05 3f 8e 62 00 	mov    0x628e3f(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1553d41:	48 39 c7             	cmp    %rax,%rdi
 1553d44:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1553d49:	74 05                	je     1553d50 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x7a0>
 1553d4b:	e8 90 24 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553d50:	e8 0b c3 e4 fe       	call   3a0060 <__cxa_end_catch@plt>
 1553d55:	e9 57 fa ff ff       	jmp    15537b1 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x201>
 1553d5a:	48 89 c3             	mov    %rax,%rbx
 1553d5d:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
 1553d64:	00 
 1553d65:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553d69:	48 8b 05 10 8e 62 00 	mov    0x628e10(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1553d70:	48 39 c7             	cmp    %rax,%rdi
 1553d73:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1553d78:	74 05                	je     1553d7f <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x7cf>
 1553d7a:	e8 61 24 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553d7f:	e8 dc c2 e4 fe       	call   3a0060 <__cxa_end_catch@plt>
 1553d84:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 1553d89:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553d8d:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 1553d92:	0f 84 25 ff ff ff    	je     1553cbd <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x70d>
 1553d98:	e8 43 24 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553d9d:	e9 1b ff ff ff       	jmp    1553cbd <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x70d>
 1553da2:	48 89 c3             	mov    %rax,%rbx
 1553da5:	48 8b 05 d4 8d 62 00 	mov    0x628dd4(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1553dac:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1553db1:	eb cc                	jmp    1553d7f <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x7cf>
 1553db3:	e8 f8 2f e3 fe       	call   386db0 <__cxa_begin_catch@plt>
 1553db8:	48 8b 05 c1 8d 62 00 	mov    0x628dc1(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1553dbf:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
 1553dc4:	48 8d 35 25 ba 21 00 	lea    0x21ba25(%rip),%rsi        # 176f7f0 <_fini@@Base+0x18acc>
 1553dcb:	4c 89 f7             	mov    %r14,%rdi
 1553dce:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1553dd3:	e8 d8 f6 e4 fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 1553dd8:	4c 89 f6             	mov    %r14,%rsi
 1553ddb:	4c 89 e7             	mov    %r12,%rdi
 1553dde:	e8 3d 13 e4 fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 1553de3:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
 1553dea:	00 
 1553deb:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553def:	48 8b 05 8a 8d 62 00 	mov    0x628d8a(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1553df6:	48 39 c7             	cmp    %rax,%rdi
 1553df9:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1553dfe:	74 05                	je     1553e05 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x855>
 1553e00:	e8 db 23 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553e05:	e8 e6 8c e4 fe       	call   39caf0 <__cxa_rethrow@plt>
 1553e0a:	48 89 c3             	mov    %rax,%rbx
 1553e0d:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
 1553e14:	00 
 1553e15:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553e19:	48 8b 05 60 8d 62 00 	mov    0x628d60(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1553e20:	48 39 c7             	cmp    %rax,%rdi
 1553e23:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1553e28:	74 05                	je     1553e2f <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x87f>
 1553e2a:	e8 b1 23 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553e2f:	e8 2c c2 e4 fe       	call   3a0060 <__cxa_end_catch@plt>
 1553e34:	e9 4b ff ff ff       	jmp    1553d84 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x7d4>
 1553e39:	48 89 c3             	mov    %rax,%rbx
 1553e3c:	eb f1                	jmp    1553e2f <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x87f>
 1553e3e:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
 1553e43:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
 1553e4a:	00 
 1553e4b:	49 89 c7             	mov    %rax,%r15
 1553e4e:	49 89 d4             	mov    %rdx,%r12
 1553e51:	48 83 c1 20          	add    $0x20,%rcx
 1553e55:	48 39 cf             	cmp    %rcx,%rdi
 1553e58:	74 05                	je     1553e5f <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x8af>
 1553e5a:	e8 21 31 e4 fe       	call   396f80 <free@plt>
 1553e5f:	49 83 ec 01          	sub    $0x1,%r12
 1553e63:	4c 89 ff             	mov    %r15,%rdi
 1553e66:	0f 85 9e 00 00 00    	jne    1553f0a <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x95a>
 1553e6c:	e8 3f 2f e3 fe       	call   386db0 <__cxa_begin_catch@plt>
 1553e71:	48 8b 10             	mov    (%rax),%rdx
 1553e74:	48 89 c7             	mov    %rax,%rdi
 1553e77:	ff 52 10             	call   *0x10(%rdx)
 1553e7a:	48 8d 54 24 27       	lea    0x27(%rsp),%rdx
 1553e7f:	48 89 c6             	mov    %rax,%rsi
 1553e82:	4c 89 f7             	mov    %r14,%rdi
 1553e85:	e8 26 f6 e4 fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 1553e8a:	4c 89 f6             	mov    %r14,%rsi
 1553e8d:	48 89 ef             	mov    %rbp,%rdi
 1553e90:	e8 8b 12 e4 fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 1553e95:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
 1553e9c:	00 
 1553e9d:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553ea1:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 1553ea6:	74 05                	je     1553ead <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x8fd>
 1553ea8:	e8 33 23 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553ead:	e8 ae c1 e4 fe       	call   3a0060 <__cxa_end_catch@plt>
 1553eb2:	e9 82 fa ff ff       	jmp    1553939 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x389>
 1553eb7:	48 89 c3             	mov    %rax,%rbx
 1553eba:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
 1553ec1:	00 
 1553ec2:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553ec6:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 1553ecb:	74 05                	je     1553ed2 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x922>
 1553ecd:	e8 0e 23 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553ed2:	e8 89 c1 e4 fe       	call   3a0060 <__cxa_end_catch@plt>
 1553ed7:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 1553edc:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553ee0:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 1553ee5:	74 05                	je     1553eec <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x93c>
 1553ee7:	e8 f4 22 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553eec:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 1553ef1:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553ef5:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 1553efa:	0f 84 73 fd ff ff    	je     1553c73 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x6c3>
 1553f00:	e9 cb fd ff ff       	jmp    1553cd0 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x720>
 1553f05:	48 89 c3             	mov    %rax,%rbx
 1553f08:	eb c8                	jmp    1553ed2 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x922>
 1553f0a:	e8 a1 2e e3 fe       	call   386db0 <__cxa_begin_catch@plt>
 1553f0f:	48 8d 54 24 27       	lea    0x27(%rsp),%rdx
 1553f14:	48 8d 35 d5 b8 21 00 	lea    0x21b8d5(%rip),%rsi        # 176f7f0 <_fini@@Base+0x18acc>
 1553f1b:	4c 89 f7             	mov    %r14,%rdi
 1553f1e:	e8 8d f5 e4 fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 1553f23:	4c 89 f6             	mov    %r14,%rsi
 1553f26:	48 89 ef             	mov    %rbp,%rdi
 1553f29:	e8 f2 11 e4 fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 1553f2e:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
 1553f35:	00 
 1553f36:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553f3a:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 1553f3f:	74 05                	je     1553f46 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x996>
 1553f41:	e8 9a 22 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553f46:	e8 a5 8b e4 fe       	call   39caf0 <__cxa_rethrow@plt>
 1553f4b:	48 89 c3             	mov    %rax,%rbx
 1553f4e:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
 1553f55:	00 
 1553f56:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1553f5a:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
 1553f5f:	74 05                	je     1553f66 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x9b6>
 1553f61:	e8 7a 22 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1553f66:	e8 f5 c0 e4 fe       	call   3a0060 <__cxa_end_catch@plt>
 1553f6b:	e9 67 ff ff ff       	jmp    1553ed7 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x927>
 1553f70:	48 89 c3             	mov    %rax,%rbx
 1553f73:	eb f1                	jmp    1553f66 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x9b6>
 1553f75:	48 89 c3             	mov    %rax,%rbx
 1553f78:	e9 5a ff ff ff       	jmp    1553ed7 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x927>
 1553f7d:	48 89 c3             	mov    %rax,%rbx
 1553f80:	e9 67 ff ff ff       	jmp    1553eec <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x93c>
 1553f85:	48 89 c3             	mov    %rax,%rbx
 1553f88:	e9 fb fc ff ff       	jmp    1553c88 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x6d8>
 1553f8d:	48 8d 3d 21 7c 20 00 	lea    0x207c21(%rip),%rdi        # 175bbb5 <_fini@@Base+0x4e91>
 1553f94:	e8 47 88 e4 fe       	call   39c7e0 <std::__throw_out_of_range(char const*)@plt>
 1553f99:	48 89 c3             	mov    %rax,%rbx
 1553f9c:	e9 f6 fc ff ff       	jmp    1553c97 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x6e7>
 1553fa1:	48 89 c3             	mov    %rax,%rbx
 1553fa4:	48 8b 05 d5 8b 62 00 	mov    0x628bd5(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1553fab:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1553fb0:	e9 cf fd ff ff       	jmp    1553d84 <RVecISUEntry::retire_smem_bar(std::shared_ptr<RVecUop> const&)@@Base+0x7d4>
 1553fb5:	90                   	nop
 1553fb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 1553fbd:	00 00 00 

0000000001553fc0 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base>:
 1553fc0:	55                   	push   %rbp
 1553fc1:	48 89 e5             	mov    %rsp,%rbp
 1553fc4:	41 57                	push   %r15
 1553fc6:	41 56                	push   %r14
 1553fc8:	41 55                	push   %r13
 1553fca:	41 54                	push   %r12
 1553fcc:	53                   	push   %rbx
 1553fcd:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
 1553fd4:	48 8b 16             	mov    (%rsi),%rdx
 1553fd7:	48 89 bd f8 fe ff ff 	mov    %rdi,-0x108(%rbp)
 1553fde:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 1553fe5:	00 00 
 1553fe7:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1553feb:	31 c0                	xor    %eax,%eax
 1553fed:	80 ba 18 03 00 00 00 	cmpb   $0x0,0x318(%rdx)
 1553ff4:	0f 85 76 04 00 00    	jne    1554470 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x4b0>
 1553ffa:	48 8b 9a b0 02 00 00 	mov    0x2b0(%rdx),%rbx
 1554001:	48 8d 82 a0 02 00 00 	lea    0x2a0(%rdx),%rax
 1554008:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 155400f:	48 39 c3             	cmp    %rax,%rbx
 1554012:	0f 84 33 07 00 00    	je     155474b <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x78b>
 1554018:	48 8d 85 20 ff ff ff 	lea    -0xe0(%rbp),%rax
 155401f:	49 89 f7             	mov    %rsi,%r15
 1554022:	c6 85 e7 fe ff ff 01 	movb   $0x1,-0x119(%rbp)
 1554029:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 1554030:	48 8d 85 40 ff ff ff 	lea    -0xc0(%rbp),%rax
 1554037:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
 155403e:	48 8d 85 10 ff ff ff 	lea    -0xf0(%rbp),%rax
 1554045:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 155404c:	0f 1f 40 00          	nopl   0x0(%rax)
 1554050:	8b 43 20             	mov    0x20(%rbx),%eax
 1554053:	48 8b b2 c8 02 00 00 	mov    0x2c8(%rdx),%rsi
 155405a:	ba 01 00 00 00       	mov    $0x1,%edx
 155405f:	48 89 c1             	mov    %rax,%rcx
 1554062:	48 c1 e8 06          	shr    $0x6,%rax
 1554066:	48 d3 e2             	shl    %cl,%rdx
 1554069:	48 85 14 c6          	test   %rdx,(%rsi,%rax,8)
 155406d:	0f 85 7c 03 00 00    	jne    15543ef <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x42f>
 1554073:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 155407a:	48 8b 90 90 01 00 00 	mov    0x190(%rax),%rdx
 1554081:	4c 8d 80 88 01 00 00 	lea    0x188(%rax),%r8
 1554088:	4d 89 c5             	mov    %r8,%r13
 155408b:	48 85 d2             	test   %rdx,%rdx
 155408e:	74 3b                	je     15540cb <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x10b>
 1554090:	48 89 c7             	mov    %rax,%rdi
 1554093:	eb 0f                	jmp    15540a4 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0xe4>
 1554095:	0f 1f 00             	nopl   (%rax)
 1554098:	49 89 d5             	mov    %rdx,%r13
 155409b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 155409f:	48 85 d2             	test   %rdx,%rdx
 15540a2:	74 0e                	je     15540b2 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0xf2>
 15540a4:	3b 4a 20             	cmp    0x20(%rdx),%ecx
 15540a7:	7e ef                	jle    1554098 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0xd8>
 15540a9:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 15540ad:	48 85 d2             	test   %rdx,%rdx
 15540b0:	75 f2                	jne    15540a4 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0xe4>
 15540b2:	4d 39 c5             	cmp    %r8,%r13
 15540b5:	48 89 f8             	mov    %rdi,%rax
 15540b8:	48 89 bd f8 fe ff ff 	mov    %rdi,-0x108(%rbp)
 15540bf:	74 0a                	je     15540cb <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x10b>
 15540c1:	41 3b 4d 20          	cmp    0x20(%r13),%ecx
 15540c5:	0f 8d e7 00 00 00    	jge    15541b2 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x1f2>
 15540cb:	bf 40 00 00 00       	mov    $0x40,%edi
 15540d0:	4c 89 85 d0 fe ff ff 	mov    %r8,-0x130(%rbp)
 15540d7:	4c 8d a0 80 01 00 00 	lea    0x180(%rax),%r12
 15540de:	e8 7d f1 e3 fe       	call   393260 <operator new(unsigned long)@plt>
 15540e3:	4c 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%r8
 15540ea:	8b 4b 20             	mov    0x20(%rbx),%ecx
 15540ed:	49 89 c6             	mov    %rax,%r14
 15540f0:	48 c7 40 28 00 00 00 	movq   $0x0,0x28(%rax)
 15540f7:	00 
 15540f8:	48 c7 40 30 00 00 00 	movq   $0x0,0x30(%rax)
 15540ff:	00 
 1554100:	48 8d 70 20          	lea    0x20(%rax),%rsi
 1554104:	48 c7 40 38 00 00 00 	movq   $0x0,0x38(%rax)
 155410b:	00 
 155410c:	4d 39 e8             	cmp    %r13,%r8
 155410f:	89 48 20             	mov    %ecx,0x20(%rax)
 1554112:	0f 84 f8 02 00 00    	je     1554410 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x450>
 1554118:	41 8b 55 20          	mov    0x20(%r13),%edx
 155411c:	39 d1                	cmp    %edx,%ecx
 155411e:	0f 8d 8c 05 00 00    	jge    15546b0 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x6f0>
 1554124:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 155412b:	48 89 b5 c0 fe ff ff 	mov    %rsi,-0x140(%rbp)
 1554132:	89 8d d0 fe ff ff    	mov    %ecx,-0x130(%rbp)
 1554138:	4c 39 a8 98 01 00 00 	cmp    %r13,0x198(%rax)
 155413f:	0f 84 fb 05 00 00    	je     1554740 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x780>
 1554145:	4c 89 ef             	mov    %r13,%rdi
 1554148:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
 155414f:	e8 ec fe e3 fe       	call   394040 <std::_Rb_tree_decrement(std::_Rb_tree_node_base*)@plt>
 1554154:	8b 8d d0 fe ff ff    	mov    -0x130(%rbp),%ecx
 155415a:	3b 48 20             	cmp    0x20(%rax),%ecx
 155415d:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
 1554164:	48 8b b5 c0 fe ff ff 	mov    -0x140(%rbp),%rsi
 155416b:	0f 8e c0 02 00 00    	jle    1554431 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x471>
 1554171:	48 83 78 18 00       	cmpq   $0x0,0x18(%rax)
 1554176:	0f 85 c4 05 00 00    	jne    1554740 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x780>
 155417c:	45 31 ed             	xor    %r13d,%r13d
 155417f:	4c 39 c0             	cmp    %r8,%rax
 1554182:	74 09                	je     155418d <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x1cd>
 1554184:	4d 85 ed             	test   %r13,%r13
 1554187:	0f 84 fb 05 00 00    	je     1554788 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x7c8>
 155418d:	bf 01 00 00 00       	mov    $0x1,%edi
 1554192:	48 89 c2             	mov    %rax,%rdx
 1554195:	4c 89 c1             	mov    %r8,%rcx
 1554198:	4c 89 f6             	mov    %r14,%rsi
 155419b:	e8 90 df e2 fe       	call   382130 <std::_Rb_tree_insert_and_rebalance(bool, std::_Rb_tree_node_base*, std::_Rb_tree_node_base*, std::_Rb_tree_node_base&)@plt>
 15541a0:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 15541a7:	4d 89 f5             	mov    %r14,%r13
 15541aa:	48 83 80 a8 01 00 00 	addq   $0x1,0x1a8(%rax)
 15541b1:	01 
 15541b2:	4c 8b b5 e8 fe ff ff 	mov    -0x118(%rbp),%r14
 15541b9:	49 8d 75 28          	lea    0x28(%r13),%rsi
 15541bd:	4c 89 f7             	mov    %r14,%rdi
 15541c0:	e8 7b 8b e4 fe       	call   39cd40 <std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::vector(std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > const&)@plt>
 15541c5:	48 8b bd f8 fe ff ff 	mov    -0x108(%rbp),%rdi
 15541cc:	e8 ff ba e3 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 15541d1:	4c 89 f6             	mov    %r14,%rsi
 15541d4:	4c 8b b5 c8 fe ff ff 	mov    -0x138(%rbp),%r14
 15541db:	41 89 c4             	mov    %eax,%r12d
 15541de:	4c 89 f7             	mov    %r14,%rdi
 15541e1:	e8 5a 8b e4 fe       	call   39cd40 <std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::vector(std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > const&)@plt>
 15541e6:	31 d2                	xor    %edx,%edx
 15541e8:	4c 89 e6             	mov    %r12,%rsi
 15541eb:	4c 89 f7             	mov    %r14,%rdi
 15541ee:	e8 9d 46 e3 fe       	call   388890 <IsuUtil::get_avail_inf_id(std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, unsigned long, bool)@plt>
 15541f3:	4c 89 f7             	mov    %r14,%rdi
 15541f6:	41 89 c5             	mov    %eax,%r13d
 15541f9:	e8 d2 2f e3 fe       	call   3871d0 <std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::~vector()@plt>
 15541fe:	45 85 ed             	test   %r13d,%r13d
 1554201:	0f 88 21 05 00 00    	js     1554728 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x768>
 1554207:	4c 8b 25 92 fa 62 00 	mov    0x62fa92(%rip),%r12        # 1b83ca0 <guard variable for ValuTypeInfoTable::Instance()::instance@@Base-0x480f8>
 155420e:	41 0f b6 04 24       	movzbl (%r12),%eax
 1554213:	84 c0                	test   %al,%al
 1554215:	0f 84 e5 03 00 00    	je     1554600 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x640>
 155421b:	4c 8b 25 46 00 63 00 	mov    0x630046(%rip),%r12        # 1b84268 <ValuTypeInfoTable::Instance()::instance@@Base-0x47b38>
 1554222:	49 8b 04 24          	mov    (%r12),%rax
 1554226:	48 85 c0             	test   %rax,%rax
 1554229:	0f 84 19 04 00 00    	je     1554648 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x688>
 155422f:	4c 8b 30             	mov    (%rax),%r14
 1554232:	49 8b 07             	mov    (%r15),%rax
 1554235:	bf 50 03 00 00       	mov    $0x350,%edi
 155423a:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
 1554241:	00 00 00 00 
 1554245:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 155424c:	00 00 00 00 
 1554250:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 1554257:	e8 04 f0 e3 fe       	call   393260 <operator new(unsigned long)@plt>
 155425c:	48 b9 01 00 00 00 01 	movabs $0x100000001,%rcx
 1554263:	00 00 00 
 1554266:	49 89 c4             	mov    %rax,%r12
 1554269:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
 1554270:	48 89 48 08          	mov    %rcx,0x8(%rax)
 1554274:	48 8b 05 45 8a 62 00 	mov    0x628a45(%rip),%rax        # 1b7ccc0 <vtable for std::_Sp_counted_ptr_inplace<RVecUop, std::allocator<RVecUop>, (__gnu_cxx::_Lock_policy)2>@@Base+0x2a0e0>
 155427b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
 1554282:	48 83 c0 10          	add    $0x10,%rax
 1554286:	49 89 04 24          	mov    %rax,(%r12)
 155428a:	e8 51 e2 e4 fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 155428f:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
 1554296:	49 8d 7c 24 10       	lea    0x10(%r12),%rdi
 155429b:	4c 89 f2             	mov    %r14,%rdx
 155429e:	e8 7d dc e2 fe       	call   381f20 <RVecUop::RVecUop(std::shared_ptr<Isa>, std::map<RvaluType, RvecValuInfo, std::less<RvaluType>, std::allocator<std::pair<RvaluType const, RvecValuInfo> > > const&)@plt>
 15542a3:	48 8b bd 18 ff ff ff 	mov    -0xe8(%rbp),%rdi
 15542aa:	48 85 ff             	test   %rdi,%rdi
 15542ad:	74 05                	je     15542b4 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x2f4>
 15542af:	e8 dc d5 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15542b4:	49 8b 04 24          	mov    (%r12),%rax
 15542b8:	4c 89 e7             	mov    %r12,%rdi
 15542bb:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 15542c2:	48 8b 35 a7 e4 62 00 	mov    0x62e4a7(%rip),%rsi        # 1b82770 <typeinfo for std::_Sp_make_shared_tag@@Base+0x3d918>
 15542c9:	ff 50 20             	call   *0x20(%rax)
 15542cc:	8b 53 20             	mov    0x20(%rbx),%edx
 15542cf:	48 8b bd f8 fe ff ff 	mov    -0x108(%rbp),%rdi
 15542d6:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 15542dd:	89 90 6c 01 00 00    	mov    %edx,0x16c(%rax)
 15542e3:	e8 e8 b9 e3 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 15542e8:	48 8b 95 00 ff ff ff 	mov    -0x100(%rbp),%rdx
 15542ef:	4c 8d a5 00 ff ff ff 	lea    -0x100(%rbp),%r12
 15542f6:	4c 89 e6             	mov    %r12,%rsi
 15542f9:	48 89 82 80 00 00 00 	mov    %rax,0x80(%rdx)
 1554300:	49 63 c5             	movslq %r13d,%rax
 1554303:	48 c1 e0 04          	shl    $0x4,%rax
 1554307:	48 03 85 20 ff ff ff 	add    -0xe0(%rbp),%rax
 155430e:	48 8b 00             	mov    (%rax),%rax
 1554311:	48 8b b8 00 01 00 00 	mov    0x100(%rax),%rdi
 1554318:	e8 93 c6 e2 fe       	call   3809b0 <TmINIPort<std::shared_ptr<RVecUop>, (FcType)0>::send(std::shared_ptr<RVecUop> const&)@plt>
 155431d:	84 c0                	test   %al,%al
 155431f:	75 6d                	jne    155438e <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x3ce>
 1554321:	48 8b bd f8 fe ff ff 	mov    -0x108(%rbp),%rdi
 1554328:	4c 8b 77 20          	mov    0x20(%rdi),%r14
 155432c:	e8 9f b9 e3 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 1554331:	41 56                	push   %r14
 1554333:	50                   	push   %rax
 1554334:	4c 8d 0d 65 60 32 00 	lea    0x326065(%rip),%r9        # 187a3a0 <typeinfo name for RVecISUHResourceChecker@@Base+0x70>
 155433b:	48 8b 05 6e e5 62 00 	mov    0x62e56e(%rip),%rax        # 1b828b0 <stderr@GLIBC_2.2.5>
 1554342:	48 8d 0d 69 5b 21 00 	lea    0x215b69(%rip),%rcx        # 1769eb2 <_fini@@Base+0x1318e>
 1554349:	48 8d 15 ba 62 20 00 	lea    0x2062ba(%rip),%rdx        # 175a60a <_fini@@Base+0x38e6>
 1554350:	48 8d 35 a9 d3 22 00 	lea    0x22d3a9(%rip),%rsi        # 1781700 <_fini@@Base+0x2a9dc>
 1554357:	41 b8 b5 05 00 00    	mov    $0x5b5,%r8d
 155435d:	48 8b 38             	mov    (%rax),%rdi
 1554360:	31 c0                	xor    %eax,%eax
 1554362:	e8 a9 7f e4 fe       	call   39c310 <fprintf@plt>
 1554367:	58                   	pop    %rax
 1554368:	48 8b 05 19 7c 62 00 	mov    0x627c19(%rip),%rax        # 1b7bf88 <stdout@GLIBC_2.2.5>
 155436f:	5a                   	pop    %rdx
 1554370:	48 8b 38             	mov    (%rax),%rdi
 1554373:	e8 08 28 e4 fe       	call   396b80 <fflush@plt>
 1554378:	48 8b 05 31 e5 62 00 	mov    0x62e531(%rip),%rax        # 1b828b0 <stderr@GLIBC_2.2.5>
 155437f:	48 8b 38             	mov    (%rax),%rdi
 1554382:	e8 f9 27 e4 fe       	call   396b80 <fflush@plt>
 1554387:	c6 85 e7 fe ff ff 00 	movb   $0x0,-0x119(%rbp)
 155438e:	8b 4b 20             	mov    0x20(%rbx),%ecx
 1554391:	49 8b 17             	mov    (%r15),%rdx
 1554394:	4c 89 e6             	mov    %r12,%rsi
 1554397:	4c 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%r14
 155439e:	48 89 c8             	mov    %rcx,%rax
 15543a1:	48 c1 e8 03          	shr    $0x3,%rax
 15543a5:	4c 89 f7             	mov    %r14,%rdi
 15543a8:	25 f8 ff ff 1f       	and    $0x1ffffff8,%eax
 15543ad:	48 03 82 c8 02 00 00 	add    0x2c8(%rdx),%rax
 15543b4:	ba 01 00 00 00       	mov    $0x1,%edx
 15543b9:	48 d3 e2             	shl    %cl,%rdx
 15543bc:	48 09 10             	or     %rdx,(%rax)
 15543bf:	44 89 ea             	mov    %r13d,%edx
 15543c2:	e8 f9 c3 e2 fe       	call   3807c0 <RVecISUEntry::push_pmu(std::shared_ptr<RVecUop> const&, int)@plt>
 15543c7:	4c 89 e6             	mov    %r12,%rsi
 15543ca:	4c 89 f7             	mov    %r14,%rdi
 15543cd:	e8 ee 97 e3 fe       	call   38dbc0 <RVecISUEntry::log_issue_check_passed_bar(std::shared_ptr<RVecUop> const&)@plt>
 15543d2:	48 8b bd 08 ff ff ff 	mov    -0xf8(%rbp),%rdi
 15543d9:	48 85 ff             	test   %rdi,%rdi
 15543dc:	74 05                	je     15543e3 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x423>
 15543de:	e8 ad d4 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15543e3:	48 8b bd e8 fe ff ff 	mov    -0x118(%rbp),%rdi
 15543ea:	e8 e1 2d e3 fe       	call   3871d0 <std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::~vector()@plt>
 15543ef:	48 89 df             	mov    %rbx,%rdi
 15543f2:	e8 09 22 e4 fe       	call   396600 <std::_Rb_tree_increment(std::_Rb_tree_node_base const*)@plt>
 15543f7:	48 39 85 f0 fe ff ff 	cmp    %rax,-0x110(%rbp)
 15543fe:	48 89 c3             	mov    %rax,%rbx
 1554401:	0f 84 99 00 00 00    	je     15544a0 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x4e0>
 1554407:	49 8b 17             	mov    (%r15),%rdx
 155440a:	e9 41 fc ff ff       	jmp    1554050 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x90>
 155440f:	90                   	nop
 1554410:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1554417:	48 83 b8 a8 01 00 00 	cmpq   $0x0,0x1a8(%rax)
 155441e:	00 
 155441f:	74 10                	je     1554431 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x471>
 1554421:	48 8b 80 a0 01 00 00 	mov    0x1a0(%rax),%rax
 1554428:	3b 48 20             	cmp    0x20(%rax),%ecx
 155442b:	0f 8f 4b fd ff ff    	jg     155417c <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x1bc>
 1554431:	4c 89 e7             	mov    %r12,%rdi
 1554434:	4c 89 85 d0 fe ff ff 	mov    %r8,-0x130(%rbp)
 155443b:	e8 e0 69 e3 fe       	call   38ae20 <std::_Rb_tree<InfFromISU, std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > >, std::_Select1st<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > >::_M_get_insert_unique_pos(InfFromISU const&)@plt>
 1554440:	48 85 d2             	test   %rdx,%rdx
 1554443:	49 89 c5             	mov    %rax,%r13
 1554446:	4c 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%r8
 155444d:	48 89 d0             	mov    %rdx,%rax
 1554450:	0f 85 29 fd ff ff    	jne    155417f <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x1bf>
 1554456:	49 8d 7e 28          	lea    0x28(%r14),%rdi
 155445a:	e8 71 2d e3 fe       	call   3871d0 <std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::~vector()@plt>
 155445f:	4c 89 f7             	mov    %r14,%rdi
 1554462:	e8 b9 df e3 fe       	call   392420 <operator delete(void*)@plt>
 1554467:	e9 46 fd ff ff       	jmp    15541b2 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x1f2>
 155446c:	0f 1f 40 00          	nopl   0x0(%rax)
 1554470:	c6 85 e7 fe ff ff 00 	movb   $0x0,-0x119(%rbp)
 1554477:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 155447b:	64 48 33 1c 25 28 00 	xor    %fs:0x28,%rbx
 1554482:	00 00 
 1554484:	0f b6 85 e7 fe ff ff 	movzbl -0x119(%rbp),%eax
 155448b:	0f 85 9d 03 00 00    	jne    155482e <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x86e>
 1554491:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
 1554495:	5b                   	pop    %rbx
 1554496:	41 5c                	pop    %r12
 1554498:	41 5d                	pop    %r13
 155449a:	41 5e                	pop    %r14
 155449c:	41 5f                	pop    %r15
 155449e:	5d                   	pop    %rbp
 155449f:	c3                   	ret
 15544a0:	80 bd e7 fe ff ff 00 	cmpb   $0x0,-0x119(%rbp)
 15544a7:	0f 85 9b 02 00 00    	jne    1554748 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x788>
 15544ad:	4c 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%r14
 15544b4:	48 8d 9d 20 ff ff ff 	lea    -0xe0(%rbp),%rbx
 15544bb:	48 8d 95 10 ff ff ff 	lea    -0xf0(%rbp),%rdx
 15544c2:	48 8d 35 51 50 21 00 	lea    0x215051(%rip),%rsi        # 176951a <_fini@@Base+0x127f6>
 15544c9:	48 c7 85 48 ff ff ff 	movq   $0x0,-0xb8(%rbp)
 15544d0:	00 00 00 00 
 15544d4:	48 c7 85 50 ff ff ff 	movq   $0x0,-0xb0(%rbp)
 15544db:	00 00 00 00 
 15544df:	48 89 df             	mov    %rbx,%rdi
 15544e2:	48 c7 85 58 ff ff ff 	movq   $0x0,-0xa8(%rbp)
 15544e9:	00 00 00 00 
 15544ed:	48 c7 85 60 ff ff ff 	movq   $0x0,-0xa0(%rbp)
 15544f4:	00 00 00 00 
 15544f8:	49 83 be 30 01 00 00 	cmpq   $0x1,0x130(%r14)
 15544ff:	01 
 1554500:	48 c7 85 68 ff ff ff 	movq   $0x0,-0x98(%rbp)
 1554507:	00 00 00 00 
 155450b:	48 c7 85 70 ff ff ff 	movq   $0x0,-0x90(%rbp)
 1554512:	00 00 00 00 
 1554516:	48 c7 85 78 ff ff ff 	movq   $0x0,-0x88(%rbp)
 155451d:	00 00 00 00 
 1554521:	48 c7 45 80 00 00 00 	movq   $0x0,-0x80(%rbp)
 1554528:	00 
 1554529:	48 c7 45 88 00 00 00 	movq   $0x0,-0x78(%rbp)
 1554530:	00 
 1554531:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 1554538:	00 
 1554539:	48 c7 45 98 00 00 00 	movq   $0x0,-0x68(%rbp)
 1554540:	00 
 1554541:	19 c0                	sbb    %eax,%eax
 1554543:	48 c7 45 a0 00 00 00 	movq   $0x0,-0x60(%rbp)
 155454a:	00 
 155454b:	48 c7 45 a8 00 00 00 	movq   $0x0,-0x58(%rbp)
 1554552:	00 
 1554553:	83 e0 1b             	and    $0x1b,%eax
 1554556:	48 c7 45 b0 00 00 00 	movq   $0x0,-0x50(%rbp)
 155455d:	00 
 155455e:	48 c7 45 b8 00 00 00 	movq   $0x0,-0x48(%rbp)
 1554565:	00 
 1554566:	83 c0 08             	add    $0x8,%eax
 1554569:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
 1554570:	00 
 1554571:	89 85 40 ff ff ff    	mov    %eax,-0xc0(%rbp)
 1554577:	e8 34 ef e4 fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 155457c:	4c 8d a5 40 ff ff ff 	lea    -0xc0(%rbp),%r12
 1554583:	48 89 da             	mov    %rbx,%rdx
 1554586:	4c 89 fe             	mov    %r15,%rsi
 1554589:	4c 89 f7             	mov    %r14,%rdi
 155458c:	4c 89 e1             	mov    %r12,%rcx
 155458f:	e8 0c c4 e3 fe       	call   3909a0 <RVecISUEntry::log_blocked_reason(std::shared_ptr<RVecUop> const&, std::string const&, IssueCheckResult const&)@plt>
 1554594:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 155459b:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 155459f:	48 3b 3d da 85 62 00 	cmp    0x6285da(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 15545a6:	0f 85 f5 01 00 00    	jne    15547a1 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x7e1>
 15545ac:	4c 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%r14
 15545b3:	4c 89 fe             	mov    %r15,%rsi
 15545b6:	48 89 df             	mov    %rbx,%rdi
 15545b9:	4d 8b ae f0 00 00 00 	mov    0xf0(%r14),%r13
 15545c0:	e8 6b 23 e3 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 15545c5:	49 8d 96 d0 00 00 00 	lea    0xd0(%r14),%rdx
 15545cc:	4c 89 e1             	mov    %r12,%rcx
 15545cf:	48 89 de             	mov    %rbx,%rsi
 15545d2:	4c 89 ef             	mov    %r13,%rdi
 15545d5:	e8 f6 ea e3 fe       	call   3930d0 <PemRVecPerfISU::que_issue_blocked(std::shared_ptr<RVecUop>, IsuQueue&, InstrBlockedReason&)@plt>
 15545da:	48 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%rdi
 15545e1:	48 85 ff             	test   %rdi,%rdi
 15545e4:	74 05                	je     15545eb <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x62b>
 15545e6:	e8 a5 d2 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15545eb:	4c 89 e7             	mov    %r12,%rdi
 15545ee:	e8 ed f4 e2 fe       	call   383ae0 <IssueCheckResult::~IssueCheckResult()@plt>
 15545f3:	e9 7f fe ff ff       	jmp    1554477 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x4b7>
 15545f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 15545ff:	00 
 1554600:	4c 89 e7             	mov    %r12,%rdi
 1554603:	e8 b8 f3 e4 fe       	call   3a39c0 <__cxa_guard_acquire@plt>
 1554608:	85 c0                	test   %eax,%eax
 155460a:	0f 84 0b fc ff ff    	je     155421b <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x25b>
 1554610:	4c 89 e7             	mov    %r12,%rdi
 1554613:	e8 28 7a e3 fe       	call   38c040 <__cxa_guard_release@plt>
 1554618:	4c 8b 25 49 fc 62 00 	mov    0x62fc49(%rip),%r12        # 1b84268 <ValuTypeInfoTable::Instance()::instance@@Base-0x47b38>
 155461f:	48 8b 3d 5a fe 62 00 	mov    0x62fe5a(%rip),%rdi        # 1b84480 <std::shared_ptr<ValuTypeInfoTable>::~shared_ptr()@@Base+0x772990>
 1554626:	48 8d 15 13 cd 5d 00 	lea    0x5dcd13(%rip),%rdx        # 1b31340 <typeinfo name for std::bad_array_new_length@@Base+0x27f150>
 155462d:	4c 89 e6             	mov    %r12,%rsi
 1554630:	e8 cb c9 e3 fe       	call   391000 <__cxa_atexit@plt>
 1554635:	49 8b 04 24          	mov    (%r12),%rax
 1554639:	48 85 c0             	test   %rax,%rax
 155463c:	0f 85 ed fb ff ff    	jne    155422f <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x26f>
 1554642:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1554648:	bf 18 00 00 00       	mov    $0x18,%edi
 155464d:	e8 0e ec e3 fe       	call   393260 <operator new(unsigned long)@plt>
 1554652:	49 89 c6             	mov    %rax,%r14
 1554655:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
 155465c:	00 00 00 
 155465f:	49 89 46 08          	mov    %rax,0x8(%r14)
 1554663:	48 8b 05 56 08 63 00 	mov    0x630856(%rip),%rax        # 1b84ec0 <vtable for std::_Sp_counted_ptr_inplace<ValuTypeInfoTable, std::allocator<ValuTypeInfoTable>, (__gnu_cxx::_Lock_policy)2>@@Base+0x305a0>
 155466a:	49 8d 7e 10          	lea    0x10(%r14),%rdi
 155466e:	48 83 c0 10          	add    $0x10,%rax
 1554672:	49 89 06             	mov    %rax,(%r14)
 1554675:	e8 86 bd e3 fe       	call   390400 <ValuTypeInfoTable::ValuTypeInfoTable()@plt>
 155467a:	49 8b 06             	mov    (%r14),%rax
 155467d:	4c 89 f7             	mov    %r14,%rdi
 1554680:	48 8b 35 e9 e0 62 00 	mov    0x62e0e9(%rip),%rsi        # 1b82770 <typeinfo for std::_Sp_make_shared_tag@@Base+0x3d918>
 1554687:	ff 50 20             	call   *0x20(%rax)
 155468a:	49 8b 7c 24 08       	mov    0x8(%r12),%rdi
 155468f:	49 89 04 24          	mov    %rax,(%r12)
 1554693:	4d 89 74 24 08       	mov    %r14,0x8(%r12)
 1554698:	48 85 ff             	test   %rdi,%rdi
 155469b:	0f 84 8e fb ff ff    	je     155422f <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x26f>
 15546a1:	e8 ea d1 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15546a6:	49 8b 04 24          	mov    (%r12),%rax
 15546aa:	e9 80 fb ff ff       	jmp    155422f <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x26f>
 15546af:	90                   	nop
 15546b0:	48 89 b5 d0 fe ff ff 	mov    %rsi,-0x130(%rbp)
 15546b7:	0f 8e 99 fd ff ff    	jle    1554456 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x496>
 15546bd:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 15546c4:	4c 39 a8 a0 01 00 00 	cmp    %r13,0x1a0(%rax)
 15546cb:	0f 84 cb 00 00 00    	je     155479c <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x7dc>
 15546d1:	4c 89 ef             	mov    %r13,%rdi
 15546d4:	89 8d b8 fe ff ff    	mov    %ecx,-0x148(%rbp)
 15546da:	4c 89 85 c0 fe ff ff 	mov    %r8,-0x140(%rbp)
 15546e1:	89 95 e0 fe ff ff    	mov    %edx,-0x120(%rbp)
 15546e7:	e8 94 88 e3 fe       	call   38cf80 <std::_Rb_tree_increment(std::_Rb_tree_node_base*)@plt>
 15546ec:	8b 8d b8 fe ff ff    	mov    -0x148(%rbp),%ecx
 15546f2:	3b 48 20             	cmp    0x20(%rax),%ecx
 15546f5:	4c 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%r8
 15546fc:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
 1554703:	0f 8d 28 fd ff ff    	jge    1554431 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x471>
 1554709:	49 83 7d 18 00       	cmpq   $0x0,0x18(%r13)
 155470e:	8b 95 e0 fe ff ff    	mov    -0x120(%rbp),%edx
 1554714:	0f 84 82 00 00 00    	je     155479c <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x7dc>
 155471a:	49 89 c5             	mov    %rax,%r13
 155471d:	e9 5d fa ff ff       	jmp    155417f <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x1bf>
 1554722:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1554728:	48 8b bd e8 fe ff ff 	mov    -0x118(%rbp),%rdi
 155472f:	e8 9c 2a e3 fe       	call   3871d0 <std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::~vector()@plt>
 1554734:	c6 85 e7 fe ff ff 00 	movb   $0x0,-0x119(%rbp)
 155473b:	e9 af fc ff ff       	jmp    15543ef <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x42f>
 1554740:	4c 89 e8             	mov    %r13,%rax
 1554743:	e9 37 fa ff ff       	jmp    155417f <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x1bf>
 1554748:	49 8b 17             	mov    (%r15),%rdx
 155474b:	48 8b 3a             	mov    (%rdx),%rdi
 155474e:	c6 82 18 03 00 00 01 	movb   $0x1,0x318(%rdx)
 1554755:	e8 46 01 e3 fe       	call   3848a0 <Isa::name() const@plt>
 155475a:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 155475f:	c6 85 e7 fe ff ff 01 	movb   $0x1,-0x119(%rbp)
 1554766:	0f 85 0b fd ff ff    	jne    1554477 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x4b7>
 155476c:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1554773:	48 8b b8 f0 00 00 00 	mov    0xf0(%rax),%rdi
 155477a:	e8 61 e4 e4 fe       	call   3a2be0 <PemRVecPerfISU::send_issue()@plt>
 155477f:	e9 f3 fc ff ff       	jmp    1554477 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x4b7>
 1554784:	0f 1f 40 00          	nopl   0x0(%rax)
 1554788:	41 8b 4e 20          	mov    0x20(%r14),%ecx
 155478c:	8b 50 20             	mov    0x20(%rax),%edx
 155478f:	31 ff                	xor    %edi,%edi
 1554791:	39 d1                	cmp    %edx,%ecx
 1554793:	40 0f 9c c7          	setl   %dil
 1554797:	e9 f6 f9 ff ff       	jmp    1554192 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x1d2>
 155479c:	4c 89 e8             	mov    %r13,%rax
 155479f:	eb ee                	jmp    155478f <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x7cf>
 15547a1:	e8 3a 1a ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 15547a6:	e9 01 fe ff ff       	jmp    15545ac <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x5ec>
 15547ab:	4c 8d a5 40 ff ff ff 	lea    -0xc0(%rbp),%r12
 15547b2:	48 89 c3             	mov    %rax,%rbx
 15547b5:	4c 89 e7             	mov    %r12,%rdi
 15547b8:	e8 23 f3 e2 fe       	call   383ae0 <IssueCheckResult::~IssueCheckResult()@plt>
 15547bd:	48 89 df             	mov    %rbx,%rdi
 15547c0:	e8 bb e5 e4 fe       	call   3a2d80 <_Unwind_Resume@plt>
 15547c5:	4c 89 f7             	mov    %r14,%rdi
 15547c8:	48 89 c3             	mov    %rax,%rbx
 15547cb:	e8 50 dc e3 fe       	call   392420 <operator delete(void*)@plt>
 15547d0:	48 8b bd e8 fe ff ff 	mov    -0x118(%rbp),%rdi
 15547d7:	e8 f4 29 e3 fe       	call   3871d0 <std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::~vector()@plt>
 15547dc:	48 89 df             	mov    %rbx,%rdi
 15547df:	e8 9c e5 e4 fe       	call   3a2d80 <_Unwind_Resume@plt>
 15547e4:	48 8b bd 08 ff ff ff 	mov    -0xf8(%rbp),%rdi
 15547eb:	48 89 c3             	mov    %rax,%rbx
 15547ee:	48 85 ff             	test   %rdi,%rdi
 15547f1:	74 dd                	je     15547d0 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x810>
 15547f3:	e8 98 d0 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15547f8:	eb d6                	jmp    15547d0 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x810>
 15547fa:	48 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%rdi
 1554801:	48 89 c3             	mov    %rax,%rbx
 1554804:	48 85 ff             	test   %rdi,%rdi
 1554807:	74 ac                	je     15547b5 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x7f5>
 1554809:	e8 82 d0 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 155480e:	eb a5                	jmp    15547b5 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x7f5>
 1554810:	48 89 c3             	mov    %rax,%rbx
 1554813:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 155481a:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 155481e:	48 3b 3d 5b 83 62 00 	cmp    0x62835b(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1554825:	74 8e                	je     15547b5 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x7f5>
 1554827:	e8 b4 19 ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 155482c:	eb 87                	jmp    15547b5 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x7f5>
 155482e:	e8 8d 0e e4 fe       	call   3956c0 <__stack_chk_fail@plt>
 1554833:	48 89 c3             	mov    %rax,%rbx
 1554836:	eb 98                	jmp    15547d0 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x810>
 1554838:	48 8b bd 18 ff ff ff 	mov    -0xe8(%rbp),%rdi
 155483f:	48 89 c3             	mov    %rax,%rbx
 1554842:	48 85 ff             	test   %rdi,%rdi
 1554845:	74 05                	je     155484c <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x88c>
 1554847:	e8 44 d0 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 155484c:	4c 89 e7             	mov    %r12,%rdi
 155484f:	e8 cc db e3 fe       	call   392420 <operator delete(void*)@plt>
 1554854:	e9 77 ff ff ff       	jmp    15547d0 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@@Base+0x810>
 1554859:	90                   	nop
 155485a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
