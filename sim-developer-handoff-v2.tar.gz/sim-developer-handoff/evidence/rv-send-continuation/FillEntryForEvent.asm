
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000001751f20 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base>:
 1751f20:	41 57                	push   %r15
 1751f22:	41 56                	push   %r14
 1751f24:	41 55                	push   %r13
 1751f26:	41 54                	push   %r12
 1751f28:	41 89 f5             	mov    %esi,%r13d
 1751f2b:	55                   	push   %rbp
 1751f2c:	53                   	push   %rbx
 1751f2d:	49 89 d4             	mov    %rdx,%r12
 1751f30:	48 89 fb             	mov    %rdi,%rbx
 1751f33:	48 83 ec 78          	sub    $0x78,%rsp
 1751f37:	4c 8b 7f 18          	mov    0x18(%rdi),%r15
 1751f3b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 1751f42:	00 00 
 1751f44:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
 1751f49:	31 c0                	xor    %eax,%eax
 1751f4b:	4d 85 ff             	test   %r15,%r15
 1751f4e:	0f 84 dc 00 00 00    	je     1752030 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0x110>
 1751f54:	4c 89 ff             	mov    %r15,%rdi
 1751f57:	e8 64 57 c3 fe       	call   3876c0 <strlen@plt>
 1751f5c:	49 89 c6             	mov    %rax,%r14
 1751f5f:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
 1751f63:	48 85 ed             	test   %rbp,%rbp
 1751f66:	0f 84 b4 00 00 00    	je     1752020 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0x100>
 1751f6c:	48 89 ef             	mov    %rbp,%rdi
 1751f6f:	e8 4c 57 c3 fe       	call   3876c0 <strlen@plt>
 1751f74:	48 89 ea             	mov    %rbp,%rdx
 1751f77:	48 89 c6             	mov    %rax,%rsi
 1751f7a:	41 0f b6 fd          	movzbl %r13b,%edi
 1751f7e:	4d 89 e1             	mov    %r12,%r9
 1751f81:	4c 89 f1             	mov    %r14,%rcx
 1751f84:	4d 89 f8             	mov    %r15,%r8
 1751f87:	e8 74 aa c3 fe       	call   38ca00 <cannsim_helper::adapter::ExtendParamsJsonForEvent(bool, std::basic_string_view<char, std::char_traits<char> >, std::basic_string_view<char, std::char_traits<char> >, std::string&)@plt>
 1751f8c:	83 f8 02             	cmp    $0x2,%eax
 1751f8f:	0f 84 ab 00 00 00    	je     1752040 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0x120>
 1751f95:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
 1751f99:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 1751fa0:	00 00 
 1751fa2:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
 1751fa9:	00 00 
 1751fab:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
 1751fb2:	00 00 
 1751fb4:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
 1751fbb:	00 00 
 1751fbd:	48 85 ed             	test   %rbp,%rbp
 1751fc0:	74 56                	je     1752018 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0xf8>
 1751fc2:	48 89 ef             	mov    %rbp,%rdi
 1751fc5:	e8 96 31 c5 fe       	call   3a5160 <std::char_traits<char>::length(char const*)@plt>
 1751fca:	48 89 ee             	mov    %rbp,%rsi
 1751fcd:	48 89 c7             	mov    %rax,%rdi
 1751fd0:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
 1751fd5:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 1751fda:	e8 b1 b6 c3 fe       	call   38d690 <cannsim_helper::adapter::ExtractInstrFields(std::basic_string_view<char, std::char_traits<char> >, std::basic_string_view<char, std::char_traits<char> >&, std::basic_string_view<char, std::char_traits<char> >&)@plt>
 1751fdf:	84 c0                	test   %al,%al
 1751fe1:	75 75                	jne    1752058 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0x138>
 1751fe3:	48 8d 05 40 87 00 00 	lea    0x8740(%rip),%rax        # 175a72a <_fini@@Base+0x3a06>
 1751fea:	48 89 43 20          	mov    %rax,0x20(%rbx)
 1751fee:	48 89 43 18          	mov    %rax,0x18(%rbx)
 1751ff2:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
 1751ff7:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 1751ffe:	00 00 
 1752000:	0f 85 f1 00 00 00    	jne    17520f7 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0x1d7>
 1752006:	48 83 c4 78          	add    $0x78,%rsp
 175200a:	5b                   	pop    %rbx
 175200b:	5d                   	pop    %rbp
 175200c:	41 5c                	pop    %r12
 175200e:	41 5d                	pop    %r13
 1752010:	41 5e                	pop    %r14
 1752012:	41 5f                	pop    %r15
 1752014:	c3                   	ret
 1752015:	0f 1f 00             	nopl   (%rax)
 1752018:	31 ff                	xor    %edi,%edi
 175201a:	31 f6                	xor    %esi,%esi
 175201c:	eb b2                	jmp    1751fd0 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0xb0>
 175201e:	66 90                	xchg   %ax,%ax
 1752020:	31 f6                	xor    %esi,%esi
 1752022:	31 d2                	xor    %edx,%edx
 1752024:	e9 51 ff ff ff       	jmp    1751f7a <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0x5a>
 1752029:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1752030:	45 31 f6             	xor    %r14d,%r14d
 1752033:	45 31 ff             	xor    %r15d,%r15d
 1752036:	e9 24 ff ff ff       	jmp    1751f5f <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0x3f>
 175203b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1752040:	48 8d 05 e3 86 00 00 	lea    0x86e3(%rip),%rax        # 175a72a <_fini@@Base+0x3a06>
 1752047:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
 175204e:	00 
 175204f:	48 89 43 18          	mov    %rax,0x18(%rbx)
 1752053:	eb 9d                	jmp    1751ff2 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0xd2>
 1752055:	0f 1f 00             	nopl   (%rax)
 1752058:	8b 43 04             	mov    0x4(%rbx),%eax
 175205b:	48 8d 6c 24 08       	lea    0x8(%rsp),%rbp
 1752060:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
 1752065:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
 175206b:	48 89 ef             	mov    %rbp,%rdi
 175206e:	89 44 24 30          	mov    %eax,0x30(%rsp)
 1752072:	49 8b 04 24          	mov    (%r12),%rax
 1752076:	0f 11 44 24 38       	movups %xmm0,0x38(%rsp)
 175207b:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 175207f:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
 1752084:	66 0f 6f 44 24 20    	movdqa 0x20(%rsp),%xmm0
 175208a:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
 175208f:	0f 11 44 24 48       	movups %xmm0,0x48(%rsp)
 1752094:	e8 37 0c c3 fe       	call   382cd0 <cannsim_helper::adapter::UniversalKeysBuilder::Build(cannsim_helper::adapter::UniversalKeysContext const&)@plt>
 1752099:	4c 89 e7             	mov    %r12,%rdi
 175209c:	48 89 ee             	mov    %rbp,%rsi
 175209f:	e8 cc 0a c3 fe       	call   382b70 <std::string::swap(std::string&)@plt>
 17520a4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 17520a9:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 17520ad:	48 3b 3d cc aa 42 00 	cmp    0x42aacc(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 17520b4:	75 3a                	jne    17520f0 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0x1d0>
 17520b6:	49 8b 14 24          	mov    (%r12),%rdx
 17520ba:	48 8d 2d 69 86 00 00 	lea    0x8669(%rip),%rbp        # 175a72a <_fini@@Base+0x3a06>
 17520c1:	48 89 e8             	mov    %rbp,%rax
 17520c4:	48 83 7a e8 00       	cmpq   $0x0,-0x18(%rdx)
 17520c9:	75 15                	jne    17520e0 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0x1c0>
 17520cb:	48 89 43 20          	mov    %rax,0x20(%rbx)
 17520cf:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
 17520d3:	e9 1a ff ff ff       	jmp    1751ff2 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0xd2>
 17520d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 17520df:	00 
 17520e0:	4c 89 e7             	mov    %r12,%rdi
 17520e3:	e8 78 b1 c4 fe       	call   39d260 <std::string::_M_leak()@plt>
 17520e8:	49 8b 04 24          	mov    (%r12),%rax
 17520ec:	eb dd                	jmp    17520cb <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0x1ab>
 17520ee:	66 90                	xchg   %ax,%ax
 17520f0:	e8 bb dd ff ff       	call   174feb0 <std::__detail::_RegexTranslatorBase<std::regex_traits<char>, true, false>::_M_translate(char) const@@Base+0x130>
 17520f5:	eb bf                	jmp    17520b6 <cannsim_helper::adapter::FillEntryForEvent(cannsim_helper::DvcInstrLogEntry&, bool, std::string&)@@Base+0x196>
 17520f7:	e8 c4 35 c4 fe       	call   3956c0 <__stack_chk_fail@plt>
 17520fc:	0f 1f 40 00          	nopl   0x0(%rax)
