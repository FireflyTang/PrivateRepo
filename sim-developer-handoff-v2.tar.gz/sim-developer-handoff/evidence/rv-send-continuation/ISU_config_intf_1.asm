
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

000000000152b7d0 <PemRVecISU::config_intf_1()@@Base>:
 152b7d0:	55                   	push   %rbp
 152b7d1:	48 89 e5             	mov    %rsp,%rbp
 152b7d4:	41 56                	push   %r14
 152b7d6:	41 55                	push   %r13
 152b7d8:	41 54                	push   %r12
 152b7da:	53                   	push   %rbx
 152b7db:	48 8d 5d b0          	lea    -0x50(%rbp),%rbx
 152b7df:	49 89 fc             	mov    %rdi,%r12
 152b7e2:	49 89 fe             	mov    %rdi,%r14
 152b7e5:	48 83 ec 50          	sub    $0x50,%rsp
 152b7e9:	4d 8d ac 24 f0 01 00 	lea    0x1f0(%r12),%r13
 152b7f0:	00 
 152b7f1:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 152b7f8:	00 00 
 152b7fa:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 152b7fe:	31 c0                	xor    %eax,%eax
 152b800:	48 8b 87 90 00 00 00 	mov    0x90(%rdi),%rax
 152b807:	48 89 df             	mov    %rbx,%rdi
 152b80a:	48 8d b0 d8 00 00 00 	lea    0xd8(%rax),%rsi
 152b811:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152b815:	e8 d6 66 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152b81a:	49 8b 84 24 90 00 00 	mov    0x90(%r12),%rax
 152b821:	00 
 152b822:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
 152b826:	4c 8d 65 a8          	lea    -0x58(%rbp),%r12
 152b82a:	48 8d b0 e8 00 00 00 	lea    0xe8(%rax),%rsi
 152b831:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152b835:	e8 b6 66 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152b83a:	4c 89 e6             	mov    %r12,%rsi
 152b83d:	4c 89 ef             	mov    %r13,%rdi
 152b840:	c7 45 a8 00 00 00 00 	movl   $0x0,-0x58(%rbp)
 152b847:	e8 74 6c e6 fe       	call   3924c0 <std::map<InfFromISU, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > >::operator[](InfFromISU&&)@plt>
 152b84c:	48 83 ec 08          	sub    $0x8,%rsp
 152b850:	48 8d 53 20          	lea    0x20(%rbx),%rdx
 152b854:	48 89 de             	mov    %rbx,%rsi
 152b857:	6a 00                	push   $0x0
 152b859:	48 89 c7             	mov    %rax,%rdi
 152b85c:	e8 6f 09 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152b861:	5f                   	pop    %rdi
 152b862:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 152b866:	41 58                	pop    %r8
 152b868:	48 85 ff             	test   %rdi,%rdi
 152b86b:	74 05                	je     152b872 <PemRVecISU::config_intf_1()@@Base+0xa2>
 152b86d:	e8 1e 60 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152b872:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152b876:	48 85 ff             	test   %rdi,%rdi
 152b879:	74 05                	je     152b880 <PemRVecISU::config_intf_1()@@Base+0xb0>
 152b87b:	e8 10 60 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152b880:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 152b887:	48 89 df             	mov    %rbx,%rdi
 152b88a:	48 8d b0 28 01 00 00 	lea    0x128(%rax),%rsi
 152b891:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152b895:	e8 56 66 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152b89a:	49 8b 96 00 02 00 00 	mov    0x200(%r14),%rdx
 152b8a1:	49 8d 8e f8 01 00 00 	lea    0x1f8(%r14),%rcx
 152b8a8:	c7 45 a4 02 00 00 00 	movl   $0x2,-0x5c(%rbp)
 152b8af:	48 89 c8             	mov    %rcx,%rax
 152b8b2:	48 85 d2             	test   %rdx,%rdx
 152b8b5:	75 15                	jne    152b8cc <PemRVecISU::config_intf_1()@@Base+0xfc>
 152b8b7:	eb 2d                	jmp    152b8e6 <PemRVecISU::config_intf_1()@@Base+0x116>
 152b8b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 152b8c0:	48 89 d0             	mov    %rdx,%rax
 152b8c3:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 152b8c7:	48 85 d2             	test   %rdx,%rdx
 152b8ca:	74 0f                	je     152b8db <PemRVecISU::config_intf_1()@@Base+0x10b>
 152b8cc:	83 7a 20 01          	cmpl   $0x1,0x20(%rdx)
 152b8d0:	7f ee                	jg     152b8c0 <PemRVecISU::config_intf_1()@@Base+0xf0>
 152b8d2:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 152b8d6:	48 85 d2             	test   %rdx,%rdx
 152b8d9:	75 f1                	jne    152b8cc <PemRVecISU::config_intf_1()@@Base+0xfc>
 152b8db:	48 39 c1             	cmp    %rax,%rcx
 152b8de:	74 06                	je     152b8e6 <PemRVecISU::config_intf_1()@@Base+0x116>
 152b8e0:	83 78 20 02          	cmpl   $0x2,0x20(%rax)
 152b8e4:	7e 16                	jle    152b8fc <PemRVecISU::config_intf_1()@@Base+0x12c>
 152b8e6:	48 8d 55 a4          	lea    -0x5c(%rbp),%rdx
 152b8ea:	48 89 c6             	mov    %rax,%rsi
 152b8ed:	4c 89 ef             	mov    %r13,%rdi
 152b8f0:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
 152b8f4:	4c 89 e2             	mov    %r12,%rdx
 152b8f7:	e8 54 fd ff ff       	call   152b650 <PemRVecISU::debug_print_uop(std::shared_ptr<RVecUop> const&, std::string const&, std::string const&) const@@Base+0xb0>
 152b8fc:	48 83 ec 08          	sub    $0x8,%rsp
 152b900:	48 8d 53 10          	lea    0x10(%rbx),%rdx
 152b904:	48 8d 78 28          	lea    0x28(%rax),%rdi
 152b908:	6a 00                	push   $0x0
 152b90a:	48 89 de             	mov    %rbx,%rsi
 152b90d:	e8 be 08 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152b912:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152b916:	59                   	pop    %rcx
 152b917:	5e                   	pop    %rsi
 152b918:	48 85 ff             	test   %rdi,%rdi
 152b91b:	74 05                	je     152b922 <PemRVecISU::config_intf_1()@@Base+0x152>
 152b91d:	e8 6e 5f 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152b922:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 152b929:	4d 8d ae 20 02 00 00 	lea    0x220(%r14),%r13
 152b930:	48 89 df             	mov    %rbx,%rdi
 152b933:	48 8d b0 f8 00 00 00 	lea    0xf8(%rax),%rsi
 152b93a:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152b93e:	e8 ad 65 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152b943:	4c 89 e6             	mov    %r12,%rsi
 152b946:	4c 89 ef             	mov    %r13,%rdi
 152b949:	c7 45 a8 01 00 00 00 	movl   $0x1,-0x58(%rbp)
 152b950:	e8 6b 6b e6 fe       	call   3924c0 <std::map<InfFromISU, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > >::operator[](InfFromISU&&)@plt>
 152b955:	48 83 ec 08          	sub    $0x8,%rsp
 152b959:	48 8d 53 10          	lea    0x10(%rbx),%rdx
 152b95d:	48 89 de             	mov    %rbx,%rsi
 152b960:	6a 00                	push   $0x0
 152b962:	48 89 c7             	mov    %rax,%rdi
 152b965:	e8 66 08 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152b96a:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152b96e:	58                   	pop    %rax
 152b96f:	5a                   	pop    %rdx
 152b970:	48 85 ff             	test   %rdi,%rdi
 152b973:	74 05                	je     152b97a <PemRVecISU::config_intf_1()@@Base+0x1aa>
 152b975:	e8 16 5f 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152b97a:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 152b981:	48 89 df             	mov    %rbx,%rdi
 152b984:	48 8d b0 38 01 00 00 	lea    0x138(%rax),%rsi
 152b98b:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152b98f:	e8 5c 65 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152b994:	4c 89 e6             	mov    %r12,%rsi
 152b997:	4c 89 ef             	mov    %r13,%rdi
 152b99a:	c7 45 a8 03 00 00 00 	movl   $0x3,-0x58(%rbp)
 152b9a1:	e8 1a 6b e6 fe       	call   3924c0 <std::map<InfFromISU, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > >::operator[](InfFromISU&&)@plt>
 152b9a6:	48 83 ec 08          	sub    $0x8,%rsp
 152b9aa:	48 8d 53 10          	lea    0x10(%rbx),%rdx
 152b9ae:	48 89 de             	mov    %rbx,%rsi
 152b9b1:	6a 00                	push   $0x0
 152b9b3:	48 89 c7             	mov    %rax,%rdi
 152b9b6:	e8 15 08 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152b9bb:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152b9bf:	41 5b                	pop    %r11
 152b9c1:	58                   	pop    %rax
 152b9c2:	48 85 ff             	test   %rdi,%rdi
 152b9c5:	74 05                	je     152b9cc <PemRVecISU::config_intf_1()@@Base+0x1fc>
 152b9c7:	e8 c4 5e 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152b9cc:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 152b9d3:	48 89 df             	mov    %rbx,%rdi
 152b9d6:	48 8d b0 28 01 00 00 	lea    0x128(%rax),%rsi
 152b9dd:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152b9e1:	e8 0a 65 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152b9e6:	49 8b 96 30 02 00 00 	mov    0x230(%r14),%rdx
 152b9ed:	49 8d 8e 28 02 00 00 	lea    0x228(%r14),%rcx
 152b9f4:	c7 45 a4 02 00 00 00 	movl   $0x2,-0x5c(%rbp)
 152b9fb:	48 89 c8             	mov    %rcx,%rax
 152b9fe:	48 85 d2             	test   %rdx,%rdx
 152ba01:	75 11                	jne    152ba14 <PemRVecISU::config_intf_1()@@Base+0x244>
 152ba03:	eb 29                	jmp    152ba2e <PemRVecISU::config_intf_1()@@Base+0x25e>
 152ba05:	0f 1f 00             	nopl   (%rax)
 152ba08:	48 89 d0             	mov    %rdx,%rax
 152ba0b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 152ba0f:	48 85 d2             	test   %rdx,%rdx
 152ba12:	74 0f                	je     152ba23 <PemRVecISU::config_intf_1()@@Base+0x253>
 152ba14:	83 7a 20 01          	cmpl   $0x1,0x20(%rdx)
 152ba18:	7f ee                	jg     152ba08 <PemRVecISU::config_intf_1()@@Base+0x238>
 152ba1a:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 152ba1e:	48 85 d2             	test   %rdx,%rdx
 152ba21:	75 f1                	jne    152ba14 <PemRVecISU::config_intf_1()@@Base+0x244>
 152ba23:	48 39 c1             	cmp    %rax,%rcx
 152ba26:	74 06                	je     152ba2e <PemRVecISU::config_intf_1()@@Base+0x25e>
 152ba28:	83 78 20 02          	cmpl   $0x2,0x20(%rax)
 152ba2c:	7e 16                	jle    152ba44 <PemRVecISU::config_intf_1()@@Base+0x274>
 152ba2e:	48 8d 55 a4          	lea    -0x5c(%rbp),%rdx
 152ba32:	48 89 c6             	mov    %rax,%rsi
 152ba35:	4c 89 ef             	mov    %r13,%rdi
 152ba38:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
 152ba3c:	4c 89 e2             	mov    %r12,%rdx
 152ba3f:	e8 0c fc ff ff       	call   152b650 <PemRVecISU::debug_print_uop(std::shared_ptr<RVecUop> const&, std::string const&, std::string const&) const@@Base+0xb0>
 152ba44:	48 83 ec 08          	sub    $0x8,%rsp
 152ba48:	48 8d 53 10          	lea    0x10(%rbx),%rdx
 152ba4c:	48 8d 78 28          	lea    0x28(%rax),%rdi
 152ba50:	6a 00                	push   $0x0
 152ba52:	48 89 de             	mov    %rbx,%rsi
 152ba55:	e8 76 07 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152ba5a:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152ba5e:	41 59                	pop    %r9
 152ba60:	41 5a                	pop    %r10
 152ba62:	48 85 ff             	test   %rdi,%rdi
 152ba65:	74 05                	je     152ba6c <PemRVecISU::config_intf_1()@@Base+0x29c>
 152ba67:	e8 24 5e 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152ba6c:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 152ba73:	4d 8d ae 50 02 00 00 	lea    0x250(%r14),%r13
 152ba7a:	48 89 df             	mov    %rbx,%rdi
 152ba7d:	48 8d b0 f8 00 00 00 	lea    0xf8(%rax),%rsi
 152ba84:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152ba88:	e8 63 64 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152ba8d:	4c 89 e6             	mov    %r12,%rsi
 152ba90:	4c 89 ef             	mov    %r13,%rdi
 152ba93:	c7 45 a8 01 00 00 00 	movl   $0x1,-0x58(%rbp)
 152ba9a:	e8 21 6a e6 fe       	call   3924c0 <std::map<InfFromISU, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > >::operator[](InfFromISU&&)@plt>
 152ba9f:	48 83 ec 08          	sub    $0x8,%rsp
 152baa3:	48 8d 53 10          	lea    0x10(%rbx),%rdx
 152baa7:	48 89 de             	mov    %rbx,%rsi
 152baaa:	6a 00                	push   $0x0
 152baac:	48 89 c7             	mov    %rax,%rdi
 152baaf:	e8 1c 07 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152bab4:	5f                   	pop    %rdi
 152bab5:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152bab9:	41 58                	pop    %r8
 152babb:	48 85 ff             	test   %rdi,%rdi
 152babe:	74 05                	je     152bac5 <PemRVecISU::config_intf_1()@@Base+0x2f5>
 152bac0:	e8 cb 5d 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152bac5:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 152bacc:	48 89 df             	mov    %rbx,%rdi
 152bacf:	48 8d b0 38 01 00 00 	lea    0x138(%rax),%rsi
 152bad6:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152bada:	e8 11 64 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152badf:	4c 89 e6             	mov    %r12,%rsi
 152bae2:	4c 89 ef             	mov    %r13,%rdi
 152bae5:	c7 45 a8 03 00 00 00 	movl   $0x3,-0x58(%rbp)
 152baec:	e8 cf 69 e6 fe       	call   3924c0 <std::map<InfFromISU, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > >::operator[](InfFromISU&&)@plt>
 152baf1:	48 83 ec 08          	sub    $0x8,%rsp
 152baf5:	48 8d 53 10          	lea    0x10(%rbx),%rdx
 152baf9:	48 89 de             	mov    %rbx,%rsi
 152bafc:	6a 00                	push   $0x0
 152bafe:	48 89 c7             	mov    %rax,%rdi
 152bb01:	e8 ca 06 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152bb06:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152bb0a:	59                   	pop    %rcx
 152bb0b:	5e                   	pop    %rsi
 152bb0c:	48 85 ff             	test   %rdi,%rdi
 152bb0f:	74 05                	je     152bb16 <PemRVecISU::config_intf_1()@@Base+0x346>
 152bb11:	e8 7a 5d 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152bb16:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 152bb1d:	48 89 df             	mov    %rbx,%rdi
 152bb20:	48 8d b0 28 01 00 00 	lea    0x128(%rax),%rsi
 152bb27:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152bb2b:	e8 c0 63 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152bb30:	49 8b 96 60 02 00 00 	mov    0x260(%r14),%rdx
 152bb37:	49 8d 8e 58 02 00 00 	lea    0x258(%r14),%rcx
 152bb3e:	c7 45 a4 02 00 00 00 	movl   $0x2,-0x5c(%rbp)
 152bb45:	48 89 c8             	mov    %rcx,%rax
 152bb48:	48 85 d2             	test   %rdx,%rdx
 152bb4b:	75 0f                	jne    152bb5c <PemRVecISU::config_intf_1()@@Base+0x38c>
 152bb4d:	eb 27                	jmp    152bb76 <PemRVecISU::config_intf_1()@@Base+0x3a6>
 152bb4f:	90                   	nop
 152bb50:	48 89 d0             	mov    %rdx,%rax
 152bb53:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 152bb57:	48 85 d2             	test   %rdx,%rdx
 152bb5a:	74 0f                	je     152bb6b <PemRVecISU::config_intf_1()@@Base+0x39b>
 152bb5c:	83 7a 20 01          	cmpl   $0x1,0x20(%rdx)
 152bb60:	7f ee                	jg     152bb50 <PemRVecISU::config_intf_1()@@Base+0x380>
 152bb62:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 152bb66:	48 85 d2             	test   %rdx,%rdx
 152bb69:	75 f1                	jne    152bb5c <PemRVecISU::config_intf_1()@@Base+0x38c>
 152bb6b:	48 39 c1             	cmp    %rax,%rcx
 152bb6e:	74 06                	je     152bb76 <PemRVecISU::config_intf_1()@@Base+0x3a6>
 152bb70:	83 78 20 02          	cmpl   $0x2,0x20(%rax)
 152bb74:	7e 16                	jle    152bb8c <PemRVecISU::config_intf_1()@@Base+0x3bc>
 152bb76:	48 8d 55 a4          	lea    -0x5c(%rbp),%rdx
 152bb7a:	48 89 c6             	mov    %rax,%rsi
 152bb7d:	4c 89 ef             	mov    %r13,%rdi
 152bb80:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
 152bb84:	4c 89 e2             	mov    %r12,%rdx
 152bb87:	e8 c4 fa ff ff       	call   152b650 <PemRVecISU::debug_print_uop(std::shared_ptr<RVecUop> const&, std::string const&, std::string const&) const@@Base+0xb0>
 152bb8c:	48 83 ec 08          	sub    $0x8,%rsp
 152bb90:	48 8d 53 10          	lea    0x10(%rbx),%rdx
 152bb94:	48 8d 78 28          	lea    0x28(%rax),%rdi
 152bb98:	6a 00                	push   $0x0
 152bb9a:	48 89 de             	mov    %rbx,%rsi
 152bb9d:	e8 2e 06 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152bba2:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152bba6:	58                   	pop    %rax
 152bba7:	5a                   	pop    %rdx
 152bba8:	48 85 ff             	test   %rdi,%rdi
 152bbab:	74 05                	je     152bbb2 <PemRVecISU::config_intf_1()@@Base+0x3e2>
 152bbad:	e8 de 5c 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152bbb2:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 152bbb9:	48 89 df             	mov    %rbx,%rdi
 152bbbc:	48 8d b0 98 00 00 00 	lea    0x98(%rax),%rsi
 152bbc3:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152bbc7:	e8 24 63 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152bbcc:	4c 89 e6             	mov    %r12,%rsi
 152bbcf:	4c 89 ef             	mov    %r13,%rdi
 152bbd2:	c7 45 a8 04 00 00 00 	movl   $0x4,-0x58(%rbp)
 152bbd9:	e8 e2 68 e6 fe       	call   3924c0 <std::map<InfFromISU, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > >::operator[](InfFromISU&&)@plt>
 152bbde:	48 83 ec 08          	sub    $0x8,%rsp
 152bbe2:	48 8d 53 10          	lea    0x10(%rbx),%rdx
 152bbe6:	48 89 de             	mov    %rbx,%rsi
 152bbe9:	6a 00                	push   $0x0
 152bbeb:	48 89 c7             	mov    %rax,%rdi
 152bbee:	e8 dd 05 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152bbf3:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152bbf7:	41 5b                	pop    %r11
 152bbf9:	58                   	pop    %rax
 152bbfa:	48 85 ff             	test   %rdi,%rdi
 152bbfd:	74 05                	je     152bc04 <PemRVecISU::config_intf_1()@@Base+0x434>
 152bbff:	e8 8c 5c 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152bc04:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 152bc0b:	48 89 df             	mov    %rbx,%rdi
 152bc0e:	48 8d b0 a8 00 00 00 	lea    0xa8(%rax),%rsi
 152bc15:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152bc19:	e8 d2 62 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152bc1e:	4c 89 e6             	mov    %r12,%rsi
 152bc21:	4c 89 ef             	mov    %r13,%rdi
 152bc24:	c7 45 a8 05 00 00 00 	movl   $0x5,-0x58(%rbp)
 152bc2b:	e8 90 68 e6 fe       	call   3924c0 <std::map<InfFromISU, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > >::operator[](InfFromISU&&)@plt>
 152bc30:	48 83 ec 08          	sub    $0x8,%rsp
 152bc34:	48 8d 53 10          	lea    0x10(%rbx),%rdx
 152bc38:	48 89 de             	mov    %rbx,%rsi
 152bc3b:	6a 00                	push   $0x0
 152bc3d:	48 89 c7             	mov    %rax,%rdi
 152bc40:	e8 8b 05 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152bc45:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152bc49:	41 59                	pop    %r9
 152bc4b:	41 5a                	pop    %r10
 152bc4d:	48 85 ff             	test   %rdi,%rdi
 152bc50:	74 05                	je     152bc57 <PemRVecISU::config_intf_1()@@Base+0x487>
 152bc52:	e8 39 5c 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152bc57:	49 8b 86 00 01 00 00 	mov    0x100(%r14),%rax
 152bc5e:	49 8b 8e 90 00 00 00 	mov    0x90(%r14),%rcx
 152bc65:	4d 8d ae 80 02 00 00 	lea    0x280(%r14),%r13
 152bc6c:	48 89 df             	mov    %rbx,%rdi
 152bc6f:	80 78 4c 00          	cmpb   $0x0,0x4c(%rax)
 152bc73:	48 89 4d 98          	mov    %rcx,-0x68(%rbp)
 152bc77:	48 8d b1 58 01 00 00 	lea    0x158(%rcx),%rsi
 152bc7e:	0f 84 8c 00 00 00    	je     152bd10 <PemRVecISU::config_intf_1()@@Base+0x540>
 152bc84:	e8 67 62 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152bc89:	49 8b b6 90 00 00 00 	mov    0x90(%r14),%rsi
 152bc90:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
 152bc94:	48 81 c6 68 01 00 00 	add    $0x168,%rsi
 152bc9b:	e8 50 62 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152bca0:	4c 89 e6             	mov    %r12,%rsi
 152bca3:	4c 89 ef             	mov    %r13,%rdi
 152bca6:	c7 45 a8 04 00 00 00 	movl   $0x4,-0x58(%rbp)
 152bcad:	e8 0e 68 e6 fe       	call   3924c0 <std::map<InfFromISU, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > >::operator[](InfFromISU&&)@plt>
 152bcb2:	48 83 ec 08          	sub    $0x8,%rsp
 152bcb6:	48 8d 53 20          	lea    0x20(%rbx),%rdx
 152bcba:	48 89 de             	mov    %rbx,%rsi
 152bcbd:	6a 00                	push   $0x0
 152bcbf:	48 89 c7             	mov    %rax,%rdi
 152bcc2:	e8 09 05 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152bcc7:	5f                   	pop    %rdi
 152bcc8:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 152bccc:	41 58                	pop    %r8
 152bcce:	48 85 ff             	test   %rdi,%rdi
 152bcd1:	74 05                	je     152bcd8 <PemRVecISU::config_intf_1()@@Base+0x508>
 152bcd3:	e8 b8 5b 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152bcd8:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152bcdc:	48 85 ff             	test   %rdi,%rdi
 152bcdf:	74 05                	je     152bce6 <PemRVecISU::config_intf_1()@@Base+0x516>
 152bce1:	e8 aa 5b 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152bce6:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 152bcea:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 152bcf1:	00 00 
 152bcf3:	0f 85 9f 00 00 00    	jne    152bd98 <PemRVecISU::config_intf_1()@@Base+0x5c8>
 152bcf9:	48 8d 65 e0          	lea    -0x20(%rbp),%rsp
 152bcfd:	5b                   	pop    %rbx
 152bcfe:	41 5c                	pop    %r12
 152bd00:	41 5d                	pop    %r13
 152bd02:	41 5e                	pop    %r14
 152bd04:	5d                   	pop    %rbp
 152bd05:	c3                   	ret
 152bd06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 152bd0d:	00 00 00 
 152bd10:	e8 db 61 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152bd15:	4c 89 e6             	mov    %r12,%rsi
 152bd18:	4c 89 ef             	mov    %r13,%rdi
 152bd1b:	c7 45 a8 04 00 00 00 	movl   $0x4,-0x58(%rbp)
 152bd22:	e8 99 67 e6 fe       	call   3924c0 <std::map<InfFromISU, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > >::operator[](InfFromISU&&)@plt>
 152bd27:	48 83 ec 08          	sub    $0x8,%rsp
 152bd2b:	48 8d 53 10          	lea    0x10(%rbx),%rdx
 152bd2f:	48 89 de             	mov    %rbx,%rsi
 152bd32:	6a 00                	push   $0x0
 152bd34:	48 89 c7             	mov    %rax,%rdi
 152bd37:	e8 94 04 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152bd3c:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152bd40:	59                   	pop    %rcx
 152bd41:	5e                   	pop    %rsi
 152bd42:	48 85 ff             	test   %rdi,%rdi
 152bd45:	74 05                	je     152bd4c <PemRVecISU::config_intf_1()@@Base+0x57c>
 152bd47:	e8 44 5b 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152bd4c:	49 8b 86 90 00 00 00 	mov    0x90(%r14),%rax
 152bd53:	48 89 df             	mov    %rbx,%rdi
 152bd56:	48 8d b0 68 01 00 00 	lea    0x168(%rax),%rsi
 152bd5d:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 152bd61:	e8 8a 61 e7 fe       	call   3a1ef0 <std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0>, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 152bd66:	49 8d be b0 02 00 00 	lea    0x2b0(%r14),%rdi
 152bd6d:	4c 89 e6             	mov    %r12,%rsi
 152bd70:	c7 45 a8 05 00 00 00 	movl   $0x5,-0x58(%rbp)
 152bd77:	e8 44 67 e6 fe       	call   3924c0 <std::map<InfFromISU, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > >::operator[](InfFromISU&&)@plt>
 152bd7c:	48 83 ec 08          	sub    $0x8,%rsp
 152bd80:	48 8d 53 10          	lea    0x10(%rbx),%rdx
 152bd84:	48 89 de             	mov    %rbx,%rsi
 152bd87:	6a 00                	push   $0x0
 152bd89:	48 89 c7             	mov    %rax,%rdi
 152bd8c:	e8 3f 04 e6 fe       	call   38c1d0 <void std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >::_M_assign_aux<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*>(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > const*, std::forward_iterator_tag)@plt>
 152bd91:	58                   	pop    %rax
 152bd92:	5a                   	pop    %rdx
 152bd93:	e9 40 ff ff ff       	jmp    152bcd8 <PemRVecISU::config_intf_1()@@Base+0x508>
 152bd98:	e8 23 99 e6 fe       	call   3956c0 <__stack_chk_fail@plt>
 152bd9d:	48 89 c3             	mov    %rax,%rbx
 152bda0:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 152bda4:	48 85 ff             	test   %rdi,%rdi
 152bda7:	74 05                	je     152bdae <PemRVecISU::config_intf_1()@@Base+0x5de>
 152bda9:	e8 e2 5a 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152bdae:	48 89 df             	mov    %rbx,%rdi
 152bdb1:	e8 ca 6f e7 fe       	call   3a2d80 <_Unwind_Resume@plt>
 152bdb6:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 152bdba:	48 89 c3             	mov    %rax,%rbx
 152bdbd:	48 85 ff             	test   %rdi,%rdi
 152bdc0:	74 de                	je     152bda0 <PemRVecISU::config_intf_1()@@Base+0x5d0>
 152bdc2:	e8 c9 5a 86 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 152bdc7:	eb d7                	jmp    152bda0 <PemRVecISU::config_intf_1()@@Base+0x5d0>
 152bdc9:	eb d2                	jmp    152bd9d <PemRVecISU::config_intf_1()@@Base+0x5cd>
 152bdcb:	eb d0                	jmp    152bd9d <PemRVecISU::config_intf_1()@@Base+0x5cd>
 152bdcd:	eb ce                	jmp    152bd9d <PemRVecISU::config_intf_1()@@Base+0x5cd>
 152bdcf:	eb cc                	jmp    152bd9d <PemRVecISU::config_intf_1()@@Base+0x5cd>
 152bdd1:	eb ca                	jmp    152bd9d <PemRVecISU::config_intf_1()@@Base+0x5cd>
 152bdd3:	eb c8                	jmp    152bd9d <PemRVecISU::config_intf_1()@@Base+0x5cd>
 152bdd5:	eb c6                	jmp    152bd9d <PemRVecISU::config_intf_1()@@Base+0x5cd>
 152bdd7:	eb c4                	jmp    152bd9d <PemRVecISU::config_intf_1()@@Base+0x5cd>
 152bdd9:	eb c2                	jmp    152bd9d <PemRVecISU::config_intf_1()@@Base+0x5cd>
 152bddb:	eb d9                	jmp    152bdb6 <PemRVecISU::config_intf_1()@@Base+0x5e6>
 152bddd:	eb be                	jmp    152bd9d <PemRVecISU::config_intf_1()@@Base+0x5cd>
 152bddf:	90                   	nop
