
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000e7a070 <pem_log::get_log_level(unsigned int)@@Base>:
  e7a070:	83 ff 06             	cmp    $0x6,%edi
  e7a073:	b8 06 00 00 00       	mov    $0x6,%eax
  e7a078:	77 0c                	ja     e7a086 <pem_log::get_log_level(unsigned int)@@Base+0x16>
  e7a07a:	48 8d 05 3f f4 91 00 	lea    0x91f43f(%rip),%rax        # 17994c0 <typeinfo name for std::_Sp_counted_ptr_inplace<VcvtInfo, std::allocator<VcvtInfo>, (__gnu_cxx::_Lock_policy)2>@@Base+0xe0>
  e7a081:	89 ff                	mov    %edi,%edi
  e7a083:	8b 04 b8             	mov    (%rax,%rdi,4),%eax
  e7a086:	f3 c3                	repz ret
