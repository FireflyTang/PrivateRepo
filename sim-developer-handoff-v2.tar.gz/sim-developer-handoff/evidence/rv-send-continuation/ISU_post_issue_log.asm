
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

000000000154f9a0 <RVecISUEntry::post_issue_uop_log(std::shared_ptr<RVecUop>&)@@Base>:
 154f9a0:	55                   	push   %rbp
 154f9a1:	48 89 e5             	mov    %rsp,%rbp
 154f9a4:	41 57                	push   %r15
 154f9a6:	41 56                	push   %r14
 154f9a8:	41 55                	push   %r13
 154f9aa:	41 54                	push   %r12
 154f9ac:	49 89 fd             	mov    %rdi,%r13
 154f9af:	53                   	push   %rbx
 154f9b0:	48 89 f3             	mov    %rsi,%rbx
 154f9b3:	48 8d bd 80 fd ff ff 	lea    -0x280(%rbp),%rdi
 154f9ba:	48 81 ec a8 02 00 00 	sub    $0x2a8,%rsp
 154f9c1:	48 8b 36             	mov    (%rsi),%rsi
 154f9c4:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 154f9cb:	00 00 
 154f9cd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 154f9d1:	31 c0                	xor    %eax,%eax
 154f9d3:	e8 08 2b e5 fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 154f9d8:	48 8b b5 80 fd ff ff 	mov    -0x280(%rbp),%rsi
 154f9df:	48 8d bd 90 fd ff ff 	lea    -0x270(%rbp),%rdi
 154f9e6:	e8 95 6b e5 fe       	call   3a6580 <Isa::get_rvec_isa_para()@plt>
 154f9eb:	48 8b 03             	mov    (%rbx),%rax
 154f9ee:	49 89 df             	mov    %rbx,%r15
 154f9f1:	8b 80 6c 01 00 00    	mov    0x16c(%rax),%eax
 154f9f7:	83 e8 04             	sub    $0x4,%eax
 154f9fa:	83 f8 01             	cmp    $0x1,%eax
 154f9fd:	77 0a                	ja     154fa09 <RVecISUEntry::post_issue_uop_log(std::shared_ptr<RVecUop>&)@@Base+0x69>
 154f9ff:	41 83 bd d0 00 00 00 	cmpl   $0x2,0xd0(%r13)
 154fa06:	02 
 154fa07:	74 65                	je     154fa6e <RVecISUEntry::post_issue_uop_log(std::shared_ptr<RVecUop>&)@@Base+0xce>
 154fa09:	48 8b bd 80 fd ff ff 	mov    -0x280(%rbp),%rdi
 154fa10:	e8 0b 53 e5 fe       	call   3a4d20 <Isa::update_exec_descr()@plt>
 154fa15:	48 8b bd 80 fd ff ff 	mov    -0x280(%rbp),%rdi
 154fa1c:	e8 8f 15 e4 fe       	call   390fb0 <Isa::update_decode_descr()@plt>
 154fa21:	48 8b bd 80 fd ff ff 	mov    -0x280(%rbp),%rdi
 154fa28:	4c 8d 67 10          	lea    0x10(%rdi),%r12
 154fa2c:	48 8d 5f 08          	lea    0x8(%rdi),%rbx
 154fa30:	e8 3b ae e3 fe       	call   38a870 <Isa::pc() const@plt>
 154fa35:	49 8b bd a0 00 00 00 	mov    0xa0(%r13),%rdi
 154fa3c:	49 89 c6             	mov    %rax,%r14
 154fa3f:	e8 8c 02 e4 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 154fa44:	49 8b bd c0 00 00 00 	mov    0xc0(%r13),%rdi
 154fa4b:	48 83 ec 08          	sub    $0x8,%rsp
 154fa4f:	49 8d 95 d8 01 00 00 	lea    0x1d8(%r13),%rdx
 154fa56:	49 89 d9             	mov    %rbx,%r9
 154fa59:	4d 89 f0             	mov    %r14,%r8
 154fa5c:	48 89 c1             	mov    %rax,%rcx
 154fa5f:	8b 77 1c             	mov    0x1c(%rdi),%esi
 154fa62:	8b 7f 18             	mov    0x18(%rdi),%edi
 154fa65:	41 54                	push   %r12
 154fa67:	e8 34 18 e5 fe       	call   3a12a0 <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@plt>
 154fa6c:	58                   	pop    %rax
 154fa6d:	5a                   	pop    %rdx
 154fa6e:	49 8b 9d b0 00 00 00 	mov    0xb0(%r13),%rbx
 154fa75:	48 85 db             	test   %rbx,%rbx
 154fa78:	0f 84 1e 01 00 00    	je     154fb9c <RVecISUEntry::post_issue_uop_log(std::shared_ptr<RVecUop>&)@@Base+0x1fc>
 154fa7e:	4d 8b 27             	mov    (%r15),%r12
 154fa81:	48 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%rax
 154fa88:	49 8b 3c 24          	mov    (%r12),%rdi
 154fa8c:	48 89 85 50 fd ff ff 	mov    %rax,-0x2b0(%rbp)
 154fa93:	e8 d8 d4 e3 fe       	call   38cf70 <Isa::pipe() const@plt>
 154fa98:	83 f8 10             	cmp    $0x10,%eax
 154fa9b:	0f 84 3f 01 00 00    	je     154fbe0 <RVecISUEntry::post_issue_uop_log(std::shared_ptr<RVecUop>&)@@Base+0x240>
 154faa1:	49 8b 07             	mov    (%r15),%rax
 154faa4:	48 8b 38             	mov    (%rax),%rdi
 154faa7:	e8 c4 d4 e3 fe       	call   38cf70 <Isa::pipe() const@plt>
 154faac:	83 f8 0f             	cmp    $0xf,%eax
 154faaf:	0f 84 8b 03 00 00    	je     154fe40 <RVecISUEntry::post_issue_uop_log(std::shared_ptr<RVecUop>&)@@Base+0x4a0>
 154fab5:	49 8b 07             	mov    (%r15),%rax
 154fab8:	48 8b 38             	mov    (%rax),%rdi
 154fabb:	e8 b0 d4 e3 fe       	call   38cf70 <Isa::pipe() const@plt>
 154fac0:	83 f8 11             	cmp    $0x11,%eax
 154fac3:	0f 84 e7 03 00 00    	je     154feb0 <RVecISUEntry::post_issue_uop_log(std::shared_ptr<RVecUop>&)@@Base+0x510>
 154fac9:	48 8b 05 b0 d0 62 00 	mov    0x62d0b0(%rip),%rax        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 154fad0:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
 154fad7:	48 83 c0 18          	add    $0x18,%rax
 154fadb:	48 89 85 78 fd ff ff 	mov    %rax,-0x288(%rbp)
 154fae2:	4c 8b b5 80 fd ff ff 	mov    -0x280(%rbp),%r14
 154fae9:	4c 89 f7             	mov    %r14,%rdi
 154faec:	e8 7f ad e3 fe       	call   38a870 <Isa::pc() const@plt>
 154faf1:	48 8b bd 80 fd ff ff 	mov    -0x280(%rbp),%rdi
 154faf8:	48 89 85 48 fd ff ff 	mov    %rax,-0x2b8(%rbp)
 154faff:	e8                   	.byte 0xe8
