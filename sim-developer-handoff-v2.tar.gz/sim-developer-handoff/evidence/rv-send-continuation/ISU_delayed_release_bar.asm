
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000015495a0 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base>:
 15495a0:	41 57                	push   %r15
 15495a2:	41 56                	push   %r14
 15495a4:	49 89 f7             	mov    %rsi,%r15
 15495a7:	41 55                	push   %r13
 15495a9:	41 54                	push   %r12
 15495ab:	4d 89 c6             	mov    %r8,%r14
 15495ae:	55                   	push   %rbp
 15495af:	53                   	push   %rbx
 15495b0:	48 89 fd             	mov    %rdi,%rbp
 15495b3:	49 89 cc             	mov    %rcx,%r12
 15495b6:	48 83 ec 58          	sub    $0x58,%rsp
 15495ba:	48 8b 31             	mov    (%rcx),%rsi
 15495bd:	4c 8d 6c 24 20       	lea    0x20(%rsp),%r13
 15495c2:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 15495c7:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
 15495cc:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 15495d3:	00 00 
 15495d5:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 15495da:	31 c0                	xor    %eax,%eax
 15495dc:	4c 89 ef             	mov    %r13,%rdi
 15495df:	e8 fc 8e e5 fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 15495e4:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 15495e9:	e8 b2 b2 e3 fe       	call   3848a0 <Isa::name() const@plt>
 15495ee:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 15495f3:	75 0d                	jne    1549602 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x62>
 15495f5:	48 8b 85 c0 00 00 00 	mov    0xc0(%rbp),%rax
 15495fc:	80 78 60 00          	cmpb   $0x0,0x60(%rax)
 1549600:	74 6e                	je     1549670 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0xd0>
 1549602:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 1549607:	e8 94 b2 e3 fe       	call   3848a0 <Isa::name() const@plt>
 154960c:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 1549611:	75 0d                	jne    1549620 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x80>
 1549613:	48 8b 85 c0 00 00 00 	mov    0xc0(%rbp),%rax
 154961a:	80 78 60 00          	cmpb   $0x0,0x60(%rax)
 154961e:	75 70                	jne    1549690 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0xf0>
 1549620:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 1549625:	e8 76 b2 e3 fe       	call   3848a0 <Isa::name() const@plt>
 154962a:	31 db                	xor    %ebx,%ebx
 154962c:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 1549631:	0f 84 39 01 00 00    	je     1549770 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x1d0>
 1549637:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 154963c:	48 85 ff             	test   %rdi,%rdi
 154963f:	74 05                	je     1549646 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0xa6>
 1549641:	e8 4a 82 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1549646:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
 154964b:	64 48 33 0c 25 28 00 	xor    %fs:0x28,%rcx
 1549652:	00 00 
 1549654:	89 d8                	mov    %ebx,%eax
 1549656:	0f 85 ad 01 00 00    	jne    1549809 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x269>
 154965c:	48 83 c4 58          	add    $0x58,%rsp
 1549660:	5b                   	pop    %rbx
 1549661:	5d                   	pop    %rbp
 1549662:	41 5c                	pop    %r12
 1549664:	41 5d                	pop    %r13
 1549666:	41 5e                	pop    %r14
 1549668:	41 5f                	pop    %r15
 154966a:	c3                   	ret
 154966b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1549670:	49 8b 04 24          	mov    (%r12),%rax
 1549674:	0f b6 98 19 03 00 00 	movzbl 0x319(%rax),%ebx
 154967b:	84 db                	test   %bl,%bl
 154967d:	0f 85 7d 00 00 00    	jne    1549700 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x160>
 1549683:	bb 01 00 00 00       	mov    $0x1,%ebx
 1549688:	eb ad                	jmp    1549637 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x97>
 154968a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1549690:	8b 85 d0 00 00 00    	mov    0xd0(%rbp),%eax
 1549696:	85 c0                	test   %eax,%eax
 1549698:	75 86                	jne    1549620 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x80>
 154969a:	49 8b 04 24          	mov    (%r12),%rax
 154969e:	0f b6 98 19 03 00 00 	movzbl 0x319(%rax),%ebx
 15496a5:	84 db                	test   %bl,%bl
 15496a7:	74 da                	je     1549683 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0xe3>
 15496a9:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 15496ae:	e8 0d 64 e4 fe       	call   38fac0 <Isa::id() const@plt>
 15496b3:	48 8d bd 18 01 00 00 	lea    0x118(%rbp),%rdi
 15496ba:	48 89 c6             	mov    %rax,%rsi
 15496bd:	e8 6e e4 ff ff       	call   1547b30 <RVecISUEntry::push_pmu(std::shared_ptr<RVecUop> const&, int)@@Base+0x6b0>
 15496c2:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
 15496c7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 15496cc:	4c 89 e6             	mov    %r12,%rsi
 15496cf:	48 89 ef             	mov    %rbp,%rdi
 15496d2:	e8 d9 7e e3 fe       	call   3815b0 <RVecISUEntry::delayed_release_proc(std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&, unsigned int&)@plt>
 15496d7:	49 8b 3f             	mov    (%r15),%rdi
 15496da:	41 8b 36             	mov    (%r14),%esi
 15496dd:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
 15496e2:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
 15496e9:	00 00 
 15496eb:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
 15496f2:	00 00 
 15496f4:	e8 57 37 e5 fe       	call   39ce50 <TmArray<std::shared_ptr<RVecUop> >::remove(unsigned int, std::shared_ptr<RVecUop> const&)@plt>
 15496f9:	eb 55                	jmp    1549750 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x1b0>
 15496fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1549700:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 1549705:	e8 b6 63 e4 fe       	call   38fac0 <Isa::id() const@plt>
 154970a:	48 8d bd 18 01 00 00 	lea    0x118(%rbp),%rdi
 1549711:	48 89 c6             	mov    %rax,%rsi
 1549714:	e8 17 e4 ff ff       	call   1547b30 <RVecISUEntry::push_pmu(std::shared_ptr<RVecUop> const&, int)@@Base+0x6b0>
 1549719:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
 154971e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 1549723:	4c 89 e6             	mov    %r12,%rsi
 1549726:	48 89 ef             	mov    %rbp,%rdi
 1549729:	e8 82 7e e3 fe       	call   3815b0 <RVecISUEntry::delayed_release_proc(std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&, unsigned int&)@plt>
 154972e:	49 8b 3f             	mov    (%r15),%rdi
 1549731:	41 8b 36             	mov    (%r14),%esi
 1549734:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
 1549739:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
 1549740:	00 00 
 1549742:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
 1549749:	00 00 
 154974b:	e8 00 37 e5 fe       	call   39ce50 <TmArray<std::shared_ptr<RVecUop> >::remove(unsigned int, std::shared_ptr<RVecUop> const&)@plt>
 1549750:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 1549755:	48 85 ff             	test   %rdi,%rdi
 1549758:	0f 84 d9 fe ff ff    	je     1549637 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x97>
 154975e:	e8 2d 81 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1549763:	e9 cf fe ff ff       	jmp    1549637 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x97>
 1549768:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 154976f:	00 
 1549770:	48 8b 85 00 01 00 00 	mov    0x100(%rbp),%rax
 1549777:	48 8d 5c 24 30       	lea    0x30(%rsp),%rbx
 154977c:	4c 89 ee             	mov    %r13,%rsi
 154977f:	48 89 df             	mov    %rbx,%rdi
 1549782:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 1549787:	e8 54 8d e5 fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 154978c:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 1549791:	48 89 de             	mov    %rbx,%rsi
 1549794:	e8 97 c8 e3 fe       	call   386030 <PemRvecDepmgr::is_send_done(std::shared_ptr<Isa>)@plt>
 1549799:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 154979e:	41 89 c5             	mov    %eax,%r13d
 15497a1:	48 85 ff             	test   %rdi,%rdi
 15497a4:	74 05                	je     15497ab <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x20b>
 15497a6:	e8 e5 80 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15497ab:	45 84 ed             	test   %r13b,%r13b
 15497ae:	0f 84 cf fe ff ff    	je     1549683 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0xe3>
 15497b4:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
 15497b9:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 15497be:	4c 89 e6             	mov    %r12,%rsi
 15497c1:	48 89 ef             	mov    %rbp,%rdi
 15497c4:	e8 e7 7d e3 fe       	call   3815b0 <RVecISUEntry::delayed_release_proc(std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&, unsigned int&)@plt>
 15497c9:	49 8b 3f             	mov    (%r15),%rdi
 15497cc:	41 8b 36             	mov    (%r14),%esi
 15497cf:	48 89 da             	mov    %rbx,%rdx
 15497d2:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
 15497d9:	00 00 
 15497db:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
 15497e2:	00 00 
 15497e4:	e8 67 36 e5 fe       	call   39ce50 <TmArray<std::shared_ptr<RVecUop> >::remove(unsigned int, std::shared_ptr<RVecUop> const&)@plt>
 15497e9:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 15497ee:	48 85 ff             	test   %rdi,%rdi
 15497f1:	74 05                	je     15497f8 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x258>
 15497f3:	e8 98 80 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15497f8:	48 8b bd f0 00 00 00 	mov    0xf0(%rbp),%rdi
 15497ff:	e8 6c 8b e5 fe       	call   3a2370 <PemRVecPerfISU::send_retire()@plt>
 1549804:	e9 7a fe ff ff       	jmp    1549683 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0xe3>
 1549809:	e8 b2 be e4 fe       	call   3956c0 <__stack_chk_fail@plt>
 154980e:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 1549813:	48 89 c3             	mov    %rax,%rbx
 1549816:	48 85 ff             	test   %rdi,%rdi
 1549819:	74 05                	je     1549820 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x280>
 154981b:	e8 70 80 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1549820:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 1549825:	48 85 ff             	test   %rdi,%rdi
 1549828:	74 05                	je     154982f <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x28f>
 154982a:	e8 61 80 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 154982f:	48 89 df             	mov    %rbx,%rdi
 1549832:	e8 49 95 e5 fe       	call   3a2d80 <_Unwind_Resume@plt>
 1549837:	eb d5                	jmp    154980e <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x26e>
 1549839:	eb d3                	jmp    154980e <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x26e>
 154983b:	48 89 c3             	mov    %rax,%rbx
 154983e:	eb e0                	jmp    1549820 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x280>
 1549840:	eb cc                	jmp    154980e <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@@Base+0x26e>
 1549842:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 1549849:	00 00 00 00 
 154984d:	0f 1f 00             	nopl   (%rax)

0000000001549850 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base>:
 1549850:	41 57                	push   %r15
 1549852:	41 56                	push   %r14
 1549854:	49 89 d6             	mov    %rdx,%r14
 1549857:	41 55                	push   %r13
 1549859:	41 54                	push   %r12
 154985b:	49 89 fd             	mov    %rdi,%r13
 154985e:	55                   	push   %rbp
 154985f:	53                   	push   %rbx
 1549860:	48 89 f5             	mov    %rsi,%rbp
 1549863:	48 83 ec 58          	sub    $0x58,%rsp
 1549867:	48 8b 36             	mov    (%rsi),%rsi
 154986a:	48 8d 5c 24 10       	lea    0x10(%rsp),%rbx
 154986f:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
 1549876:	00 
 1549877:	4c 8d 64 24 30       	lea    0x30(%rsp),%r12
 154987c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 1549883:	00 00 
 1549885:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 154988a:	31 c0                	xor    %eax,%eax
 154988c:	48 89 df             	mov    %rbx,%rdi
 154988f:	4c 8d 7c 24 0c       	lea    0xc(%rsp),%r15
 1549894:	e8 17 ea e4 fe       	call   3982b0 <TmArray<std::shared_ptr<RVecUop> >::begin()@plt>
 1549899:	eb 6e                	jmp    1549909 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb9>
 154989b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 15498a0:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 15498a5:	4d 89 f9             	mov    %r15,%r9
 15498a8:	49 89 d8             	mov    %rbx,%r8
 15498ab:	4c 89 e1             	mov    %r12,%rcx
 15498ae:	4c 89 f2             	mov    %r14,%rdx
 15498b1:	48 89 ee             	mov    %rbp,%rsi
 15498b4:	4c 89 ef             	mov    %r13,%rdi
 15498b7:	e8 64 71 e3 fe       	call   380a20 <RVecISUEntry::delayed_release_bar(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@plt>
 15498bc:	84 c0                	test   %al,%al
 15498be:	75 32                	jne    15498f2 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xa2>
 15498c0:	4d 89 f9             	mov    %r15,%r9
 15498c3:	49 89 d8             	mov    %rbx,%r8
 15498c6:	4c 89 e1             	mov    %r12,%rcx
 15498c9:	4c 89 f2             	mov    %r14,%rdx
 15498cc:	48 89 ee             	mov    %rbp,%rsi
 15498cf:	4c 89 ef             	mov    %r13,%rdi
 15498d2:	e8 89 51 e5 fe       	call   39ea60 <RVecISUEntry::delayed_release_nonfixed(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@plt>
 15498d7:	84 c0                	test   %al,%al
 15498d9:	75 17                	jne    15498f2 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xa2>
 15498db:	4d 89 f9             	mov    %r15,%r9
 15498de:	49 89 d8             	mov    %rbx,%r8
 15498e1:	4c 89 e1             	mov    %r12,%rcx
 15498e4:	4c 89 f2             	mov    %r14,%rdx
 15498e7:	48 89 ee             	mov    %rbp,%rsi
 15498ea:	4c 89 ef             	mov    %r13,%rdi
 15498ed:	e8 1e b9 e4 fe       	call   395210 <RVecISUEntry::delayed_release_fixed(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&, std::shared_ptr<RVecUop>&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, unsigned int&)@plt>
 15498f2:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 15498f7:	48 85 ff             	test   %rdi,%rdi
 15498fa:	74 05                	je     1549901 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb1>
 15498fc:	e8 8f 7f 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1549901:	48 89 df             	mov    %rbx,%rdi
 1549904:	e8 17 f4 e3 fe       	call   388d20 <TmArray<std::shared_ptr<RVecUop> >::iterator::operator++()@plt>
 1549909:	48 8b 75 00          	mov    0x0(%rbp),%rsi
 154990d:	4c 89 e7             	mov    %r12,%rdi
 1549910:	e8 8b 9b e5 fe       	call   3a34a0 <TmArray<std::shared_ptr<RVecUop> >::end()@plt>
 1549915:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 154991a:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 154991f:	48 8b 40 18          	mov    0x18(%rax),%rax
 1549923:	48 39 42 18          	cmp    %rax,0x18(%rdx)
 1549927:	74 4f                	je     1549978 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x128>
 1549929:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 154992e:	48 85 ff             	test   %rdi,%rdi
 1549931:	74 05                	je     1549938 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xe8>
 1549933:	e8 58 7f 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1549938:	48 89 df             	mov    %rbx,%rdi
 154993b:	e8 d0 fb e4 fe       	call   399510 <TmArray<std::shared_ptr<RVecUop> >::iterator::operator*()@plt>
 1549940:	48 8b 10             	mov    (%rax),%rdx
 1549943:	48 8b 40 08          	mov    0x8(%rax),%rax
 1549947:	48 85 c0             	test   %rax,%rax
 154994a:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
 154994f:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 1549954:	0f 84 4b ff ff ff    	je     15498a5 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x55>
 154995a:	48 83 3d 6e aa 63 00 	cmpq   $0x0,0x63aa6e(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 1549961:	00 
 1549962:	0f 85 38 ff ff ff    	jne    15498a0 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x50>
 1549968:	83 40 08 01          	addl   $0x1,0x8(%rax)
 154996c:	e9 34 ff ff ff       	jmp    15498a5 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x55>
 1549971:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1549978:	8b 44 24 30          	mov    0x30(%rsp),%eax
 154997c:	39 44 24 10          	cmp    %eax,0x10(%rsp)
 1549980:	75 a7                	jne    1549929 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xd9>
 1549982:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 1549987:	48 85 ff             	test   %rdi,%rdi
 154998a:	75 65                	jne    15499f1 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x1a1>
 154998c:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 1549991:	48 85 ff             	test   %rdi,%rdi
 1549994:	74 05                	je     154999b <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x14b>
 1549996:	e8 f5 7e 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 154999b:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
 15499a0:	64 48 33 0c 25 28 00 	xor    %fs:0x28,%rcx
 15499a7:	00 00 
 15499a9:	8b 44 24 0c          	mov    0xc(%rsp),%eax
 15499ad:	75 0f                	jne    15499be <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x16e>
 15499af:	48 83 c4 58          	add    $0x58,%rsp
 15499b3:	5b                   	pop    %rbx
 15499b4:	5d                   	pop    %rbp
 15499b5:	41 5c                	pop    %r12
 15499b7:	41 5d                	pop    %r13
 15499b9:	41 5e                	pop    %r14
 15499bb:	41 5f                	pop    %r15
 15499bd:	c3                   	ret
 15499be:	e8 fd bc e4 fe       	call   3956c0 <__stack_chk_fail@plt>
 15499c3:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 15499c8:	48 89 c3             	mov    %rax,%rbx
 15499cb:	48 85 ff             	test   %rdi,%rdi
 15499ce:	74 05                	je     15499d5 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x185>
 15499d0:	e8 bb 7e 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15499d5:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 15499da:	48 85 ff             	test   %rdi,%rdi
 15499dd:	74 05                	je     15499e4 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x194>
 15499df:	e8 ac 7e 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15499e4:	48 89 df             	mov    %rbx,%rdi
 15499e7:	e8 94 93 e5 fe       	call   3a2d80 <_Unwind_Resume@plt>
 15499ec:	48 89 c3             	mov    %rax,%rbx
 15499ef:	eb e4                	jmp    15499d5 <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x185>
 15499f1:	e8 9a 7e 84 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 15499f6:	eb 94                	jmp    154998c <RVecISUEntry::delayed_release(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x13c>
 15499f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 15499ff:	00 

0000000001549a00 <RVecISUEntry::reorder_exq_entry(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&)@@Base>:
 1549a00:	41 57                	push   %r15
 1549a02:	41 56                	push   %r14
 1549a04:	41 55                	push   %r13
 1549a06:	41 54                	push   %r12
 1549a08:	55                   	push   %rbp
 1549a09:	53                   	push   %rbx
 1549a0a:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
 1549a11:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 1549a18:	00 00 
 1549a1a:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
 1549a21:	00 
 1549a22:	31 c0                	xor    %eax,%eax
 1549a24:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
 1549a2b:	8b 80 30 01 00 00    	mov    0x130(%rax),%eax
 1549a31:	85 c0                	test   %eax,%eax
 1549a33:	74 0e                	je     1549a43 <RVecISUEntry::reorder_exq_entry(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&)@@Base+0x43>
 1549a35:	8b 87 d0 00 00 00    	mov    0xd0(%rdi),%eax
 1549a3b:	83 e8 03             	sub    $0x3,%eax
 1549a3e:	83 f8 01             	cmp    $0x1,%eax
 1549a41:	76 2d                	jbe    1549a70 <RVecISUEntry::reorder_exq_entry(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&)@@Base+0x70>
 1549a43:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
 1549a4a:	00 
 1549a4b:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 1549a52:	00 00 
 1549a54:	0f 85 57 02 00 00    	jne    1549cb1 <RVecISUEntry::reorder_exq_entry(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&)@@Base+0x2b1>
 1549a5a:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
 1549a61:	5b                   	pop    %rbx
 1549a62:	5d                   	pop    %rbp
 1549a63:	41 5c                	pop    %r12
 1549a65:	41 5d                	pop    %r13
 1549a67:	41 5e                	pop    %r14
 1549a69:	41 5f                	pop    %r15
 1549a6b:	c3                   	ret
 1549a6c:	0f 1f 40 00          	nopl   0x0(%rax)
 1549a70:	4c 8d 74 24 50       	lea    0x50(%rsp),%r14
 1549a75:	49 89 f4             	mov    %rsi,%r12
 1549a78:	48 8d 6c 24 10       	lea    0x10(%rsp),%rbp
 1549a7d:	48 8b 36             	mov    (%rsi),%rsi
