
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000e7c5e0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base>:
  e7c5e0:	55                   	push   %rbp
  e7c5e1:	48 89 e5             	mov    %rsp,%rbp
  e7c5e4:	41 57                	push   %r15
  e7c5e6:	41 56                	push   %r14
  e7c5e8:	41 55                	push   %r13
  e7c5ea:	41 54                	push   %r12
  e7c5ec:	49 89 f6             	mov    %rsi,%r14
  e7c5ef:	53                   	push   %rbx
  e7c5f0:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
  e7c5f7:	48 8b 3a             	mov    (%rdx),%rdi
  e7c5fa:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  e7c601:	00 00 
  e7c603:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
  e7c607:	31 c0                	xor    %eax,%eax
  e7c609:	48 83 ef 18          	sub    $0x18,%rdi
  e7c60d:	e8 8e d9 ff ff       	call   e79fa0 <DvcAttachLogCallback@@Base+0x6a0>
  e7c612:	48 8d 3d 12 e1 8d 00 	lea    0x8de112(%rip),%rdi        # 175a72b <_fini@@Base+0x3a07>
  e7c619:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
  e7c620:	e8 fb b0 51 ff       	call   397720 <getenv@plt>
  e7c625:	48 85 c0             	test   %rax,%rax
  e7c628:	0f 84 c2 04 00 00    	je     e7caf0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x510>
  e7c62e:	48 8d 3d f6 e0 8d 00 	lea    0x8de0f6(%rip),%rdi        # 175a72b <_fini@@Base+0x3a07>
  e7c635:	48 8d 9d 40 ff ff ff 	lea    -0xc0(%rbp),%rbx
  e7c63c:	e8 df b0 51 ff       	call   397720 <getenv@plt>
  e7c641:	49 89 c7             	mov    %rax,%r15
  e7c644:	48 89 c7             	mov    %rax,%rdi
  e7c647:	e8 14 8b 52 ff       	call   3a5160 <std::char_traits<char>::length(char const*)@plt>
  e7c64c:	4c 89 fe             	mov    %r15,%rsi
  e7c64f:	48 89 c2             	mov    %rax,%rdx
  e7c652:	48 89 df             	mov    %rbx,%rdi
  e7c655:	4c 8b 25 24 05 d0 00 	mov    0xd00524(%rip),%r12        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7c65c:	e8 8f ce 50 ff       	call   3894f0 <std::string::assign(char const*, unsigned long)@plt>
  e7c661:	48 8b 3d f0 34 d0 00 	mov    0xd034f0(%rip),%rdi        # 1b7fb58 <global_log_cfg_t::path@@Base-0xbf68>
  e7c668:	48 89 de             	mov    %rbx,%rsi
  e7c66b:	4c 8b 25 0e 05 d0 00 	mov    0xd0050e(%rip),%r12        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7c672:	e8 69 69 50 ff       	call   382fe0 <std::string::assign(std::string const&)@plt>
  e7c677:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
  e7c67b:	4c 8d 6d 90          	lea    -0x70(%rbp),%r13
  e7c67f:	48 8d 35 b6 e0 8d 00 	lea    0x8de0b6(%rip),%rsi        # 175a73c <_fini@@Base+0x3a18>
  e7c686:	49 8b 1e             	mov    (%r14),%rbx
  e7c689:	4c 8b 25 f0 04 d0 00 	mov    0xd004f0(%rip),%r12        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7c690:	4c 89 ea             	mov    %r13,%rdx
  e7c693:	48 89 c7             	mov    %rax,%rdi
  e7c696:	49 89 c7             	mov    %rax,%r15
  e7c699:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
  e7c6a0:	e8 0b 6e 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7c6a5:	48 83 ec 08          	sub    $0x8,%rsp
  e7c6a9:	31 d2                	xor    %edx,%edx
  e7c6ab:	4c 89 fe             	mov    %r15,%rsi
  e7c6ae:	6a 00                	push   $0x0
  e7c6b0:	48 89 df             	mov    %rbx,%rdi
  e7c6b3:	e8 58 45 50 ff       	call   380c10 <DvcConfig::Cfg::GetCfg(std::string const&, unsigned int, DvcConfig::CfgId<unsigned int>) const@plt>
  e7c6b8:	5f                   	pop    %rdi
  e7c6b9:	41 58                	pop    %r8
  e7c6bb:	89 c7                	mov    %eax,%edi
  e7c6bd:	e8 ae b5 50 ff       	call   387c70 <pem_log::get_log_level(unsigned int)@plt>
  e7c6c2:	48 8b 15 2f 7b d0 00 	mov    0xd07b2f(%rip),%rdx        # 1b841f8 <global_log_cfg_t::file_print_level@@Base-0x1e98>
  e7c6c9:	4c 8b 25 b0 04 d0 00 	mov    0xd004b0(%rip),%r12        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7c6d0:	89 02                	mov    %eax,(%rdx)
  e7c6d2:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  e7c6d6:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7c6da:	4c 39 e7             	cmp    %r12,%rdi
  e7c6dd:	0f 85 4d 04 00 00    	jne    e7cb30 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x550>
  e7c6e3:	4c 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%r15
  e7c6ea:	48 8d 35 60 e0 8d 00 	lea    0x8de060(%rip),%rsi        # 175a751 <_fini@@Base+0x3a2d>
  e7c6f1:	4c 89 ea             	mov    %r13,%rdx
  e7c6f4:	49 8b 1e             	mov    (%r14),%rbx
  e7c6f7:	4c 89 ff             	mov    %r15,%rdi
  e7c6fa:	e8 b1 6d 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7c6ff:	48 83 ec 08          	sub    $0x8,%rsp
  e7c703:	31 d2                	xor    %edx,%edx
  e7c705:	4c 89 fe             	mov    %r15,%rsi
  e7c708:	6a 00                	push   $0x0
  e7c70a:	48 89 df             	mov    %rbx,%rdi
  e7c70d:	e8 fe 44 50 ff       	call   380c10 <DvcConfig::Cfg::GetCfg(std::string const&, unsigned int, DvcConfig::CfgId<unsigned int>) const@plt>
  e7c712:	59                   	pop    %rcx
  e7c713:	5e                   	pop    %rsi
  e7c714:	89 c7                	mov    %eax,%edi
  e7c716:	e8 55 b5 50 ff       	call   387c70 <pem_log::get_log_level(unsigned int)@plt>
  e7c71b:	48 8b 15 7e 47 d0 00 	mov    0xd0477e(%rip),%rdx        # 1b80ea0 <global_log_cfg_t::screen_print_level@@Base-0x51ec>
  e7c722:	89 02                	mov    %eax,(%rdx)
  e7c724:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  e7c728:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7c72c:	4c 39 e7             	cmp    %r12,%rdi
  e7c72f:	0f 85 1b 04 00 00    	jne    e7cb50 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x570>
  e7c735:	4c 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%r15
  e7c73c:	48 8d 35 25 e0 8d 00 	lea    0x8de025(%rip),%rsi        # 175a768 <_fini@@Base+0x3a44>
  e7c743:	4c 89 ea             	mov    %r13,%rdx
  e7c746:	49 8b 1e             	mov    (%r14),%rbx
  e7c749:	4c 89 ff             	mov    %r15,%rdi
  e7c74c:	e8 5f 6d 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7c751:	48 83 ec 08          	sub    $0x8,%rsp
  e7c755:	31 d2                	xor    %edx,%edx
  e7c757:	4c 89 fe             	mov    %r15,%rsi
  e7c75a:	6a 00                	push   $0x0
  e7c75c:	48 89 df             	mov    %rbx,%rdi
  e7c75f:	e8 ac 44 50 ff       	call   380c10 <DvcConfig::Cfg::GetCfg(std::string const&, unsigned int, DvcConfig::CfgId<unsigned int>) const@plt>
  e7c764:	41 5f                	pop    %r15
  e7c766:	5a                   	pop    %rdx
  e7c767:	89 c7                	mov    %eax,%edi
  e7c769:	e8 02 b5 50 ff       	call   387c70 <pem_log::get_log_level(unsigned int)@plt>
  e7c76e:	48 8b 15 5b 54 d0 00 	mov    0xd0545b(%rip),%rdx        # 1b81bd0 <global_log_cfg_t::flush_level@@Base-0x44b8>
  e7c775:	89 02                	mov    %eax,(%rdx)
  e7c777:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  e7c77b:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7c77f:	4c 39 e7             	cmp    %r12,%rdi
  e7c782:	0f 85 d8 03 00 00    	jne    e7cb60 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x580>
  e7c788:	4c 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%r15
  e7c78f:	48 8d 35 e2 df 8d 00 	lea    0x8ddfe2(%rip),%rsi        # 175a778 <_fini@@Base+0x3a54>
  e7c796:	4c 89 ea             	mov    %r13,%rdx
  e7c799:	49 8b 1e             	mov    (%r14),%rbx
  e7c79c:	4c 89 ff             	mov    %r15,%rdi
  e7c79f:	e8 0c 6d 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7c7a4:	48 83 ec 08          	sub    $0x8,%rsp
  e7c7a8:	31 d2                	xor    %edx,%edx
  e7c7aa:	4c 89 fe             	mov    %r15,%rsi
  e7c7ad:	6a 00                	push   $0x0
  e7c7af:	48 89 df             	mov    %rbx,%rdi
  e7c7b2:	e8 59 44 50 ff       	call   380c10 <DvcConfig::Cfg::GetCfg(std::string const&, unsigned int, DvcConfig::CfgId<unsigned int>) const@plt>
  e7c7b7:	48 8b 15 2a 68 d0 00 	mov    0xd0682a(%rip),%rdx        # 1b82fe8 <global_log_cfg_t::rotating_file_size@@Base-0x309c>
  e7c7be:	41 5b                	pop    %r11
  e7c7c0:	5b                   	pop    %rbx
  e7c7c1:	89 02                	mov    %eax,(%rdx)
  e7c7c3:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  e7c7c7:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7c7cb:	4c 39 e7             	cmp    %r12,%rdi
  e7c7ce:	0f 85 9c 03 00 00    	jne    e7cb70 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x590>
  e7c7d4:	4c 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%r15
  e7c7db:	48 8d 35 ad df 8d 00 	lea    0x8ddfad(%rip),%rsi        # 175a78f <_fini@@Base+0x3a6b>
  e7c7e2:	4c 89 ea             	mov    %r13,%rdx
  e7c7e5:	49 8b 1e             	mov    (%r14),%rbx
  e7c7e8:	4c 89 ff             	mov    %r15,%rdi
  e7c7eb:	e8 c0 6c 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7c7f0:	48 83 ec 08          	sub    $0x8,%rsp
  e7c7f4:	31 d2                	xor    %edx,%edx
  e7c7f6:	4c 89 fe             	mov    %r15,%rsi
  e7c7f9:	6a 00                	push   $0x0
  e7c7fb:	48 89 df             	mov    %rbx,%rdi
  e7c7fe:	e8 0d 44 50 ff       	call   380c10 <DvcConfig::Cfg::GetCfg(std::string const&, unsigned int, DvcConfig::CfgId<unsigned int>) const@plt>
  e7c803:	48 8b 15 06 fa cf 00 	mov    0xcffa06(%rip),%rdx        # 1b7c210 <global_log_cfg_t::rotating_file_number@@Base-0x9e70>
  e7c80a:	41 59                	pop    %r9
  e7c80c:	41 5a                	pop    %r10
  e7c80e:	89 02                	mov    %eax,(%rdx)
  e7c810:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  e7c814:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7c818:	4c 39 e7             	cmp    %r12,%rdi
  e7c81b:	0f 85 5f 03 00 00    	jne    e7cb80 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x5a0>
  e7c821:	48 8d 85 70 ff ff ff 	lea    -0x90(%rbp),%rax
  e7c828:	66 0f ef c0          	pxor   %xmm0,%xmm0
  e7c82c:	48 8d 35 75 df 8d 00 	lea    0x8ddf75(%rip),%rsi        # 175a7a8 <_fini@@Base+0x3a84>
  e7c833:	4c 89 ef             	mov    %r13,%rdi
  e7c836:	49 8b 1e             	mov    (%r14),%rbx
  e7c839:	48 89 c2             	mov    %rax,%rdx
  e7c83c:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
  e7c843:	00 
  e7c844:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
  e7c84b:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
  e7c84f:	e8 5c 6c 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7c854:	48 83 ec 08          	sub    $0x8,%rsp
  e7c858:	48 8d bd 50 ff ff ff 	lea    -0xb0(%rbp),%rdi
  e7c85f:	4c 89 ea             	mov    %r13,%rdx
  e7c862:	48 89 de             	mov    %rbx,%rsi
  e7c865:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
  e7c86c:	6a 00                	push   $0x0
  e7c86e:	e8 3d ae 51 ff       	call   3976b0 <DvcConfig::Cfg::GetArrayCfg(std::string const&, std::vector<unsigned long, std::allocator<unsigned long> > const&, DvcConfig::CfgId<unsigned long>) const@plt>
  e7c873:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  e7c877:	5f                   	pop    %rdi
  e7c878:	41 58                	pop    %r8
  e7c87a:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7c87e:	4c 39 e7             	cmp    %r12,%rdi
  e7c881:	0f 85 b9 02 00 00    	jne    e7cb40 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x560>
  e7c887:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
  e7c88b:	48 85 ff             	test   %rdi,%rdi
  e7c88e:	74 05                	je     e7c895 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x2b5>
  e7c890:	e8 8b 5b 51 ff       	call   392420 <operator delete(void*)@plt>
  e7c895:	48 8d 3d 21 df 8d 00 	lea    0x8ddf21(%rip),%rdi        # 175a7bd <_fini@@Base+0x3a99>
  e7c89c:	e8 7f ae 51 ff       	call   397720 <getenv@plt>
  e7c8a1:	48 85 c0             	test   %rax,%rax
  e7c8a4:	0f 84 16 02 00 00    	je     e7cac0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x4e0>
  e7c8aa:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
  e7c8b1:	48 89 c6             	mov    %rax,%rsi
  e7c8b4:	4c 89 ef             	mov    %r13,%rdi
  e7c8b7:	e8 f4 6b 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7c8bc:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
  e7c8c0:	e8 fb 3f 50 ff       	call   3808c0 <__errno_location@plt>
  e7c8c5:	48 8b b5 28 ff ff ff 	mov    -0xd8(%rbp),%rsi
  e7c8cc:	48 89 c3             	mov    %rax,%rbx
  e7c8cf:	8b 00                	mov    (%rax),%eax
  e7c8d1:	31 d2                	xor    %edx,%edx
  e7c8d3:	c7 03 00 00 00 00    	movl   $0x0,(%rbx)
  e7c8d9:	4c 89 ff             	mov    %r15,%rdi
  e7c8dc:	89 85 18 ff ff ff    	mov    %eax,-0xe8(%rbp)
  e7c8e2:	e8 49 d0 51 ff       	call   399930 <strtoull@plt>
  e7c8e7:	4c 3b 7d b0          	cmp    -0x50(%rbp),%r15
  e7c8eb:	0f 84 6d 03 00 00    	je     e7cc5e <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x67e>
  e7c8f1:	8b 13                	mov    (%rbx),%edx
  e7c8f3:	83 fa 22             	cmp    $0x22,%edx
  e7c8f6:	0f 84 73 03 00 00    	je     e7cc6f <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x68f>
  e7c8fc:	85 d2                	test   %edx,%edx
  e7c8fe:	75 08                	jne    e7c908 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x328>
  e7c900:	8b 8d 18 ff ff ff    	mov    -0xe8(%rbp),%ecx
  e7c906:	89 0b                	mov    %ecx,(%rbx)
  e7c908:	48 8b 15 61 57 d0 00 	mov    0xd05761(%rip),%rdx        # 1b82070 <global_log_cfg_t::core_enable_mask@@Base-0x4008>
  e7c90f:	48 89 02             	mov    %rax,(%rdx)
  e7c912:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  e7c916:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7c91a:	4c 39 e7             	cmp    %r12,%rdi
  e7c91d:	0f 85 d9 01 00 00    	jne    e7cafc <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x51c>
  e7c923:	48 8d 85 48 ff ff ff 	lea    -0xb8(%rbp),%rax
  e7c92a:	66 0f ef c0          	pxor   %xmm0,%xmm0
  e7c92e:	48 8d 35 a0 de 8d 00 	lea    0x8ddea0(%rip),%rsi        # 175a7d5 <_fini@@Base+0x3ab1>
  e7c935:	4c 89 ef             	mov    %r13,%rdi
  e7c938:	49 8b 1e             	mov    (%r14),%rbx
  e7c93b:	48 89 c2             	mov    %rax,%rdx
  e7c93e:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
  e7c945:	00 
  e7c946:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
  e7c94d:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
  e7c951:	e8 5a 6b 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7c956:	48 83 ec 08          	sub    $0x8,%rsp
  e7c95a:	4c 89 ea             	mov    %r13,%rdx
  e7c95d:	48 89 de             	mov    %rbx,%rsi
  e7c960:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
  e7c967:	48 8b bd 20 ff ff ff 	mov    -0xe0(%rbp),%rdi
  e7c96e:	6a 00                	push   $0x0
  e7c970:	e8 1b 14 52 ff       	call   39dd90 <std::vector<std::string, std::allocator<std::string> > DvcConfig::Cfg::GetArrayCfg<std::string, std::string>(std::string const&, std::vector<std::string, std::allocator<std::string> > const&, DvcConfig::CfgId<std::string>) const@plt>
  e7c975:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  e7c979:	59                   	pop    %rcx
  e7c97a:	5e                   	pop    %rsi
  e7c97b:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7c97f:	4c 39 e7             	cmp    %r12,%rdi
  e7c982:	0f 85 98 01 00 00    	jne    e7cb20 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x540>
  e7c988:	48 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%rdi
  e7c98f:	e8 74 ac 52 ff       	call   3a7608 <std::vector<std::string, std::allocator<std::string> >::~vector()@plt>
  e7c994:	4c 8b bd 78 ff ff ff 	mov    -0x88(%rbp),%r15
  e7c99b:	48 8b 9d 70 ff ff ff 	mov    -0x90(%rbp),%rbx
  e7c9a2:	4c 39 fb             	cmp    %r15,%rbx
  e7c9a5:	74 1a                	je     e7c9c1 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x3e1>
  e7c9a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  e7c9ae:	00 00 
  e7c9b0:	48 89 df             	mov    %rbx,%rdi
  e7c9b3:	e8 98 23 52 ff       	call   39ed50 <pem_log::disable_log(std::string const&)@plt>
  e7c9b8:	48 83 c3 08          	add    $0x8,%rbx
  e7c9bc:	49 39 df             	cmp    %rbx,%r15
  e7c9bf:	75 ef                	jne    e7c9b0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x3d0>
  e7c9c1:	49 8b 1e             	mov    (%r14),%rbx
  e7c9c4:	4c 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%r14
  e7c9cb:	48 8d 95 3f ff ff ff 	lea    -0xc1(%rbp),%rdx
  e7c9d2:	66 0f ef c0          	pxor   %xmm0,%xmm0
  e7c9d6:	48 8d 35 09 de 8d 00 	lea    0x8dde09(%rip),%rsi        # 175a7e6 <_fini@@Base+0x3ac2>
  e7c9dd:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
  e7c9e4:	00 
  e7c9e5:	4c 89 f7             	mov    %r14,%rdi
  e7c9e8:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
  e7c9ec:	e8 bf 6a 52 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  e7c9f1:	48 83 ec 08          	sub    $0x8,%rsp
  e7c9f5:	4c 89 f2             	mov    %r14,%rdx
  e7c9f8:	48 89 de             	mov    %rbx,%rsi
  e7c9fb:	4c 89 ef             	mov    %r13,%rdi
  e7c9fe:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
  e7ca05:	6a 00                	push   $0x0
  e7ca07:	e8 84 13 52 ff       	call   39dd90 <std::vector<std::string, std::allocator<std::string> > DvcConfig::Cfg::GetArrayCfg<std::string, std::string>(std::string const&, std::vector<std::string, std::allocator<std::string> > const&, DvcConfig::CfgId<std::string>) const@plt>
  e7ca0c:	58                   	pop    %rax
  e7ca0d:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
  e7ca14:	5a                   	pop    %rdx
  e7ca15:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7ca19:	4c 39 e7             	cmp    %r12,%rdi
  e7ca1c:	0f 85 ee 00 00 00    	jne    e7cb10 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x530>
  e7ca22:	48 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%rdi
  e7ca29:	e8 da ab 52 ff       	call   3a7608 <std::vector<std::string, std::allocator<std::string> >::~vector()@plt>
  e7ca2e:	48 8b 45 98          	mov    -0x68(%rbp),%rax
  e7ca32:	48 8b 5d 90          	mov    -0x70(%rbp),%rbx
  e7ca36:	48 39 c3             	cmp    %rax,%rbx
  e7ca39:	49 89 c6             	mov    %rax,%r14
  e7ca3c:	74 13                	je     e7ca51 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x471>
  e7ca3e:	66 90                	xchg   %ax,%ax
  e7ca40:	48 89 df             	mov    %rbx,%rdi
  e7ca43:	e8 d8 80 52 ff       	call   3a4b20 <pem_log::enable_log(std::string const&)@plt>
  e7ca48:	48 83 c3 08          	add    $0x8,%rbx
  e7ca4c:	49 39 de             	cmp    %rbx,%r14
  e7ca4f:	75 ef                	jne    e7ca40 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x460>
  e7ca51:	bf 00 00 01 00       	mov    $0x10000,%edi
  e7ca56:	e8 75 86 51 ff       	call   3950d0 <pem_log::init_async_instr_log(unsigned long)@plt>
  e7ca5b:	4c 89 ef             	mov    %r13,%rdi
  e7ca5e:	e8 a5 ab 52 ff       	call   3a7608 <std::vector<std::string, std::allocator<std::string> >::~vector()@plt>
  e7ca63:	48 8b bd 20 ff ff ff 	mov    -0xe0(%rbp),%rdi
  e7ca6a:	e8 99 ab 52 ff       	call   3a7608 <std::vector<std::string, std::allocator<std::string> >::~vector()@plt>
  e7ca6f:	48 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%rdi
  e7ca76:	48 85 ff             	test   %rdi,%rdi
  e7ca79:	74 05                	je     e7ca80 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x4a0>
  e7ca7b:	e8 a0 59 51 ff       	call   392420 <operator delete(void*)@plt>
  e7ca80:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
  e7ca87:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7ca8b:	4c 39 e7             	cmp    %r12,%rdi
  e7ca8e:	0f 85 fc 00 00 00    	jne    e7cb90 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x5b0>
  e7ca94:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
  e7ca98:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
  e7ca9f:	00 00 
  e7caa1:	0f 85 f3 00 00 00    	jne    e7cb9a <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x5ba>
  e7caa7:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
  e7caab:	5b                   	pop    %rbx
  e7caac:	41 5c                	pop    %r12
  e7caae:	41 5d                	pop    %r13
  e7cab0:	41 5e                	pop    %r14
  e7cab2:	41 5f                	pop    %r15
  e7cab4:	5d                   	pop    %rbp
  e7cab5:	c3                   	ret
  e7cab6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  e7cabd:	00 00 00 
  e7cac0:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
  e7cac7:	48 39 85 58 ff ff ff 	cmp    %rax,-0xa8(%rbp)
  e7cace:	0f 84 4f fe ff ff    	je     e7c923 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x343>
  e7cad4:	48 8b 10             	mov    (%rax),%rdx
  e7cad7:	48 8b 05 92 55 d0 00 	mov    0xd05592(%rip),%rax        # 1b82070 <global_log_cfg_t::core_enable_mask@@Base-0x4008>
  e7cade:	48 89 10             	mov    %rdx,(%rax)
  e7cae1:	e9 3d fe ff ff       	jmp    e7c923 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x343>
  e7cae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  e7caed:	00 00 00 
  e7caf0:	48 8d 9d 40 ff ff ff 	lea    -0xc0(%rbp),%rbx
  e7caf7:	e9 65 fb ff ff       	jmp    e7c661 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x81>
  e7cafc:	e8 7f cf ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cb01:	e9 1d fe ff ff       	jmp    e7c923 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x343>
  e7cb06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  e7cb0d:	00 00 00 
  e7cb10:	e8 6b cf ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cb15:	e9 08 ff ff ff       	jmp    e7ca22 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x442>
  e7cb1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  e7cb20:	e8 5b cf ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cb25:	e9 5e fe ff ff       	jmp    e7c988 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x3a8>
  e7cb2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  e7cb30:	e8 4b cf ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cb35:	e9 a9 fb ff ff       	jmp    e7c6e3 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x103>
  e7cb3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  e7cb40:	e8 3b cf ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cb45:	e9 3d fd ff ff       	jmp    e7c887 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x2a7>
  e7cb4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  e7cb50:	e8 2b cf ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cb55:	e9 db fb ff ff       	jmp    e7c735 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x155>
  e7cb5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  e7cb60:	e8 1b cf ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cb65:	e9 1e fc ff ff       	jmp    e7c788 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1a8>
  e7cb6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  e7cb70:	e8 0b cf ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cb75:	e9 5a fc ff ff       	jmp    e7c7d4 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x1f4>
  e7cb7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  e7cb80:	e8 fb ce ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cb85:	e9 97 fc ff ff       	jmp    e7c821 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x241>
  e7cb8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  e7cb90:	e8 eb ce ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cb95:	e9 fa fe ff ff       	jmp    e7ca94 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x4b4>
  e7cb9a:	e8 21 8b 51 ff       	call   3956c0 <__stack_chk_fail@plt>
  e7cb9f:	48 89 c3             	mov    %rax,%rbx
  e7cba2:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
  e7cba9:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7cbad:	4c 39 e7             	cmp    %r12,%rdi
  e7cbb0:	74 05                	je     e7cbb7 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x5d7>
  e7cbb2:	e8 c9 ce ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cbb7:	48 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%rdi
  e7cbbe:	e8 45 aa 52 ff       	call   3a7608 <std::vector<std::string, std::allocator<std::string> >::~vector()@plt>
  e7cbc3:	48 8b bd 20 ff ff ff 	mov    -0xe0(%rbp),%rdi
  e7cbca:	e8 39 aa 52 ff       	call   3a7608 <std::vector<std::string, std::allocator<std::string> >::~vector()@plt>
  e7cbcf:	48 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%rdi
  e7cbd6:	48 85 ff             	test   %rdi,%rdi
  e7cbd9:	74 05                	je     e7cbe0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x600>
  e7cbdb:	e8 40 58 51 ff       	call   392420 <operator delete(void*)@plt>
  e7cbe0:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
  e7cbe7:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7cbeb:	4c 39 e7             	cmp    %r12,%rdi
  e7cbee:	74 05                	je     e7cbf5 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x615>
  e7cbf0:	e8 8b ce ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cbf5:	48 89 df             	mov    %rbx,%rdi
  e7cbf8:	e8 83 61 52 ff       	call   3a2d80 <_Unwind_Resume@plt>
  e7cbfd:	48 89 c3             	mov    %rax,%rbx
  e7cc00:	eb b5                	jmp    e7cbb7 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x5d7>
  e7cc02:	48 89 c3             	mov    %rax,%rbx
  e7cc05:	eb bc                	jmp    e7cbc3 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x5e3>
  e7cc07:	48 89 c3             	mov    %rax,%rbx
  e7cc0a:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  e7cc0e:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7cc12:	4c 39 e7             	cmp    %r12,%rdi
  e7cc15:	74 05                	je     e7cc1c <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x63c>
  e7cc17:	e8 64 ce ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cc1c:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
  e7cc20:	48 85 ff             	test   %rdi,%rdi
  e7cc23:	75 b6                	jne    e7cbdb <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x5fb>
  e7cc25:	eb b9                	jmp    e7cbe0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x600>
  e7cc27:	48 89 c3             	mov    %rax,%rbx
  e7cc2a:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  e7cc2e:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7cc32:	4c 39 e7             	cmp    %r12,%rdi
  e7cc35:	74 a9                	je     e7cbe0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x600>
  e7cc37:	e8 44 ce ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7cc3c:	eb a2                	jmp    e7cbe0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x600>
  e7cc3e:	48 89 c3             	mov    %rax,%rbx
  e7cc41:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  e7cc45:	4c 8b 25 34 ff cf 00 	mov    0xcfff34(%rip),%r12        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
  e7cc4c:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7cc50:	4c 39 e7             	cmp    %r12,%rdi
  e7cc53:	74 8b                	je     e7cbe0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x600>
  e7cc55:	eb e0                	jmp    e7cc37 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x657>
  e7cc57:	48 89 c3             	mov    %rax,%rbx
  e7cc5a:	eb 84                	jmp    e7cbe0 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x600>
  e7cc5c:	eb c9                	jmp    e7cc27 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x647>
  e7cc5e:	48 8d 3d 69 db 8d 00 	lea    0x8ddb69(%rip),%rdi        # 175a7ce <_fini@@Base+0x3aaa>
  e7cc65:	e8 c6 e6 50 ff       	call   38b330 <std::__throw_invalid_argument(char const*)@plt>
  e7cc6a:	48 89 c3             	mov    %rax,%rbx
  e7cc6d:	eb ad                	jmp    e7cc1c <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x63c>
  e7cc6f:	48 8d 3d 58 db 8d 00 	lea    0x8ddb58(%rip),%rdi        # 175a7ce <_fini@@Base+0x3aaa>
  e7cc76:	e8 65 fb 51 ff       	call   39c7e0 <std::__throw_out_of_range(char const*)@plt>
  e7cc7b:	eb aa                	jmp    e7cc27 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x647>
  e7cc7d:	48 89 c3             	mov    %rax,%rbx
  e7cc80:	48 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%rdi
  e7cc87:	e8 7c a9 52 ff       	call   3a7608 <std::vector<std::string, std::allocator<std::string> >::~vector()@plt>
  e7cc8c:	e9 3e ff ff ff       	jmp    e7cbcf <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x5ef>
  e7cc91:	48 89 c3             	mov    %rax,%rbx
  e7cc94:	e9 36 ff ff ff       	jmp    e7cbcf <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x5ef>
  e7cc99:	48 89 c3             	mov    %rax,%rbx
  e7cc9c:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  e7cca0:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
  e7cca4:	4c 39 e7             	cmp    %r12,%rdi
  e7cca7:	74 d7                	je     e7cc80 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x6a0>
  e7cca9:	e8 d2 cd ff ff       	call   e79a80 <DvcAttachLogCallback@@Base+0x180>
  e7ccae:	eb d0                	jmp    e7cc80 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x6a0>
  e7ccb0:	4c 89 ef             	mov    %r13,%rdi
  e7ccb3:	48 89 c3             	mov    %rax,%rbx
  e7ccb6:	e8 4d a9 52 ff       	call   3a7608 <std::vector<std::string, std::allocator<std::string> >::~vector()@plt>
  e7ccbb:	e9 03 ff ff ff       	jmp    e7cbc3 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x5e3>
  e7ccc0:	e9 62 ff ff ff       	jmp    e7cc27 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x647>
  e7ccc5:	83 3b 00             	cmpl   $0x0,(%rbx)
  e7ccc8:	49 89 c6             	mov    %rax,%r14
  e7cccb:	75 08                	jne    e7ccd5 <pem_log::config_aicore_log(unsigned int, std::shared_ptr<DvcConfig::Cfg> const&, std::string const&)@@Base+0x6f5>
  e7cccd:	8b                   	.byte 0x8b
  e7ccce:	85 18                	test   %ebx,(%rax)
