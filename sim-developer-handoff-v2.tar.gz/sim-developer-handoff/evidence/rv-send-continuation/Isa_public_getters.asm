
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000f72c60 <Isa::name() const@@Base>:
  f72c60:	8b 87 80 02 00 00    	mov    0x280(%rdi),%eax
  f72c66:	c3                   	ret
  f72c67:	90                   	nop
  f72c68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  f72c6f:	00 

0000000000f72c70 <Isa::type() const@@Base>:
  f72c70:	8b 87 78 02 00 00    	mov    0x278(%rdi),%eax
  f72c76:	c3                   	ret
  f72c77:	90                   	nop
  f72c78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  f72c7f:	00 

0000000000f72c80 <Isa::pipe() const@@Base>:
  f72c80:	8b 87 7c 02 00 00    	mov    0x27c(%rdi),%eax
  f72c86:	c3                   	ret
  f72c87:	90                   	nop
  f72c88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  f72c8f:	00 

0000000000f72c90 <Isa::id() const@@Base>:
  f72c90:	48 8b 87 40 02 00 00 	mov    0x240(%rdi),%rax
  f72c97:	c3                   	ret
  f72c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  f72c9f:	00 

0000000000f72ca0 <Isa::pc() const@@Base>:
  f72ca0:	48 8b 87 70 02 00 00 	mov    0x270(%rdi),%rax
  f72ca7:	c3                   	ret
  f72ca8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  f72caf:	00 
