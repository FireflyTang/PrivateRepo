
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013cb060 <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base>:
 13cb060:	41 56                	push   %r14
 13cb062:	41 55                	push   %r13
 13cb064:	41 54                	push   %r12
 13cb066:	55                   	push   %rbp
 13cb067:	48 89 f5             	mov    %rsi,%rbp
 13cb06a:	53                   	push   %rbx
 13cb06b:	48 83 ec 40          	sub    $0x40,%rsp
 13cb06f:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13cb076:	00 00 
 13cb078:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 13cb07d:	31 c0                	xor    %eax,%eax
 13cb07f:	48 8b 87 b0 01 00 00 	mov    0x1b0(%rdi),%rax
 13cb086:	48 8b 70 10          	mov    0x10(%rax),%rsi
 13cb08a:	48 3b 70 30          	cmp    0x30(%rax),%rsi
 13cb08e:	74 4b                	je     13cb0db <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x7b>
 13cb090:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
 13cb095:	48 89 fb             	mov    %rdi,%rbx
 13cb098:	4c 89 e7             	mov    %r12,%rdi
 13cb09b:	e8 90 b8 fb fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13cb0a0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13cb0a5:	48 8b 38             	mov    (%rax),%rdi
 13cb0a8:	e8 f3 97 fb fe       	call   3848a0 <Isa::name() const@plt>
 13cb0ad:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 13cb0b2:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 13cb0b7:	74 47                	je     13cb100 <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0xa0>
 13cb0b9:	48 8b 3e             	mov    (%rsi),%rdi
 13cb0bc:	e8 df 97 fb fe       	call   3848a0 <Isa::name() const@plt>
 13cb0c1:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 13cb0c6:	0f 84 d4 00 00 00    	je     13cb1a0 <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x140>
 13cb0cc:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 13cb0d1:	48 85 ff             	test   %rdi,%rdi
 13cb0d4:	74 05                	je     13cb0db <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x7b>
 13cb0d6:	e8 b5 67 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb0db:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 13cb0e0:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 13cb0e7:	00 00 
 13cb0e9:	0f 85 d7 02 00 00    	jne    13cb3c6 <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x366>
 13cb0ef:	48 83 c4 40          	add    $0x40,%rsp
 13cb0f3:	5b                   	pop    %rbx
 13cb0f4:	5d                   	pop    %rbp
 13cb0f5:	41 5c                	pop    %r12
 13cb0f7:	41 5d                	pop    %r13
 13cb0f9:	41 5e                	pop    %r14
 13cb0fb:	c3                   	ret
 13cb0fc:	0f 1f 40 00          	nopl   0x0(%rax)
 13cb100:	4c 8b b3 e8 00 00 00 	mov    0xe8(%rbx),%r14
 13cb107:	4c 8d 6c 24 20       	lea    0x20(%rsp),%r13
 13cb10c:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
 13cb110:	4c 89 ef             	mov    %r13,%rdi
 13cb113:	e8 c8 73 fd fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13cb118:	4c 89 ea             	mov    %r13,%rdx
 13cb11b:	be 03 00 00 00       	mov    $0x3,%esi
 13cb120:	4c 89 f7             	mov    %r14,%rdi
 13cb123:	e8 48 59 fd fe       	call   3a0a70 <PemRvecDepmgr::can_smem_bar_go(SMemBarUnit, std::shared_ptr<Isa>)@plt>
 13cb128:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13cb12d:	41 89 c6             	mov    %eax,%r14d
 13cb130:	48 85 ff             	test   %rdi,%rdi
 13cb133:	74 05                	je     13cb13a <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0xda>
 13cb135:	e8 56 67 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb13a:	45 84 f6             	test   %r14b,%r14b
 13cb13d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 13cb142:	0f 85 d8 00 00 00    	jne    13cb220 <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x1c0>
 13cb148:	4c 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%r14
 13cb14f:	48 8b 3e             	mov    (%rsi),%rdi
 13cb152:	4d 85 f6             	test   %r14,%r14
 13cb155:	0f 84 61 ff ff ff    	je     13cb0bc <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x5c>
 13cb15b:	e8 60 49 fc fe       	call   38fac0 <Isa::id() const@plt>
 13cb160:	48 89 df             	mov    %rbx,%rdi
 13cb163:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 13cb168:	e8 63 4b fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13cb16d:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 13cb172:	48 8d 35 af 30 3b 00 	lea    0x3b30af(%rip),%rsi        # 177e228 <_fini@@Base+0x27504>
 13cb179:	4d 89 e8             	mov    %r13,%r8
 13cb17c:	ba 3a 00 00 00       	mov    $0x3a,%edx
 13cb181:	4c 89 f7             	mov    %r14,%rdi
 13cb184:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13cb189:	e8 12 48 fc fe       	call   38f9a0 <void spdlog::logger::info<unsigned long, unsigned long>(fmt::v11::fstring<unsigned long, unsigned long>::t, unsigned long&&, unsigned long&&)@plt>
 13cb18e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13cb193:	48 8b 38             	mov    (%rax),%rdi
 13cb196:	e9 21 ff ff ff       	jmp    13cb0bc <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x5c>
 13cb19b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 13cb1a0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13cb1a5:	48 8b bb e8 00 00 00 	mov    0xe8(%rbx),%rdi
 13cb1ac:	be 03 00 00 00       	mov    $0x3,%esi
 13cb1b1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
 13cb1b5:	48 8b 90 80 00 00 00 	mov    0x80(%rax),%rdx
 13cb1bc:	e8 1f c3 fb fe       	call   3874e0 <PemRvecDepmgr::can_send_go(SMemBarUnit, unsigned long)@plt>
 13cb1c1:	84 c0                	test   %al,%al
 13cb1c3:	0f 85 27 01 00 00    	jne    13cb2f0 <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x290>
 13cb1c9:	48 8b ab d0 00 00 00 	mov    0xd0(%rbx),%rbp
 13cb1d0:	48 85 ed             	test   %rbp,%rbp
 13cb1d3:	0f 84 f3 fe ff ff    	je     13cb0cc <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x6c>
 13cb1d9:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13cb1de:	48 8b 38             	mov    (%rax),%rdi
 13cb1e1:	e8 da 48 fc fe       	call   38fac0 <Isa::id() const@plt>
 13cb1e6:	48 89 df             	mov    %rbx,%rdi
 13cb1e9:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 13cb1ee:	e8 dd 4a fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13cb1f3:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 13cb1f8:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
 13cb1fd:	48 8d 35 9c 30 3b 00 	lea    0x3b309c(%rip),%rsi        # 177e2a0 <_fini@@Base+0x2757c>
 13cb204:	ba 36 00 00 00       	mov    $0x36,%edx
 13cb209:	48 89 ef             	mov    %rbp,%rdi
 13cb20c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13cb211:	e8 8a 47 fc fe       	call   38f9a0 <void spdlog::logger::info<unsigned long, unsigned long>(fmt::v11::fstring<unsigned long, unsigned long>::t, unsigned long&&, unsigned long&&)@plt>
 13cb216:	e9 b1 fe ff ff       	jmp    13cb0cc <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x6c>
 13cb21b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 13cb220:	4c 8b b3 e8 00 00 00 	mov    0xe8(%rbx),%r14
 13cb227:	4c 89 ef             	mov    %r13,%rdi
 13cb22a:	e8 b1 72 fd fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13cb22f:	4c 89 ea             	mov    %r13,%rdx
 13cb232:	be 03 00 00 00       	mov    $0x3,%esi
 13cb237:	4c 89 f7             	mov    %r14,%rdi
 13cb23a:	e8 b1 2e fc fe       	call   38e0f0 <PemRvecDepmgr::smem_bar_update(SMemBarUnit, std::shared_ptr<Isa>)@plt>
 13cb23f:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13cb244:	48 85 ff             	test   %rdi,%rdi
 13cb247:	74 05                	je     13cb24e <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x1ee>
 13cb249:	e8 42 66 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb24e:	48 8b bb b0 01 00 00 	mov    0x1b0(%rbx),%rdi
 13cb255:	e8 06 92 fd fe       	call   3a4460 <std::deque<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > >::pop_front()@plt>
 13cb25a:	48 89 df             	mov    %rbx,%rdi
 13cb25d:	e8 6e 4a fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13cb262:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 13cb267:	4c 8b b3 88 02 00 00 	mov    0x288(%rbx),%r14
 13cb26e:	83 c0 01             	add    $0x1,%eax
 13cb271:	4c 89 e6             	mov    %r12,%rsi
 13cb274:	4c 89 ef             	mov    %r13,%rdi
 13cb277:	89 82 a0 00 00 00    	mov    %eax,0xa0(%rdx)
 13cb27d:	e8 ae b6 fb fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13cb282:	4c 89 ee             	mov    %r13,%rsi
 13cb285:	4c 89 f7             	mov    %r14,%rdi
 13cb288:	e8 33 9a fd fe       	call   3a4cc0 <TmQue<std::shared_ptr<RVecUop> >::push_back(std::shared_ptr<RVecUop>)@plt>
 13cb28d:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13cb292:	48 85 ff             	test   %rdi,%rdi
 13cb295:	74 05                	je     13cb29c <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x23c>
 13cb297:	e8 f4 65 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb29c:	4c 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%r14
 13cb2a3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13cb2a8:	4d 85 f6             	test   %r14,%r14
 13cb2ab:	48 8b 38             	mov    (%rax),%rdi
 13cb2ae:	0f 84 08 fe ff ff    	je     13cb0bc <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x5c>
 13cb2b4:	e8 07 48 fc fe       	call   38fac0 <Isa::id() const@plt>
 13cb2b9:	48 89 df             	mov    %rbx,%rdi
 13cb2bc:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 13cb2c1:	e8 0a 4a fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13cb2c6:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 13cb2cb:	48 8d 35 1e 2f 3b 00 	lea    0x3b2f1e(%rip),%rsi        # 177e1f0 <_fini@@Base+0x274cc>
 13cb2d2:	4d 89 e8             	mov    %r13,%r8
 13cb2d5:	ba 37 00 00 00       	mov    $0x37,%edx
 13cb2da:	4c 89 f7             	mov    %r14,%rdi
 13cb2dd:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13cb2e2:	e8 b9 46 fc fe       	call   38f9a0 <void spdlog::logger::info<unsigned long, unsigned long>(fmt::v11::fstring<unsigned long, unsigned long>::t, unsigned long&&, unsigned long&&)@plt>
 13cb2e7:	e9 a2 fe ff ff       	jmp    13cb18e <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x12e>
 13cb2ec:	0f 1f 40 00          	nopl   0x0(%rax)
 13cb2f0:	48 8b ab e8 00 00 00 	mov    0xe8(%rbx),%rbp
 13cb2f7:	4c 8d 6c 24 20       	lea    0x20(%rsp),%r13
 13cb2fc:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 13cb301:	4c 89 ef             	mov    %r13,%rdi
 13cb304:	e8 d7 71 fd fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13cb309:	4c 89 ea             	mov    %r13,%rdx
 13cb30c:	be 03 00 00 00       	mov    $0x3,%esi
 13cb311:	48 89 ef             	mov    %rbp,%rdi
 13cb314:	e8 a7 44 fc fe       	call   38f7c0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@plt>
 13cb319:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13cb31e:	48 85 ff             	test   %rdi,%rdi
 13cb321:	74 05                	je     13cb328 <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x2c8>
 13cb323:	e8 68 65 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb328:	48 8b bb b0 01 00 00 	mov    0x1b0(%rbx),%rdi
 13cb32f:	e8 2c 91 fd fe       	call   3a4460 <std::deque<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > >::pop_front()@plt>
 13cb334:	48 8b ab d0 00 00 00 	mov    0xd0(%rbx),%rbp
 13cb33b:	48 85 ed             	test   %rbp,%rbp
 13cb33e:	74 3b                	je     13cb37b <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x31b>
 13cb340:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13cb345:	48 8b 38             	mov    (%rax),%rdi
 13cb348:	e8 73 47 fc fe       	call   38fac0 <Isa::id() const@plt>
 13cb34d:	48 89 df             	mov    %rbx,%rdi
 13cb350:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 13cb355:	e8 76 49 fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13cb35a:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 13cb35f:	48 8d 35 02 2f 3b 00 	lea    0x3b2f02(%rip),%rsi        # 177e268 <_fini@@Base+0x27544>
 13cb366:	4d 89 e8             	mov    %r13,%r8
 13cb369:	ba 33 00 00 00       	mov    $0x33,%edx
 13cb36e:	48 89 ef             	mov    %rbp,%rdi
 13cb371:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13cb376:	e8 25 46 fc fe       	call   38f9a0 <void spdlog::logger::info<unsigned long, unsigned long>(fmt::v11::fstring<unsigned long, unsigned long>::t, unsigned long&&, unsigned long&&)@plt>
 13cb37b:	48 89 df             	mov    %rbx,%rdi
 13cb37e:	e8 4d 49 fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13cb383:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 13cb388:	48 8b 9b 88 02 00 00 	mov    0x288(%rbx),%rbx
 13cb38f:	83 c0 01             	add    $0x1,%eax
 13cb392:	4c 89 e6             	mov    %r12,%rsi
 13cb395:	4c 89 ef             	mov    %r13,%rdi
 13cb398:	89 82 a0 00 00 00    	mov    %eax,0xa0(%rdx)
 13cb39e:	e8 8d b5 fb fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13cb3a3:	4c 89 ee             	mov    %r13,%rsi
 13cb3a6:	48 89 df             	mov    %rbx,%rdi
 13cb3a9:	e8 12 99 fd fe       	call   3a4cc0 <TmQue<std::shared_ptr<RVecUop> >::push_back(std::shared_ptr<RVecUop>)@plt>
 13cb3ae:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13cb3b3:	48 85 ff             	test   %rdi,%rdi
 13cb3b6:	0f 84 10 fd ff ff    	je     13cb0cc <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x6c>
 13cb3bc:	e8 cf 64 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb3c1:	e9 06 fd ff ff       	jmp    13cb0cc <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x6c>
 13cb3c6:	e8 f5 a2 fc fe       	call   3956c0 <__stack_chk_fail@plt>
 13cb3cb:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13cb3d0:	48 89 c3             	mov    %rax,%rbx
 13cb3d3:	48 85 ff             	test   %rdi,%rdi
 13cb3d6:	74 05                	je     13cb3dd <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x37d>
 13cb3d8:	e8 b3 64 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb3dd:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 13cb3e2:	48 85 ff             	test   %rdi,%rdi
 13cb3e5:	74 05                	je     13cb3ec <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x38c>
 13cb3e7:	e8 a4 64 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb3ec:	48 89 df             	mov    %rbx,%rdi
 13cb3ef:	e8 8c 79 fd fe       	call   3a2d80 <_Unwind_Resume@plt>
 13cb3f4:	eb d5                	jmp    13cb3cb <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x36b>
 13cb3f6:	eb d3                	jmp    13cb3cb <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x36b>
 13cb3f8:	eb d1                	jmp    13cb3cb <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x36b>
 13cb3fa:	eb cf                	jmp    13cb3cb <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x36b>
 13cb3fc:	48 89 c3             	mov    %rax,%rbx
 13cb3ff:	eb dc                	jmp    13cb3dd <PemRVecGSU::on_gsu_intf_gather_bar(bool&)@@Base+0x37d>
 13cb401:	90                   	nop
 13cb402:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 13cb409:	00 00 00 00 
 13cb40d:	0f 1f 00             	nopl   (%rax)
