
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/x86_64-linux/simulator/bin/libcannsim_helper.so:     file format elf64-x86-64


Disassembly of section .text:

000000000003b1c0 <std::string::assign(std::string const&)@@Base+0x27370>:
   3b1c0:	41 57                	push   %r15
   3b1c2:	41 56                	push   %r14
   3b1c4:	41 55                	push   %r13
   3b1c6:	41 54                	push   %r12
   3b1c8:	55                   	push   %rbp
   3b1c9:	53                   	push   %rbx
   3b1ca:	48 89 fb             	mov    %rdi,%rbx
   3b1cd:	48 83 ec 28          	sub    $0x28,%rsp
   3b1d1:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   3b1d8:	00 00 
   3b1da:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   3b1df:	31 c0                	xor    %eax,%eax
   3b1e1:	e8 ea b0 fc ff       	call   62d0 <dlerror@plt>
   3b1e6:	48 8d 35 ab 7e 01 00 	lea    0x17eab(%rip),%rsi        # 53098 <rtKernelLaunch@@Base+0xbb88>
   3b1ed:	48 89 df             	mov    %rbx,%rdi
   3b1f0:	e8 3b b4 fc ff       	call   6630 <dlsym@plt>
   3b1f5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   3b1fa:	e8 d1 b0 fc ff       	call   62d0 <dlerror@plt>
   3b1ff:	48 85 c0             	test   %rax,%rax
   3b202:	0f 85 dc 01 00 00    	jne    3b3e4 <std::string::assign(std::string const&)@@Base+0x27594>
   3b208:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
   3b20e:	0f 84 c9 01 00 00    	je     3b3dd <std::string::assign(std::string const&)@@Base+0x2758d>
   3b214:	48 8d 35 7d 7e 01 00 	lea    0x17e7d(%rip),%rsi        # 53098 <rtKernelLaunch@@Base+0xbb88>
   3b21b:	48 8d 3d 85 7e 01 00 	lea    0x17e85(%rip),%rdi        # 530a7 <rtKernelLaunch@@Base+0xbb97>
   3b222:	31 c0                	xor    %eax,%eax
   3b224:	e8 37 9d fd ff       	call   14f60 <std::string::assign(std::string const&)@@Base+0x1110>
   3b229:	48 8d 54 24 08       	lea    0x8(%rsp),%rdx
   3b22e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   3b233:	b9 08 00 00 00       	mov    $0x8,%ecx
   3b238:	be 08 00 00 00       	mov    $0x8,%esi
   3b23d:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   3b244:	00 00 
   3b246:	e8 2f df 00 00       	call   4917a <rtKernelLaunch@@Base+0x1c6a>
   3b24b:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
   3b250:	e8 7b b0 fc ff       	call   62d0 <dlerror@plt>
   3b255:	48 8d 35 5c 7e 01 00 	lea    0x17e5c(%rip),%rsi        # 530b8 <rtKernelLaunch@@Base+0xbba8>
   3b25c:	48 89 df             	mov    %rbx,%rdi
   3b25f:	e8 cc b3 fc ff       	call   6630 <dlsym@plt>
   3b264:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   3b269:	e8 62 b0 fc ff       	call   62d0 <dlerror@plt>
   3b26e:	48 85 c0             	test   %rax,%rax
   3b271:	0f 85 4a 01 00 00    	jne    3b3c1 <std::string::assign(std::string const&)@@Base+0x27571>
   3b277:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
   3b27d:	0f 84 37 01 00 00    	je     3b3ba <std::string::assign(std::string const&)@@Base+0x2756a>
   3b283:	48 8d 35 2e 7e 01 00 	lea    0x17e2e(%rip),%rsi        # 530b8 <rtKernelLaunch@@Base+0xbba8>
   3b28a:	48 8d 3d 16 7e 01 00 	lea    0x17e16(%rip),%rdi        # 530a7 <rtKernelLaunch@@Base+0xbb97>
   3b291:	31 c0                	xor    %eax,%eax
   3b293:	e8 c8 9c fd ff       	call   14f60 <std::string::assign(std::string const&)@@Base+0x1110>
   3b298:	48 8d 54 24 08       	lea    0x8(%rsp),%rdx
   3b29d:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   3b2a2:	b9 08 00 00 00       	mov    $0x8,%ecx
   3b2a7:	be 08 00 00 00       	mov    $0x8,%esi
   3b2ac:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   3b2b3:	00 00 
   3b2b5:	e8 c0 de 00 00       	call   4917a <rtKernelLaunch@@Base+0x1c6a>
   3b2ba:	48 85 ed             	test   %rbp,%rbp
   3b2bd:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   3b2c2:	0f 84 3b 01 00 00    	je     3b403 <std::string::assign(std::string const&)@@Base+0x275b3>
   3b2c8:	4d 85 e4             	test   %r12,%r12
   3b2cb:	0f 84 32 01 00 00    	je     3b403 <std::string::assign(std::string const&)@@Base+0x275b3>
   3b2d1:	ba 02 00 00 00       	mov    $0x2,%edx
   3b2d6:	be 04 00 00 00       	mov    $0x4,%esi
   3b2db:	bf 06 00 00 00       	mov    $0x6,%edi
   3b2e0:	48 8d 1d 59 f1 02 00 	lea    0x2f159(%rip),%rbx        # 6a440 <rtKernelLaunch@@Base+0x22f30>
   3b2e7:	4c 8d 35 3a d4 01 00 	lea    0x1d43a(%rip),%r14        # 58728 <rtKernelLaunch@@Base+0x11218>
   3b2ee:	ff d5                	call   *%rbp
   3b2f0:	48 8d 3d d1 d3 01 00 	lea    0x1d3d1(%rip),%rdi        # 586c8 <rtKernelLaunch@@Base+0x111b8>
   3b2f7:	31 c0                	xor    %eax,%eax
   3b2f9:	4c 8d ab a0 00 00 00 	lea    0xa0(%rbx),%r13
   3b300:	31 ed                	xor    %ebp,%ebp
   3b302:	e8 59 9c fd ff       	call   14f60 <std::string::assign(std::string const&)@@Base+0x1110>
   3b307:	e8 d4 13 00 00       	call   3c6e0 <std::string::assign(std::string const&)@@Base+0x28890>
   3b30c:	48                   	rex.W
   3b30d:	8d                   	.byte 0x8d
   3b30e:	3d                   	.byte 0x3d
   3b30f:	ba                   	.byte 0xba
