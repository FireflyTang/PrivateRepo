
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000001533940 <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x690>:
 1533940:	24 50                	and    $0x50,%al
 1533942:	02 00                	add    (%rax),%al
 1533944:	00 48 8b             	add    %cl,-0x75(%rax)
 1533947:	7c 24                	jl     153396d <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x6bd>
 1533949:	28 e8                	sub    %ch,%al
 153394b:	01 dd                	add    %ebx,%ebp
 153394d:	e6 fe                	out    %al,$0xfe
 153394f:	48 8d 83 98 03 00 00 	lea    0x398(%rbx),%rax
 1533956:	48 8d 35 57 43 34 00 	lea    0x344357(%rip),%rsi        # 1877cb4 <typeinfo name for PemRvecValuTb_V310_1982_VALUINFO081_DAVIDV130@@Base+0x413d4>
 153395d:	ba 01 00 00 00       	mov    $0x1,%edx
 1533962:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 1533967:	48 8d 84 24 e0 01 00 	lea    0x1e0(%rsp),%rax
 153396e:	00 
 153396f:	48 89 c7             	mov    %rax,%rdi
 1533972:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 1533977:	e8 64 7b ff ff       	call   152b4e0 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x6d0>
 153397c:	48 8d ac 24 80 03 00 	lea    0x380(%rsp),%rbp
 1533983:	00 
 1533984:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
 1533989:	c7 84 24 80 03 00 00 	movl   $0x0,0x380(%rsp)
 1533990:	00 00 00 00 
 1533994:	48 8d 7d 08          	lea    0x8(%rbp),%rdi
 1533998:	e8 d3 68 e6 fe       	call   39a270 <std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> >::_Rb_tree(std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> > const&)@plt>
 153399d:	48 8d 84 24 10 02 00 	lea    0x210(%rsp),%rax
 15339a4:	00 
 15339a5:	4c 8d 25 f4 42 34 00 	lea    0x3442f4(%rip),%r12        # 1877ca0 <typeinfo name for PemRvecValuTb_V310_1982_VALUINFO081_DAVIDV130@@Base+0x413c0>
 15339ac:	c7 84 24 18 02 00 00 	movl   $0x0,0x218(%rsp)
 15339b3:	00 00 00 00 
 15339b7:	48 c7 84 24 20 02 00 	movq   $0x0,0x220(%rsp)
 15339be:	00 00 00 00 00 
 15339c3:	48 c7 84 24 38 02 00 	movq   $0x0,0x238(%rsp)
 15339ca:	00 00 00 00 00 
 15339cf:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 15339d4:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
 15339db:	00 
 15339dc:	4d 8d 6c 24 14       	lea    0x14(%r12),%r13
 15339e1:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
 15339e8:	00 
 15339e9:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
 15339f0:	00 
 15339f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 15339f8:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 15339fd:	4c 89 e2             	mov    %r12,%rdx
 1533a00:	48 8d 77 08          	lea    0x8(%rdi),%rsi
 1533a04:	e8 c7 72 ff ff       	call   152acd0 <PemRVecISU::exq1_busy()@@Base+0x80>
 1533a09:	49 83 c4 04          	add    $0x4,%r12
 1533a0d:	4d 39 ec             	cmp    %r13,%r12
 1533a10:	75 e6                	jne    15339f8 <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x748>
 1533a12:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 1533a17:	48 8d 7d 40          	lea    0x40(%rbp),%rdi
 1533a1b:	c7 84 24 b8 03 00 00 	movl   $0x2,0x3b8(%rsp)
 1533a22:	02 00 00 00 
 1533a26:	e8 45 68 e6 fe       	call   39a270 <std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> >::_Rb_tree(std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> > const&)@plt>
 1533a2b:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
 1533a30:	48 8d 35 59 42 34 00 	lea    0x344259(%rip),%rsi        # 1877c90 <typeinfo name for PemRvecValuTb_V310_1982_VALUINFO081_DAVIDV130@@Base+0x413b0>
 1533a37:	ba 03 00 00 00       	mov    $0x3,%edx
 1533a3c:	4c 89 ff             	mov    %r15,%rdi
 1533a3f:	e8 ac 78 ff ff       	call   152b2f0 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x4e0>
 1533a44:	48 8d 7d 78          	lea    0x78(%rbp),%rdi
 1533a48:	4c 89 fe             	mov    %r15,%rsi
 1533a4b:	c7 84 24 f0 03 00 00 	movl   $0x1,0x3f0(%rsp)
 1533a52:	01 00 00 00 
 1533a56:	e8 15 68 e6 fe       	call   39a270 <std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> >::_Rb_tree(std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> > const&)@plt>
 1533a5b:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
 1533a60:	48 8d 35 21 42 34 00 	lea    0x344221(%rip),%rsi        # 1877c88 <typeinfo name for PemRvecValuTb_V310_1982_VALUINFO081_DAVIDV130@@Base+0x413a8>
 1533a67:	ba 01 00 00 00       	mov    $0x1,%edx
 1533a6c:	4c 89 ff             	mov    %r15,%rdi
 1533a6f:	e8 6c 7a ff ff       	call   152b4e0 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x6d0>
 1533a74:	48 8d bd b0 00 00 00 	lea    0xb0(%rbp),%rdi
 1533a7b:	4c 89 fe             	mov    %r15,%rsi
 1533a7e:	c7 84 24 28 04 00 00 	movl   $0x3,0x428(%rsp)
 1533a85:	03 00 00 00 
 1533a89:	e8 e2 67 e6 fe       	call   39a270 <std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> >::_Rb_tree(std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> > const&)@plt>
 1533a8e:	4c 8b 7c 24 38       	mov    0x38(%rsp),%r15
 1533a93:	48 8d 35 ea 41 34 00 	lea    0x3441ea(%rip),%rsi        # 1877c84 <typeinfo name for PemRvecValuTb_V310_1982_VALUINFO081_DAVIDV130@@Base+0x413a4>
 1533a9a:	ba 01 00 00 00       	mov    $0x1,%edx
 1533a9f:	4c 89 ff             	mov    %r15,%rdi
 1533aa2:	e8 39 7a ff ff       	call   152b4e0 <PemRVecISU::init_bar_uop(IsuQueue, std::shared_ptr<RVecUop>&) const@@Base+0x6d0>
 1533aa7:	48 8d bd e8 00 00 00 	lea    0xe8(%rbp),%rdi
 1533aae:	4c 89 fe             	mov    %r15,%rsi
 1533ab1:	c7 84 24 60 04 00 00 	movl   $0x4,0x460(%rsp)
 1533ab8:	04 00 00 00 
 1533abc:	e8 af 67 e6 fe       	call   39a270 <std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> >::_Rb_tree(std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> > const&)@plt>
 1533ac1:	4c 8d b3 a0 03 00 00 	lea    0x3a0(%rbx),%r14
 1533ac8:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 1533acd:	c7 83 a0 03 00 00 00 	movl   $0x0,0x3a0(%rbx)
 1533ad4:	00 00 00 
 1533ad7:	48 c7 83 a8 03 00 00 	movq   $0x0,0x3a8(%rbx)
 1533ade:	00 00 00 00 
 1533ae2:	48 c7 83 c0 03 00 00 	movq   $0x0,0x3c0(%rbx)
 1533ae9:	00 00 00 00 
 1533aed:	48 89 ee             	mov    %rbp,%rsi
 1533af0:	4c 89 b3 b0 03 00 00 	mov    %r14,0x3b0(%rbx)
 1533af7:	4c 89 b3 b8 03 00 00 	mov    %r14,0x3b8(%rbx)
 1533afe:	e8 8d da e4 fe       	call   381590 <std::_Rb_tree<IsuQueue, std::pair<IsuQueue const, std::set<InfFromISU, std::less<InfFromISU>, std::allocator<InfFromISU> > >, std::_Select1st<std::pair<IsuQueue const, std::set<InfFromISU, std::less<InfFromISU>, std::allocator<InfFromISU> > > >, std::less<IsuQueue>, std::allocator<std::pair<IsuQueue const, std::set<InfFromISU, std::less<InfFromISU>, std::allocator<InfFromISU> > > > >::_M_get_insert_unique_pos(IsuQueue const&)@plt>
 1533b03:	48 85 d2             	test   %rdx,%rdx
 1533b06:	49 89 d4             	mov    %rdx,%r12
 1533b09:	74 56                	je     1533b61 <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x8b1>
 1533b0b:	48 85 c0             	test   %rax,%rax
 1533b0e:	41 0f 95 c7          	setne  %r15b
 1533b12:	49 39 d6             	cmp    %rdx,%r14
 1533b15:	40 0f 94 c7          	sete   %dil
 1533b19:	41 08 ff             	or     %dil,%r15b
 1533b1c:	0f 84 3e 0a 00 00    	je     1534560 <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x12b0>
 1533b22:	bf 58 00 00 00       	mov    $0x58,%edi
 1533b27:	e8 34 f7 e5 fe       	call   393260 <operator new(unsigned long)@plt>
 1533b2c:	49 89 c5             	mov    %rax,%r13
 1533b2f:	8b 84 24 80 03 00 00 	mov    0x380(%rsp),%eax
 1533b36:	48 8d 75 08          	lea    0x8(%rbp),%rsi
 1533b3a:	49 8d 7d 28          	lea    0x28(%r13),%rdi
 1533b3e:	41 89 45 20          	mov    %eax,0x20(%r13)
 1533b42:	e8 29 67 e6 fe       	call   39a270 <std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> >::_Rb_tree(std::_Rb_tree<InfFromISU, InfFromISU, std::_Identity<InfFromISU>, std::less<InfFromISU>, std::allocator<InfFromISU> > const&)@plt>
 1533b47:	41 0f b6 ff          	movzbl %r15b,%edi
 1533b4b:	4c 89 f1             	mov    %r14,%rcx
 1533b4e:	4c 89 e2             	mov    %r12,%rdx
 1533b51:	4c 89 ee             	mov    %r13,%rsi
 1533b54:	e8 d7 e5 e4 fe       	call   382130 <std::_Rb_tree_insert_and_rebalance(bool, std::_Rb_tree_node_base*, std::_Rb_tree_node_base*, std::_Rb_tree_node_base&)@plt>
 1533b59:	48 83 83 c0 03 00 00 	addq   $0x1,0x3c0(%rbx)
 1533b60:	01 
 1533b61:	48 83 bb c0 03 00 00 	cmpq   $0x0,0x3c0(%rbx)
 1533b68:	00 
 1533b69:	74 19                	je     1533b84 <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x8d4>
 1533b6b:	4c 8b a3 b8 03 00 00 	mov    0x3b8(%rbx),%r12
 1533b72:	8b 84 24 b8 03 00 00 	mov    0x3b8(%rsp),%eax
 1533b79:	41 39 44 24 20       	cmp    %eax,0x20(%r12)
 1533b7e:	0f 8c 21 08 00 00    	jl     15343a5 <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x10f5>
 1533b84:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 1533b89:	48 8d 75 38          	lea    0x38(%rbp),%rsi
 1533b8d:	e8 fe d9 e4 fe       	call   381590 <std::_Rb_tree<IsuQueue, std::pair<IsuQueue const, std::set<InfFromISU, std::less<InfFromISU>, std::allocator<InfFromISU> > >, std::_Select1st<std::pair<IsuQueue const, std::set<InfFromISU, std::less<InfFromISU>, std::allocator<InfFromISU> > > >, std::less<IsuQueue>, std::allocator<std::pair<IsuQueue const, std::set<InfFromISU, std::less<InfFromISU>, std::allocator<InfFromISU> > > > >::_M_get_insert_unique_pos(IsuQueue const&)@plt>
 1533b92:	48 85 d2             	test   %rdx,%rdx
 1533b95:	49 89 d4             	mov    %rdx,%r12
 1533b98:	0f 85 09 08 00 00    	jne    15343a7 <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x10f7>
 1533b9e:	48 83 bb c0 03 00 00 	cmpq   $0x0,0x3c0(%rbx)
 1533ba5:	00 
 1533ba6:	74 19                	je     1533bc1 <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x911>
 1533ba8:	4c 8b a3 b8 03 00 00 	mov    0x3b8(%rbx),%r12
 1533baf:	8b 84 24 f0 03 00 00 	mov    0x3f0(%rsp),%eax
 1533bb6:	41 39 44 24 20       	cmp    %eax,0x20(%r12)
 1533bbb:	0f 8c 87 07 00 00    	jl     1534348 <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x1098>
 1533bc1:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 1533bc6:	48 8d 75 70          	lea    0x70(%rbp),%rsi
 1533bca:	e8 c1 d9 e4 fe       	call   381590 <std::_Rb_tree<IsuQueue, std::pair<IsuQueue const, std::set<InfFromISU, std::less<InfFromISU>, std::allocator<InfFromISU> > >, std::_Select1st<std::pair<IsuQueue const, std::set<InfFromISU, std::less<InfFromISU>, std::allocator<InfFromISU> > > >, std::less<IsuQueue>, std::allocator<std::pair<IsuQueue const, std::set<InfFromISU, std::less<InfFromISU>, std::allocator<InfFromISU> > > > >::_M_get_insert_unique_pos(IsuQueue const&)@plt>
 1533bcf:	48 85 d2             	test   %rdx,%rdx
 1533bd2:	49 89 d4             	mov    %rdx,%r12
 1533bd5:	0f 85 6f 07 00 00    	jne    153434a <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x109a>
 1533bdb:	48 83 bb c0 03 00 00 	cmpq   $0x0,0x3c0(%rbx)
 1533be2:	00 
 1533be3:	74 19                	je     1533bfe <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x94e>
 1533be5:	4c 8b a3 b8 03 00 00 	mov    0x3b8(%rbx),%r12
 1533bec:	41 8b 44 24 20       	mov    0x20(%r12),%eax
 1533bf1:	39 84 24 28 04 00 00 	cmp    %eax,0x428(%rsp)
 1533bf8:	0f 8f ea 06 00 00    	jg     15342e8 <PemRVecISU::PemRVecISU(std::string const&, std::shared_ptr<tm_engine::TmClock> const&, std::shared_ptr<DvcConfig::Cfg> const&, std::shared_ptr<spdlog::logger> const&, unsigned int, unsigned int)@@Base+0x1038>
 1533bfe:	48                   	rex.W
 1533bff:	8b                   	.byte 0x8b
