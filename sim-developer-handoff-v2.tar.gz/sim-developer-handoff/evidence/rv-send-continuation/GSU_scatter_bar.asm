
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013cb410 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base>:
 13cb410:	41 55                	push   %r13
 13cb412:	41 54                	push   %r12
 13cb414:	49 89 f4             	mov    %rsi,%r12
 13cb417:	55                   	push   %rbp
 13cb418:	53                   	push   %rbx
 13cb419:	48 83 ec 48          	sub    $0x48,%rsp
 13cb41d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13cb424:	00 00 
 13cb426:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 13cb42b:	31 c0                	xor    %eax,%eax
 13cb42d:	48 8b 87 b0 01 00 00 	mov    0x1b0(%rdi),%rax
 13cb434:	48 8b 70 60          	mov    0x60(%rax),%rsi
 13cb438:	48 3b b0 80 00 00 00 	cmp    0x80(%rax),%rsi
 13cb43f:	74 47                	je     13cb488 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x78>
 13cb441:	48 8d 6c 24 10       	lea    0x10(%rsp),%rbp
 13cb446:	48 89 fb             	mov    %rdi,%rbx
 13cb449:	48 89 ef             	mov    %rbp,%rdi
 13cb44c:	e8 df b4 fb fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13cb451:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13cb456:	48 8b 38             	mov    (%rax),%rdi
 13cb459:	e8 42 94 fb fe       	call   3848a0 <Isa::name() const@plt>
 13cb45e:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 13cb463:	74 4b                	je     13cb4b0 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0xa0>
 13cb465:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13cb46a:	48 8b 38             	mov    (%rax),%rdi
 13cb46d:	e8 2e 94 fb fe       	call   3848a0 <Isa::name() const@plt>
 13cb472:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 13cb477:	74 57                	je     13cb4d0 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0xc0>
 13cb479:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 13cb47e:	48 85 ff             	test   %rdi,%rdi
 13cb481:	74 05                	je     13cb488 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x78>
 13cb483:	e8 08 64 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb488:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 13cb48d:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 13cb494:	00 00 
 13cb496:	0f 85 8e 01 00 00    	jne    13cb62a <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x21a>
 13cb49c:	48 83 c4 48          	add    $0x48,%rsp
 13cb4a0:	5b                   	pop    %rbx
 13cb4a1:	5d                   	pop    %rbp
 13cb4a2:	41 5c                	pop    %r12
 13cb4a4:	41 5d                	pop    %r13
 13cb4a6:	c3                   	ret
 13cb4a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 13cb4ae:	00 00 
 13cb4b0:	48 8b 05 d1 0a 7b 00 	mov    0x7b0ad1(%rip),%rax        # 1b7bf88 <stdout@GLIBC_2.2.5>
 13cb4b7:	48 8b 38             	mov    (%rax),%rdi
 13cb4ba:	e8 c1 b6 fc fe       	call   396b80 <fflush@plt>
 13cb4bf:	48 8b 05 ea 73 7b 00 	mov    0x7b73ea(%rip),%rax        # 1b828b0 <stderr@GLIBC_2.2.5>
 13cb4c6:	48 8b 38             	mov    (%rax),%rdi
 13cb4c9:	e8 b2 b6 fc fe       	call   396b80 <fflush@plt>
 13cb4ce:	eb 95                	jmp    13cb465 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x55>
 13cb4d0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13cb4d5:	48 8b bb e8 00 00 00 	mov    0xe8(%rbx),%rdi
 13cb4dc:	be 03 00 00 00       	mov    $0x3,%esi
 13cb4e1:	41 c6 04 24 01       	movb   $0x1,(%r12)
 13cb4e6:	48 8b 90 80 00 00 00 	mov    0x80(%rax),%rdx
 13cb4ed:	e8 ee bf fb fe       	call   3874e0 <PemRvecDepmgr::can_send_go(SMemBarUnit, unsigned long)@plt>
 13cb4f2:	84 c0                	test   %al,%al
 13cb4f4:	75 5a                	jne    13cb550 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x140>
 13cb4f6:	48 8b ab d0 00 00 00 	mov    0xd0(%rbx),%rbp
 13cb4fd:	48 85 ed             	test   %rbp,%rbp
 13cb500:	0f 84 73 ff ff ff    	je     13cb479 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x69>
 13cb506:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13cb50b:	48 8b 38             	mov    (%rax),%rdi
 13cb50e:	e8 ad 45 fc fe       	call   38fac0 <Isa::id() const@plt>
 13cb513:	48 89 df             	mov    %rbx,%rdi
 13cb516:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 13cb51b:	e8 b0 47 fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13cb520:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 13cb525:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
 13cb52a:	48 8d 35 df 2d 3b 00 	lea    0x3b2ddf(%rip),%rsi        # 177e310 <_fini@@Base+0x275ec>
 13cb531:	ba 36 00 00 00       	mov    $0x36,%edx
 13cb536:	48 89 ef             	mov    %rbp,%rdi
 13cb539:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13cb53e:	e8 5d 44 fc fe       	call   38f9a0 <void spdlog::logger::info<unsigned long, unsigned long>(fmt::v11::fstring<unsigned long, unsigned long>::t, unsigned long&&, unsigned long&&)@plt>
 13cb543:	e9 31 ff ff ff       	jmp    13cb479 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x69>
 13cb548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 13cb54f:	00 
 13cb550:	4c 8b ab e8 00 00 00 	mov    0xe8(%rbx),%r13
 13cb557:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
 13cb55c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 13cb561:	4c 89 e7             	mov    %r12,%rdi
 13cb564:	e8 77 6f fd fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13cb569:	4c 89 e2             	mov    %r12,%rdx
 13cb56c:	be 04 00 00 00       	mov    $0x4,%esi
 13cb571:	4c 89 ef             	mov    %r13,%rdi
 13cb574:	e8 47 42 fc fe       	call   38f7c0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@plt>
 13cb579:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13cb57e:	48 85 ff             	test   %rdi,%rdi
 13cb581:	74 05                	je     13cb588 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x178>
 13cb583:	e8 08 63 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb588:	48 8b 83 b0 01 00 00 	mov    0x1b0(%rbx),%rax
 13cb58f:	48 8d 78 50          	lea    0x50(%rax),%rdi
 13cb593:	e8 c8 8e fd fe       	call   3a4460 <std::deque<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > >::pop_front()@plt>
 13cb598:	48 89 df             	mov    %rbx,%rdi
 13cb59b:	e8 30 47 fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13cb5a0:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 13cb5a5:	4c 8b ab 88 02 00 00 	mov    0x288(%rbx),%r13
 13cb5ac:	83 c0 01             	add    $0x1,%eax
 13cb5af:	48 89 ee             	mov    %rbp,%rsi
 13cb5b2:	4c 89 e7             	mov    %r12,%rdi
 13cb5b5:	89 82 a0 00 00 00    	mov    %eax,0xa0(%rdx)
 13cb5bb:	e8 70 b3 fb fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13cb5c0:	4c 89 e6             	mov    %r12,%rsi
 13cb5c3:	4c 89 ef             	mov    %r13,%rdi
 13cb5c6:	e8 f5 96 fd fe       	call   3a4cc0 <TmQue<std::shared_ptr<RVecUop> >::push_back(std::shared_ptr<RVecUop>)@plt>
 13cb5cb:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13cb5d0:	48 85 ff             	test   %rdi,%rdi
 13cb5d3:	74 05                	je     13cb5da <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x1ca>
 13cb5d5:	e8 b6 62 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb5da:	48 8b ab d0 00 00 00 	mov    0xd0(%rbx),%rbp
 13cb5e1:	48 85 ed             	test   %rbp,%rbp
 13cb5e4:	0f 84 8f fe ff ff    	je     13cb479 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x69>
 13cb5ea:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13cb5ef:	48 8b 38             	mov    (%rax),%rdi
 13cb5f2:	e8 c9 44 fc fe       	call   38fac0 <Isa::id() const@plt>
 13cb5f7:	48 89 df             	mov    %rbx,%rdi
 13cb5fa:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 13cb5ff:	e8 cc 46 fc fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13cb604:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 13cb609:	48 8d 35 c8 2c 3b 00 	lea    0x3b2cc8(%rip),%rsi        # 177e2d8 <_fini@@Base+0x275b4>
 13cb610:	4d 89 e0             	mov    %r12,%r8
 13cb613:	ba 33 00 00 00       	mov    $0x33,%edx
 13cb618:	48 89 ef             	mov    %rbp,%rdi
 13cb61b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13cb620:	e8 7b 43 fc fe       	call   38f9a0 <void spdlog::logger::info<unsigned long, unsigned long>(fmt::v11::fstring<unsigned long, unsigned long>::t, unsigned long&&, unsigned long&&)@plt>
 13cb625:	e9 4f fe ff ff       	jmp    13cb479 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x69>
 13cb62a:	e8 91 a0 fc fe       	call   3956c0 <__stack_chk_fail@plt>
 13cb62f:	48 89 c3             	mov    %rax,%rbx
 13cb632:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 13cb637:	48 85 ff             	test   %rdi,%rdi
 13cb63a:	74 05                	je     13cb641 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x231>
 13cb63c:	e8 4f 62 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb641:	48 89 df             	mov    %rbx,%rdi
 13cb644:	e8 37 77 fd fe       	call   3a2d80 <_Unwind_Resume@plt>
 13cb649:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13cb64e:	48 89 c3             	mov    %rax,%rbx
 13cb651:	48 85 ff             	test   %rdi,%rdi
 13cb654:	74 dc                	je     13cb632 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x222>
 13cb656:	e8 35 62 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13cb65b:	eb d5                	jmp    13cb632 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x222>
 13cb65d:	eb ea                	jmp    13cb649 <PemRVecGSU::on_gsu_intf_scatter_bar(bool&)@@Base+0x239>
 13cb65f:	90                   	nop

00000000013cb660 <PemRVecGSU::rls_uwdb()@@Base>:
 13cb660:	41 54                	push   %r12
 13cb662:	55                   	push   %rbp
 13cb663:	53                   	push   %rbx
 13cb664:	48 89 fb             	mov    %rdi,%rbx
 13cb667:	48 83 ec 30          	sub    $0x30,%rsp
 13cb66b:	8b 8f f0 01 00 00    	mov    0x1f0(%rdi),%ecx
 13cb671:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13cb678:	00 00 
 13cb67a:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 13cb67f:	31                   	.byte 0x31
