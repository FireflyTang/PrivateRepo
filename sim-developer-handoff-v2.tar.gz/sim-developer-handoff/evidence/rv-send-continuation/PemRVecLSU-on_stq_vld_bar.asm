
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013fe750 <PemRVecLSU::on_stq_vld_bar()@@Base>:
 13fe750:	41 56                	push   %r14
 13fe752:	41 55                	push   %r13
 13fe754:	41 54                	push   %r12
 13fe756:	55                   	push   %rbp
 13fe757:	53                   	push   %rbx
 13fe758:	48 89 fb             	mov    %rdi,%rbx
 13fe75b:	48 83 ec 50          	sub    $0x50,%rsp
 13fe75f:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13fe766:	00 00 
 13fe768:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 13fe76d:	31 c0                	xor    %eax,%eax
 13fe76f:	48 8b 87 b0 00 00 00 	mov    0xb0(%rdi),%rax
 13fe776:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
 13fe77b:	48 8d 6c 24 20       	lea    0x20(%rsp),%rbp
 13fe780:	4c 89 e7             	mov    %r12,%rdi
 13fe783:	48 8b b0 f0 00 00 00 	mov    0xf0(%rax),%rsi
 13fe78a:	e8 01 ac f9 fe       	call   399390 <TmTGTPort<std::shared_ptr<RVecUop>, (FcType)0>::get_pld()@plt>
 13fe78f:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 13fe794:	48 89 ef             	mov    %rbp,%rdi
 13fe797:	e8 44 3d fa fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13fe79c:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 13fe7a1:	e8 fa 60 f8 fe       	call   3848a0 <Isa::name() const@plt>
 13fe7a6:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 13fe7ab:	0f 85 9f 00 00 00    	jne    13fe850 <PemRVecLSU::on_stq_vld_bar()@@Base+0x100>
 13fe7b1:	8b 83 e8 01 00 00    	mov    0x1e8(%rbx),%eax
 13fe7b7:	39 83 d8 01 00 00    	cmp    %eax,0x1d8(%rbx)
 13fe7bd:	0f 82 2d 01 00 00    	jb     13fe8f0 <PemRVecLSU::on_stq_vld_bar()@@Base+0x1a0>
 13fe7c3:	48 8b ab 60 01 00 00 	mov    0x160(%rbx),%rbp
 13fe7ca:	48 85 ed             	test   %rbp,%rbp
 13fe7cd:	74 3a                	je     13fe809 <PemRVecLSU::on_stq_vld_bar()@@Base+0xb9>
 13fe7cf:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 13fe7d4:	e8 e7 12 f9 fe       	call   38fac0 <Isa::id() const@plt>
 13fe7d9:	48 89 df             	mov    %rbx,%rdi
 13fe7dc:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 13fe7e1:	e8 ea 14 f9 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13fe7e6:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 13fe7eb:	4c 8d 44 24 30       	lea    0x30(%rsp),%r8
 13fe7f0:	48 8d 35 d9 04 38 00 	lea    0x3804d9(%rip),%rsi        # 177ecd0 <_fini@@Base+0x27fac>
 13fe7f7:	ba 37 00 00 00       	mov    $0x37,%edx
 13fe7fc:	48 89 ef             	mov    %rbp,%rdi
 13fe7ff:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13fe804:	e8 97 11 f9 fe       	call   38f9a0 <void spdlog::logger::info<unsigned long, unsigned long>(fmt::v11::fstring<unsigned long, unsigned long>::t, unsigned long&&, unsigned long&&)@plt>
 13fe809:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13fe80e:	48 85 ff             	test   %rdi,%rdi
 13fe811:	74 05                	je     13fe818 <PemRVecLSU::on_stq_vld_bar()@@Base+0xc8>
 13fe813:	e8 78 30 99 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13fe818:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 13fe81d:	48 85 ff             	test   %rdi,%rdi
 13fe820:	74 05                	je     13fe827 <PemRVecLSU::on_stq_vld_bar()@@Base+0xd7>
 13fe822:	e8 69 30 99 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13fe827:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
 13fe82c:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 13fe833:	00 00 
 13fe835:	0f 85 da 02 00 00    	jne    13feb15 <PemRVecLSU::on_stq_vld_bar()@@Base+0x3c5>
 13fe83b:	48 83 c4 50          	add    $0x50,%rsp
 13fe83f:	5b                   	pop    %rbx
 13fe840:	5d                   	pop    %rbp
 13fe841:	41 5c                	pop    %r12
 13fe843:	41 5d                	pop    %r13
 13fe845:	41 5e                	pop    %r14
 13fe847:	c3                   	ret
 13fe848:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 13fe84f:	00 
 13fe850:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 13fe855:	e8 46 60 f8 fe       	call   3848a0 <Isa::name() const@plt>
 13fe85a:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 13fe85f:	75 a8                	jne    13fe809 <PemRVecLSU::on_stq_vld_bar()@@Base+0xb9>
 13fe861:	8b 83 e8 01 00 00    	mov    0x1e8(%rbx),%eax
 13fe867:	39 83 d8 01 00 00    	cmp    %eax,0x1d8(%rbx)
 13fe86d:	0f 83 50 ff ff ff    	jae    13fe7c3 <PemRVecLSU::on_stq_vld_bar()@@Base+0x73>
 13fe873:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13fe878:	48 8b bb 40 02 00 00 	mov    0x240(%rbx),%rdi
 13fe87f:	be 02 00 00 00       	mov    $0x2,%esi
 13fe884:	48 8b 90 80 00 00 00 	mov    0x80(%rax),%rdx
 13fe88b:	e8 50 8c f8 fe       	call   3874e0 <PemRvecDepmgr::can_send_go(SMemBarUnit, unsigned long)@plt>
 13fe890:	84 c0                	test   %al,%al
 13fe892:	0f 85 e8 01 00 00    	jne    13fea80 <PemRVecLSU::on_stq_vld_bar()@@Base+0x330>
 13fe898:	48 8b ab 60 01 00 00 	mov    0x160(%rbx),%rbp
 13fe89f:	48 85 ed             	test   %rbp,%rbp
 13fe8a2:	0f 84 61 ff ff ff    	je     13fe809 <PemRVecLSU::on_stq_vld_bar()@@Base+0xb9>
 13fe8a8:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 13fe8ad:	e8 0e 12 f9 fe       	call   38fac0 <Isa::id() const@plt>
 13fe8b2:	48 89 df             	mov    %rbx,%rdi
 13fe8b5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 13fe8ba:	e8 11 14 f9 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13fe8bf:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 13fe8c4:	4c 8d 44 24 30       	lea    0x30(%rsp),%r8
 13fe8c9:	48 8d 35 a8 04 38 00 	lea    0x3804a8(%rip),%rsi        # 177ed78 <_fini@@Base+0x28054>
 13fe8d0:	ba 33 00 00 00       	mov    $0x33,%edx
 13fe8d5:	48 89 ef             	mov    %rbp,%rdi
 13fe8d8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13fe8dd:	e8 be 10 f9 fe       	call   38f9a0 <void spdlog::logger::info<unsigned long, unsigned long>(fmt::v11::fstring<unsigned long, unsigned long>::t, unsigned long&&, unsigned long&&)@plt>
 13fe8e2:	e9 22 ff ff ff       	jmp    13fe809 <PemRVecLSU::on_stq_vld_bar()@@Base+0xb9>
 13fe8e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 13fe8ee:	00 00 
 13fe8f0:	4c 8b b3 40 02 00 00 	mov    0x240(%rbx),%r14
 13fe8f7:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
 13fe8fc:	48 89 ee             	mov    %rbp,%rsi
 13fe8ff:	4c 89 ef             	mov    %r13,%rdi
 13fe902:	e8 d9 3b fa fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13fe907:	4c 89 ee             	mov    %r13,%rsi
 13fe90a:	4c 89 f7             	mov    %r14,%rdi
 13fe90d:	e8 0e e6 f9 fe       	call   39cf20 <PemRvecDepmgr::can_vst_vst_release(std::shared_ptr<Isa>)@plt>
 13fe912:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13fe917:	41 89 c6             	mov    %eax,%r14d
 13fe91a:	48 85 ff             	test   %rdi,%rdi
 13fe91d:	74 05                	je     13fe924 <PemRVecLSU::on_stq_vld_bar()@@Base+0x1d4>
 13fe91f:	e8 6c 2f 99 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13fe924:	45 84 f6             	test   %r14b,%r14b
 13fe927:	74 25                	je     13fe94e <PemRVecLSU::on_stq_vld_bar()@@Base+0x1fe>
 13fe929:	4c 89 e6             	mov    %r12,%rsi
 13fe92c:	4c 89 ef             	mov    %r13,%rdi
 13fe92f:	e8 fc 7f f8 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13fe934:	4c 89 ee             	mov    %r13,%rsi
 13fe937:	48 89 df             	mov    %rbx,%rdi
 13fe93a:	e8 c1 fb f8 fe       	call   38e500 <PemRVecLSU::stu_release_vst_vst(std::shared_ptr<RVecUop>)@plt>
 13fe93f:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13fe944:	48 85 ff             	test   %rdi,%rdi
 13fe947:	74 05                	je     13fe94e <PemRVecLSU::on_stq_vld_bar()@@Base+0x1fe>
 13fe949:	e8 42 2f 99 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13fe94e:	4c 8b b3 40 02 00 00 	mov    0x240(%rbx),%r14
 13fe955:	48 89 ee             	mov    %rbp,%rsi
 13fe958:	4c 89 ef             	mov    %r13,%rdi
 13fe95b:	e8 80 3b fa fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13fe960:	4c 89 ea             	mov    %r13,%rdx
 13fe963:	be 02 00 00 00       	mov    $0x2,%esi
 13fe968:	4c 89 f7             	mov    %r14,%rdi
 13fe96b:	e8 00 21 fa fe       	call   3a0a70 <PemRvecDepmgr::can_smem_bar_go(SMemBarUnit, std::shared_ptr<Isa>)@plt>
 13fe970:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13fe975:	41 89 c6             	mov    %eax,%r14d
 13fe978:	48 85 ff             	test   %rdi,%rdi
 13fe97b:	74 05                	je     13fe982 <PemRVecLSU::on_stq_vld_bar()@@Base+0x232>
 13fe97d:	e8 0e 2f 99 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13fe982:	45 84 f6             	test   %r14b,%r14b
 13fe985:	75 51                	jne    13fe9d8 <PemRVecLSU::on_stq_vld_bar()@@Base+0x288>
 13fe987:	48 8b ab 60 01 00 00 	mov    0x160(%rbx),%rbp
 13fe98e:	48 85 ed             	test   %rbp,%rbp
 13fe991:	0f 84 72 fe ff ff    	je     13fe809 <PemRVecLSU::on_stq_vld_bar()@@Base+0xb9>
 13fe997:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 13fe99c:	e8 1f 11 f9 fe       	call   38fac0 <Isa::id() const@plt>
 13fe9a1:	48 89 df             	mov    %rbx,%rdi
 13fe9a4:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 13fe9a9:	e8 22 13 f9 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13fe9ae:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 13fe9b3:	48 8d 35 16 03 38 00 	lea    0x380316(%rip),%rsi        # 177ecd0 <_fini@@Base+0x27fac>
 13fe9ba:	4d 89 e8             	mov    %r13,%r8
 13fe9bd:	ba 37 00 00 00       	mov    $0x37,%edx
 13fe9c2:	48 89 ef             	mov    %rbp,%rdi
 13fe9c5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13fe9ca:	e8 d1 0f f9 fe       	call   38f9a0 <void spdlog::logger::info<unsigned long, unsigned long>(fmt::v11::fstring<unsigned long, unsigned long>::t, unsigned long&&, unsigned long&&)@plt>
 13fe9cf:	e9 35 fe ff ff       	jmp    13fe809 <PemRVecLSU::on_stq_vld_bar()@@Base+0xb9>
 13fe9d4:	0f 1f 40 00          	nopl   0x0(%rax)
 13fe9d8:	4c 8b b3 40 02 00 00 	mov    0x240(%rbx),%r14
 13fe9df:	48 89 ee             	mov    %rbp,%rsi
 13fe9e2:	4c 89 ef             	mov    %r13,%rdi
 13fe9e5:	e8 f6 3a fa fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13fe9ea:	4c 89 ea             	mov    %r13,%rdx
 13fe9ed:	be 02 00 00 00       	mov    $0x2,%esi
 13fe9f2:	4c 89 f7             	mov    %r14,%rdi
 13fe9f5:	e8 f6 f6 f8 fe       	call   38e0f0 <PemRvecDepmgr::smem_bar_update(SMemBarUnit, std::shared_ptr<Isa>)@plt>
 13fe9fa:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13fe9ff:	48 85 ff             	test   %rdi,%rdi
 13fea02:	74 05                	je     13fea09 <PemRVecLSU::on_stq_vld_bar()@@Base+0x2b9>
 13fea04:	e8 87 2e 99 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13fea09:	48 8b ab 60 01 00 00 	mov    0x160(%rbx),%rbp
 13fea10:	48 85 ed             	test   %rbp,%rbp
 13fea13:	74 38                	je     13fea4d <PemRVecLSU::on_stq_vld_bar()@@Base+0x2fd>
 13fea15:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 13fea1a:	e8 a1 10 f9 fe       	call   38fac0 <Isa::id() const@plt>
 13fea1f:	48 89 df             	mov    %rbx,%rdi
 13fea22:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 13fea27:	e8 a4 12 f9 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13fea2c:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 13fea31:	48 8d 35 d0 02 38 00 	lea    0x3802d0(%rip),%rsi        # 177ed08 <_fini@@Base+0x27fe4>
 13fea38:	4d 89 e8             	mov    %r13,%r8
 13fea3b:	ba 34 00 00 00       	mov    $0x34,%edx
 13fea40:	48 89 ef             	mov    %rbp,%rdi
 13fea43:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13fea48:	e8 53 0f f9 fe       	call   38f9a0 <void spdlog::logger::info<unsigned long, unsigned long>(fmt::v11::fstring<unsigned long, unsigned long>::t, unsigned long&&, unsigned long&&)@plt>
 13fea4d:	4c 89 e6             	mov    %r12,%rsi
 13fea50:	4c 89 ef             	mov    %r13,%rdi
 13fea53:	e8 d8 7e f8 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13fea58:	4c 89 ee             	mov    %r13,%rsi
 13fea5b:	48 89 df             	mov    %rbx,%rdi
 13fea5e:	e8 bd ac f8 fe       	call   389720 <PemRVecLSU::stu_retire_bar_instr(std::shared_ptr<RVecUop>)@plt>
 13fea63:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13fea68:	48 85 ff             	test   %rdi,%rdi
 13fea6b:	0f 84 98 fd ff ff    	je     13fe809 <PemRVecLSU::on_stq_vld_bar()@@Base+0xb9>
 13fea71:	e8 1a 2e 99 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13fea76:	e9 8e fd ff ff       	jmp    13fe809 <PemRVecLSU::on_stq_vld_bar()@@Base+0xb9>
 13fea7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 13fea80:	4c 8b b3 40 02 00 00 	mov    0x240(%rbx),%r14
 13fea87:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
 13fea8c:	48 89 ee             	mov    %rbp,%rsi
 13fea8f:	4c 89 ef             	mov    %r13,%rdi
 13fea92:	e8 49 3a fa fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13fea97:	4c 89 ea             	mov    %r13,%rdx
 13fea9a:	be 02 00 00 00       	mov    $0x2,%esi
 13fea9f:	4c 89 f7             	mov    %r14,%rdi
 13feaa2:	e8 19 0d f9 fe       	call   38f7c0 <PemRvecDepmgr::send_update(SMemBarUnit, std::shared_ptr<Isa>)@plt>
 13feaa7:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13feaac:	48 85 ff             	test   %rdi,%rdi
 13feaaf:	74 05                	je     13feab6 <PemRVecLSU::on_stq_vld_bar()@@Base+0x366>
 13feab1:	e8 da 2d 99 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13feab6:	48 8b ab 60 01 00 00 	mov    0x160(%rbx),%rbp
 13feabd:	48 85 ed             	test   %rbp,%rbp
 13feac0:	74 38                	je     13feafa <PemRVecLSU::on_stq_vld_bar()@@Base+0x3aa>
 13feac2:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 13feac7:	e8 f4 0f f9 fe       	call   38fac0 <Isa::id() const@plt>
 13feacc:	48 89 df             	mov    %rbx,%rdi
 13feacf:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 13fead4:	e8 f7 11 f9 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13fead9:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 13feade:	48 8d 35 5b 02 38 00 	lea    0x38025b(%rip),%rsi        # 177ed40 <_fini@@Base+0x2801c>
 13feae5:	4d 89 e8             	mov    %r13,%r8
 13feae8:	ba 30 00 00 00       	mov    $0x30,%edx
 13feaed:	48 89 ef             	mov    %rbp,%rdi
 13feaf0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13feaf5:	e8 a6 0e f9 fe       	call   38f9a0 <void spdlog::logger::info<unsigned long, unsigned long>(fmt::v11::fstring<unsigned long, unsigned long>::t, unsigned long&&, unsigned long&&)@plt>
 13feafa:	4c 89 e6             	mov    %r12,%rsi
 13feafd:	4c 89 ef             	mov    %r13,%rdi
 13feb00:	e8 2b 7e f8 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13feb05:	4c 89 ee             	mov    %r13,%rsi
 13feb08:	48 89 df             	mov    %rbx,%rdi
 13feb0b:	e8 10 ac f8 fe       	call   389720 <PemRVecLSU::stu_retire_bar_instr(std::shared_ptr<RVecUop>)@plt>
 13feb10:	e9 4e ff ff ff       	jmp    13fea63 <PemRVecLSU::on_stq_vld_bar()@@Base+0x313>
 13feb15:	e8 a6 6b f9 fe       	call   3956c0 <__stack_chk_fail@plt>
 13feb1a:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13feb1f:	48 89 c3             	mov    %rax,%rbx
 13feb22:	48 85 ff             	test   %rdi,%rdi
 13feb25:	74 05                	je     13feb2c <PemRVecLSU::on_stq_vld_bar()@@Base+0x3dc>
 13feb27:	e8 64 2d 99 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13feb2c:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13feb31:	48 85 ff             	test   %rdi,%rdi
 13feb34:	74 05                	je     13feb3b <PemRVecLSU::on_stq_vld_bar()@@Base+0x3eb>
 13feb36:	e8 55 2d 99 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13feb3b:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 13feb40:	48 85 ff             	test   %rdi,%rdi
 13feb43:	74 05                	je     13feb4a <PemRVecLSU::on_stq_vld_bar()@@Base+0x3fa>
 13feb45:	e8 46 2d 99 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13feb4a:	48 89 df             	mov    %rbx,%rdi
 13feb4d:	e8 2e 42 fa fe       	call   3a2d80 <_Unwind_Resume@plt>
 13feb52:	eb c6                	jmp    13feb1a <PemRVecLSU::on_stq_vld_bar()@@Base+0x3ca>
 13feb54:	eb c4                	jmp    13feb1a <PemRVecLSU::on_stq_vld_bar()@@Base+0x3ca>
 13feb56:	eb c2                	jmp    13feb1a <PemRVecLSU::on_stq_vld_bar()@@Base+0x3ca>
 13feb58:	eb c0                	jmp    13feb1a <PemRVecLSU::on_stq_vld_bar()@@Base+0x3ca>
 13feb5a:	eb be                	jmp    13feb1a <PemRVecLSU::on_stq_vld_bar()@@Base+0x3ca>
 13feb5c:	48 89 c3             	mov    %rax,%rbx
 13feb5f:	eb cb                	jmp    13feb2c <PemRVecLSU::on_stq_vld_bar()@@Base+0x3dc>
 13feb61:	eb b7                	jmp    13feb1a <PemRVecLSU::on_stq_vld_bar()@@Base+0x3ca>
 13feb63:	90                   	nop
 13feb64:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 13feb6b:	00 00 00 00 
 13feb6f:	90                   	nop
