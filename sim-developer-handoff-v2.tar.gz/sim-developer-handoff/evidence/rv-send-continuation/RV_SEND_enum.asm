
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000f905b0 <IsaDefine::IsaDefine()@@Base+0x4a40>:
  f905b0:	7c 00                	jl     f905b2 <IsaDefine::IsaDefine()@@Base+0x4a42>
  f905b2:	e8 f9 2e 41 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  f905b7:	48 8d 94 24 ca 03 00 	lea    0x3ca(%rsp),%rdx
  f905be:	00 
  f905bf:	48 8d bb e0 0f 00 00 	lea    0xfe0(%rbx),%rdi
  f905c6:	48 8d 35 03 e0 7c 00 	lea    0x7ce003(%rip),%rsi        # 175e5d0 <_fini@@Base+0x78ac>
  f905cd:	e8 de 2e 41 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  f905d2:	48 8d 94 24 cb 03 00 	lea    0x3cb(%rsp),%rdx
  f905d9:	00 
  f905da:	48 8d bb e8 0f 00 00 	lea    0xfe8(%rbx),%rdi
  f905e1:	48 8d 35 f1 df 7c 00 	lea    0x7cdff1(%rip),%rsi        # 175e5d9 <_fini@@Base+0x78b5>
  f905e8:	e8 c3 2e 41 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  f905ed:	48 8d 94 24 cc 03 00 	lea    0x3cc(%rsp),%rdx
  f905f4:	00 
  f905f5:	48 8d bb f0 0f 00 00 	lea    0xff0(%rbx),%rdi
  f905fc:	48 8d 35 de df 7c 00 	lea    0x7cdfde(%rip),%rsi        # 175e5e1 <_fini@@Base+0x78bd>
  f90603:	e8 a8 2e 41 ff       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
  f90608:	48 8d 94 24 cd 03 00 	lea    0x3cd(%rsp),%rdx
  f9060f:	00 
