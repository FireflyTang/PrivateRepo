
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013c2a9e <PemRVecExu::recv_inf_instr(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >&, std::unordered_map<unsigned long, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > >, std::hash<unsigned long>, std::equal_to<unsigned long>, std::allocator<std::pair<unsigned long const, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > > > > >&, unsigned int, std::shared_ptr<PemRvecExuElements>)@@Base+0xd5e>:
 13c2a9e:	49 8b 95 80 00 00 00 	mov    0x80(%r13),%rdx
 13c2aa5:	be 05 00 00 00       	mov    $0x5,%esi
 13c2aaa:	e8 31 4a fc fe       	call   3874e0 <PemRvecDepmgr::can_send_go(SMemBarUnit, unsigned long)@plt>
 13c2aaf:	84 c0                	test   %al,%al
 13c2ab1:	75 16                	jne    13c2ac9 <PemRVecExu::recv_inf_instr(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >&, std::unordered_map<unsigned long, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > >, std::hash<unsigned long>, std::equal_to<unsigned long>, std::allocator<std::pair<unsigned long const, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > > > > >&, unsigned int, std::shared_ptr<PemRvecExuElements>)@@Base+0xd89>
 13c2ab3:	4d 85 e4             	test   %r12,%r12
 13c2ab6:	0f 84 13 f3 ff ff    	je     13c1dcf <PemRVecExu::recv_inf_instr(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >&, std::unordered_map<unsigned long, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > >, std::hash<unsigned long>, std::equal_to<unsigned long>, std::allocator<std::pair<unsigned long const, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > > > > >&, unsigned int, std::shared_ptr<PemRvecExuElements>)@@Base+0x8f>
 13c2abc:	4c 89 e7             	mov    %r12,%rdi
 13c2abf:	e8 cc ed 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c2ac4:	e9 06 f3 ff ff       	jmp    13c1dcf <PemRVecExu::recv_inf_instr(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >&, std::unordered_map<unsigned long, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > >, std::hash<unsigned long>, std::equal_to<unsigned long>, std::allocator<std::pair<unsigned long const, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > > > > >&, unsigned int, std::shared_ptr<PemRvecExuElements>)@@Base+0x8f>
 13c2ac9:	49 8b 07             	mov    (%r15),%rax
 13c2acc:	48 8d 4c 24 70       	lea    0x70(%rsp),%rcx
 13c2ad1:	48 89 cf             	mov    %rcx,%rdi
 13c2ad4:	49 89 cf             	mov    %rcx,%r15
 13c2ad7:	48 8b b0 f0 00 00 00 	mov    0xf0(%rax),%rsi
 13c2ade:	e8 8d c3 fc fe       	call   38ee70 <TmTGTPort<std::shared_ptr<RVecUop>, (FcType)0>::pop_pld()@plt>
 13c2ae3:	8b 54 24 34          	mov    0x34(%rsp),%edx
 13c2ae7:	4c 89 fe             	mov    %r15,%rsi
 13c2aea:	48 89 df             	mov    %rbx,%rdi
 13c2aed:	e8 1e 24 fe fe       	call   3a4f10 <PemRVecExu::send_done(std::shared_ptr<RVecUop>, unsigned int)@plt>
 13c2af2:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
 13c2af7:	48 85 ff             	test   %rdi,%rdi
 13c2afa:	74 b7                	je     13c2ab3 <PemRVecExu::recv_inf_instr(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >&, std::unordered_map<unsigned long, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > >, std::hash<unsigned long>, std::equal_to<unsigned long>, std::allocator<std::pair<unsigned long const, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > > > > >&, unsigned int, std::shared_ptr<PemRvecExuElements>)@@Base+0xd73>
 13c2afc:	e8 8f ed 9c ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13c2b01:	eb b0                	jmp    13c2ab3 <PemRVecExu::recv_inf_instr(std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >&, std::unordered_map<unsigned long, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > >, std::hash<unsigned long>, std::equal_to<unsigned long>, std::allocator<std::pair<unsigned long const, std::vector<std::shared_ptr<RVecUop>, std::allocator<std::shared_ptr<RVecUop> > > > > >&, unsigned int, std::shared_ptr<PemRvecExuElements>)@@Base+0xd73>
