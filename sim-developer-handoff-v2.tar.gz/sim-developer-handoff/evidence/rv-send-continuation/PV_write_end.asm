
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

000000000146fc40 <RvecPV::run_ca_write_result_from_isa_to_reg(std::shared_ptr<Isa>&)@@Base>:
 146fc40:	41 54                	push   %r12
 146fc42:	55                   	push   %rbp
 146fc43:	48 89 f5             	mov    %rsi,%rbp
 146fc46:	53                   	push   %rbx
 146fc47:	48 89 fb             	mov    %rdi,%rbx
 146fc4a:	48 83 ec 20          	sub    $0x20,%rsp
 146fc4e:	49 89 e4             	mov    %rsp,%r12
 146fc51:	4c 89 e7             	mov    %r12,%rdi
 146fc54:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 146fc5b:	00 00 
 146fc5d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 146fc62:	31 c0                	xor    %eax,%eax
 146fc64:	e8 77 28 f3 fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 146fc69:	4c 89 e6             	mov    %r12,%rsi
 146fc6c:	48 89 df             	mov    %rbx,%rdi
 146fc6f:	e8 dc 3f f2 fe       	call   393c50 <RvecPV::write_regfile(std::shared_ptr<Isa>)@plt>
 146fc74:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 146fc79:	48 85 ff             	test   %rdi,%rdi
 146fc7c:	74 05                	je     146fc83 <RvecPV::run_ca_write_result_from_isa_to_reg(std::shared_ptr<Isa>&)@@Base+0x43>
 146fc7e:	e8 0d 1c 92 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 146fc83:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
 146fc87:	e8 94 50 f3 fe       	call   3a4d20 <Isa::update_exec_descr()@plt>
 146fc8c:	48 8b 6d 00          	mov    0x0(%rbp),%rbp
 146fc90:	48 89 ef             	mov    %rbp,%rdi
 146fc93:	e8 d8 ab f1 fe       	call   38a870 <Isa::pc() const@plt>
 146fc98:	48 89 df             	mov    %rbx,%rdi
 146fc9b:	49 89 c4             	mov    %rax,%r12
 146fc9e:	e8 2d 00 f2 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 146fca3:	48 8d 4d 10          	lea    0x10(%rbp),%rcx
 146fca7:	48 83 ec 08          	sub    $0x8,%rsp
 146fcab:	8b b3 94 00 00 00    	mov    0x94(%rbx),%esi
 146fcb1:	8b bb 90 00 00 00    	mov    0x90(%rbx),%edi
 146fcb7:	48 8d 93 c8 00 00 00 	lea    0xc8(%rbx),%rdx
 146fcbe:	4c 8d 4d 08          	lea    0x8(%rbp),%r9
 146fcc2:	51                   	push   %rcx
 146fcc3:	4d 89 e0             	mov    %r12,%r8
 146fcc6:	48 89 c1             	mov    %rax,%rcx
 146fcc9:	e8 d2 60 f2 fe       	call   395da0 <pem_log::dump_instr_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@plt>
 146fcce:	58                   	pop    %rax
 146fccf:	5a                   	pop    %rdx
 146fcd0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 146fcd5:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 146fcdc:	00 00 
 146fcde:	75 09                	jne    146fce9 <RvecPV::run_ca_write_result_from_isa_to_reg(std::shared_ptr<Isa>&)@@Base+0xa9>
 146fce0:	48 83 c4 20          	add    $0x20,%rsp
 146fce4:	5b                   	pop    %rbx
 146fce5:	5d                   	pop    %rbp
 146fce6:	41 5c                	pop    %r12
 146fce8:	c3                   	ret
 146fce9:	e8 d2 59 f2 fe       	call   3956c0 <__stack_chk_fail@plt>
 146fcee:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 146fcf3:	48 89 c3             	mov    %rax,%rbx
 146fcf6:	48 85 ff             	test   %rdi,%rdi
 146fcf9:	74 05                	je     146fd00 <RvecPV::run_ca_write_result_from_isa_to_reg(std::shared_ptr<Isa>&)@@Base+0xc0>
 146fcfb:	e8 90 1b 92 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 146fd00:	48 89 df             	mov    %rbx,%rdi
 146fd03:	e8 78 30 f3 fe       	call   3a2d80 <_Unwind_Resume@plt>
 146fd08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 146fd0f:	00 
