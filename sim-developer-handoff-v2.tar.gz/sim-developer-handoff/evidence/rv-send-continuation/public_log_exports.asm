
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000e798e0 <DvcSetLogLevel@@Base>:
  e798e0:	e9 fb 8e 51 ff       	jmp    3927e0 <pem_log::set_log_level(unsigned int, unsigned int, unsigned int)@plt>
  e798e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  e798ec:	00 00 00 00 

0000000000e798f0 <DvcSetLogRotation@@Base>:
  e798f0:	e9 fb d5 50 ff       	jmp    386ef0 <pem_log::set_rotation(unsigned long, unsigned int)@plt>
  e798f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  e798fc:	00 00 00 00 

0000000000e79900 <DvcAttachLogCallback@@Base>:
  e79900:	e9 2b 47 52 ff       	jmp    39e030 <pem_log::attach_log_cb(DvcLogType, DvcLogCbFnUnion)@plt>
