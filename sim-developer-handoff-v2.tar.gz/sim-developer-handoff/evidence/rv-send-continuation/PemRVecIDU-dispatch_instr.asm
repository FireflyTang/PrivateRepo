
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013ec660 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base>:
 13ec660:	41 57                	push   %r15
 13ec662:	41 56                	push   %r14
 13ec664:	49 89 cf             	mov    %rcx,%r15
 13ec667:	41 55                	push   %r13
 13ec669:	41 54                	push   %r12
 13ec66b:	49 89 f4             	mov    %rsi,%r12
 13ec66e:	55                   	push   %rbp
 13ec66f:	53                   	push   %rbx
 13ec670:	48 89 fd             	mov    %rdi,%rbp
 13ec673:	48 89 d3             	mov    %rdx,%rbx
 13ec676:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
 13ec67d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13ec684:	00 00 
 13ec686:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
 13ec68d:	00 
 13ec68e:	31 c0                	xor    %eax,%eax
 13ec690:	e8 5b 13 fb fe       	call   39d9f0 <PemRVecIDU::can_dispatch(std::shared_ptr<Isa> const&)@plt>
 13ec695:	84 c0                	test   %al,%al
 13ec697:	75 5f                	jne    13ec6f8 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x98>
 13ec699:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
 13ec69e:	4c 89 e6             	mov    %r12,%rsi
 13ec6a1:	41 89 c6             	mov    %eax,%r14d
 13ec6a4:	4c 89 ef             	mov    %r13,%rdi
 13ec6a7:	e8 34 5e fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ec6ac:	48 89 da             	mov    %rbx,%rdx
 13ec6af:	4c 89 ee             	mov    %r13,%rsi
 13ec6b2:	48 89 ef             	mov    %rbp,%rdi
 13ec6b5:	e8 e6 dc f9 fe       	call   38a3a0 <PemRVecIDU::log_dispatch_failed(std::shared_ptr<Isa>, unsigned int&)@plt>
 13ec6ba:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13ec6bf:	48 85 ff             	test   %rdi,%rdi
 13ec6c2:	74 05                	je     13ec6c9 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x69>
 13ec6c4:	e8 c7 51 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ec6c9:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
 13ec6d0:	00 
 13ec6d1:	64 48 33 0c 25 28 00 	xor    %fs:0x28,%rcx
 13ec6d8:	00 00 
 13ec6da:	44 89 f0             	mov    %r14d,%eax
 13ec6dd:	0f 85 b9 02 00 00    	jne    13ec99c <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x33c>
 13ec6e3:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
 13ec6ea:	5b                   	pop    %rbx
 13ec6eb:	5d                   	pop    %rbp
 13ec6ec:	41 5c                	pop    %r12
 13ec6ee:	41 5d                	pop    %r13
 13ec6f0:	41 5e                	pop    %r14
 13ec6f2:	41 5f                	pop    %r15
 13ec6f4:	c3                   	ret
 13ec6f5:	0f 1f 00             	nopl   (%rax)
 13ec6f8:	49 8b 3c 24          	mov    (%r12),%rdi
 13ec6fc:	e8 6f 08 fa fe       	call   38cf70 <Isa::pipe() const@plt>
 13ec701:	83 f8 0e             	cmp    $0xe,%eax
 13ec704:	0f 84 f6 01 00 00    	je     13ec900 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x2a0>
 13ec70a:	0f 8f 58 01 00 00    	jg     13ec868 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x208>
 13ec710:	83 f8 0d             	cmp    $0xd,%eax
 13ec713:	0f 85 58 01 00 00    	jne    13ec871 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x211>
 13ec719:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
 13ec71e:	4c 89 e6             	mov    %r12,%rsi
 13ec721:	4c 89 ef             	mov    %r13,%rdi
 13ec724:	e8 b7 5d fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ec729:	8b 33                	mov    (%rbx),%esi
 13ec72b:	4c 89 f9             	mov    %r15,%rcx
 13ec72e:	4c 89 ea             	mov    %r13,%rdx
 13ec731:	48 89 ef             	mov    %rbp,%rdi
 13ec734:	e8 47 18 fa fe       	call   38df80 <PemRVecIDU::do_dispatch_pipe_ld_st_ex_lp(unsigned int, std::shared_ptr<Isa>, bool&)@plt>
 13ec739:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13ec73e:	48 85 ff             	test   %rdi,%rdi
 13ec741:	74 05                	je     13ec748 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xe8>
 13ec743:	e8 48 51 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ec748:	45 0f b6 37          	movzbl (%r15),%r14d
 13ec74c:	45 84 f6             	test   %r14b,%r14b
 13ec74f:	0f 84 88 01 00 00    	je     13ec8dd <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x27d>
 13ec755:	48 8b 9d 58 02 00 00 	mov    0x258(%rbp),%rbx
 13ec75c:	4c 8b bd 60 02 00 00 	mov    0x260(%rbp),%r15
 13ec763:	49 39 df             	cmp    %rbx,%r15
 13ec766:	0f 84 5d ff ff ff    	je     13ec6c9 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x69>
 13ec76c:	48 83 3d 5c 7c 79 00 	cmpq   $0x0,0x797c5c(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 13ec773:	00 
 13ec774:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
 13ec779:	0f 85 7e 00 00 00    	jne    13ec7fd <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x19d>
 13ec77f:	90                   	nop
 13ec780:	48 8b 6b 08          	mov    0x8(%rbx),%rbp
 13ec784:	48 8b 03             	mov    (%rbx),%rax
 13ec787:	48 85 ed             	test   %rbp,%rbp
 13ec78a:	74 04                	je     13ec790 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x130>
 13ec78c:	83 45 08 01          	addl   $0x1,0x8(%rbp)
 13ec790:	48 8b 10             	mov    (%rax),%rdx
 13ec793:	4c 89 e6             	mov    %r12,%rsi
 13ec796:	4c 89 ef             	mov    %r13,%rdi
 13ec799:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13ec79e:	48 8b 52 20          	mov    0x20(%rdx),%rdx
 13ec7a2:	48 89 14 24          	mov    %rdx,(%rsp)
 13ec7a6:	e8 35 5d fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ec7ab:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 13ec7b0:	4c 89 ee             	mov    %r13,%rsi
 13ec7b3:	48 8b 14 24          	mov    (%rsp),%rdx
 13ec7b7:	48 89 c7             	mov    %rax,%rdi
 13ec7ba:	ff d2                	call   *%rdx
 13ec7bc:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13ec7c1:	48 85 ff             	test   %rdi,%rdi
 13ec7c4:	74 05                	je     13ec7cb <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x16b>
 13ec7c6:	e8 c5 50 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ec7cb:	48 85 ed             	test   %rbp,%rbp
 13ec7ce:	0f 84 44 01 00 00    	je     13ec918 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x2b8>
 13ec7d4:	48 89 ef             	mov    %rbp,%rdi
 13ec7d7:	48 83 c3 10          	add    $0x10,%rbx
 13ec7db:	e8 b0 50 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ec7e0:	49 39 df             	cmp    %rbx,%r15
 13ec7e3:	75 9b                	jne    13ec780 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x120>
 13ec7e5:	e9 df fe ff ff       	jmp    13ec6c9 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x69>
 13ec7ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13ec7f0:	48 83 c3 10          	add    $0x10,%rbx
 13ec7f4:	49 39 df             	cmp    %rbx,%r15
 13ec7f7:	0f 84 cc fe ff ff    	je     13ec6c9 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x69>
 13ec7fd:	48 8b 6b 08          	mov    0x8(%rbx),%rbp
 13ec801:	48 8b 03             	mov    (%rbx),%rax
 13ec804:	48 85 ed             	test   %rbp,%rbp
 13ec807:	74 05                	je     13ec80e <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x1ae>
 13ec809:	f0 83 45 08 01       	lock addl $0x1,0x8(%rbp)
 13ec80e:	48 8b 10             	mov    (%rax),%rdx
 13ec811:	4c 89 e6             	mov    %r12,%rsi
 13ec814:	4c 89 ef             	mov    %r13,%rdi
 13ec817:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 13ec81c:	48 8b 52 20          	mov    0x20(%rdx),%rdx
 13ec820:	48 89 14 24          	mov    %rdx,(%rsp)
 13ec824:	e8 b7 5c fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ec829:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 13ec82e:	4c 89 ee             	mov    %r13,%rsi
 13ec831:	48 8b 14 24          	mov    (%rsp),%rdx
 13ec835:	48 89 c7             	mov    %rax,%rdi
 13ec838:	ff d2                	call   *%rdx
 13ec83a:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13ec83f:	48 85 ff             	test   %rdi,%rdi
 13ec842:	74 05                	je     13ec849 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x1e9>
 13ec844:	e8 47 50 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ec849:	48 85 ed             	test   %rbp,%rbp
 13ec84c:	74 a2                	je     13ec7f0 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x190>
 13ec84e:	48 89 ef             	mov    %rbp,%rdi
 13ec851:	48 83 c3 10          	add    $0x10,%rbx
 13ec855:	e8 36 50 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ec85a:	49 39 df             	cmp    %rbx,%r15
 13ec85d:	75 9e                	jne    13ec7fd <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x19d>
 13ec85f:	e9 65 fe ff ff       	jmp    13ec6c9 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x69>
 13ec864:	0f 1f 40 00          	nopl   0x0(%rax)
 13ec868:	83 f8 11             	cmp    $0x11,%eax
 13ec86b:	0f 8e a8 fe ff ff    	jle    13ec719 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb9>
 13ec871:	4c 8b b5 d0 00 00 00 	mov    0xd0(%rbp),%r14
 13ec878:	4d 85 f6             	test   %r14,%r14
 13ec87b:	74 35                	je     13ec8b2 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x252>
 13ec87d:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 13ec884:	00 00 
 13ec886:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
 13ec88d:	00 
 13ec88e:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
 13ec895:	00 00 
 13ec897:	41 8b 46 28          	mov    0x28(%r14),%eax
 13ec89b:	45 0f b6 56 78       	movzbl 0x78(%r14),%r10d
 13ec8a0:	83 f8 05             	cmp    $0x5,%eax
 13ec8a3:	0f 8e 87 00 00 00    	jle    13ec930 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x2d0>
 13ec8a9:	45 84 d2             	test   %r10b,%r10b
 13ec8ac:	0f 85 7e 00 00 00    	jne    13ec930 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x2d0>
 13ec8b2:	48 8b 05 cf f6 78 00 	mov    0x78f6cf(%rip),%rax        # 1b7bf88 <stdout@GLIBC_2.2.5>
 13ec8b9:	48 8b 38             	mov    (%rax),%rdi
 13ec8bc:	e8 bf a2 fa fe       	call   396b80 <fflush@plt>
 13ec8c1:	48 8b 05 e8 5f 79 00 	mov    0x795fe8(%rip),%rax        # 1b828b0 <stderr@GLIBC_2.2.5>
 13ec8c8:	48 8b 38             	mov    (%rax),%rdi
 13ec8cb:	e8 b0 a2 fa fe       	call   396b80 <fflush@plt>
 13ec8d0:	45 0f b6 37          	movzbl (%r15),%r14d
 13ec8d4:	45 84 f6             	test   %r14b,%r14b
 13ec8d7:	0f 85 78 fe ff ff    	jne    13ec755 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xf5>
 13ec8dd:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
 13ec8e2:	4c 89 e6             	mov    %r12,%rsi
 13ec8e5:	4c 89 ef             	mov    %r13,%rdi
 13ec8e8:	e8 f3 5b fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ec8ed:	48 89 da             	mov    %rbx,%rdx
 13ec8f0:	4c 89 ee             	mov    %r13,%rsi
 13ec8f3:	48 89 ef             	mov    %rbp,%rdi
 13ec8f6:	e8 a5 da f9 fe       	call   38a3a0 <PemRVecIDU::log_dispatch_failed(std::shared_ptr<Isa>, unsigned int&)@plt>
 13ec8fb:	e9 ba fd ff ff       	jmp    13ec6ba <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x5a>
 13ec900:	8b 33                	mov    (%rbx),%esi
 13ec902:	4c 89 f9             	mov    %r15,%rcx
 13ec905:	4c 89 e2             	mov    %r12,%rdx
 13ec908:	48 89 ef             	mov    %rbp,%rdi
 13ec90b:	e8 00 51 f9 fe       	call   381a10 <PemRVecIDU::do_dispatch_pipe_su(unsigned int, std::shared_ptr<Isa>&, bool&)@plt>
 13ec910:	e9 33 fe ff ff       	jmp    13ec748 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xe8>
 13ec915:	0f 1f 00             	nopl   (%rax)
 13ec918:	48 83 c3 10          	add    $0x10,%rbx
 13ec91c:	49 39 df             	cmp    %rbx,%r15
 13ec91f:	0f 85 5b fe ff ff    	jne    13ec780 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x120>
 13ec925:	e9 9f fd ff ff       	jmp    13ec6c9 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x69>
 13ec92a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13ec930:	49 8b 76 08          	mov    0x8(%r14),%rsi
 13ec934:	44 88 54 24 08       	mov    %r10b,0x8(%rsp)
 13ec939:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
 13ec93e:	89 04 24             	mov    %eax,(%rsp)
 13ec941:	48 83 ec 08          	sub    $0x8,%rsp
 13ec945:	4c 8d 05 32 8a 37 00 	lea    0x378a32(%rip),%r8        # 176537e <_fini@@Base+0xe65a>
 13ec94c:	4c 89 ef             	mov    %r13,%rdi
 13ec94f:	41 b9 1b 00 00 00    	mov    $0x1b,%r9d
 13ec955:	b9 05 00 00 00       	mov    $0x5,%ecx
 13ec95a:	48 8b 56 e8          	mov    -0x18(%rsi),%rdx
 13ec95e:	ff 74 24 28          	push   0x28(%rsp)
 13ec962:	ff 74 24 28          	push   0x28(%rsp)
 13ec966:	ff 74 24 28          	push   0x28(%rsp)
 13ec96a:	e8 e1 0f fb fe       	call   39d950 <spdlog::details::log_msg::log_msg(spdlog::source_loc, fmt::v11::basic_string_view<char>, spdlog::level::level_enum, fmt::v11::basic_string_view<char>)@plt>
 13ec96f:	48 83 c4 20          	add    $0x20,%rsp
 13ec973:	44 0f b6 54 24 08    	movzbl 0x8(%rsp),%r10d
 13ec979:	8b 04 24             	mov    (%rsp),%eax
 13ec97c:	31 c9                	xor    %ecx,%ecx
 13ec97e:	4c 89 ee             	mov    %r13,%rsi
 13ec981:	4c 89 f7             	mov    %r14,%rdi
 13ec984:	45 84 d2             	test   %r10b,%r10b
 13ec987:	0f 95 c1             	setne  %cl
 13ec98a:	31 d2                	xor    %edx,%edx
 13ec98c:	83 f8 05             	cmp    $0x5,%eax
 13ec98f:	0f 9e c2             	setle  %dl
 13ec992:	e8 a9 9b fb fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 13ec997:	e9 16 ff ff ff       	jmp    13ec8b2 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x252>
 13ec99c:	e8 1f 8d fa fe       	call   3956c0 <__stack_chk_fail@plt>
 13ec9a1:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13ec9a6:	48 89 c3             	mov    %rax,%rbx
 13ec9a9:	48 85 ff             	test   %rdi,%rdi
 13ec9ac:	74 05                	je     13ec9b3 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x353>
 13ec9ae:	e8 dd 4e 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ec9b3:	48 85 ed             	test   %rbp,%rbp
 13ec9b6:	74 08                	je     13ec9c0 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x360>
 13ec9b8:	48 89 ef             	mov    %rbp,%rdi
 13ec9bb:	e8 d0 4e 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ec9c0:	48 89 df             	mov    %rbx,%rdi
 13ec9c3:	e8 b8 63 fb fe       	call   3a2d80 <_Unwind_Resume@plt>
 13ec9c8:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13ec9cd:	48 89 c3             	mov    %rax,%rbx
 13ec9d0:	48 85 ff             	test   %rdi,%rdi
 13ec9d3:	75 e6                	jne    13ec9bb <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x35b>
 13ec9d5:	eb e9                	jmp    13ec9c0 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x360>
 13ec9d7:	eb ef                	jmp    13ec9c8 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x368>
 13ec9d9:	eb ed                	jmp    13ec9c8 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x368>
 13ec9db:	90                   	nop
 13ec9dc:	0f 1f 40 00          	nopl   0x0(%rax)
