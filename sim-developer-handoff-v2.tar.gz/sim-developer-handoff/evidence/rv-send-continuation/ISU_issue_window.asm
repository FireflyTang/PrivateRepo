
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000001554860 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base>:
 1554860:	41 57                	push   %r15
 1554862:	41 56                	push   %r14
 1554864:	41 55                	push   %r13
 1554866:	41 54                	push   %r12
 1554868:	55                   	push   %rbp
 1554869:	53                   	push   %rbx
 155486a:	48 89 fd             	mov    %rdi,%rbp
 155486d:	48 81 ec 48 03 00 00 	sub    $0x348,%rsp
 1554874:	48 8b 06             	mov    (%rsi),%rax
 1554877:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
 155487c:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
 1554881:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
 1554888:	00 00 
 155488a:	48 89 9c 24 38 03 00 	mov    %rbx,0x338(%rsp)
 1554891:	00 
 1554892:	31 db                	xor    %ebx,%ebx
 1554894:	8b 90 90 00 00 00    	mov    0x90(%rax),%edx
 155489a:	85 d2                	test   %edx,%edx
 155489c:	74 45                	je     15548e3 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x83>
 155489e:	48 8b 80 00 01 00 00 	mov    0x100(%rax),%rax
 15548a5:	8b 08                	mov    (%rax),%ecx
 15548a7:	8d 71 fe             	lea    -0x2(%rcx),%esi
 15548aa:	83 fe 01             	cmp    $0x1,%esi
 15548ad:	76 34                	jbe    15548e3 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x83>
 15548af:	85 c9                	test   %ecx,%ecx
 15548b1:	0f 85 17 0a 00 00    	jne    15552ce <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xa6e>
 15548b7:	48 83 c0 04          	add    $0x4,%rax
 15548bb:	83 ea 01             	sub    $0x1,%edx
 15548be:	48 8d 34 90          	lea    (%rax,%rdx,4),%rsi
 15548c2:	eb 10                	jmp    15548d4 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x74>
 15548c4:	0f 1f 40 00          	nopl   0x0(%rax)
 15548c8:	48 83 c0 04          	add    $0x4,%rax
 15548cc:	85 d2                	test   %edx,%edx
 15548ce:	0f 85 fa 09 00 00    	jne    15552ce <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xa6e>
 15548d4:	48 39 c6             	cmp    %rax,%rsi
 15548d7:	74 0a                	je     15548e3 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x83>
 15548d9:	8b 10                	mov    (%rax),%edx
 15548db:	8d 4a fe             	lea    -0x2(%rdx),%ecx
 15548de:	83 f9 01             	cmp    $0x1,%ecx
 15548e1:	77 e5                	ja     15548c8 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x68>
 15548e3:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
 15548e8:	48 89 ef             	mov    %rbp,%rdi
 15548eb:	4c 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%r15
 15548f2:	00 
 15548f3:	4c 8d a4 24 20 01 00 	lea    0x120(%rsp),%r12
 15548fa:	00 
 15548fb:	48 89 de             	mov    %rbx,%rsi
 15548fe:	e8 4d 05 e5 fe       	call   3a4e50 <RVecISUEntry::reorder_exq_entry(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&)@plt>
 1554903:	48 89 de             	mov    %rbx,%rsi
 1554906:	48 89 ef             	mov    %rbp,%rdi
 1554909:	e8 e2 60 e3 fe       	call   38a9f0 <RVecISUEntry::issue_uop_window_wakeup(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&)@plt>
 155490e:	48 8b 33             	mov    (%rbx),%rsi
 1554911:	4c 89 ff             	mov    %r15,%rdi
 1554914:	e8 97 39 e4 fe       	call   3982b0 <TmArray<std::shared_ptr<RVecUop> >::begin()@plt>
 1554919:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
 1554920:	00 
 1554921:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1554926:	48 8d 84 24 10 02 00 	lea    0x210(%rsp),%rax
 155492d:	00 
 155492e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
 1554933:	48 8d 84 24 30 02 00 	lea    0x230(%rsp),%rax
 155493a:	00 
 155493b:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 1554940:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 1554945:	4c 89 e7             	mov    %r12,%rdi
 1554948:	48 8b 30             	mov    (%rax),%rsi
 155494b:	e8 50 eb e4 fe       	call   3a34a0 <TmArray<std::shared_ptr<RVecUop> >::end()@plt>
 1554950:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
 1554957:	00 
 1554958:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
 155495f:	00 
 1554960:	48 8b 40 18          	mov    0x18(%rax),%rax
 1554964:	48 39 42 18          	cmp    %rax,0x18(%rdx)
 1554968:	0f 84 8a 06 00 00    	je     1554ff8 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x798>
 155496e:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
 1554975:	00 
 1554976:	48 85 ff             	test   %rdi,%rdi
 1554979:	74 05                	je     1554980 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x120>
 155497b:	e8 10 cf 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1554980:	4c 89 ff             	mov    %r15,%rdi
 1554983:	e8 88 4b e4 fe       	call   399510 <TmArray<std::shared_ptr<RVecUop> >::iterator::operator*()@plt>
 1554988:	48 8b 00             	mov    (%rax),%rax
 155498b:	80 b8 c4 00 00 00 00 	cmpb   $0x0,0xc4(%rax)
 1554992:	0f 84 79 02 00 00    	je     1554c11 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x3b1>
 1554998:	4c 89 ff             	mov    %r15,%rdi
 155499b:	e8 70 4b e4 fe       	call   399510 <TmArray<std::shared_ptr<RVecUop> >::iterator::operator*()@plt>
 15549a0:	48 8b 00             	mov    (%rax),%rax
 15549a3:	4c 89 ff             	mov    %r15,%rdi
 15549a6:	c6 80 c4 00 00 00 00 	movb   $0x0,0xc4(%rax)
 15549ad:	e8 5e 4b e4 fe       	call   399510 <TmArray<std::shared_ptr<RVecUop> >::iterator::operator*()@plt>
 15549b2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 15549b7:	48 89 c6             	mov    %rax,%rsi
 15549ba:	e8 71 1f e3 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 15549bf:	48 8b 9d 68 01 00 00 	mov    0x168(%rbp),%rbx
 15549c6:	4c 8b b5 70 01 00 00 	mov    0x170(%rbp),%r14
 15549cd:	c7 84 24 20 01 00 00 	movl   $0x0,0x120(%rsp)
 15549d4:	00 00 00 00 
 15549d8:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
 15549df:	00 00 00 00 00 
 15549e4:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
 15549eb:	00 00 00 00 00 
 15549f0:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
 15549f7:	00 00 00 00 00 
 15549fc:	4c 39 f3             	cmp    %r14,%rbx
 15549ff:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
 1554a06:	00 00 00 00 00 
 1554a0b:	48 c7 84 24 48 01 00 	movq   $0x0,0x148(%rsp)
 1554a12:	00 00 00 00 00 
 1554a17:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
 1554a1e:	00 00 00 00 00 
 1554a23:	48 c7 84 24 58 01 00 	movq   $0x0,0x158(%rsp)
 1554a2a:	00 00 00 00 00 
 1554a2f:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
 1554a36:	00 00 00 00 00 
 1554a3b:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
 1554a42:	00 00 00 00 00 
 1554a47:	48 c7 84 24 70 01 00 	movq   $0x0,0x170(%rsp)
 1554a4e:	00 00 00 00 00 
 1554a53:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
 1554a5a:	00 00 00 00 00 
 1554a5f:	48 c7 84 24 80 01 00 	movq   $0x0,0x180(%rsp)
 1554a66:	00 00 00 00 00 
 1554a6b:	48 c7 84 24 88 01 00 	movq   $0x0,0x188(%rsp)
 1554a72:	00 00 00 00 00 
 1554a77:	48 c7 84 24 90 01 00 	movq   $0x0,0x190(%rsp)
 1554a7e:	00 00 00 00 00 
 1554a83:	48 c7 84 24 98 01 00 	movq   $0x0,0x198(%rsp)
 1554a8a:	00 00 00 00 00 
 1554a8f:	48 c7 84 24 a0 01 00 	movq   $0x0,0x1a0(%rsp)
 1554a96:	00 00 00 00 00 
 1554a9b:	0f 84 a7 00 00 00    	je     1554b48 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x2e8>
 1554aa1:	4c 8d ac 24 c0 00 00 	lea    0xc0(%rsp),%r13
 1554aa8:	00 
 1554aa9:	eb 4a                	jmp    1554af5 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x295>
 1554aab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1554ab0:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 1554ab5:	4c 89 e1             	mov    %r12,%rcx
 1554ab8:	4c 89 ee             	mov    %r13,%rsi
 1554abb:	41 ff d0             	call   *%r8
 1554abe:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
 1554ac5:	00 
 1554ac6:	48 85 d2             	test   %rdx,%rdx
 1554ac9:	74 19                	je     1554ae4 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x284>
 1554acb:	48 83 3d fd f8 62 00 	cmpq   $0x0,0x62f8fd(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 1554ad2:	00 
 1554ad3:	0f 84 47 01 00 00    	je     1554c20 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x3c0>
 1554ad9:	f0 83 6a 08 01       	lock subl $0x1,0x8(%rdx)
 1554ade:	0f 84 e4 04 00 00    	je     1554fc8 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x768>
 1554ae4:	84 c0                	test   %al,%al
 1554ae6:	0f 84 94 01 00 00    	je     1554c80 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x420>
 1554aec:	48 83 c3 10          	add    $0x10,%rbx
 1554af0:	49 39 de             	cmp    %rbx,%r14
 1554af3:	74 53                	je     1554b48 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x2e8>
 1554af5:	48 8b 3b             	mov    (%rbx),%rdi
 1554af8:	8b 95 d0 00 00 00    	mov    0xd0(%rbp),%edx
 1554afe:	48 8b 07             	mov    (%rdi),%rax
 1554b01:	4c 8b 40 08          	mov    0x8(%rax),%r8
 1554b05:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
 1554b0c:	00 
 1554b0d:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
 1554b14:	00 
 1554b15:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
 1554b1c:	00 
 1554b1d:	48 85 c0             	test   %rax,%rax
 1554b20:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
 1554b27:	00 
 1554b28:	74 8b                	je     1554ab5 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x255>
 1554b2a:	48 83 3d 9e f8 62 00 	cmpq   $0x0,0x62f89e(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 1554b31:	00 
 1554b32:	0f 85 78 ff ff ff    	jne    1554ab0 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x250>
 1554b38:	83 40 08 01          	addl   $0x1,0x8(%rax)
 1554b3c:	e9 74 ff ff ff       	jmp    1554ab5 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x255>
 1554b41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1554b48:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
 1554b4f:	00 
 1554b50:	48 8b 38             	mov    (%rax),%rdi
 1554b53:	e8 48 fd e2 fe       	call   3848a0 <Isa::name() const@plt>
 1554b58:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 1554b5d:	0f 84 c5 04 00 00    	je     1555028 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x7c8>
 1554b63:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
 1554b6a:	00 
 1554b6b:	48 8b 38             	mov    (%rax),%rdi
 1554b6e:	e8 2d fd e2 fe       	call   3848a0 <Isa::name() const@plt>
 1554b73:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 1554b78:	0f 84 aa 04 00 00    	je     1555028 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x7c8>
 1554b7e:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 1554b83:	48 89 ef             	mov    %rbp,%rdi
 1554b86:	e8 15 31 e4 fe       	call   397ca0 <RVecISUEntry::issue_nonbar_instr(std::shared_ptr<RVecUop>&)@plt>
 1554b8b:	84 c0                	test   %al,%al
 1554b8d:	74 68                	je     1554bf7 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x397>
 1554b8f:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
 1554b94:	48 89 ef             	mov    %rbp,%rdi
 1554b97:	4c 89 f6             	mov    %r14,%rsi
 1554b9a:	e8 21 86 e3 fe       	call   38d1c0 <RVecISUEntry::log_issue_check_passed(std::shared_ptr<RVecUop> const&)@plt>
 1554b9f:	4c 8d ac 24 c0 00 00 	lea    0xc0(%rsp),%r13
 1554ba6:	00 
 1554ba7:	48 8b 9d f0 00 00 00 	mov    0xf0(%rbp),%rbx
 1554bae:	4c 89 f6             	mov    %r14,%rsi
 1554bb1:	4c 89 ef             	mov    %r13,%rdi
 1554bb4:	e8 77 1d e3 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 1554bb9:	48 8d 95 d0 00 00 00 	lea    0xd0(%rbp),%rdx
 1554bc0:	4c 89 ee             	mov    %r13,%rsi
 1554bc3:	48 89 df             	mov    %rbx,%rdi
 1554bc6:	e8 e5 33 e3 fe       	call   387fb0 <PemRVecPerfISU::que_issue(std::shared_ptr<RVecUop>, IsuQueue&)@plt>
 1554bcb:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1554bd2:	00 
 1554bd3:	48 85 ff             	test   %rdi,%rdi
 1554bd6:	74 05                	je     1554bdd <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x37d>
 1554bd8:	e8 b3 cc 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1554bdd:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
 1554be2:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
 1554be7:	4c 89 fa             	mov    %r15,%rdx
 1554bea:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 1554bef:	48 89 ef             	mov    %rbp,%rdi
 1554bf2:	e8 99 5a e4 fe       	call   39a690 <RVecISUEntry::post_issue_uop(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, TmArray<std::shared_ptr<RVecUop> >::iterator const&, std::shared_ptr<RVecUop>&, std::shared_ptr<IsuIssueStatus>&)@plt>
 1554bf7:	4c 89 e7             	mov    %r12,%rdi
 1554bfa:	e8 e1 ee e2 fe       	call   383ae0 <IssueCheckResult::~IssueCheckResult()@plt>
 1554bff:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
 1554c06:	00 
 1554c07:	48 85 ff             	test   %rdi,%rdi
 1554c0a:	74 05                	je     1554c11 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x3b1>
 1554c0c:	e8 7f cc 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1554c11:	4c 89 ff             	mov    %r15,%rdi
 1554c14:	e8 07 41 e3 fe       	call   388d20 <TmArray<std::shared_ptr<RVecUop> >::iterator::operator++()@plt>
 1554c19:	e9 22 fd ff ff       	jmp    1554940 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xe0>
 1554c1e:	66 90                	xchg   %ax,%ax
 1554c20:	8b 4a 08             	mov    0x8(%rdx),%ecx
 1554c23:	8d 71 ff             	lea    -0x1(%rcx),%esi
 1554c26:	83 f9 01             	cmp    $0x1,%ecx
 1554c29:	89 72 08             	mov    %esi,0x8(%rdx)
 1554c2c:	0f 85 b2 fe ff ff    	jne    1554ae4 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x284>
 1554c32:	48 8b 0a             	mov    (%rdx),%rcx
 1554c35:	88 44 24 20          	mov    %al,0x20(%rsp)
 1554c39:	48 89 d7             	mov    %rdx,%rdi
 1554c3c:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
 1554c41:	ff 51 10             	call   *0x10(%rcx)
 1554c44:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 1554c49:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
 1554c4e:	8b 4a 0c             	mov    0xc(%rdx),%ecx
 1554c51:	8d 71 ff             	lea    -0x1(%rcx),%esi
 1554c54:	89 72 0c             	mov    %esi,0xc(%rdx)
 1554c57:	83 f9 01             	cmp    $0x1,%ecx
 1554c5a:	0f 85 84 fe ff ff    	jne    1554ae4 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x284>
 1554c60:	48 8b 0a             	mov    (%rdx),%rcx
 1554c63:	88 44 24 18          	mov    %al,0x18(%rsp)
 1554c67:	48 89 d7             	mov    %rdx,%rdi
 1554c6a:	ff 51 18             	call   *0x18(%rcx)
 1554c6d:	0f b6 44 24 18       	movzbl 0x18(%rsp),%eax
 1554c72:	84 c0                	test   %al,%al
 1554c74:	0f 85 72 fe ff ff    	jne    1554aec <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x28c>
 1554c7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1554c80:	48 8b 03             	mov    (%rbx),%rax
 1554c83:	48 8d 73 08          	lea    0x8(%rbx),%rsi
 1554c87:	49 8d 7c 24 10       	lea    0x10(%r12),%rdi
 1554c8c:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
 1554c93:	00 
 1554c94:	e8 37 03 e5 fe       	call   3a4fd0 <std::__shared_count<(__gnu_cxx::_Lock_policy)2>::operator=(std::__shared_count<(__gnu_cxx::_Lock_policy)2> const&)@plt>
 1554c99:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
 1554ca0:	00 
 1554ca1:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1554ca5:	48 8b 30             	mov    (%rax),%rsi
 1554ca8:	4d 85 f6             	test   %r14,%r14
 1554cab:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
 1554cb0:	74 14                	je     1554cc6 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x466>
 1554cb2:	48 83 3d 16 f7 62 00 	cmpq   $0x0,0x62f716(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 1554cb9:	00 
 1554cba:	0f 84 80 03 00 00    	je     1555040 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x7e0>
 1554cc0:	f0 41 83 46 08 01    	lock addl $0x1,0x8(%r14)
 1554cc6:	48 8d 84 24 88 00 00 	lea    0x88(%rsp),%rax
 1554ccd:	00 
 1554cce:	48 8d 35 b0 50 21 00 	lea    0x2150b0(%rip),%rsi        # 1769d85 <_fini@@Base+0x13061>
 1554cd5:	4c 89 ef             	mov    %r13,%rdi
 1554cd8:	48 89 c2             	mov    %rax,%rdx
 1554cdb:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 1554ce0:	e8 cb e7 e4 fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 1554ce5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 1554cea:	4c 89 e1             	mov    %r12,%rcx
 1554ced:	4c 89 ea             	mov    %r13,%rdx
 1554cf0:	48 89 ef             	mov    %rbp,%rdi
 1554cf3:	e8 a8 bc e3 fe       	call   3909a0 <RVecISUEntry::log_blocked_reason(std::shared_ptr<RVecUop> const&, std::string const&, IssueCheckResult const&)@plt>
 1554cf8:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
 1554cff:	00 
 1554d00:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1554d04:	48 3b 3d 75 7e 62 00 	cmp    0x627e75(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1554d0b:	0f 85 e0 05 00 00    	jne    15552f1 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xa91>
 1554d11:	48 8b 95 58 02 00 00 	mov    0x258(%rbp),%rdx
 1554d18:	48 8d 85 50 02 00 00 	lea    0x250(%rbp),%rax
 1554d1f:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 1554d24:	48 85 d2             	test   %rdx,%rdx
 1554d27:	0f 84 7b 05 00 00    	je     15552a8 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xa48>
 1554d2d:	48 89 c6             	mov    %rax,%rsi
 1554d30:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
 1554d37:	00 
 1554d38:	48 89 d0             	mov    %rdx,%rax
 1554d3b:	eb 0f                	jmp    1554d4c <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x4ec>
 1554d3d:	0f 1f 00             	nopl   (%rax)
 1554d40:	48 89 c6             	mov    %rax,%rsi
 1554d43:	48 8b 40 10          	mov    0x10(%rax),%rax
 1554d47:	48 85 c0             	test   %rax,%rax
 1554d4a:	74 0f                	je     1554d5b <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x4fb>
 1554d4c:	48 3b 48 20          	cmp    0x20(%rax),%rcx
 1554d50:	76 ee                	jbe    1554d40 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x4e0>
 1554d52:	48 8b 40 18          	mov    0x18(%rax),%rax
 1554d56:	48 85 c0             	test   %rax,%rax
 1554d59:	75 f1                	jne    1554d4c <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x4ec>
 1554d5b:	48 39 74 24 18       	cmp    %rsi,0x18(%rsp)
 1554d60:	74 16                	je     1554d78 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x518>
 1554d62:	48 3b 4e 20          	cmp    0x20(%rsi),%rcx
 1554d66:	72 10                	jb     1554d78 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x518>
 1554d68:	8b 84 24 20 01 00 00 	mov    0x120(%rsp),%eax
 1554d6f:	39 46 30             	cmp    %eax,0x30(%rsi)
 1554d72:	0f 84 84 01 00 00    	je     1554efc <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x69c>
 1554d78:	48 8b 85 b0 00 00 00 	mov    0xb0(%rbp),%rax
 1554d7f:	48 85 c0             	test   %rax,%rax
 1554d82:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 1554d87:	0f 84 e3 04 00 00    	je     1555270 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xa10>
 1554d8d:	48 8b 05 5c df b3 00 	mov    0xb3df5c(%rip),%rax        # 2092cf0 <RVecUtil::is_vsldb_ga_instr@@Base+0x15f0>
 1554d94:	48 85 c0             	test   %rax,%rax
 1554d97:	0f 84 2c 06 00 00    	je     15553c9 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb69>
 1554d9d:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
 1554da4:	48 8d 1d 3d df b3 00 	lea    0xb3df3d(%rip),%rbx        # 2092ce8 <RVecUtil::is_vsldb_ga_instr@@Base+0x15e8>
 1554dab:	eb 0f                	jmp    1554dbc <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x55c>
 1554dad:	0f 1f 00             	nopl   (%rax)
 1554db0:	48 89 c3             	mov    %rax,%rbx
 1554db3:	48 8b 40 10          	mov    0x10(%rax),%rax
 1554db7:	48 85 c0             	test   %rax,%rax
 1554dba:	74 0e                	je     1554dca <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x56a>
 1554dbc:	39 50 20             	cmp    %edx,0x20(%rax)
 1554dbf:	7d ef                	jge    1554db0 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x550>
 1554dc1:	48 8b 40 18          	mov    0x18(%rax),%rax
 1554dc5:	48 85 c0             	test   %rax,%rax
 1554dc8:	75 f2                	jne    1554dbc <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x55c>
 1554dca:	48 8d 05 17 df b3 00 	lea    0xb3df17(%rip),%rax        # 2092ce8 <RVecUtil::is_vsldb_ga_instr@@Base+0x15e8>
 1554dd1:	48 39 c3             	cmp    %rax,%rbx
 1554dd4:	0f 84 ef 05 00 00    	je     15553c9 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb69>
 1554dda:	3b 53 20             	cmp    0x20(%rbx),%edx
 1554ddd:	0f 8c e6 05 00 00    	jl     15553c9 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb69>
 1554de3:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 1554de8:	e8 83 5a e3 fe       	call   38a870 <Isa::pc() const@plt>
 1554ded:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 1554df2:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 1554df7:	e8 c4 ac e3 fe       	call   38fac0 <Isa::id() const@plt>
 1554dfc:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
 1554e01:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
 1554e06:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
 1554e0b:	e8 90 38 e3 fe       	call   3886a0 <Isa::name_str() const@plt>
 1554e10:	8b 95 d0 00 00 00    	mov    0xd0(%rbp),%edx
 1554e16:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
 1554e1d:	00 
 1554e1e:	48 89 ee             	mov    %rbp,%rsi
 1554e21:	e8 4a 17 e3 fe       	call   386570 <RVecISUEntry::get_que_str(IsuQueue) const@plt>
 1554e26:	48 89 ef             	mov    %rbp,%rdi
 1554e29:	e8 a2 ae e3 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 1554e2e:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
 1554e33:	8b 4e 28             	mov    0x28(%rsi),%ecx
 1554e36:	89 4c 24 20          	mov    %ecx,0x20(%rsp)
 1554e3a:	0f b6 76 78          	movzbl 0x78(%rsi),%esi
 1554e3e:	83 f9 02             	cmp    $0x2,%ecx
 1554e41:	40 88 74 24 5f       	mov    %sil,0x5f(%rsp)
 1554e46:	0f 8e 44 02 00 00    	jle    1555090 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x830>
 1554e4c:	40 84 f6             	test   %sil,%sil
 1554e4f:	0f 85 3b 02 00 00    	jne    1555090 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x830>
 1554e55:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 1554e5c:	00 
 1554e5d:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1554e61:	48 3b 3d 18 7d 62 00 	cmp    0x627d18(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1554e68:	0f 85 97 04 00 00    	jne    1555305 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xaa5>
 1554e6e:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
 1554e75:	00 
 1554e76:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1554e7a:	48 3b 3d ff 7c 62 00 	cmp    0x627cff(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1554e81:	0f 85 74 04 00 00    	jne    15552fb <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xa9b>
 1554e87:	48 8b 95 58 02 00 00 	mov    0x258(%rbp),%rdx
 1554e8e:	8b 9c 24 20 01 00 00 	mov    0x120(%rsp),%ebx
 1554e95:	48 85 d2             	test   %rdx,%rdx
 1554e98:	0f 84 61 06 00 00    	je     15554ff <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xc9f>
 1554e9e:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
 1554ea5:	00 
 1554ea6:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 1554eab:	eb 0f                	jmp    1554ebc <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x65c>
 1554ead:	0f 1f 00             	nopl   (%rax)
 1554eb0:	48 89 d0             	mov    %rdx,%rax
 1554eb3:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 1554eb7:	48 85 d2             	test   %rdx,%rdx
 1554eba:	74 0f                	je     1554ecb <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x66b>
 1554ebc:	48 3b 4a 20          	cmp    0x20(%rdx),%rcx
 1554ec0:	76 ee                	jbe    1554eb0 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x650>
 1554ec2:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 1554ec6:	48 85 d2             	test   %rdx,%rdx
 1554ec9:	75 f1                	jne    1554ebc <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x65c>
 1554ecb:	48 39 44 24 18       	cmp    %rax,0x18(%rsp)
 1554ed0:	74 06                	je     1554ed8 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x678>
 1554ed2:	48 3b 48 20          	cmp    0x20(%rax),%rcx
 1554ed6:	73 21                	jae    1554ef9 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x699>
 1554ed8:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 1554edd:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
 1554ee2:	48 8d bd 48 02 00 00 	lea    0x248(%rbp),%rdi
 1554ee9:	48 89 b4 24 88 00 00 	mov    %rsi,0x88(%rsp)
 1554ef0:	00 
 1554ef1:	48 89 c6             	mov    %rax,%rsi
 1554ef4:	e8 27 50 ff ff       	call   1549f20 <RVecISUEntry::attach(std::vector<std::shared_ptr<RVecISUChecker>, std::allocator<std::shared_ptr<RVecISUChecker> > > const&, std::vector<std::shared_ptr<RVecISUChecker>, std::allocator<std::shared_ptr<RVecISUChecker> > > const&, std::vector<std::shared_ptr<RVecISUIssPriority>, std::allocator<std::shared_ptr<RVecISUIssPriority> > > const&, std::map<InfFromISU, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > >, std::less<InfFromISU>, std::allocator<std::pair<InfFromISU const, std::vector<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> >, std::allocator<std::shared_ptr<TmInf<std::shared_ptr<RVecUop>, (FcType)0> > > > > > > const&, std::shared_ptr<IssueCounter> const&, PemRvecDepmgr*)@@Base+0x200>
 1554ef9:	89 58 30             	mov    %ebx,0x30(%rax)
 1554efc:	4d 85 f6             	test   %r14,%r14
 1554eff:	74 08                	je     1554f09 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x6a9>
 1554f01:	4c 89 f7             	mov    %r14,%rdi
 1554f04:	e8 87 c9 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1554f09:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 1554f0e:	48 8b 9d f0 00 00 00 	mov    0xf0(%rbp),%rbx
 1554f15:	4c 89 ef             	mov    %r13,%rdi
 1554f18:	e8 13 1a e3 fe       	call   386930 <std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<RVecUop, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 1554f1d:	48 8d 95 d0 00 00 00 	lea    0xd0(%rbp),%rdx
 1554f24:	4c 89 e1             	mov    %r12,%rcx
 1554f27:	4c 89 ee             	mov    %r13,%rsi
 1554f2a:	48 89 df             	mov    %rbx,%rdi
 1554f2d:	e8 9e e1 e3 fe       	call   3930d0 <PemRVecPerfISU::que_issue_blocked(std::shared_ptr<RVecUop>, IsuQueue&, InstrBlockedReason&)@plt>
 1554f32:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 1554f39:	00 
 1554f3a:	48 85 ff             	test   %rdi,%rdi
 1554f3d:	74 05                	je     1554f44 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x6e4>
 1554f3f:	e8 4c c9 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1554f44:	8b 85 d0 00 00 00    	mov    0xd0(%rbp),%eax
 1554f4a:	83 f8 03             	cmp    $0x3,%eax
 1554f4d:	0f 84 fd 00 00 00    	je     1555050 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x7f0>
 1554f53:	83 f8 04             	cmp    $0x4,%eax
 1554f56:	0f 85 9b fc ff ff    	jne    1554bf7 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x397>
 1554f5c:	48 8b 85 c0 00 00 00 	mov    0xc0(%rbp),%rax
 1554f63:	83 b8 8c 00 00 00 01 	cmpl   $0x1,0x8c(%rax)
 1554f6a:	0f 85 87 fc ff ff    	jne    1554bf7 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x397>
 1554f70:	4c 89 e7             	mov    %r12,%rdi
 1554f73:	e8 68 eb e2 fe       	call   383ae0 <IssueCheckResult::~IssueCheckResult()@plt>
 1554f78:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
 1554f7f:	00 
 1554f80:	48 85 ff             	test   %rdi,%rdi
 1554f83:	74 05                	je     1554f8a <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x72a>
 1554f85:	e8 06 c9 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1554f8a:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
 1554f91:	00 
 1554f92:	48 85 ff             	test   %rdi,%rdi
 1554f95:	74 05                	je     1554f9c <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x73c>
 1554f97:	e8 f4 c8 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1554f9c:	48 8b 84 24 38 03 00 	mov    0x338(%rsp),%rax
 1554fa3:	00 
 1554fa4:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 1554fab:	00 00 
 1554fad:	0f 85 2a 04 00 00    	jne    15553dd <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb7d>
 1554fb3:	48 81 c4 48 03 00 00 	add    $0x348,%rsp
 1554fba:	5b                   	pop    %rbx
 1554fbb:	5d                   	pop    %rbp
 1554fbc:	41 5c                	pop    %r12
 1554fbe:	41 5d                	pop    %r13
 1554fc0:	41 5e                	pop    %r14
 1554fc2:	41 5f                	pop    %r15
 1554fc4:	c3                   	ret
 1554fc5:	0f 1f 00             	nopl   (%rax)
 1554fc8:	48 8b 0a             	mov    (%rdx),%rcx
 1554fcb:	48 89 d7             	mov    %rdx,%rdi
 1554fce:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
 1554fd3:	88 44 24 20          	mov    %al,0x20(%rsp)
 1554fd7:	ff 51 10             	call   *0x10(%rcx)
 1554fda:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 1554fdf:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 1554fe4:	f0 0f c1 4a 0c       	lock xadd %ecx,0xc(%rdx)
 1554fe9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
 1554fee:	e9 64 fc ff ff       	jmp    1554c57 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x3f7>
 1554ff3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1554ff8:	8b 84 24 20 01 00 00 	mov    0x120(%rsp),%eax
 1554fff:	39 84 24 a0 00 00 00 	cmp    %eax,0xa0(%rsp)
 1555006:	0f 85 62 f9 ff ff    	jne    155496e <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x10e>
 155500c:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
 1555013:	00 
 1555014:	48 85 ff             	test   %rdi,%rdi
 1555017:	0f 85 68 ff ff ff    	jne    1554f85 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x725>
 155501d:	e9 68 ff ff ff       	jmp    1554f8a <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x72a>
 1555022:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1555028:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 155502d:	48 89 ef             	mov    %rbp,%rdi
 1555030:	e8 db b8 e3 fe       	call   390910 <RVecISUEntry::issue_bar_instr(std::shared_ptr<RVecUop>&)@plt>
 1555035:	e9 51 fb ff ff       	jmp    1554b8b <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x32b>
 155503a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1555040:	41 83 46 08 01       	addl   $0x1,0x8(%r14)
 1555045:	e9 7c fc ff ff       	jmp    1554cc6 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x466>
 155504a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1555050:	48 8b 85 c0 00 00 00 	mov    0xc0(%rbp),%rax
 1555057:	8b 80 88 00 00 00    	mov    0x88(%rax),%eax
 155505d:	83 f8 01             	cmp    $0x1,%eax
 1555060:	0f 84 0a ff ff ff    	je     1554f70 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x710>
 1555066:	83 f8 02             	cmp    $0x2,%eax
 1555069:	0f 85 88 fb ff ff    	jne    1554bf7 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x397>
 155506f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 1555074:	48 8b 00             	mov    (%rax),%rax
 1555077:	8b 00                	mov    (%rax),%eax
 1555079:	85 c0                	test   %eax,%eax
 155507b:	0f 85 ef fe ff ff    	jne    1554f70 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x710>
 1555081:	e9 71 fb ff ff       	jmp    1554bf7 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x397>
 1555086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 155508d:	00 00 00 
 1555090:	48 8b 15 81 85 62 00 	mov    0x628581(%rip),%rdx        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 1555097:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
 155509e:	00 
 155509f:	4c 8d 84 24 b0 01 00 	lea    0x1b0(%rsp),%r8
 15550a6:	00 
 15550a7:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 15550ae:	00 
 15550af:	48 c7 84 24 20 02 00 	movq   $0xfa,0x220(%rsp)
 15550b6:	00 fa 00 00 00 
 15550bb:	45 31 c9             	xor    %r9d,%r9d
 15550be:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
 15550c3:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
 15550c8:	b9 d4 4d d4 00       	mov    $0xd44dd4,%ecx
 15550cd:	48 89 94 24 28 02 00 	mov    %rdx,0x228(%rsp)
 15550d4:	00 
 15550d5:	48 c7 84 24 18 02 00 	movq   $0x0,0x218(%rsp)
 15550dc:	00 00 00 00 00 
 15550e1:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 15550e5:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
 15550ec:	00 
 15550ed:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
 15550f4:	00 
 15550f5:	48 89 b4 24 10 02 00 	mov    %rsi,0x210(%rsp)
 15550fc:	00 
 15550fd:	48 8d 35 4c c7 22 00 	lea    0x22c74c(%rip),%rsi        # 1781850 <_fini@@Base+0x2ab2c>
 1555104:	48 89 94 24 c8 01 00 	mov    %rdx,0x1c8(%rsp)
 155510b:	00 
 155510c:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 1555110:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
 1555117:	00 
 1555118:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
 155511d:	48 89 94 24 d8 01 00 	mov    %rdx,0x1d8(%rsp)
 1555124:	00 
 1555125:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
 155512c:	00 
 155512d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
 1555132:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
 1555139:	00 
 155513a:	48 8b 43 28          	mov    0x28(%rbx),%rax
 155513e:	48 8b 50 e8          	mov    -0x18(%rax),%rdx
 1555142:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
 1555149:	00 
 155514a:	48 89 94 24 08 02 00 	mov    %rdx,0x208(%rsp)
 1555151:	00 
 1555152:	ba 54 00 00 00       	mov    $0x54,%edx
 1555157:	e8 b4 eb e4 fe       	call   3a3d10 <fmt::v11::detail::vformat_to(fmt::v11::detail::buffer<char>&, fmt::v11::basic_string_view<char>, fmt::v11::basic_format_args<fmt::v11::context>, fmt::v11::detail::locale_ref)@plt>
 155515c:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
 1555163:	00 
 1555164:	48 8b 9c 24 10 02 00 	mov    0x210(%rsp),%rbx
 155516b:	00 
 155516c:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 1555171:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 1555176:	48 8b 50 08          	mov    0x8(%rax),%rdx
 155517a:	48 8b 4a e8          	mov    -0x18(%rdx),%rcx
 155517e:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
 1555183:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
 1555188:	e8 53 bb e2 fe       	call   380ce0 <std::chrono::_V2::system_clock::now()@plt>
 155518d:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
 1555192:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
 1555197:	c7 84 24 d0 00 00 00 	movl   $0x2,0xd0(%rsp)
 155519e:	02 00 00 00 
 15551a2:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
 15551a9:	00 
 15551aa:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
 15551b1:	00 
 15551b2:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 15551b9:	00 
 15551ba:	48 8d 3d 47 69 62 00 	lea    0x626947(%rip),%rdi        # 1b7bb08 <vtable for std::bad_array_new_length@@Base+0x13c48>
 15551c1:	e8 0a c0 e4 fe       	call   3a11d0 <__tls_get_addr@plt>
 15551c6:	80 b8 e8 01 00 00 00 	cmpb   $0x0,0x1e8(%rax)
 15551cd:	0f 84 a9 00 00 00    	je     155527c <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xa1c>
 15551d3:	48 8b 80 f0 01 00 00 	mov    0x1f0(%rax),%rax
 15551da:	31 c9                	xor    %ecx,%ecx
 15551dc:	80 7c 24 5f 00       	cmpb   $0x0,0x5f(%rsp)
 15551e1:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 15551e8:	00 
 15551e9:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 15551ee:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
 15551f3:	4c 89 ee             	mov    %r13,%rsi
 15551f6:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
 15551fd:	00 00 00 00 00 
 1555202:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
 1555209:	00 00 00 00 00 
 155520e:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
 1555215:	00 00 00 00 00 
 155521a:	c7 84 24 00 01 00 00 	movl   $0x0,0x100(%rsp)
 1555221:	00 00 00 00 
 1555225:	0f 95 c1             	setne  %cl
 1555228:	31 d2                	xor    %edx,%edx
 155522a:	83 7c 24 20 02       	cmpl   $0x2,0x20(%rsp)
 155522f:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
 1555236:	00 00 00 00 00 
 155523b:	48 89 9c 24 10 01 00 	mov    %rbx,0x110(%rsp)
 1555242:	00 
 1555243:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
 155524a:	00 
 155524b:	0f 9e c2             	setle  %dl
 155524e:	e8 ed 12 e5 fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 1555253:	48 8b bc 24 10 02 00 	mov    0x210(%rsp),%rdi
 155525a:	00 
 155525b:	48 3b 7c 24 40       	cmp    0x40(%rsp),%rdi
 1555260:	0f 84 ef fb ff ff    	je     1554e55 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x5f5>
 1555266:	e8 15 1d e4 fe       	call   396f80 <free@plt>
 155526b:	e9 e5 fb ff ff       	jmp    1554e55 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x5f5>
 1555270:	8b 9c 24 20 01 00 00 	mov    0x120(%rsp),%ebx
 1555277:	e9 2a fc ff ff       	jmp    1554ea6 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x646>
 155527c:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
 1555281:	bf ba 00 00 00       	mov    $0xba,%edi
 1555286:	31 c0                	xor    %eax,%eax
 1555288:	e8 73 bd e2 fe       	call   381000 <syscall@plt>
 155528d:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
 1555292:	48 89 82 f0 01 00 00 	mov    %rax,0x1f0(%rdx)
 1555299:	c6 82 e8 01 00 00 01 	movb   $0x1,0x1e8(%rdx)
 15552a0:	e9 35 ff ff ff       	jmp    15551da <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x97a>
 15552a5:	0f 1f 00             	nopl   (%rax)
 15552a8:	48 8b 85 b0 00 00 00 	mov    0xb0(%rbp),%rax
 15552af:	48 85 c0             	test   %rax,%rax
 15552b2:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 15552b7:	0f 85 d0 fa ff ff    	jne    1554d8d <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x52d>
 15552bd:	8b 9c 24 20 01 00 00 	mov    0x120(%rsp),%ebx
 15552c4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 15552c9:	e9 0a fc ff ff       	jmp    1554ed8 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x678>
 15552ce:	48 8b 05 b3 6c 62 00 	mov    0x626cb3(%rip),%rax        # 1b7bf88 <stdout@GLIBC_2.2.5>
 15552d5:	48 8b 38             	mov    (%rax),%rdi
 15552d8:	e8 a3 18 e4 fe       	call   396b80 <fflush@plt>
 15552dd:	48 8b 05 cc d5 62 00 	mov    0x62d5cc(%rip),%rax        # 1b828b0 <stderr@GLIBC_2.2.5>
 15552e4:	48 8b 38             	mov    (%rax),%rdi
 15552e7:	e8 94 18 e4 fe       	call   396b80 <fflush@plt>
 15552ec:	e9 f2 f5 ff ff       	jmp    15548e3 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x83>
 15552f1:	e8 ea 0e ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 15552f6:	e9 16 fa ff ff       	jmp    1554d11 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x4b1>
 15552fb:	e8 e0 0e ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1555300:	e9 82 fb ff ff       	jmp    1554e87 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x627>
 1555305:	e8 d6 0e ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 155530a:	e9 5f fb ff ff       	jmp    1554e6e <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x60e>
 155530f:	48 89 c3             	mov    %rax,%rbx
 1555312:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
 1555319:	00 
 155531a:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 155531e:	48 3b 3d 5b 78 62 00 	cmp    0x62785b(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1555325:	75 73                	jne    155539a <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb3a>
 1555327:	4d 85 f6             	test   %r14,%r14
 155532a:	74 08                	je     1555334 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xad4>
 155532c:	4c 89 f7             	mov    %r14,%rdi
 155532f:	e8 5c c5 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1555334:	4c 89 e7             	mov    %r12,%rdi
 1555337:	e8 a4 e7 e2 fe       	call   383ae0 <IssueCheckResult::~IssueCheckResult()@plt>
 155533c:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
 1555343:	00 
 1555344:	48 85 ff             	test   %rdi,%rdi
 1555347:	74 05                	je     155534e <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xaee>
 1555349:	e8 42 c5 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 155534e:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
 1555355:	00 
 1555356:	48 85 ff             	test   %rdi,%rdi
 1555359:	74 05                	je     1555360 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb00>
 155535b:	e8 30 c5 83 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1555360:	48 89 df             	mov    %rbx,%rdi
 1555363:	e8 18 da e4 fe       	call   3a2d80 <_Unwind_Resume@plt>
 1555368:	48 89 c3             	mov    %rax,%rbx
 155536b:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 1555372:	00 
 1555373:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1555377:	48 3b 3d 02 78 62 00 	cmp    0x627802(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 155537e:	74 05                	je     1555385 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb25>
 1555380:	e8 5b 0e ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1555385:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
 155538c:	00 
 155538d:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1555391:	48 3b 3d e8 77 62 00 	cmp    0x6277e8(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1555398:	74 8d                	je     1555327 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xac7>
 155539a:	e8 41 0e ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 155539f:	eb 86                	jmp    1555327 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xac7>
 15553a1:	48 89 c3             	mov    %rax,%rbx
 15553a4:	eb 8e                	jmp    1555334 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xad4>
 15553a6:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
 15553ad:	00 
 15553ae:	48 89 c3             	mov    %rax,%rbx
 15553b1:	48 85 ff             	test   %rdi,%rdi
 15553b4:	0f 85 75 ff ff ff    	jne    155532f <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xacf>
 15553ba:	e9 75 ff ff ff       	jmp    1555334 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xad4>
 15553bf:	48 89 c3             	mov    %rax,%rbx
 15553c2:	e9 60 ff ff ff       	jmp    1555327 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xac7>
 15553c7:	eb dd                	jmp    15553a6 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb46>
 15553c9:	48 8d 3d d0 1c 20 00 	lea    0x201cd0(%rip),%rdi        # 17570a0 <_fini@@Base+0x37c>
 15553d0:	e8 0b 74 e4 fe       	call   39c7e0 <std::__throw_out_of_range(char const*)@plt>
 15553d5:	48 89 c3             	mov    %rax,%rbx
 15553d8:	e9 71 ff ff ff       	jmp    155534e <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xaee>
 15553dd:	e8 de 02 e4 fe       	call   3956c0 <__stack_chk_fail@plt>
 15553e2:	eb c2                	jmp    15553a6 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb46>
 15553e4:	48 89 c3             	mov    %rax,%rbx
 15553e7:	eb 9c                	jmp    1555385 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb25>
 15553e9:	48 8b bc 24 10 02 00 	mov    0x210(%rsp),%rdi
 15553f0:	00 
 15553f1:	48 3b 7c 24 40       	cmp    0x40(%rsp),%rdi
 15553f6:	48 89 d3             	mov    %rdx,%rbx
 15553f9:	74 0f                	je     155540a <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xbaa>
 15553fb:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 1555400:	e8 7b 1b e4 fe       	call   396f80 <free@plt>
 1555405:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 155540a:	48 83 eb 01          	sub    $0x1,%rbx
 155540e:	48 89 c7             	mov    %rax,%rdi
 1555411:	75 7b                	jne    155548e <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xc2e>
 1555413:	e8 98 19 e3 fe       	call   386db0 <__cxa_begin_catch@plt>
 1555418:	48 8b 10             	mov    (%rax),%rdx
 155541b:	48 89 c7             	mov    %rax,%rdi
 155541e:	ff 52 10             	call   *0x10(%rdx)
 1555421:	48 8d 54 24 7f       	lea    0x7f(%rsp),%rdx
 1555426:	48 89 c6             	mov    %rax,%rsi
 1555429:	4c 89 ef             	mov    %r13,%rdi
 155542c:	e8 7f e0 e4 fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 1555431:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 1555436:	4c 89 ee             	mov    %r13,%rsi
 1555439:	e8 e2 fc e3 fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 155543e:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
 1555445:	00 
 1555446:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 155544a:	48 3b 3d 2f 77 62 00 	cmp    0x62772f(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1555451:	74 05                	je     1555458 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xbf8>
 1555453:	e8 88 0d ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 1555458:	e8 03 ac e4 fe       	call   3a0060 <__cxa_end_catch@plt>
 155545d:	e9 f3 f9 ff ff       	jmp    1554e55 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x5f5>
 1555462:	48 89 c3             	mov    %rax,%rbx
 1555465:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
 155546c:	00 
 155546d:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 1555471:	48 3b 3d 08 77 62 00 	cmp    0x627708(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 1555478:	74 05                	je     155547f <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xc1f>
 155547a:	e8 61 0d ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 155547f:	e8 dc ab e4 fe       	call   3a0060 <__cxa_end_catch@plt>
 1555484:	e9 e2 fe ff ff       	jmp    155536b <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb0b>
 1555489:	48 89 c3             	mov    %rax,%rbx
 155548c:	eb f1                	jmp    155547f <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xc1f>
 155548e:	e8 1d 19 e3 fe       	call   386db0 <__cxa_begin_catch@plt>
 1555493:	48 8d 54 24 7f       	lea    0x7f(%rsp),%rdx
 1555498:	48 8d 35 51 a3 21 00 	lea    0x21a351(%rip),%rsi        # 176f7f0 <_fini@@Base+0x18acc>
 155549f:	4c 89 ef             	mov    %r13,%rdi
 15554a2:	e8 09 e0 e4 fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 15554a7:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 15554ac:	4c 89 ee             	mov    %r13,%rsi
 15554af:	e8 6c fc e3 fe       	call   395120 <spdlog::logger::err_handler_(std::string const&)@plt>
 15554b4:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
 15554bb:	00 
 15554bc:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 15554c0:	48 3b 3d b9 76 62 00 	cmp    0x6276b9(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 15554c7:	74 05                	je     15554ce <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xc6e>
 15554c9:	e8 12 0d ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 15554ce:	e8 1d 76 e4 fe       	call   39caf0 <__cxa_rethrow@plt>
 15554d3:	48 89 c3             	mov    %rax,%rbx
 15554d6:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
 15554dd:	00 
 15554de:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 15554e2:	48 3b 3d 97 76 62 00 	cmp    0x627697(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 15554e9:	74 05                	je     15554f0 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xc90>
 15554eb:	e8 f0 0c ff ff       	call   15461e0 <RVecISUEntry::dec_entry()@@Base+0x2b0>
 15554f0:	e8 6b ab e4 fe       	call   3a0060 <__cxa_end_catch@plt>
 15554f5:	e9 71 fe ff ff       	jmp    155536b <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xb0b>
 15554fa:	48 89 c3             	mov    %rax,%rbx
 15554fd:	eb f1                	jmp    15554f0 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0xc90>
 15554ff:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 1555504:	e9 cf f9 ff ff       	jmp    1554ed8 <RVecISUEntry::issue_uop_window(std::shared_ptr<TmArray<std::shared_ptr<RVecUop> > >&, std::shared_ptr<IsuIssueStatus>&)@@Base+0x678>
 1555509:	90                   	nop
 155550a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
