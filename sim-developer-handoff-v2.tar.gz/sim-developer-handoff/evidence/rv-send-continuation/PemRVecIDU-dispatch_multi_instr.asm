
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013ec9e0 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base>:
 13ec9e0:	41 57                	push   %r15
 13ec9e2:	41 56                	push   %r14
 13ec9e4:	48 89 f0             	mov    %rsi,%rax
 13ec9e7:	41 55                	push   %r13
 13ec9e9:	41 54                	push   %r12
 13ec9eb:	55                   	push   %rbp
 13ec9ec:	53                   	push   %rbx
 13ec9ed:	48 89 fd             	mov    %rdi,%rbp
 13ec9f0:	48 8d 9d e0 03 00 00 	lea    0x3e0(%rbp),%rbx
 13ec9f7:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
 13ec9fe:	48 8b 38             	mov    (%rax),%rdi
 13eca01:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
 13eca06:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
 13eca0b:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
 13eca12:	00 00 
 13eca14:	48 89 b4 24 68 01 00 	mov    %rsi,0x168(%rsp)
 13eca1b:	00 
 13eca1c:	31 f6                	xor    %esi,%esi
 13eca1e:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
 13eca23:	e8 98 30 fa fe       	call   38fac0 <Isa::id() const@plt>
 13eca28:	48 8b 95 e8 03 00 00 	mov    0x3e8(%rbp),%rdx
 13eca2f:	48 85 d2             	test   %rdx,%rdx
 13eca32:	74 36                	je     13eca6a <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x8a>
 13eca34:	48 89 d9             	mov    %rbx,%rcx
 13eca37:	eb 13                	jmp    13eca4c <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x6c>
 13eca39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13eca40:	48 89 d1             	mov    %rdx,%rcx
 13eca43:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 13eca47:	48 85 d2             	test   %rdx,%rdx
 13eca4a:	74 0f                	je     13eca5b <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x7b>
 13eca4c:	48 3b 42 20          	cmp    0x20(%rdx),%rax
 13eca50:	76 ee                	jbe    13eca40 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x60>
 13eca52:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 13eca56:	48 85 d2             	test   %rdx,%rdx
 13eca59:	75 f1                	jne    13eca4c <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x6c>
 13eca5b:	48 39 cb             	cmp    %rcx,%rbx
 13eca5e:	74 0a                	je     13eca6a <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x8a>
 13eca60:	48 3b 41 20          	cmp    0x20(%rcx),%rax
 13eca64:	0f 83 a6 00 00 00    	jae    13ecb10 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x130>
 13eca6a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 13eca6f:	48 8b 38             	mov    (%rax),%rdi
 13eca72:	e8 29 7e f9 fe       	call   3848a0 <Isa::name() const@plt>
 13eca77:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 13eca7c:	0f 84 0c 0a 00 00    	je     13ed48e <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xaae>
 13eca82:	66 0f ef c0          	pxor   %xmm0,%xmm0
 13eca86:	bf 0c 00 00 00       	mov    $0xc,%edi
 13eca8b:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
 13eca92:	00 00 00 00 00 
 13eca97:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
 13eca9e:	00 
 13eca9f:	e8 bc 67 fa fe       	call   393260 <operator new(unsigned long)@plt>
 13ecaa4:	48 8d 50 0c          	lea    0xc(%rax),%rdx
 13ecaa8:	48 8b 0d 11 ba 42 00 	mov    0x42ba11(%rip),%rcx        # 18184c0 <typeinfo name for std::_Bind<void (TmQue<std::shared_ptr<GsuUbReq> >::*(TmQue<std::shared_ptr<GsuUbReq> >*))()>@@Base+0x440>
 13ecaaf:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 13ecab6:	00 
 13ecab7:	48 89 94 24 f0 00 00 	mov    %rdx,0xf0(%rsp)
 13ecabe:	00 
 13ecabf:	48 89 94 24 e8 00 00 	mov    %rdx,0xe8(%rsp)
 13ecac6:	00 
 13ecac7:	48 89 08             	mov    %rcx,(%rax)
 13ecaca:	8b 0d f8 b9 42 00    	mov    0x42b9f8(%rip),%ecx        # 18184c8 <typeinfo name for std::_Bind<void (TmQue<std::shared_ptr<GsuUbReq> >::*(TmQue<std::shared_ptr<GsuUbReq> >*))()>@@Base+0x448>
 13ecad0:	89 48 08             	mov    %ecx,0x8(%rax)
 13ecad3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 13ecad8:	48 8b 38             	mov    (%rax),%rdi
 13ecadb:	e8 e0 2f fa fe       	call   38fac0 <Isa::id() const@plt>
 13ecae0:	48 8d 94 24 e0 00 00 	lea    0xe0(%rsp),%rdx
 13ecae7:	00 
 13ecae8:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
 13ecaed:	48 8d bd d8 03 00 00 	lea    0x3d8(%rbp),%rdi
 13ecaf4:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
 13ecaf9:	e8 f2 18 fa fe       	call   38e3f0 <std::pair<std::_Rb_tree_iterator<std::pair<unsigned long const, std::vector<isa_pipe_t, std::allocator<isa_pipe_t> > > >, bool> std::_Rb_tree<unsigned long, std::pair<unsigned long const, std::vector<isa_pipe_t, std::allocator<isa_pipe_t> > >, std::_Select1st<std::pair<unsigned long const, std::vector<isa_pipe_t, std::allocator<isa_pipe_t> > > >, std::less<unsigned long>, std::allocator<std::pair<unsigned long const, std::vector<isa_pipe_t, std::allocator<isa_pipe_t> > > > >::_M_emplace_unique<unsigned long, std::vector<isa_pipe_t, std::allocator<isa_pipe_t> >&>(unsigned long&&, std::vector<isa_pipe_t, std::allocator<isa_pipe_t> >&)@plt>
 13ecafe:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
 13ecb05:	00 
 13ecb06:	48 85 ff             	test   %rdi,%rdi
 13ecb09:	74 05                	je     13ecb10 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x130>
 13ecb0b:	e8 10 59 fa fe       	call   392420 <operator delete(void*)@plt>
 13ecb10:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 13ecb15:	48 8b 38             	mov    (%rax),%rdi
 13ecb18:	e8 a3 2f fa fe       	call   38fac0 <Isa::id() const@plt>
 13ecb1d:	48 8b 95 e8 03 00 00 	mov    0x3e8(%rbp),%rdx
 13ecb24:	48 85 d2             	test   %rdx,%rdx
 13ecb27:	0f 84 28 0a 00 00    	je     13ed555 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb75>
 13ecb2d:	48 89 d9             	mov    %rbx,%rcx
 13ecb30:	eb 12                	jmp    13ecb44 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x164>
 13ecb32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13ecb38:	48 89 d1             	mov    %rdx,%rcx
 13ecb3b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 13ecb3f:	48 85 d2             	test   %rdx,%rdx
 13ecb42:	74 0f                	je     13ecb53 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x173>
 13ecb44:	48 3b 42 20          	cmp    0x20(%rdx),%rax
 13ecb48:	76 ee                	jbe    13ecb38 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x158>
 13ecb4a:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 13ecb4e:	48 85 d2             	test   %rdx,%rdx
 13ecb51:	75 f1                	jne    13ecb44 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x164>
 13ecb53:	48 39 cb             	cmp    %rcx,%rbx
 13ecb56:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
 13ecb5b:	0f 84 f4 09 00 00    	je     13ed555 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb75>
 13ecb61:	48 3b 41 20          	cmp    0x20(%rcx),%rax
 13ecb65:	0f 82 ea 09 00 00    	jb     13ed555 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb75>
 13ecb6b:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
 13ecb70:	4c 8b 71 28          	mov    0x28(%rcx),%r14
 13ecb74:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 13ecb79:	48 8d 84 24 b8 00 00 	lea    0xb8(%rsp),%rax
 13ecb80:	00 
 13ecb81:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 13ecb86:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13ecb8b:	48 8b 40 30          	mov    0x30(%rax),%rax
 13ecb8f:	49 39 c6             	cmp    %rax,%r14
 13ecb92:	0f 84 ad 06 00 00    	je     13ed245 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x865>
 13ecb98:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 13ecb9d:	31 c9                	xor    %ecx,%ecx
 13ecb9f:	48 8b 18             	mov    (%rax),%rbx
 13ecba2:	48 8b 83 40 02 00 00 	mov    0x240(%rbx),%rax
 13ecba9:	48 8b b3 58 02 00 00 	mov    0x258(%rbx),%rsi
 13ecbb0:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
 13ecbb5:	8b 83 48 02 00 00    	mov    0x248(%rbx),%eax
 13ecbbb:	89 44 24 68          	mov    %eax,0x68(%rsp)
 13ecbbf:	48 8b 83 50 02 00 00 	mov    0x250(%rbx),%rax
 13ecbc6:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
 13ecbcb:	48 8b 83 60 02 00 00 	mov    0x260(%rbx),%rax
 13ecbd2:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
 13ecbd9:	00 00 
 13ecbdb:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
 13ecbe2:	00 00 00 00 00 
 13ecbe7:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
 13ecbee:	00 00 00 00 00 
 13ecbf3:	49 89 c4             	mov    %rax,%r12
 13ecbf6:	49 29 f4             	sub    %rsi,%r12
 13ecbf9:	4c 89 e2             	mov    %r12,%rdx
 13ecbfc:	4d 89 e5             	mov    %r12,%r13
 13ecbff:	48 c1 fa 03          	sar    $0x3,%rdx
 13ecc03:	48 85 d2             	test   %rdx,%rdx
 13ecc06:	74 32                	je     13ecc3a <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x25a>
 13ecc08:	48 b8 ff ff ff ff ff 	movabs $0x1fffffffffffffff,%rax
 13ecc0f:	ff ff 1f 
 13ecc12:	48 39 c2             	cmp    %rax,%rdx
 13ecc15:	0f 87 ae 08 00 00    	ja     13ed4c9 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xae9>
 13ecc1b:	4c 89 e7             	mov    %r12,%rdi
 13ecc1e:	e8 3d 66 fa fe       	call   393260 <operator new(unsigned long)@plt>
 13ecc23:	48 89 c1             	mov    %rax,%rcx
 13ecc26:	48 8b 83 60 02 00 00 	mov    0x260(%rbx),%rax
 13ecc2d:	48 8b b3 58 02 00 00 	mov    0x258(%rbx),%rsi
 13ecc34:	49 89 c5             	mov    %rax,%r13
 13ecc37:	49 29 f5             	sub    %rsi,%r13
 13ecc3a:	49 01 cc             	add    %rcx,%r12
 13ecc3d:	48 39 f0             	cmp    %rsi,%rax
 13ecc40:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
 13ecc45:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
 13ecc4c:	00 
 13ecc4d:	4c 89 a4 24 88 00 00 	mov    %r12,0x88(%rsp)
 13ecc54:	00 
 13ecc55:	74 0e                	je     13ecc65 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x285>
 13ecc57:	48 89 cf             	mov    %rcx,%rdi
 13ecc5a:	4c 89 ea             	mov    %r13,%rdx
 13ecc5d:	e8 fe 31 fb fe       	call   39fe60 <memmove@plt>
 13ecc62:	48 89 c1             	mov    %rax,%rcx
 13ecc65:	48 8b 83 70 02 00 00 	mov    0x270(%rbx),%rax
 13ecc6c:	4c 01 e9             	add    %r13,%rcx
 13ecc6f:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
 13ecc76:	00 
 13ecc77:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
 13ecc7e:	00 
 13ecc7f:	8b 83 78 02 00 00    	mov    0x278(%rbx),%eax
 13ecc85:	89 84 24 98 00 00 00 	mov    %eax,0x98(%rsp)
 13ecc8c:	8b 83 7c 02 00 00    	mov    0x27c(%rbx),%eax
 13ecc92:	89 84 24 9c 00 00 00 	mov    %eax,0x9c(%rsp)
 13ecc99:	8b 83 80 02 00 00    	mov    0x280(%rbx),%eax
 13ecc9f:	89 84 24 a0 00 00 00 	mov    %eax,0xa0(%rsp)
 13ecca6:	48 8b 83 88 02 00 00 	mov    0x288(%rbx),%rax
 13eccad:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13eccb1:	e8 ba 0e ff ff       	call   13ddb70 <IDU_ARegHazard::reset()@@Base+0x60>
 13eccb6:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
 13eccbb:	48 c7 84 24 c0 00 00 	movq   $0x0,0xc0(%rsp)
 13eccc2:	00 00 00 00 00 
 13eccc7:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
 13eccce:	00 
 13ecccf:	c7 84 24 b8 00 00 00 	movl   $0x0,0xb8(%rsp)
 13eccd6:	00 00 00 00 
 13eccda:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
 13ecce1:	00 00 00 00 00 
 13ecce6:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
 13ecced:	00 
 13eccee:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
 13eccf5:	00 
 13eccf6:	48 8b b3 a0 02 00 00 	mov    0x2a0(%rbx),%rsi
 13eccfd:	48 85 f6             	test   %rsi,%rsi
 13ecd00:	74 71                	je     13ecd73 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x393>
 13ecd02:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 13ecd07:	48 8d 8c 24 e0 00 00 	lea    0xe0(%rsp),%rcx
 13ecd0e:	00 
 13ecd0f:	48 8d 78 50          	lea    0x50(%rax),%rdi
 13ecd13:	48 89 bc 24 e0 00 00 	mov    %rdi,0xe0(%rsp)
 13ecd1a:	00 
 13ecd1b:	e8 a0 b9 fa fe       	call   3986c0 <std::_Rb_tree_node<unsigned int>* std::_Rb_tree<unsigned int, unsigned int, std::_Identity<unsigned int>, std::less<unsigned int>, std::allocator<unsigned int> >::_M_copy<std::_Rb_tree<unsigned int, unsigned int, std::_Identity<unsigned int>, std::less<unsigned int>, std::allocator<unsigned int> >::_Alloc_node>(std::_Rb_tree_node<unsigned int> const*, std::_Rb_tree_node_base*, std::_Rb_tree<unsigned int, unsigned int, std::_Identity<unsigned int>, std::less<unsigned int>, std::allocator<unsigned int> >::_Alloc_node&)@plt>
 13ecd20:	48 89 c1             	mov    %rax,%rcx
 13ecd23:	eb 06                	jmp    13ecd2b <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x34b>
 13ecd25:	0f 1f 00             	nopl   (%rax)
 13ecd28:	48 89 d1             	mov    %rdx,%rcx
 13ecd2b:	48 8b 51 10          	mov    0x10(%rcx),%rdx
 13ecd2f:	48 85 d2             	test   %rdx,%rdx
 13ecd32:	75 f4                	jne    13ecd28 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x348>
 13ecd34:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 13ecd3b:	00 
 13ecd3c:	48 89 c1             	mov    %rax,%rcx
 13ecd3f:	eb 0a                	jmp    13ecd4b <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x36b>
 13ecd41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13ecd48:	48 89 d1             	mov    %rdx,%rcx
 13ecd4b:	48 8b 51 18          	mov    0x18(%rcx),%rdx
 13ecd4f:	48 85 d2             	test   %rdx,%rdx
 13ecd52:	75 f4                	jne    13ecd48 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x368>
 13ecd54:	48 8b 93 b8 02 00 00 	mov    0x2b8(%rbx),%rdx
 13ecd5b:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
 13ecd62:	00 
 13ecd63:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
 13ecd6a:	00 
 13ecd6b:	48 89 94 24 d8 00 00 	mov    %rdx,0xd8(%rsp)
 13ecd72:	00 
 13ecd73:	41 8b 06             	mov    (%r14),%eax
 13ecd76:	bf 28 03 00 00       	mov    $0x328,%edi
 13ecd7b:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
 13ecd82:	00 00 
 13ecd84:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
 13ecd8b:	00 00 
 13ecd8d:	89 84 24 9c 00 00 00 	mov    %eax,0x9c(%rsp)
 13ecd94:	e8 c7 64 fa fe       	call   393260 <operator new(unsigned long)@plt>
 13ecd99:	49 89 c4             	mov    %rax,%r12
 13ecd9c:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
 13ecda3:	00 00 00 
 13ecda6:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
 13ecdab:	49 89 44 24 08       	mov    %rax,0x8(%r12)
 13ecdb0:	48 8b 05 51 5d 79 00 	mov    0x795d51(%rip),%rax        # 1b82b08 <vtable for std::_Sp_counted_ptr_inplace<Isa, std::allocator<Isa>, (__gnu_cxx::_Lock_policy)2>@@Base+0x38970>
 13ecdb7:	31 c9                	xor    %ecx,%ecx
 13ecdb9:	4d 8d 6c 24 10       	lea    0x10(%r12),%r13
 13ecdbe:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
 13ecdc5:	00 00 00 00 00 
 13ecdca:	48 c7 84 24 00 01 00 	movq   $0x0,0x100(%rsp)
 13ecdd1:	00 00 00 00 00 
 13ecdd6:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
 13ecddd:	00 00 00 00 00 
 13ecde2:	48 83 c0 10          	add    $0x10,%rax
 13ecde6:	49 89 04 24          	mov    %rax,(%r12)
 13ecdea:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
 13ecdef:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 13ecdf6:	00 
 13ecdf7:	8b 44 24 68          	mov    0x68(%rsp),%eax
 13ecdfb:	89 84 24 e8 00 00 00 	mov    %eax,0xe8(%rsp)
 13ece02:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
 13ece07:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
 13ece0e:	00 
 13ece0f:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 13ece16:	00 
 13ece17:	48 89 c3             	mov    %rax,%rbx
 13ece1a:	48 29 f3             	sub    %rsi,%rbx
 13ece1d:	48 89 da             	mov    %rbx,%rdx
 13ece20:	49 89 df             	mov    %rbx,%r15
 13ece23:	48 c1 fa 03          	sar    $0x3,%rdx
 13ece27:	48 85 d2             	test   %rdx,%rdx
 13ece2a:	74 31                	je     13ece5d <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x47d>
 13ece2c:	48 b8 ff ff ff ff ff 	movabs $0x1fffffffffffffff,%rax
 13ece33:	ff ff 1f 
 13ece36:	48 39 c2             	cmp    %rax,%rdx
 13ece39:	0f 87 c1 06 00 00    	ja     13ed500 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb20>
 13ece3f:	48 89 df             	mov    %rbx,%rdi
 13ece42:	e8 19 64 fa fe       	call   393260 <operator new(unsigned long)@plt>
 13ece47:	48 89 c1             	mov    %rax,%rcx
 13ece4a:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 13ece51:	00 
 13ece52:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
 13ece57:	49 89 c7             	mov    %rax,%r15
 13ece5a:	49 29 f7             	sub    %rsi,%r15
 13ece5d:	48 01 cb             	add    %rcx,%rbx
 13ece60:	48 39 f0             	cmp    %rsi,%rax
 13ece63:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
 13ece6a:	00 
 13ece6b:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
 13ece72:	00 
 13ece73:	48 89 9c 24 08 01 00 	mov    %rbx,0x108(%rsp)
 13ece7a:	00 
 13ece7b:	74 0e                	je     13ece8b <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x4ab>
 13ece7d:	48 89 cf             	mov    %rcx,%rdi
 13ece80:	4c 89 fa             	mov    %r15,%rdx
 13ece83:	e8 d8 2f fb fe       	call   39fe60 <memmove@plt>
 13ece88:	48 89 c1             	mov    %rax,%rcx
 13ece8b:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
 13ece92:	00 
 13ece93:	4c 01 f9             	add    %r15,%rcx
 13ece96:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
 13ece9d:	00 
 13ece9e:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
 13ecea5:	00 
 13ecea6:	8b 84 24 98 00 00 00 	mov    0x98(%rsp),%eax
 13ecead:	89 84 24 18 01 00 00 	mov    %eax,0x118(%rsp)
 13eceb4:	8b 84 24 9c 00 00 00 	mov    0x9c(%rsp),%eax
 13ecebb:	89 84 24 1c 01 00 00 	mov    %eax,0x11c(%rsp)
 13ecec2:	8b 84 24 a0 00 00 00 	mov    0xa0(%rsp),%eax
 13ecec9:	89 84 24 20 01 00 00 	mov    %eax,0x120(%rsp)
 13eced0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
 13eced7:	00 
 13eced8:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ecedc:	e8 8f 0c ff ff       	call   13ddb70 <IDU_ARegHazard::reset()@@Base+0x60>
 13ecee1:	48 8d 9c 24 e0 00 00 	lea    0xe0(%rsp),%rbx
 13ecee8:	00 
 13ecee9:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
 13ecef0:	00 
 13ecef1:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
 13ecef8:	00 
 13ecef9:	c7 84 24 38 01 00 00 	movl   $0x0,0x138(%rsp)
 13ecf00:	00 00 00 00 
 13ecf04:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
 13ecf0b:	00 00 00 00 00 
 13ecf10:	48 8d 53 58          	lea    0x58(%rbx),%rdx
 13ecf14:	48 c7 84 24 58 01 00 	movq   $0x0,0x158(%rsp)
 13ecf1b:	00 00 00 00 00 
 13ecf20:	48 85 f6             	test   %rsi,%rsi
 13ecf23:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
 13ecf2a:	00 
 13ecf2b:	48 89 94 24 50 01 00 	mov    %rdx,0x150(%rsp)
 13ecf32:	00 
 13ecf33:	74 67                	je     13ecf9c <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x5bc>
 13ecf35:	48 8d 7b 50          	lea    0x50(%rbx),%rdi
 13ecf39:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
 13ecf3e:	48 89 7c 24 50       	mov    %rdi,0x50(%rsp)
 13ecf43:	e8 78 b7 fa fe       	call   3986c0 <std::_Rb_tree_node<unsigned int>* std::_Rb_tree<unsigned int, unsigned int, std::_Identity<unsigned int>, std::less<unsigned int>, std::allocator<unsigned int> >::_M_copy<std::_Rb_tree<unsigned int, unsigned int, std::_Identity<unsigned int>, std::less<unsigned int>, std::allocator<unsigned int> >::_Alloc_node>(std::_Rb_tree_node<unsigned int> const*, std::_Rb_tree_node_base*, std::_Rb_tree<unsigned int, unsigned int, std::_Identity<unsigned int>, std::less<unsigned int>, std::allocator<unsigned int> >::_Alloc_node&)@plt>
 13ecf48:	48 89 c1             	mov    %rax,%rcx
 13ecf4b:	eb 06                	jmp    13ecf53 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x573>
 13ecf4d:	0f 1f 00             	nopl   (%rax)
 13ecf50:	48 89 d1             	mov    %rdx,%rcx
 13ecf53:	48 8b 51 10          	mov    0x10(%rcx),%rdx
 13ecf57:	48 85 d2             	test   %rdx,%rdx
 13ecf5a:	75 f4                	jne    13ecf50 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x570>
 13ecf5c:	48 89 8c 24 48 01 00 	mov    %rcx,0x148(%rsp)
 13ecf63:	00 
 13ecf64:	48 89 c1             	mov    %rax,%rcx
 13ecf67:	eb 0a                	jmp    13ecf73 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x593>
 13ecf69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13ecf70:	48 89 d1             	mov    %rdx,%rcx
 13ecf73:	48 8b 51 18          	mov    0x18(%rcx),%rdx
 13ecf77:	48 85 d2             	test   %rdx,%rdx
 13ecf7a:	75 f4                	jne    13ecf70 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x590>
 13ecf7c:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
 13ecf83:	00 
 13ecf84:	48 89 8c 24 50 01 00 	mov    %rcx,0x150(%rsp)
 13ecf8b:	00 
 13ecf8c:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
 13ecf93:	00 
 13ecf94:	48 89 94 24 58 01 00 	mov    %rdx,0x158(%rsp)
 13ecf9b:	00 
 13ecf9c:	48 89 de             	mov    %rbx,%rsi
 13ecf9f:	4c 89 ef             	mov    %r13,%rdi
 13ecfa2:	e8 b9 40 fb fe       	call   3a1060 <Isa::Isa(IsaBasicInfo)@plt>
 13ecfa7:	4c 8b bc 24 40 01 00 	mov    0x140(%rsp),%r15
 13ecfae:	00 
 13ecfaf:	4d 85 ff             	test   %r15,%r15
 13ecfb2:	74 29                	je     13ecfdd <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x5fd>
 13ecfb4:	48 8d 43 50          	lea    0x50(%rbx),%rax
 13ecfb8:	48 89 04 24          	mov    %rax,(%rsp)
 13ecfbc:	49 8b 77 18          	mov    0x18(%r15),%rsi
 13ecfc0:	48 8b 3c 24          	mov    (%rsp),%rdi
 13ecfc4:	e8 67 c2 fa fe       	call   399230 <std::_Rb_tree<unsigned int, unsigned int, std::_Identity<unsigned int>, std::less<unsigned int>, std::allocator<unsigned int> >::_M_erase(std::_Rb_tree_node<unsigned int>*)@plt>
 13ecfc9:	4d 8b 6f 10          	mov    0x10(%r15),%r13
 13ecfcd:	4c 89 ff             	mov    %r15,%rdi
 13ecfd0:	e8 4b 54 fa fe       	call   392420 <operator delete(void*)@plt>
 13ecfd5:	4d 85 ed             	test   %r13,%r13
 13ecfd8:	4d 89 ef             	mov    %r13,%r15
 13ecfdb:	75 df                	jne    13ecfbc <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x5dc>
 13ecfdd:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
 13ecfe4:	00 
 13ecfe5:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ecfe9:	48 3b 3d 90 fb 78 00 	cmp    0x78fb90(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ecff0:	0f 85 22 04 00 00    	jne    13ed418 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xa38>
 13ecff6:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
 13ecffd:	00 
 13ecffe:	48 85 ff             	test   %rdi,%rdi
 13ed001:	74 05                	je     13ed008 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x628>
 13ed003:	e8 18 54 fa fe       	call   392420 <operator delete(void*)@plt>
 13ed008:	49 8b 04 24          	mov    (%r12),%rax
 13ed00c:	4c 89 e7             	mov    %r12,%rdi
 13ed00f:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
 13ed014:	48 8b 35 55 57 79 00 	mov    0x795755(%rip),%rsi        # 1b82770 <typeinfo for std::_Sp_make_shared_tag@@Base+0x3d918>
 13ed01b:	4c 8d 6c 24 50       	lea    0x50(%rsp),%r13
 13ed020:	4c 8d 64 24 40       	lea    0x40(%rsp),%r12
 13ed025:	ff 50 20             	call   *0x20(%rax)
 13ed028:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 13ed02d:	48 89 df             	mov    %rbx,%rdi
 13ed030:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 13ed035:	e8 a6 54 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed03a:	4c 89 e6             	mov    %r12,%rsi
 13ed03d:	4c 89 ef             	mov    %r13,%rdi
 13ed040:	e8 9b 54 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed045:	48 89 da             	mov    %rbx,%rdx
 13ed048:	4c 89 ee             	mov    %r13,%rsi
 13ed04b:	48 89 ef             	mov    %rbp,%rdi
 13ed04e:	e8 1d 40 fa fe       	call   391070 <PemRVecIDU::update_new_isa(std::shared_ptr<Isa>, std::shared_ptr<Isa>) const@plt>
 13ed053:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
 13ed058:	48 85 ff             	test   %rdi,%rdi
 13ed05b:	74 05                	je     13ed062 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x682>
 13ed05d:	e8 2e 48 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed062:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed069:	00 
 13ed06a:	48 85 ff             	test   %rdi,%rdi
 13ed06d:	74 05                	je     13ed074 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x694>
 13ed06f:	e8 1c 48 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed074:	4c 8b ad 18 02 00 00 	mov    0x218(%rbp),%r13
 13ed07b:	48 89 ef             	mov    %rbp,%rdi
 13ed07e:	49 8b 45 00          	mov    0x0(%r13),%rax
 13ed082:	4c 8b 78 18          	mov    0x18(%rax),%r15
 13ed086:	e8 45 2c fa fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13ed08b:	4c 89 e6             	mov    %r12,%rsi
 13ed08e:	48 89 df             	mov    %rbx,%rdi
 13ed091:	48 89 04 24          	mov    %rax,(%rsp)
 13ed095:	e8 46 54 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed09a:	48 8b 04 24          	mov    (%rsp),%rax
 13ed09e:	48 89 de             	mov    %rbx,%rsi
 13ed0a1:	4c 89 ef             	mov    %r13,%rdi
 13ed0a4:	48 89 c2             	mov    %rax,%rdx
 13ed0a7:	41 ff d7             	call   *%r15
 13ed0aa:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed0b1:	00 
 13ed0b2:	48 85 ff             	test   %rdi,%rdi
 13ed0b5:	74 05                	je     13ed0bc <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x6dc>
 13ed0b7:	e8 d4 47 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed0bc:	4c 8b ad 28 02 00 00 	mov    0x228(%rbp),%r13
 13ed0c3:	48 89 ef             	mov    %rbp,%rdi
 13ed0c6:	49 8b 45 00          	mov    0x0(%r13),%rax
 13ed0ca:	4c 8b 78 18          	mov    0x18(%rax),%r15
 13ed0ce:	e8 fd 2b fa fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 13ed0d3:	4c 89 e6             	mov    %r12,%rsi
 13ed0d6:	48 89 df             	mov    %rbx,%rdi
 13ed0d9:	48 89 04 24          	mov    %rax,(%rsp)
 13ed0dd:	e8 fe 53 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed0e2:	48 8b 04 24          	mov    (%rsp),%rax
 13ed0e6:	48 89 de             	mov    %rbx,%rsi
 13ed0e9:	4c 89 ef             	mov    %r13,%rdi
 13ed0ec:	48 89 c2             	mov    %rax,%rdx
 13ed0ef:	41 ff d7             	call   *%r15
 13ed0f2:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed0f9:	00 
 13ed0fa:	48 85 ff             	test   %rdi,%rdi
 13ed0fd:	74 05                	je     13ed104 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x724>
 13ed0ff:	e8 8c 47 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed104:	4c 8b bd 78 02 00 00 	mov    0x278(%rbp),%r15
 13ed10b:	49 8b 47 08          	mov    0x8(%r15),%rax
 13ed10f:	49 8b 37             	mov    (%r15),%rsi
 13ed112:	48 89 c1             	mov    %rax,%rcx
 13ed115:	48 29 f1             	sub    %rsi,%rcx
 13ed118:	48 89 ca             	mov    %rcx,%rdx
 13ed11b:	48 c1 fa 02          	sar    $0x2,%rdx
 13ed11f:	48 85 d2             	test   %rdx,%rdx
 13ed122:	0f 84 10 03 00 00    	je     13ed438 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xa58>
 13ed128:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
 13ed12f:	ff ff 3f 
 13ed132:	48 39 c2             	cmp    %rax,%rdx
 13ed135:	0f 87 93 03 00 00    	ja     13ed4ce <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xaee>
 13ed13b:	48 89 cf             	mov    %rcx,%rdi
 13ed13e:	e8 1d 61 fa fe       	call   393260 <operator new(unsigned long)@plt>
 13ed143:	49 89 c5             	mov    %rax,%r13
 13ed146:	49 89 c0             	mov    %rax,%r8
 13ed149:	49 8b 47 08          	mov    0x8(%r15),%rax
 13ed14d:	49 8b 37             	mov    (%r15),%rsi
 13ed150:	48 89 c1             	mov    %rax,%rcx
 13ed153:	48 29 f1             	sub    %rsi,%rcx
 13ed156:	48 39 f0             	cmp    %rsi,%rax
 13ed159:	74 1d                	je     13ed178 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x798>
 13ed15b:	48 89 ca             	mov    %rcx,%rdx
 13ed15e:	4c 89 ef             	mov    %r13,%rdi
 13ed161:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
 13ed166:	48 89 0c 24          	mov    %rcx,(%rsp)
 13ed16a:	e8 f1 2c fb fe       	call   39fe60 <memmove@plt>
 13ed16f:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
 13ed174:	48 8b 0c 24          	mov    (%rsp),%rcx
 13ed178:	4c 01 e9             	add    %r13,%rcx
 13ed17b:	4c 89 e6             	mov    %r12,%rsi
 13ed17e:	48 89 df             	mov    %rbx,%rdi
 13ed181:	4c 39 c1             	cmp    %r8,%rcx
 13ed184:	0f 84 06 01 00 00    	je     13ed290 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x8b0>
 13ed18a:	e8 51 53 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed18f:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 13ed194:	48 89 de             	mov    %rbx,%rsi
 13ed197:	48 89 ef             	mov    %rbp,%rdi
 13ed19a:	e8 01 d2 f9 fe       	call   38a3a0 <PemRVecIDU::log_dispatch_failed(std::shared_ptr<Isa>, unsigned int&)@plt>
 13ed19f:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed1a6:	00 
 13ed1a7:	48 85 ff             	test   %rdi,%rdi
 13ed1aa:	74 05                	je     13ed1b1 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x7d1>
 13ed1ac:	e8 df 46 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed1b1:	49 83 c6 04          	add    $0x4,%r14
 13ed1b5:	4d 85 ed             	test   %r13,%r13
 13ed1b8:	74 08                	je     13ed1c2 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x7e2>
 13ed1ba:	4c 89 ef             	mov    %r13,%rdi
 13ed1bd:	e8 5e 52 fa fe       	call   392420 <operator delete(void*)@plt>
 13ed1c2:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
 13ed1c7:	48 85 ff             	test   %rdi,%rdi
 13ed1ca:	74 05                	je     13ed1d1 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x7f1>
 13ed1cc:	e8 bf 46 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed1d1:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
 13ed1d8:	00 
 13ed1d9:	4d 85 ed             	test   %r13,%r13
 13ed1dc:	74 29                	je     13ed207 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x827>
 13ed1de:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 13ed1e3:	4c 8d 60 50          	lea    0x50(%rax),%r12
 13ed1e7:	49 8b 75 18          	mov    0x18(%r13),%rsi
 13ed1eb:	4c 89 e7             	mov    %r12,%rdi
 13ed1ee:	e8 3d c0 fa fe       	call   399230 <std::_Rb_tree<unsigned int, unsigned int, std::_Identity<unsigned int>, std::less<unsigned int>, std::allocator<unsigned int> >::_M_erase(std::_Rb_tree_node<unsigned int>*)@plt>
 13ed1f3:	49 8b 5d 10          	mov    0x10(%r13),%rbx
 13ed1f7:	4c 89 ef             	mov    %r13,%rdi
 13ed1fa:	e8 21 52 fa fe       	call   392420 <operator delete(void*)@plt>
 13ed1ff:	48 85 db             	test   %rbx,%rbx
 13ed202:	49 89 dd             	mov    %rbx,%r13
 13ed205:	75 e0                	jne    13ed1e7 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x807>
 13ed207:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
 13ed20e:	00 
 13ed20f:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ed213:	48 3b 3d 66 f9 78 00 	cmp    0x78f966(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ed21a:	0f 85 08 02 00 00    	jne    13ed428 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xa48>
 13ed220:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
 13ed225:	48 85 ff             	test   %rdi,%rdi
 13ed228:	0f 84 58 f9 ff ff    	je     13ecb86 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x1a6>
 13ed22e:	e8 ed 51 fa fe       	call   392420 <operator delete(void*)@plt>
 13ed233:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13ed238:	48 8b 40 30          	mov    0x30(%rax),%rax
 13ed23c:	49 39 c6             	cmp    %rax,%r14
 13ed23f:	0f 85 53 f9 ff ff    	jne    13ecb98 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x1b8>
 13ed245:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 13ed24a:	48 8b 56 28          	mov    0x28(%rsi),%rdx
 13ed24e:	49 39 d6             	cmp    %rdx,%r14
 13ed251:	0f 84 ec 01 00 00    	je     13ed443 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xa63>
 13ed257:	48 39 c2             	cmp    %rax,%rdx
 13ed25a:	0f 94 c0             	sete   %al
 13ed25d:	48 8b b4 24 68 01 00 	mov    0x168(%rsp),%rsi
 13ed264:	00 
 13ed265:	64 48 33 34 25 28 00 	xor    %fs:0x28,%rsi
 13ed26c:	00 00 
 13ed26e:	0f 85 5b 03 00 00    	jne    13ed5cf <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xbef>
 13ed274:	48 81 c4 78 01 00 00 	add    $0x178,%rsp
 13ed27b:	5b                   	pop    %rbx
 13ed27c:	5d                   	pop    %rbp
 13ed27d:	41 5c                	pop    %r12
 13ed27f:	41 5d                	pop    %r13
 13ed281:	41 5e                	pop    %r14
 13ed283:	41 5f                	pop    %r15
 13ed285:	c3                   	ret
 13ed286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 13ed28d:	00 00 00 
 13ed290:	e8 4b 52 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed295:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
 13ed29a:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 13ed29f:	48 89 de             	mov    %rbx,%rsi
 13ed2a2:	48 89 ef             	mov    %rbp,%rdi
 13ed2a5:	e8 c6 48 f9 fe       	call   381b70 <PemRVecIDU::dispatch_multi_instr_body(std::shared_ptr<Isa>, unsigned int&, bool&)@plt>
 13ed2aa:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed2b1:	00 
 13ed2b2:	48 85 ff             	test   %rdi,%rdi
 13ed2b5:	74 05                	je     13ed2bc <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x8dc>
 13ed2b7:	e8 d4 45 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed2bc:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 13ed2c1:	4c 89 e6             	mov    %r12,%rsi
 13ed2c4:	48 89 df             	mov    %rbx,%rdi
 13ed2c7:	80 38 00             	cmpb   $0x0,(%rax)
 13ed2ca:	0f 84 28 01 00 00    	je     13ed3f8 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xa18>
 13ed2d0:	e8 0b 52 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed2d5:	48 89 de             	mov    %rbx,%rsi
 13ed2d8:	48 89 ef             	mov    %rbp,%rdi
 13ed2db:	e8 20 6f f9 fe       	call   384200 <PemRVecIDU::log_dispatch_bar_instr(std::shared_ptr<Isa>)@plt>
 13ed2e0:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed2e7:	00 
 13ed2e8:	48 85 ff             	test   %rdi,%rdi
 13ed2eb:	74 05                	je     13ed2f2 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x912>
 13ed2ed:	e8 9e 45 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed2f2:	4c 8b bd 18 02 00 00 	mov    0x218(%rbp),%r15
 13ed2f9:	4c 89 e6             	mov    %r12,%rsi
 13ed2fc:	48 89 df             	mov    %rbx,%rdi
 13ed2ff:	49 8b 07             	mov    (%r15),%rax
 13ed302:	48 8b 40 20          	mov    0x20(%rax),%rax
 13ed306:	48 89 04 24          	mov    %rax,(%rsp)
 13ed30a:	e8 d1 51 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed30f:	48 89 de             	mov    %rbx,%rsi
 13ed312:	4c 89 ff             	mov    %r15,%rdi
 13ed315:	48 8b 04 24          	mov    (%rsp),%rax
 13ed319:	ff d0                	call   *%rax
 13ed31b:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed322:	00 
 13ed323:	48 85 ff             	test   %rdi,%rdi
 13ed326:	74 05                	je     13ed32d <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x94d>
 13ed328:	e8 63 45 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed32d:	4c 8b bd 28 02 00 00 	mov    0x228(%rbp),%r15
 13ed334:	4c 89 e6             	mov    %r12,%rsi
 13ed337:	48 89 df             	mov    %rbx,%rdi
 13ed33a:	49 8b 07             	mov    (%r15),%rax
 13ed33d:	48 8b 40 20          	mov    0x20(%rax),%rax
 13ed341:	48 89 04 24          	mov    %rax,(%rsp)
 13ed345:	e8 96 51 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed34a:	48 89 de             	mov    %rbx,%rsi
 13ed34d:	4c 89 ff             	mov    %r15,%rdi
 13ed350:	48 8b 04 24          	mov    (%rsp),%rax
 13ed354:	ff d0                	call   *%rax
 13ed356:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed35d:	00 
 13ed35e:	48 85 ff             	test   %rdi,%rdi
 13ed361:	74 05                	je     13ed368 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x988>
 13ed363:	e8 28 45 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed368:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
 13ed36d:	49 8d 76 04          	lea    0x4(%r14),%rsi
 13ed371:	48 8b 53 30          	mov    0x30(%rbx),%rdx
 13ed375:	48 39 f2             	cmp    %rsi,%rdx
 13ed378:	74 0f                	je     13ed389 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x9a9>
 13ed37a:	48 29 f2             	sub    %rsi,%rdx
 13ed37d:	4c 89 f7             	mov    %r14,%rdi
 13ed380:	e8 db 2a fb fe       	call   39fe60 <memmove@plt>
 13ed385:	48 8b 53 30          	mov    0x30(%rbx),%rdx
 13ed389:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 13ed38e:	48 83 ea 04          	sub    $0x4,%rdx
 13ed392:	4d 85 ed             	test   %r13,%r13
 13ed395:	48 89 50 30          	mov    %rdx,0x30(%rax)
 13ed399:	74 08                	je     13ed3a3 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x9c3>
 13ed39b:	4c 89 ef             	mov    %r13,%rdi
 13ed39e:	e8 7d 50 fa fe       	call   392420 <operator delete(void*)@plt>
 13ed3a3:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
 13ed3a8:	48 85 ff             	test   %rdi,%rdi
 13ed3ab:	74 05                	je     13ed3b2 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x9d2>
 13ed3ad:	e8 de 44 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed3b2:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
 13ed3b9:	00 
 13ed3ba:	4d 85 ed             	test   %r13,%r13
 13ed3bd:	0f 84 44 fe ff ff    	je     13ed207 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x827>
 13ed3c3:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 13ed3c8:	4c 8d 60 50          	lea    0x50(%rax),%r12
 13ed3cc:	49 8b 75 18          	mov    0x18(%r13),%rsi
 13ed3d0:	4c 89 e7             	mov    %r12,%rdi
 13ed3d3:	e8 58 be fa fe       	call   399230 <std::_Rb_tree<unsigned int, unsigned int, std::_Identity<unsigned int>, std::less<unsigned int>, std::allocator<unsigned int> >::_M_erase(std::_Rb_tree_node<unsigned int>*)@plt>
 13ed3d8:	49 8b 5d 10          	mov    0x10(%r13),%rbx
 13ed3dc:	4c 89 ef             	mov    %r13,%rdi
 13ed3df:	e8 3c 50 fa fe       	call   392420 <operator delete(void*)@plt>
 13ed3e4:	48 85 db             	test   %rbx,%rbx
 13ed3e7:	49 89 dd             	mov    %rbx,%r13
 13ed3ea:	75 e0                	jne    13ed3cc <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x9ec>
 13ed3ec:	e9 16 fe ff ff       	jmp    13ed207 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x827>
 13ed3f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13ed3f8:	e8 e3 50 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed3fd:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 13ed402:	48 89 de             	mov    %rbx,%rsi
 13ed405:	48 89 ef             	mov    %rbp,%rdi
 13ed408:	e8 93 cf f9 fe       	call   38a3a0 <PemRVecIDU::log_dispatch_failed(std::shared_ptr<Isa>, unsigned int&)@plt>
 13ed40d:	e9 8d fd ff ff       	jmp    13ed19f <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x7bf>
 13ed412:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13ed418:	e8 b3 06 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13ed41d:	e9 d4 fb ff ff       	jmp    13ecff6 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x616>
 13ed422:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13ed428:	e8 a3 06 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13ed42d:	e9 ee fd ff ff       	jmp    13ed220 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x840>
 13ed432:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 13ed438:	45 31 c0             	xor    %r8d,%r8d
 13ed43b:	45 31 ed             	xor    %r13d,%r13d
 13ed43e:	e9 13 fd ff ff       	jmp    13ed156 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x776>
 13ed443:	48 8d 9c 24 e0 00 00 	lea    0xe0(%rsp),%rbx
 13ed44a:	00 
 13ed44b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 13ed450:	48 89 df             	mov    %rbx,%rdi
 13ed453:	e8 88 50 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed458:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 13ed45d:	48 89 da             	mov    %rbx,%rdx
 13ed460:	48 89 ef             	mov    %rbp,%rdi
 13ed463:	8b 30                	mov    (%rax),%esi
 13ed465:	e8 36 5b fa fe       	call   392fa0 <PemRVecIDU::do_dispatch_update_pmu(unsigned int, std::shared_ptr<Isa>)@plt>
 13ed46a:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed471:	00 
 13ed472:	48 85 ff             	test   %rdi,%rdi
 13ed475:	74 05                	je     13ed47c <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xa9c>
 13ed477:	e8 14 44 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed47c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 13ed481:	48 8b 46 30          	mov    0x30(%rsi),%rax
 13ed485:	48 8b 56 28          	mov    0x28(%rsi),%rdx
 13ed489:	e9 c9 fd ff ff       	jmp    13ed257 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x877>
 13ed48e:	4c 8d a4 24 e0 00 00 	lea    0xe0(%rsp),%r12
 13ed495:	00 
 13ed496:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 13ed49b:	4c 89 e7             	mov    %r12,%rdi
 13ed49e:	e8 3d 50 fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed4a3:	4c 89 e6             	mov    %r12,%rsi
 13ed4a6:	48 89 ef             	mov    %rbp,%rdi
 13ed4a9:	e8 92 4e fa fe       	call   392340 <PemRVecIDU::gen_smem_bar_pipe(std::shared_ptr<Isa>)@plt>
 13ed4ae:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed4b5:	00 
 13ed4b6:	48 85 ff             	test   %rdi,%rdi
 13ed4b9:	0f 84 51 f6 ff ff    	je     13ecb10 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x130>
 13ed4bf:	e8 cc 43 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed4c4:	e9 47 f6 ff ff       	jmp    13ecb10 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0x130>
 13ed4c9:	e8 62 8a f9 fe       	call   385f30 <std::__throw_bad_alloc()@plt>
 13ed4ce:	e8 5d 8a f9 fe       	call   385f30 <std::__throw_bad_alloc()@plt>
 13ed4d3:	48 89 c3             	mov    %rax,%rbx
 13ed4d6:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
 13ed4db:	48 85 ff             	test   %rdi,%rdi
 13ed4de:	74 05                	je     13ed4e5 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb05>
 13ed4e0:	e8 ab 43 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed4e5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 13ed4ea:	e8 21 b8 fa fe       	call   398d10 <IsaBasicInfo::~IsaBasicInfo()@plt>
 13ed4ef:	48 89 df             	mov    %rbx,%rdi
 13ed4f2:	e8 89 58 fb fe       	call   3a2d80 <_Unwind_Resume@plt>
 13ed4f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 13ed4fe:	00 00 
 13ed500:	e8 2b 8a f9 fe       	call   385f30 <std::__throw_bad_alloc()@plt>
 13ed505:	48 89 c3             	mov    %rax,%rbx
 13ed508:	4c 89 e7             	mov    %r12,%rdi
 13ed50b:	e8 10 4f fa fe       	call   392420 <operator delete(void*)@plt>
 13ed510:	eb d3                	jmp    13ed4e5 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb05>
 13ed512:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
 13ed517:	48 89 c3             	mov    %rax,%rbx
 13ed51a:	48 85 ff             	test   %rdi,%rdi
 13ed51d:	74 05                	je     13ed524 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb44>
 13ed51f:	e8 6c 43 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed524:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed52b:	00 
 13ed52c:	48 85 ff             	test   %rdi,%rdi
 13ed52f:	74 a5                	je     13ed4d6 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xaf6>
 13ed531:	e8 5a 43 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed536:	eb 9e                	jmp    13ed4d6 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xaf6>
 13ed538:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed53f:	00 
 13ed540:	48 89 c3             	mov    %rax,%rbx
 13ed543:	48 85 ff             	test   %rdi,%rdi
 13ed546:	74 05                	je     13ed54d <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb6d>
 13ed548:	e8 43 43 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed54d:	48 89 df             	mov    %rbx,%rdi
 13ed550:	e8 2b 58 fb fe       	call   3a2d80 <_Unwind_Resume@plt>
 13ed555:	48 8d 3d 44 9b 36 00 	lea    0x369b44(%rip),%rdi        # 17570a0 <_fini@@Base+0x37c>
 13ed55c:	e8 7f f2 fa fe       	call   39c7e0 <std::__throw_out_of_range(char const*)@plt>
 13ed561:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
 13ed568:	00 
 13ed569:	48 89 c3             	mov    %rax,%rbx
 13ed56c:	48 85 ff             	test   %rdi,%rdi
 13ed56f:	74 dc                	je     13ed54d <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb6d>
 13ed571:	e8 aa 4e fa fe       	call   392420 <operator delete(void*)@plt>
 13ed576:	eb d5                	jmp    13ed54d <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb6d>
 13ed578:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
 13ed57f:	00 
 13ed580:	48 89 c3             	mov    %rax,%rbx
 13ed583:	48 85 ff             	test   %rdi,%rdi
 13ed586:	74 05                	je     13ed58d <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xbad>
 13ed588:	e8 03 43 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed58d:	4d 85 ed             	test   %r13,%r13
 13ed590:	0f 84 40 ff ff ff    	je     13ed4d6 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xaf6>
 13ed596:	4c 89 ef             	mov    %r13,%rdi
 13ed599:	e8 82 4e fa fe       	call   392420 <operator delete(void*)@plt>
 13ed59e:	e9 33 ff ff ff       	jmp    13ed4d6 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xaf6>
 13ed5a3:	eb d3                	jmp    13ed578 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb98>
 13ed5a5:	48 89 c3             	mov    %rax,%rbx
 13ed5a8:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
 13ed5af:	00 
 13ed5b0:	48 85 ff             	test   %rdi,%rdi
 13ed5b3:	0f 84 4f ff ff ff    	je     13ed508 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb28>
 13ed5b9:	e8 62 4e fa fe       	call   392420 <operator delete(void*)@plt>
 13ed5be:	e9 45 ff ff ff       	jmp    13ed508 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb28>
 13ed5c3:	eb b3                	jmp    13ed578 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb98>
 13ed5c5:	48 89 c3             	mov    %rax,%rbx
 13ed5c8:	e9 18 ff ff ff       	jmp    13ed4e5 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb05>
 13ed5cd:	eb a9                	jmp    13ed578 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb98>
 13ed5cf:	e8 ec 80 fa fe       	call   3956c0 <__stack_chk_fail@plt>
 13ed5d4:	48 89 c3             	mov    %rax,%rbx
 13ed5d7:	e9 48 ff ff ff       	jmp    13ed524 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb44>
 13ed5dc:	eb f6                	jmp    13ed5d4 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xbf4>
 13ed5de:	48 89 c3             	mov    %rax,%rbx
 13ed5e1:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
 13ed5e8:	00 
 13ed5e9:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ed5ed:	48 3b 3d 8c f5 78 00 	cmp    0x78f58c(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ed5f4:	74 05                	je     13ed5fb <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xc1b>
 13ed5f6:	e8 d5 04 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13ed5fb:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
 13ed600:	48 85 ff             	test   %rdi,%rdi
 13ed603:	0f 85 68 ff ff ff    	jne    13ed571 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb91>
 13ed609:	e9 3f ff ff ff       	jmp    13ed54d <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb6d>
 13ed60e:	48 89 c3             	mov    %rax,%rbx
 13ed611:	eb e8                	jmp    13ed5fb <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xc1b>
 13ed613:	e9 60 ff ff ff       	jmp    13ed578 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb98>
 13ed618:	e9 5b ff ff ff       	jmp    13ed578 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb98>
 13ed61d:	48 89 c5             	mov    %rax,%rbp
 13ed620:	48 89 df             	mov    %rbx,%rdi
 13ed623:	e8 e8 b6 fa fe       	call   398d10 <IsaBasicInfo::~IsaBasicInfo()@plt>
 13ed628:	48 89 eb             	mov    %rbp,%rbx
 13ed62b:	e9 d8 fe ff ff       	jmp    13ed508 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb28>
 13ed630:	48 89 c3             	mov    %rax,%rbx
 13ed633:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
 13ed63a:	00 
 13ed63b:	48 8d 78 e8          	lea    -0x18(%rax),%rdi
 13ed63f:	48 3b 3d 3a f5 78 00 	cmp    0x78f53a(%rip),%rdi        # 1b7cb80 <std::string::_Rep::_S_empty_rep_storage@GLIBCXX_3.4>
 13ed646:	0f 84 5c ff ff ff    	je     13ed5a8 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xbc8>
 13ed64c:	e8 7f 04 ff ff       	call   13ddad0 <IDU_OOOPhyRegAvail::update(std::shared_ptr<Isa>)@@Base+0x380>
 13ed651:	e9 52 ff ff ff       	jmp    13ed5a8 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xbc8>
 13ed656:	e9 06 ff ff ff       	jmp    13ed561 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb81>
 13ed65b:	e9 d8 fe ff ff       	jmp    13ed538 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@@Base+0xb58>
