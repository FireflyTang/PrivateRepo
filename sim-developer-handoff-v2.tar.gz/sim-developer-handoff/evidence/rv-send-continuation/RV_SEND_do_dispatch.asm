
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

00000000013ed660 <PemRVecIDU::do_dispatch()@@Base>:
 13ed660:	41 57                	push   %r15
 13ed662:	41 56                	push   %r14
 13ed664:	41 55                	push   %r13
 13ed666:	41 54                	push   %r12
 13ed668:	55                   	push   %rbp
 13ed669:	53                   	push   %rbx
 13ed66a:	48 89 fb             	mov    %rdi,%rbx
 13ed66d:	4c 8d ab b0 01 00 00 	lea    0x1b0(%rbx),%r13
 13ed674:	48 83 ec 58          	sub    $0x58,%rsp
 13ed678:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 13ed67f:	00 00 
 13ed681:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 13ed686:	31 c0                	xor    %eax,%eax
 13ed688:	c6 44 24 1a 01       	movb   $0x1,0x1a(%rsp)
 13ed68d:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
 13ed692:	48 8d 6c 24 30       	lea    0x30(%rsp),%rbp
 13ed697:	e8 d4 58 f9 fe       	call   382f70 <PemRVecIDU::pre_dispatch()@plt>
 13ed69c:	4c 8d 74 24 1a       	lea    0x1a(%rsp),%r14
 13ed6a1:	c7 44 24 1c 00 00 00 	movl   $0x0,0x1c(%rsp)
 13ed6a8:	00 
 13ed6a9:	31 c0                	xor    %eax,%eax
 13ed6ab:	4c 8d 7c 24 1c       	lea    0x1c(%rsp),%r15
 13ed6b0:	e9 84 01 00 00       	jmp    13ed839 <PemRVecIDU::do_dispatch()@@Base+0x1d9>
 13ed6b5:	0f 1f 00             	nopl   (%rax)
 13ed6b8:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 13ed6bd:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 13ed6c2:	48 85 ff             	test   %rdi,%rdi
 13ed6c5:	0f 84 e5 01 00 00    	je     13ed8b0 <PemRVecIDU::do_dispatch()@@Base+0x250>
 13ed6cb:	e8 d0 71 f9 fe       	call   3848a0 <Isa::name() const@plt>
 13ed6d0:	3d fd 01 00 00       	cmp    $0x1fd,%eax
 13ed6d5:	0f 84 9d 01 00 00    	je     13ed878 <PemRVecIDU::do_dispatch()@@Base+0x218>
 13ed6db:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 13ed6e0:	e8 bb 71 f9 fe       	call   3848a0 <Isa::name() const@plt>
 13ed6e5:	3d f8 01 00 00       	cmp    $0x1f8,%eax
 13ed6ea:	0f 84 88 01 00 00    	je     13ed878 <PemRVecIDU::do_dispatch()@@Base+0x218>
 13ed6f0:	4c 89 e6             	mov    %r12,%rsi
 13ed6f3:	48 89 ef             	mov    %rbp,%rdi
 13ed6f6:	e8 e5 4d fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed6fb:	4c 89 f1             	mov    %r14,%rcx
 13ed6fe:	4c 89 fa             	mov    %r15,%rdx
 13ed701:	48 89 ee             	mov    %rbp,%rsi
 13ed704:	48 89 df             	mov    %rbx,%rdi
 13ed707:	e8 d4 32 f9 fe       	call   3809e0 <PemRVecIDU::dispatch_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@plt>
 13ed70c:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13ed711:	48 85 ff             	test   %rdi,%rdi
 13ed714:	74 0e                	je     13ed724 <PemRVecIDU::do_dispatch()@@Base+0xc4>
 13ed716:	88 44 24 0f          	mov    %al,0xf(%rsp)
 13ed71a:	e8 71 41 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed71f:	0f b6 44 24 0f       	movzbl 0xf(%rsp),%eax
 13ed724:	84 c0                	test   %al,%al
 13ed726:	0f 84 84 01 00 00    	je     13ed8b0 <PemRVecIDU::do_dispatch()@@Base+0x250>
 13ed72c:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 13ed731:	e8 6a 71 f9 fe       	call   3848a0 <Isa::name() const@plt>
 13ed736:	3d 18 01 00 00       	cmp    $0x118,%eax
 13ed73b:	0f 84 cf 01 00 00    	je     13ed910 <PemRVecIDU::do_dispatch()@@Base+0x2b0>
 13ed741:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 13ed746:	48 8b bb 08 01 00 00 	mov    0x108(%rbx),%rdi
 13ed74d:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 13ed752:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 13ed757:	48 85 c0             	test   %rax,%rax
 13ed75a:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 13ed75f:	74 13                	je     13ed774 <PemRVecIDU::do_dispatch()@@Base+0x114>
 13ed761:	48 83 3d 67 6c 79 00 	cmpq   $0x0,0x796c67(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 13ed768:	00 
 13ed769:	0f 84 91 01 00 00    	je     13ed900 <PemRVecIDU::do_dispatch()@@Base+0x2a0>
 13ed76f:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 13ed774:	48 89 ee             	mov    %rbp,%rsi
 13ed777:	e8 d4 f2 f9 fe       	call   38ca50 <PemRVecPerfIDU::idu_disp(std::shared_ptr<Isa>)@plt>
 13ed77c:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13ed781:	48 85 ff             	test   %rdi,%rdi
 13ed784:	74 05                	je     13ed78b <PemRVecIDU::do_dispatch()@@Base+0x12b>
 13ed786:	e8 05 41 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed78b:	4c 89 e6             	mov    %r12,%rsi
 13ed78e:	48 89 df             	mov    %rbx,%rdi
 13ed791:	e8 aa 49 f9 fe       	call   382140 <PemRVecIDU::clear_fail_reason(std::shared_ptr<Isa> const&)@plt>
 13ed796:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
 13ed79a:	48 c1 e0 04          	shl    $0x4,%rax
 13ed79e:	4c 01 e8             	add    %r13,%rax
 13ed7a1:	48 8b 78 08          	mov    0x8(%rax),%rdi
 13ed7a5:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
 13ed7ac:	48 c7 40 08 00 00 00 	movq   $0x0,0x8(%rax)
 13ed7b3:	00 
 13ed7b4:	48 85 ff             	test   %rdi,%rdi
 13ed7b7:	74 05                	je     13ed7be <PemRVecIDU::do_dispatch()@@Base+0x15e>
 13ed7b9:	e8 d2 40 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed7be:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 13ed7c3:	83 ab 10 02 00 00 01 	subl   $0x1,0x210(%rbx)
 13ed7ca:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 13ed7cf:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 13ed7d4:	48 85 c0             	test   %rax,%rax
 13ed7d7:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 13ed7dc:	74 13                	je     13ed7f1 <PemRVecIDU::do_dispatch()@@Base+0x191>
 13ed7de:	48 83 3d ea 6b 79 00 	cmpq   $0x0,0x796bea(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 13ed7e5:	00 
 13ed7e6:	0f 84 04 01 00 00    	je     13ed8f0 <PemRVecIDU::do_dispatch()@@Base+0x290>
 13ed7ec:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 13ed7f1:	48 89 ee             	mov    %rbp,%rsi
 13ed7f4:	48 89 df             	mov    %rbx,%rdi
 13ed7f7:	e8 44 5a f9 fe       	call   383240 <PemRVecIDU::log_dispatch(std::shared_ptr<Isa>)@plt>
 13ed7fc:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13ed801:	48 85 ff             	test   %rdi,%rdi
 13ed804:	74 05                	je     13ed80b <PemRVecIDU::do_dispatch()@@Base+0x1ab>
 13ed806:	e8 85 40 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed80b:	4c 89 e6             	mov    %r12,%rsi
 13ed80e:	48 89 df             	mov    %rbx,%rdi
 13ed811:	e8 2a 96 fa fe       	call   396e40 <PemRVecIDU::log_idu_disp(std::shared_ptr<Isa> const&)@plt>
 13ed816:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13ed81b:	48 85 ff             	test   %rdi,%rdi
 13ed81e:	74 05                	je     13ed825 <PemRVecIDU::do_dispatch()@@Base+0x1c5>
 13ed820:	e8 6b 40 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed825:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
 13ed829:	83 c0 01             	add    $0x1,%eax
 13ed82c:	83 f8 05             	cmp    $0x5,%eax
 13ed82f:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
 13ed833:	0f 87 87 00 00 00    	ja     13ed8c0 <PemRVecIDU::do_dispatch()@@Base+0x260>
 13ed839:	48 c1 e0 04          	shl    $0x4,%rax
 13ed83d:	48 8b bc 03 b0 01 00 	mov    0x1b0(%rbx,%rax,1),%rdi
 13ed844:	00 
 13ed845:	49 8b 44 05 08       	mov    0x8(%r13,%rax,1),%rax
 13ed84a:	48 85 c0             	test   %rax,%rax
 13ed84d:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
 13ed852:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 13ed857:	0f 84 65 fe ff ff    	je     13ed6c2 <PemRVecIDU::do_dispatch()@@Base+0x62>
 13ed85d:	48 83 3d 6b 6b 79 00 	cmpq   $0x0,0x796b6b(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 13ed864:	00 
 13ed865:	0f 85 4d fe ff ff    	jne    13ed6b8 <PemRVecIDU::do_dispatch()@@Base+0x58>
 13ed86b:	83 40 08 01          	addl   $0x1,0x8(%rax)
 13ed86f:	e9 4e fe ff ff       	jmp    13ed6c2 <PemRVecIDU::do_dispatch()@@Base+0x62>
 13ed874:	0f 1f 40 00          	nopl   0x0(%rax)
 13ed878:	4c 89 e6             	mov    %r12,%rsi
 13ed87b:	48 89 ef             	mov    %rbp,%rdi
 13ed87e:	e8 5d 4c fb fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 13ed883:	4c 89 f1             	mov    %r14,%rcx
 13ed886:	4c 89 fa             	mov    %r15,%rdx
 13ed889:	48 89 ee             	mov    %rbp,%rsi
 13ed88c:	48 89 df             	mov    %rbx,%rdi
 13ed88f:	e8 fc 24 fa fe       	call   38fd90 <PemRVecIDU::dispatch_multi_instr(std::shared_ptr<Isa>, unsigned int&, bool&)@plt>
 13ed894:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 13ed899:	48 85 ff             	test   %rdi,%rdi
 13ed89c:	74 0e                	je     13ed8ac <PemRVecIDU::do_dispatch()@@Base+0x24c>
 13ed89e:	88 44 24 0f          	mov    %al,0xf(%rsp)
 13ed8a2:	e8 e9 3f 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed8a7:	0f b6 44 24 0f       	movzbl 0xf(%rsp),%eax
 13ed8ac:	84 c0                	test   %al,%al
 13ed8ae:	75 78                	jne    13ed928 <PemRVecIDU::do_dispatch()@@Base+0x2c8>
 13ed8b0:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 13ed8b5:	48 85 ff             	test   %rdi,%rdi
 13ed8b8:	74 06                	je     13ed8c0 <PemRVecIDU::do_dispatch()@@Base+0x260>
 13ed8ba:	e8 d1 3f 9a ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 13ed8bf:	90                   	nop
 13ed8c0:	48 89 df             	mov    %rbx,%rdi
 13ed8c3:	e8 38 cf fa fe       	call   39a800 <PemRVecIDU::post_dispatch()@plt>
 13ed8c8:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
 13ed8cd:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 13ed8d4:	00 00 
 13ed8d6:	0f 85 8e 00 00 00    	jne    13ed96a <PemRVecIDU::do_dispatch()@@Base+0x30a>
 13ed8dc:	48 83 c4 58          	add    $0x58,%rsp
 13ed8e0:	5b                   	pop    %rbx
 13ed8e1:	5d                   	pop    %rbp
 13ed8e2:	41 5c                	pop    %r12
 13ed8e4:	41 5d                	pop    %r13
 13ed8e6:	41 5e                	pop    %r14
 13ed8e8:	41 5f                	pop    %r15
 13ed8ea:	c3                   	ret
 13ed8eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 13ed8f0:	83 40 08 01          	addl   $0x1,0x8(%rax)
 13ed8f4:	e9 f8 fe ff ff       	jmp    13ed7f1 <PemRVecIDU::do_dispatch()@@Base+0x191>
 13ed8f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13ed900:	83 40 08 01          	addl   $0x1,0x8(%rax)
 13ed904:	e9 6b fe ff ff       	jmp    13ed774 <PemRVecIDU::do_dispatch()@@Base+0x114>
 13ed909:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 13ed910:	48 8b bb 98 01 00 00 	mov    0x198(%rbx),%rdi
 13ed917:	4c 89 e6             	mov    %r12,%rsi
 13ed91a:	e8 a1 7f f9 fe       	call   3858c0 <PemRvecDepmgr::retire_instr(std::shared_ptr<Isa> const&)@plt>
 13ed91f:	e9 1d fe ff ff       	jmp    13ed741 <PemRVecIDU::do_dispatch()@@Base+0xe1>
 13ed924:	0f 1f 40 00          	nopl   0x0(%rax)
 13ed928:	48 8d 54 24 1b       	lea    0x1b(%rsp),%rdx
 13ed92d:	48 8d 35 66 7a 37 00 	lea    0x377a66(%rip),%rsi        # 176539a <_fini@@Base+0xe676>
 13ed934:	48 89 ef             	mov    %rbp,%rdi
 13ed937:	e8 74 5b fb fe       	call   3a34b0 <std::basic_string<char, std::char_traits<char>, std::allocator<char> >::basic_string(char const*, std::allocator<char> const&)@plt>
 13ed93c:	48 89 ea             	mov    %rbp,%rdx
 13ed93f:	4c                   	rex.WR
