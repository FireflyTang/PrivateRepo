
/home/t00826093/Ascend/9.3.0-weekly.20261104.01/cann-9.3.0/tools/simulator/Ascend950PR_9589/camodel/libpem_davinci.so:     file format elf64-x86-64


Disassembly of section .text:

0000000001436080 <PemRVecAuxScalar::process_instr()@@Base>:
 1436080:	55                   	push   %rbp
 1436081:	48 89 e5             	mov    %rsp,%rbp
 1436084:	41 57                	push   %r15
 1436086:	41 56                	push   %r14
 1436088:	41 55                	push   %r13
 143608a:	41 54                	push   %r12
 143608c:	53                   	push   %rbx
 143608d:	48 89 fb             	mov    %rdi,%rbx
 1436090:	48 81 ec 78 02 00 00 	sub    $0x278,%rsp
 1436097:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
 143609e:	00 00 
 14360a0:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 14360a4:	31 c0                	xor    %eax,%eax
 14360a6:	e8 f5 41 f5 fe       	call   38a2a0 <PemRVecAuxScalar::retire_instr()@plt>
 14360ab:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
 14360b2:	c6 83 f8 01 00 00 00 	movb   $0x0,0x1f8(%rbx)
 14360b9:	48 8b b8 f0 00 00 00 	mov    0xf0(%rax),%rdi
 14360c0:	e8 9b 16 f6 fe       	call   397760 <TmTGTPort<std::shared_ptr<Isa>, (FcType)0>::valid()@plt>
 14360c5:	84 c0                	test   %al,%al
 14360c7:	75 47                	jne    1436110 <PemRVecAuxScalar::process_instr()@@Base+0x90>
 14360c9:	48 8b bb c8 01 00 00 	mov    0x1c8(%rbx),%rdi
 14360d0:	48 8d b5 10 fe ff ff 	lea    -0x1f0(%rbp),%rsi
 14360d7:	48 c7 85 10 fe ff ff 	movq   $0x1,-0x1f0(%rbp)
 14360de:	01 00 00 00 
 14360e2:	e8 39 0e f6 fe       	call   396f20 <tm_engine::TmEvent::notify_after(unsigned long const&)@plt>
 14360e7:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 14360eb:	64 48 33 04 25 28 00 	xor    %fs:0x28,%rax
 14360f2:	00 00 
 14360f4:	0f 85 06 10 00 00    	jne    1437100 <PemRVecAuxScalar::process_instr()@@Base+0x1080>
 14360fa:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
 14360fe:	5b                   	pop    %rbx
 14360ff:	41 5c                	pop    %r12
 1436101:	41 5d                	pop    %r13
 1436103:	41 5e                	pop    %r14
 1436105:	41 5f                	pop    %r15
 1436107:	5d                   	pop    %rbp
 1436108:	c3                   	ret
 1436109:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1436110:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
 1436117:	48 8b 80 f0 00 00 00 	mov    0xf0(%rax),%rax
 143611e:	44 8b 88 fc 00 00 00 	mov    0xfc(%rax),%r9d
 1436125:	49 89 c7             	mov    %rax,%r15
 1436128:	45 85 c9             	test   %r9d,%r9d
 143612b:	0f 85 5f 04 00 00    	jne    1436590 <PemRVecAuxScalar::process_instr()@@Base+0x510>
 1436131:	49 8b 77 10          	mov    0x10(%r15),%rsi
 1436135:	49 39 77 30          	cmp    %rsi,0x30(%r15)
 1436139:	0f 84 11 04 00 00    	je     1436550 <PemRVecAuxScalar::process_instr()@@Base+0x4d0>
 143613f:	48 8d 85 c0 fd ff ff 	lea    -0x240(%rbp),%rax
 1436146:	48 89 c7             	mov    %rax,%rdi
 1436149:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 1436150:	e8 8b c3 f6 fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 1436155:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 143615c:	48 85 ff             	test   %rdi,%rdi
 143615f:	0f 84 f6 03 00 00    	je     143655b <PemRVecAuxScalar::process_instr()@@Base+0x4db>
 1436165:	4c 8b b3 18 01 00 00 	mov    0x118(%rbx),%r14
 143616c:	4d 85 f6             	test   %r14,%r14
 143616f:	4c 89 b5 a8 fd ff ff 	mov    %r14,-0x258(%rbp)
 1436176:	74 5b                	je     14361d3 <PemRVecAuxScalar::process_instr()@@Base+0x153>
 1436178:	e8 f3 46 f5 fe       	call   38a870 <Isa::pc() const@plt>
 143617d:	48 89 df             	mov    %rbx,%rdi
 1436180:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 1436187:	e8 44 9b f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 143618c:	48 89 df             	mov    %rbx,%rdi
 143618f:	49 89 c7             	mov    %rax,%r15
 1436192:	e8 39 9b f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 1436197:	48 c7 85 d0 fd ff ff 	movq   $0x0,-0x230(%rbp)
 143619e:	00 00 00 00 
 14361a2:	c7 85 d8 fd ff ff 00 	movl   $0x0,-0x228(%rbp)
 14361a9:	00 00 00 
 14361ac:	48 c7 85 e0 fd ff ff 	movq   $0x0,-0x220(%rbp)
 14361b3:	00 00 00 00 
 14361b7:	45 8b 6e 28          	mov    0x28(%r14),%r13d
 14361bb:	45 0f b6 76 78       	movzbl 0x78(%r14),%r14d
 14361c0:	41 83 fd 02          	cmp    $0x2,%r13d
 14361c4:	0f 8e 16 08 00 00    	jle    14369e0 <PemRVecAuxScalar::process_instr()@@Base+0x960>
 14361ca:	45 84 f6             	test   %r14b,%r14b
 14361cd:	0f 85 0d 08 00 00    	jne    14369e0 <PemRVecAuxScalar::process_instr()@@Base+0x960>
 14361d3:	48 89 df             	mov    %rbx,%rdi
 14361d6:	e8 f5 9a f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 14361db:	4c 8d ab 50 01 00 00 	lea    0x150(%rbx),%r13
 14361e2:	4c 8d bd 10 fe ff ff 	lea    -0x1f0(%rbp),%r15
 14361e9:	49 89 c6             	mov    %rax,%r14
 14361ec:	4c 89 ff             	mov    %r15,%rdi
 14361ef:	4c 89 ee             	mov    %r13,%rsi
 14361f2:	e8 09 95 f5 fe       	call   38f700 <std::__shared_ptr<PMU, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<PMU, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 14361f7:	48 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%rdi
 14361fe:	48 85 ff             	test   %rdi,%rdi
 1436201:	74 12                	je     1436215 <PemRVecAuxScalar::process_instr()@@Base+0x195>
 1436203:	b9 01 00 00 00       	mov    $0x1,%ecx
 1436208:	4c 89 f2             	mov    %r14,%rdx
 143620b:	be 03 00 00 00       	mov    $0x3,%esi
 1436210:	e8 db be f5 fe       	call   3920f0 <PMU::push(unsigned int, unsigned long, unsigned long)@plt>
 1436215:	48 8b bd 18 fe ff ff 	mov    -0x1e8(%rbp),%rdi
 143621c:	48 85 ff             	test   %rdi,%rdi
 143621f:	74 05                	je     1436226 <PemRVecAuxScalar::process_instr()@@Base+0x1a6>
 1436221:	e8 6a b6 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1436226:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 143622d:	e8 3e 46 f5 fe       	call   38a870 <Isa::pc() const@plt>
 1436232:	48 89 df             	mov    %rbx,%rdi
 1436235:	49 89 c6             	mov    %rax,%r14
 1436238:	e8 93 9a f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 143623d:	4c 89 ff             	mov    %r15,%rdi
 1436240:	4c 89 ee             	mov    %r13,%rsi
 1436243:	49 89 c4             	mov    %rax,%r12
 1436246:	e8 b5 94 f5 fe       	call   38f700 <std::__shared_ptr<PMU, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<PMU, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 143624b:	48 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%rdi
 1436252:	48 85 ff             	test   %rdi,%rdi
 1436255:	74 10                	je     1436267 <PemRVecAuxScalar::process_instr()@@Base+0x1e7>
 1436257:	4c 89 f1             	mov    %r14,%rcx
 143625a:	4c 89 e2             	mov    %r12,%rdx
 143625d:	be 04 00 00 00       	mov    $0x4,%esi
 1436262:	e8 89 be f5 fe       	call   3920f0 <PMU::push(unsigned int, unsigned long, unsigned long)@plt>
 1436267:	48 8b bd 18 fe ff ff 	mov    -0x1e8(%rbp),%rdi
 143626e:	48 85 ff             	test   %rdi,%rdi
 1436271:	74 05                	je     1436278 <PemRVecAuxScalar::process_instr()@@Base+0x1f8>
 1436273:	e8 18 b6 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1436278:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 143627f:	48 8d b3 68 02 00 00 	lea    0x268(%rbx),%rsi
 1436286:	49 89 f6             	mov    %rsi,%r14
 1436289:	e8 32 98 f5 fe       	call   38fac0 <Isa::id() const@plt>
 143628e:	48 8b 93 70 02 00 00 	mov    0x270(%rbx),%rdx
 1436295:	48 85 d2             	test   %rdx,%rdx
 1436298:	74 34                	je     14362ce <PemRVecAuxScalar::process_instr()@@Base+0x24e>
 143629a:	4c 89 f1             	mov    %r14,%rcx
 143629d:	4c 89 f6             	mov    %r14,%rsi
 14362a0:	eb 12                	jmp    14362b4 <PemRVecAuxScalar::process_instr()@@Base+0x234>
 14362a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 14362a8:	48 89 d1             	mov    %rdx,%rcx
 14362ab:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 14362af:	48 85 d2             	test   %rdx,%rdx
 14362b2:	74 0f                	je     14362c3 <PemRVecAuxScalar::process_instr()@@Base+0x243>
 14362b4:	48 39 42 20          	cmp    %rax,0x20(%rdx)
 14362b8:	73 ee                	jae    14362a8 <PemRVecAuxScalar::process_instr()@@Base+0x228>
 14362ba:	48 8b 52 18          	mov    0x18(%rdx),%rdx
 14362be:	48 85 d2             	test   %rdx,%rdx
 14362c1:	75 f1                	jne    14362b4 <PemRVecAuxScalar::process_instr()@@Base+0x234>
 14362c3:	48 39 ce             	cmp    %rcx,%rsi
 14362c6:	74 06                	je     14362ce <PemRVecAuxScalar::process_instr()@@Base+0x24e>
 14362c8:	48 3b 41 20          	cmp    0x20(%rcx),%rax
 14362cc:	73 47                	jae    1436315 <PemRVecAuxScalar::process_instr()@@Base+0x295>
 14362ce:	48 89 df             	mov    %rbx,%rdi
 14362d1:	e8 fa 99 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 14362d6:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 14362dd:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 14362e4:	e8 d7 97 f5 fe       	call   38fac0 <Isa::id() const@plt>
 14362e9:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 14362f0:	48 8d bb 60 02 00 00 	lea    0x260(%rbx),%rdi
 14362f7:	4c 89 fe             	mov    %r15,%rsi
 14362fa:	f3 0f 7e 85 98 fd ff 	movq   -0x268(%rbp),%xmm0
 1436301:	ff 
 1436302:	0f 16 85 a8 fd ff ff 	movhps -0x258(%rbp),%xmm0
 1436309:	0f 29 85 10 fe ff ff 	movaps %xmm0,-0x1f0(%rbp)
 1436310:	e8 eb 6a f5 fe       	call   38ce00 <std::pair<std::_Rb_tree_iterator<std::pair<unsigned long const, unsigned long> >, bool> std::_Rb_tree<unsigned long, std::pair<unsigned long const, unsigned long>, std::_Select1st<std::pair<unsigned long const, unsigned long> >, std::less<unsigned long>, std::allocator<std::pair<unsigned long const, unsigned long> > >::_M_emplace_unique<std::pair<unsigned long, unsigned long> >(std::pair<unsigned long, unsigned long>&&)@plt>
 1436315:	be 02 00 00 00       	mov    $0x2,%esi
 143631a:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 1436321:	e8 fa c6 f5 fe       	call   392a20 <Isa::get_src_rsreg_map(unsigned int)@plt>
 1436326:	48 85 c0             	test   %rax,%rax
 1436329:	0f 84 53 01 00 00    	je     1436482 <PemRVecAuxScalar::process_instr()@@Base+0x402>
 143632f:	48 83 78 28 00       	cmpq   $0x0,0x28(%rax)
 1436334:	0f 84 48 01 00 00    	je     1436482 <PemRVecAuxScalar::process_instr()@@Base+0x402>
 143633a:	48 8b 48 18          	mov    0x18(%rax),%rcx
 143633e:	4c 8d 70 08          	lea    0x8(%rax),%r14
 1436342:	49 39 ce             	cmp    %rcx,%r14
 1436345:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
 143634c:	0f 84 30 01 00 00    	je     1436482 <PemRVecAuxScalar::process_instr()@@Base+0x402>
 1436352:	48 8d 85 a0 fe ff ff 	lea    -0x160(%rbp),%rax
 1436359:	48 89 85 70 fd ff ff 	mov    %rax,-0x290(%rbp)
 1436360:	48 83 c0 20          	add    $0x20,%rax
 1436364:	48 89 85 78 fd ff ff 	mov    %rax,-0x288(%rbp)
 143636b:	48 8d 85 70 fe ff ff 	lea    -0x190(%rbp),%rax
 1436372:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
 1436379:	48 8d 85 bf fd ff ff 	lea    -0x241(%rbp),%rax
 1436380:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
 1436387:	48 89 c8             	mov    %rcx,%rax
 143638a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1436390:	80 78 30 00          	cmpb   $0x0,0x30(%rax)
 1436394:	0f 85 cc 00 00 00    	jne    1436466 <PemRVecAuxScalar::process_instr()@@Base+0x3e6>
 143639a:	4c 8b a3 18 01 00 00 	mov    0x118(%rbx),%r12
 14363a1:	c6 83 f8 01 00 00 01 	movb   $0x1,0x1f8(%rbx)
 14363a8:	4d 85 e4             	test   %r12,%r12
 14363ab:	74 74                	je     1436421 <PemRVecAuxScalar::process_instr()@@Base+0x3a1>
 14363ad:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 14363b4:	e8 b7 44 f5 fe       	call   38a870 <Isa::pc() const@plt>
 14363b9:	48 89 df             	mov    %rbx,%rdi
 14363bc:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 14363c3:	e8 08 99 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 14363c8:	48 89 df             	mov    %rbx,%rdi
 14363cb:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 14363d2:	e8 f9 98 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 14363d7:	48 c7 85 f0 fd ff ff 	movq   $0x0,-0x210(%rbp)
 14363de:	00 00 00 00 
 14363e2:	c7 85 f8 fd ff ff 00 	movl   $0x0,-0x208(%rbp)
 14363e9:	00 00 00 
 14363ec:	48 c7 85 00 fe ff ff 	movq   $0x0,-0x200(%rbp)
 14363f3:	00 00 00 00 
 14363f7:	41 8b 4c 24 28       	mov    0x28(%r12),%ecx
 14363fc:	89 8d 88 fd ff ff    	mov    %ecx,-0x278(%rbp)
 1436402:	41 0f b6 74 24 78    	movzbl 0x78(%r12),%esi
 1436408:	83 f9 02             	cmp    $0x2,%ecx
 143640b:	40 88 b5 80 fd ff ff 	mov    %sil,-0x280(%rbp)
 1436412:	0f 8e c8 06 00 00    	jle    1436ae0 <PemRVecAuxScalar::process_instr()@@Base+0xa60>
 1436418:	40 84 f6             	test   %sil,%sil
 143641b:	0f 85 bf 06 00 00    	jne    1436ae0 <PemRVecAuxScalar::process_instr()@@Base+0xa60>
 1436421:	48 89 df             	mov    %rbx,%rdi
 1436424:	e8 a7 98 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 1436429:	4c 89 ff             	mov    %r15,%rdi
 143642c:	4c 89 ee             	mov    %r13,%rsi
 143642f:	49 89 c4             	mov    %rax,%r12
 1436432:	e8 c9 92 f5 fe       	call   38f700 <std::__shared_ptr<PMU, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<PMU, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 1436437:	48 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%rdi
 143643e:	48 85 ff             	test   %rdi,%rdi
 1436441:	74 12                	je     1436455 <PemRVecAuxScalar::process_instr()@@Base+0x3d5>
 1436443:	b9 01 00 00 00       	mov    $0x1,%ecx
 1436448:	4c 89 e2             	mov    %r12,%rdx
 143644b:	be 08 00 00 00       	mov    $0x8,%esi
 1436450:	e8 9b bc f5 fe       	call   3920f0 <PMU::push(unsigned int, unsigned long, unsigned long)@plt>
 1436455:	48 8b bd 18 fe ff ff 	mov    -0x1e8(%rbp),%rdi
 143645c:	48 85 ff             	test   %rdi,%rdi
 143645f:	74 05                	je     1436466 <PemRVecAuxScalar::process_instr()@@Base+0x3e6>
 1436461:	e8 2a b4 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1436466:	48 8b bd a8 fd ff ff 	mov    -0x258(%rbp),%rdi
 143646d:	e8 0e 6b f5 fe       	call   38cf80 <std::_Rb_tree_increment(std::_Rb_tree_node_base*)@plt>
 1436472:	49 39 c6             	cmp    %rax,%r14
 1436475:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 143647c:	0f 85 0e ff ff ff    	jne    1436390 <PemRVecAuxScalar::process_instr()@@Base+0x310>
 1436482:	48 8b b5 a0 fd ff ff 	mov    -0x260(%rbp),%rsi
 1436489:	48 89 df             	mov    %rbx,%rdi
 143648c:	e8 2f 20 f6 fe       	call   3984c0 <PemRVecAuxScalar::is_sreg_hazard(std::shared_ptr<Isa> const&)@plt>
 1436491:	84 c0                	test   %al,%al
 1436493:	74 67                	je     14364fc <PemRVecAuxScalar::process_instr()@@Base+0x47c>
 1436495:	48 8b 83 18 01 00 00 	mov    0x118(%rbx),%rax
 143649c:	c6 83 f8 01 00 00 01 	movb   $0x1,0x1f8(%rbx)
 14364a3:	48 85 c0             	test   %rax,%rax
 14364a6:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 14364ad:	74 5a                	je     1436509 <PemRVecAuxScalar::process_instr()@@Base+0x489>
 14364af:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 14364b6:	e8 b5 43 f5 fe       	call   38a870 <Isa::pc() const@plt>
 14364bb:	48 89 df             	mov    %rbx,%rdi
 14364be:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 14364c5:	e8 06 98 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 14364ca:	48 89 df             	mov    %rbx,%rdi
 14364cd:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 14364d4:	e8 f7 97 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 14364d9:	48 8b 8d a8 fd ff ff 	mov    -0x258(%rbp),%rcx
 14364e0:	44 8b 69 28          	mov    0x28(%rcx),%r13d
 14364e4:	44 0f b6 71 78       	movzbl 0x78(%rcx),%r14d
 14364e9:	41 83 fd 02          	cmp    $0x2,%r13d
 14364ed:	0f 8e f5 07 00 00    	jle    1436ce8 <PemRVecAuxScalar::process_instr()@@Base+0xc68>
 14364f3:	45 84 f6             	test   %r14b,%r14b
 14364f6:	0f 85 ec 07 00 00    	jne    1436ce8 <PemRVecAuxScalar::process_instr()@@Base+0xc68>
 14364fc:	80 bb f8 01 00 00 00 	cmpb   $0x0,0x1f8(%rbx)
 1436503:	0f 84 e7 00 00 00    	je     14365f0 <PemRVecAuxScalar::process_instr()@@Base+0x570>
 1436509:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
 1436510:	48 39 83 d0 00 00 00 	cmp    %rax,0xd0(%rbx)
 1436517:	74 1a                	je     1436533 <PemRVecAuxScalar::process_instr()@@Base+0x4b3>
 1436519:	48 8b bb c8 01 00 00 	mov    0x1c8(%rbx),%rdi
 1436520:	4c 89 fe             	mov    %r15,%rsi
 1436523:	48 c7 85 10 fe ff ff 	movq   $0x1,-0x1f0(%rbp)
 143652a:	01 00 00 00 
 143652e:	e8 ed 09 f6 fe       	call   396f20 <tm_engine::TmEvent::notify_after(unsigned long const&)@plt>
 1436533:	48 8b bd c8 fd ff ff 	mov    -0x238(%rbp),%rdi
 143653a:	48 85 ff             	test   %rdi,%rdi
 143653d:	0f 84 a4 fb ff ff    	je     14360e7 <PemRVecAuxScalar::process_instr()@@Base+0x67>
 1436543:	e8 48 b3 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 1436548:	e9 9a fb ff ff       	jmp    14360e7 <PemRVecAuxScalar::process_instr()@@Base+0x67>
 143654d:	0f 1f 00             	nopl   (%rax)
 1436550:	66 0f ef c0          	pxor   %xmm0,%xmm0
 1436554:	0f 29 85 c0 fd ff ff 	movaps %xmm0,-0x240(%rbp)
 143655b:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
 1436562:	48 39 83 b0 00 00 00 	cmp    %rax,0xb0(%rbx)
 1436569:	74 c8                	je     1436533 <PemRVecAuxScalar::process_instr()@@Base+0x4b3>
 143656b:	48 8b bb c8 01 00 00 	mov    0x1c8(%rbx),%rdi
 1436572:	48 8d b5 10 fe ff ff 	lea    -0x1f0(%rbp),%rsi
 1436579:	48 c7 85 10 fe ff ff 	movq   $0x1,-0x1f0(%rbp)
 1436580:	01 00 00 00 
 1436584:	e8 97 09 f6 fe       	call   396f20 <tm_engine::TmEvent::notify_after(unsigned long const&)@plt>
 1436589:	eb a8                	jmp    1436533 <PemRVecAuxScalar::process_instr()@@Base+0x4b3>
 143658b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1436590:	4c 8b 25 19 c3 74 00 	mov    0x74c319(%rip),%r12        # 1b828b0 <stderr@GLIBC_2.2.5>
 1436597:	4c 8d 05 62 91 3e 00 	lea    0x3e9162(%rip),%r8        # 181f700 <typeinfo name for PemRVecRegUtil::PemRVecRegUtil()::{lambda(PemRVecReg&, unsigned int, unsigned long)#17}@@Base+0x180>
 143659e:	48 8d 15 69 0b 33 00 	lea    0x330b69(%rip),%rdx        # 176710e <_fini@@Base+0x103ea>
 14365a5:	48 8d 35 e4 ab 33 00 	lea    0x33abe4(%rip),%rsi        # 1771190 <_fini@@Base+0x1a46c>
 14365ac:	b9 c5 00 00 00       	mov    $0xc5,%ecx
 14365b1:	31 c0                	xor    %eax,%eax
 14365b3:	49 8b 3c 24          	mov    (%r12),%rdi
 14365b7:	e8 54 5d f6 fe       	call   39c310 <fprintf@plt>
 14365bc:	41 8b 8f fc 00 00 00 	mov    0xfc(%r15),%ecx
 14365c3:	85 c9                	test   %ecx,%ecx
 14365c5:	0f 84 66 fb ff ff    	je     1436131 <PemRVecAuxScalar::process_instr()@@Base+0xb1>
 14365cb:	48 8b 05 b6 59 74 00 	mov    0x7459b6(%rip),%rax        # 1b7bf88 <stdout@GLIBC_2.2.5>
 14365d2:	48 8b 38             	mov    (%rax),%rdi
 14365d5:	e8 a6 05 f6 fe       	call   396b80 <fflush@plt>
 14365da:	49 8b 3c 24          	mov    (%r12),%rdi
 14365de:	e8 9d 05 f6 fe       	call   396b80 <fflush@plt>
 14365e3:	e9 49 fb ff ff       	jmp    1436131 <PemRVecAuxScalar::process_instr()@@Base+0xb1>
 14365e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 14365ef:	00 
 14365f0:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
 14365f7:	4c 89 ff             	mov    %r15,%rdi
 14365fa:	48 8b b0 f0 00 00 00 	mov    0xf0(%rax),%rsi
 1436601:	e8 4a be f5 fe       	call   392450 <TmTGTPort<std::shared_ptr<Isa>, (FcType)0>::pop_pld()@plt>
 1436606:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
 143660d:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1436611:	66 0f 6f 85 10 fe ff 	movdqa -0x1f0(%rbp),%xmm0
 1436618:	ff 
 1436619:	48 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%rdi
 1436620:	48 85 c0             	test   %rax,%rax
 1436623:	0f 29 8d 10 fe ff ff 	movaps %xmm1,-0x1f0(%rbp)
 143662a:	0f 29 85 c0 fd ff ff 	movaps %xmm0,-0x240(%rbp)
 1436631:	74 20                	je     1436653 <PemRVecAuxScalar::process_instr()@@Base+0x5d3>
 1436633:	48 89 c7             	mov    %rax,%rdi
 1436636:	e8 55 b2 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 143663b:	48 8b bd 18 fe ff ff 	mov    -0x1e8(%rbp),%rdi
 1436642:	48 85 ff             	test   %rdi,%rdi
 1436645:	74 05                	je     143664c <PemRVecAuxScalar::process_instr()@@Base+0x5cc>
 1436647:	e8 44 b2 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 143664c:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 1436653:	e8 58 a9 f5 fe       	call   390fb0 <Isa::update_decode_descr()@plt>
 1436658:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 143665f:	e8 bc e6 f6 fe       	call   3a4d20 <Isa::update_exec_descr()@plt>
 1436664:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 143666b:	4c 8d 67 10          	lea    0x10(%rdi),%r12
 143666f:	4c 8d 77 08          	lea    0x8(%rdi),%r14
 1436673:	e8 f8 41 f5 fe       	call   38a870 <Isa::pc() const@plt>
 1436678:	48 8b bb f8 00 00 00 	mov    0xf8(%rbx),%rdi
 143667f:	49 89 c5             	mov    %rax,%r13
 1436682:	e8 49 96 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 1436687:	8b b3 2c 01 00 00    	mov    0x12c(%rbx),%esi
 143668d:	8b bb 28 01 00 00    	mov    0x128(%rbx),%edi
 1436693:	48 83 ec 08          	sub    $0x8,%rsp
 1436697:	48 8d 93 40 02 00 00 	lea    0x240(%rbx),%rdx
 143669e:	41 54                	push   %r12
 14366a0:	4d 89 f1             	mov    %r14,%r9
 14366a3:	4d 89 e8             	mov    %r13,%r8
 14366a6:	48 89 c1             	mov    %rax,%rcx
 14366a9:	e8 f2 ab f6 fe       	call   3a12a0 <pem_log::dump_instr_popped_log(unsigned int, unsigned int, std::shared_ptr<spdlog::logger> const&, unsigned long, unsigned long, std::string const&, std::string const&)@plt>
 14366ae:	58                   	pop    %rax
 14366af:	5a                   	pop    %rdx
 14366b0:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 14366b7:	e8 e4 e1 f4 fe       	call   3848a0 <Isa::name() const@plt>
 14366bc:	3d f1 01 00 00       	cmp    $0x1f1,%eax
 14366c1:	74 17                	je     14366da <PemRVecAuxScalar::process_instr()@@Base+0x65a>
 14366c3:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 14366ca:	e8 d1 e1 f4 fe       	call   3848a0 <Isa::name() const@plt>
 14366cf:	3d f3 01 00 00       	cmp    $0x1f3,%eax
 14366d4:	0f 85 06 05 00 00    	jne    1436be0 <PemRVecAuxScalar::process_instr()@@Base+0xb60>
 14366da:	48 89 df             	mov    %rbx,%rdi
 14366dd:	e8 ee 95 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 14366e2:	bf 38 00 00 00       	mov    $0x38,%edi
 14366e7:	49 89 c4             	mov    %rax,%r12
 14366ea:	48 c7 85 10 fe ff ff 	movq   $0x0,-0x1f0(%rbp)
 14366f1:	00 00 00 00 
 14366f5:	48 c7 85 18 fe ff ff 	movq   $0x0,-0x1e8(%rbp)
 14366fc:	00 00 00 00 
 1436700:	e8 5b cb f5 fe       	call   393260 <operator new(unsigned long)@plt>
 1436705:	49 89 c6             	mov    %rax,%r14
 1436708:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
 143670f:	00 00 00 
 1436712:	48 8b b5 a0 fd ff ff 	mov    -0x260(%rbp),%rsi
 1436719:	49 89 46 08          	mov    %rax,0x8(%r14)
 143671d:	48 8b 05 44 b9 74 00 	mov    0x74b944(%rip),%rax        # 1b82068 <vtable for std::_Sp_counted_ptr_inplace<Retire_Uop, std::allocator<Retire_Uop>, (__gnu_cxx::_Lock_policy)2>@@Base+0x2cf20>
 1436724:	49 8d 7e 10          	lea    0x10(%r14),%rdi
 1436728:	48 83 c0 10          	add    $0x10,%rax
 143672c:	49 89 06             	mov    %rax,(%r14)
 143672f:	e8 ac bd f6 fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 1436734:	49 8b 06             	mov    (%r14),%rax
 1436737:	41 c7 46 20 00 00 00 	movl   $0x0,0x20(%r14)
 143673e:	00 
 143673f:	4c 89 f7             	mov    %r14,%rdi
 1436742:	4d 89 66 28          	mov    %r12,0x28(%r14)
 1436746:	41 c6 46 30 01       	movb   $0x1,0x30(%r14)
 143674b:	41 c6 46 31 00       	movb   $0x0,0x31(%r14)
 1436750:	41 c7 46 34 00 00 00 	movl   $0x0,0x34(%r14)
 1436757:	00 
 1436758:	4c 89 b5 18 fe ff ff 	mov    %r14,-0x1e8(%rbp)
 143675f:	48 8b 35 0a c0 74 00 	mov    0x74c00a(%rip),%rsi        # 1b82770 <typeinfo for std::_Sp_make_shared_tag@@Base+0x3d918>
 1436766:	ff 50 20             	call   *0x20(%rax)
 1436769:	48 8b 8b e0 00 00 00 	mov    0xe0(%rbx),%rcx
 1436770:	48 8b 93 d0 00 00 00 	mov    0xd0(%rbx),%rdx
 1436777:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 143677e:	48 83 e9 10          	sub    $0x10,%rcx
 1436782:	48 39 ca             	cmp    %rcx,%rdx
 1436785:	0f 84 05 07 00 00    	je     1436e90 <PemRVecAuxScalar::process_instr()@@Base+0xe10>
 143678b:	48 89 02             	mov    %rax,(%rdx)
 143678e:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
 1436795:	48 85 c0             	test   %rax,%rax
 1436798:	48 89 42 08          	mov    %rax,0x8(%rdx)
 143679c:	74 12                	je     14367b0 <PemRVecAuxScalar::process_instr()@@Base+0x730>
 143679e:	48 83 3d 2a dc 74 00 	cmpq   $0x0,0x74dc2a(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 14367a5:	00 
 14367a6:	0f 85 24 05 00 00    	jne    1436cd0 <PemRVecAuxScalar::process_instr()@@Base+0xc50>
 14367ac:	83 40 08 01          	addl   $0x1,0x8(%rax)
 14367b0:	48 83 c2 10          	add    $0x10,%rdx
 14367b4:	48 89 93 d0 00 00 00 	mov    %rdx,0xd0(%rbx)
 14367bb:	4c 89 fe             	mov    %r15,%rsi
 14367be:	48 89 df             	mov    %rbx,%rdi
 14367c1:	e8 5a ce f5 fe       	call   393620 <PemRVecAuxScalar::exec_ld_st_instr(std::shared_ptr<Retire_Uop>&) const@plt>
 14367c6:	48 8b bd 18 fe ff ff 	mov    -0x1e8(%rbp),%rdi
 14367cd:	48 85 ff             	test   %rdi,%rdi
 14367d0:	74 05                	je     14367d7 <PemRVecAuxScalar::process_instr()@@Base+0x757>
 14367d2:	e8 b9 b0 95 ff       	call   d91890 <std::map<spr_reg_t, std::string, std::less<spr_reg_t>, std::allocator<std::pair<spr_reg_t const, std::string> > >::~map()@@Base+0x70>
 14367d7:	48 8b b5 a0 fd ff ff 	mov    -0x260(%rbp),%rsi
 14367de:	48 89 df             	mov    %rbx,%rdi
 14367e1:	e8 8a 89 f6 fe       	call   39f170 <PemRVecAuxScalar::add_wait_commit_tab(std::shared_ptr<Isa> const&)@plt>
 14367e6:	4c 8b b3 18 01 00 00 	mov    0x118(%rbx),%r14
 14367ed:	4d 85 f6             	test   %r14,%r14
 14367f0:	4c 89 b5 a8 fd ff ff 	mov    %r14,-0x258(%rbp)
 14367f7:	0f 84 0c fd ff ff    	je     1436509 <PemRVecAuxScalar::process_instr()@@Base+0x489>
 14367fd:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 1436804:	e8 67 40 f5 fe       	call   38a870 <Isa::pc() const@plt>
 1436809:	48 89 df             	mov    %rbx,%rdi
 143680c:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 1436813:	e8 b8 94 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 1436818:	48 89 df             	mov    %rbx,%rdi
 143681b:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 1436822:	e8 a9 94 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 1436827:	45 8b 6e 28          	mov    0x28(%r14),%r13d
 143682b:	45 0f b6 76 78       	movzbl 0x78(%r14),%r14d
 1436830:	41 83 fd 02          	cmp    $0x2,%r13d
 1436834:	7e 09                	jle    143683f <PemRVecAuxScalar::process_instr()@@Base+0x7bf>
 1436836:	45 84 f6             	test   %r14b,%r14b
 1436839:	0f 84 ca fc ff ff    	je     1436509 <PemRVecAuxScalar::process_instr()@@Base+0x489>
 143683f:	48 8b 15 d2 6d 74 00 	mov    0x746dd2(%rip),%rdx        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 1436846:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 143684d:	4c 8d a5 a0 fe ff ff 	lea    -0x160(%rbp),%r12
 1436854:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
 143685b:	4c 8d 85 70 fe ff ff 	lea    -0x190(%rbp),%r8
 1436862:	48 8d 35 87 96 34 00 	lea    0x349687(%rip),%rsi        # 177fef0 <_fini@@Base+0x291cc>
 1436869:	45 31 c9             	xor    %r9d,%r9d
 143686c:	b9 44 04 00 00       	mov    $0x444,%ecx
 1436871:	4c 89 e7             	mov    %r12,%rdi
 1436874:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
 143687b:	49 8d 54 24 20       	lea    0x20(%r12),%rdx
 1436880:	48 c7 85 a8 fe ff ff 	movq   $0x0,-0x158(%rbp)
 1436887:	00 00 00 00 
 143688b:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 1436892:	48 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%rax
 1436899:	48 89 95 a0 fe ff ff 	mov    %rdx,-0x160(%rbp)
 14368a0:	ba 40 00 00 00       	mov    $0x40,%edx
 14368a5:	48 c7 85 b0 fe ff ff 	movq   $0xfa,-0x150(%rbp)
 14368ac:	fa 00 00 00 
 14368b0:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 14368b7:	e8 54 d4 f6 fe       	call   3a3d10 <fmt::v11::detail::vformat_to(fmt::v11::detail::buffer<char>&, fmt::v11::basic_string_view<char>, fmt::v11::basic_format_args<fmt::v11::context>, fmt::v11::detail::locale_ref)@plt>
 14368bc:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 14368c3:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 14368ca:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
 14368d1:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 14368d8:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
 14368df:	48 8b 50 08          	mov    0x8(%rax),%rdx
 14368e3:	48 8b 4a e8          	mov    -0x18(%rdx),%rcx
 14368e7:	48 89 95 88 fd ff ff 	mov    %rdx,-0x278(%rbp)
 14368ee:	48 89 8d 90 fd ff ff 	mov    %rcx,-0x270(%rbp)
 14368f5:	e8 e6 a3 f4 fe       	call   380ce0 <std::chrono::_V2::system_clock::now()@plt>
 14368fa:	48 8b 95 88 fd ff ff 	mov    -0x278(%rbp),%rdx
 1436901:	48 8b 8d 90 fd ff ff 	mov    -0x270(%rbp),%rcx
 1436908:	c7 85 20 fe ff ff 02 	movl   $0x2,-0x1e0(%rbp)
 143690f:	00 00 00 
 1436912:	48 89 85 28 fe ff ff 	mov    %rax,-0x1d8(%rbp)
 1436919:	48 89 95 10 fe ff ff 	mov    %rdx,-0x1f0(%rbp)
 1436920:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
 1436927:	48 8d 3d da 51 74 00 	lea    0x7451da(%rip),%rdi        # 1b7bb08 <vtable for std::bad_array_new_length@@Base+0x13c48>
 143692e:	e8 9d a8 f6 fe       	call   3a11d0 <__tls_get_addr@plt>
 1436933:	80 b8 e8 01 00 00 00 	cmpb   $0x0,0x1e8(%rax)
 143693a:	0f 84 c5 06 00 00    	je     1437005 <PemRVecAuxScalar::process_instr()@@Base+0xf85>
 1436940:	48 8b 80 f0 01 00 00 	mov    0x1f0(%rax),%rax
 1436947:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
 143694e:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
 1436955:	31 c9                	xor    %ecx,%ecx
 1436957:	48 8b bd a8 fd ff ff 	mov    -0x258(%rbp),%rdi
 143695e:	45 84 f6             	test   %r14b,%r14b
 1436961:	4c 89 fe             	mov    %r15,%rsi
 1436964:	0f 95 c1             	setne  %cl
 1436967:	31 d2                	xor    %edx,%edx
 1436969:	41 83 fd 02          	cmp    $0x2,%r13d
 143696d:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
 1436974:	48 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%rax
 143697b:	0f 9e c2             	setle  %dl
 143697e:	48 c7 85 38 fe ff ff 	movq   $0x0,-0x1c8(%rbp)
 1436985:	00 00 00 00 
 1436989:	48 c7 85 40 fe ff ff 	movq   $0x0,-0x1c0(%rbp)
 1436990:	00 00 00 00 
 1436994:	48 c7 85 48 fe ff ff 	movq   $0x0,-0x1b8(%rbp)
 143699b:	00 00 00 00 
 143699f:	c7 85 50 fe ff ff 00 	movl   $0x0,-0x1b0(%rbp)
 14369a6:	00 00 00 
 14369a9:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 14369b0:	00 00 00 00 
 14369b4:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 14369bb:	e8 80 fb f6 fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 14369c0:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
 14369c7:	49 83 c4 20          	add    $0x20,%r12
 14369cb:	4c 39 e7             	cmp    %r12,%rdi
 14369ce:	0f 84 35 fb ff ff    	je     1436509 <PemRVecAuxScalar::process_instr()@@Base+0x489>
 14369d4:	e8 a7 05 f6 fe       	call   396f80 <free@plt>
 14369d9:	e9 2b fb ff ff       	jmp    1436509 <PemRVecAuxScalar::process_instr()@@Base+0x489>
 14369de:	66 90                	xchg   %ax,%ax
 14369e0:	48 8b 15 31 6c 74 00 	mov    0x746c31(%rip),%rdx        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 14369e7:	4c 8d a5 a0 fe ff ff 	lea    -0x160(%rbp),%r12
 14369ee:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 14369f5:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
 14369fc:	4c 8d 85 70 fe ff ff 	lea    -0x190(%rbp),%r8
 1436a03:	48 8d 35 3e 94 34 00 	lea    0x34943e(%rip),%rsi        # 177fe48 <_fini@@Base+0x29124>
 1436a0a:	45 31 c9             	xor    %r9d,%r9d
 1436a0d:	b9 44 04 00 00       	mov    $0x444,%ecx
 1436a12:	4c 89 e7             	mov    %r12,%rdi
 1436a15:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
 1436a1c:	49 8d 54 24 20       	lea    0x20(%r12),%rdx
 1436a21:	4c 89 bd 80 fe ff ff 	mov    %r15,-0x180(%rbp)
 1436a28:	48 c7 85 a8 fe ff ff 	movq   $0x0,-0x158(%rbp)
 1436a2f:	00 00 00 00 
 1436a33:	48 c7 85 b0 fe ff ff 	movq   $0xfa,-0x150(%rbp)
 1436a3a:	fa 00 00 00 
 1436a3e:	4c 8d bd 10 fe ff ff 	lea    -0x1f0(%rbp),%r15
 1436a45:	48 89 95 a0 fe ff ff 	mov    %rdx,-0x160(%rbp)
 1436a4c:	ba 39 00 00 00       	mov    $0x39,%edx
 1436a51:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1436a58:	e8 b3 d2 f6 fe       	call   3a3d10 <fmt::v11::detail::vformat_to(fmt::v11::detail::buffer<char>&, fmt::v11::basic_string_view<char>, fmt::v11::basic_format_args<fmt::v11::context>, fmt::v11::detail::locale_ref)@plt>
 1436a5d:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
 1436a64:	4c 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%r8
 1436a6b:	48 83 ec 08          	sub    $0x8,%rsp
 1436a6f:	4c 8b 8d a8 fe ff ff 	mov    -0x158(%rbp),%r9
 1436a76:	b9 02 00 00 00       	mov    $0x2,%ecx
 1436a7b:	4c 89 ff             	mov    %r15,%rdi
 1436a7e:	48 8b 70 08          	mov    0x8(%rax),%rsi
 1436a82:	48 8b 56 e8          	mov    -0x18(%rsi),%rdx
 1436a86:	ff b5 e0 fd ff ff    	push   -0x220(%rbp)
 1436a8c:	ff b5 d8 fd ff ff    	push   -0x228(%rbp)
 1436a92:	ff b5 d0 fd ff ff    	push   -0x230(%rbp)
 1436a98:	e8 b3 6e f6 fe       	call   39d950 <spdlog::details::log_msg::log_msg(spdlog::source_loc, fmt::v11::basic_string_view<char>, spdlog::level::level_enum, fmt::v11::basic_string_view<char>)@plt>
 1436a9d:	31 c9                	xor    %ecx,%ecx
 1436a9f:	48 83 c4 20          	add    $0x20,%rsp
 1436aa3:	48 8b bd a8 fd ff ff 	mov    -0x258(%rbp),%rdi
 1436aaa:	45 84 f6             	test   %r14b,%r14b
 1436aad:	4c 89 fe             	mov    %r15,%rsi
 1436ab0:	0f 95 c1             	setne  %cl
 1436ab3:	31 d2                	xor    %edx,%edx
 1436ab5:	41 83 fd 02          	cmp    $0x2,%r13d
 1436ab9:	0f 9e c2             	setle  %dl
 1436abc:	e8 7f fa f6 fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 1436ac1:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
 1436ac8:	49 83 c4 20          	add    $0x20,%r12
 1436acc:	4c 39 e7             	cmp    %r12,%rdi
 1436acf:	0f 84 fe f6 ff ff    	je     14361d3 <PemRVecAuxScalar::process_instr()@@Base+0x153>
 1436ad5:	e8 a6 04 f6 fe       	call   396f80 <free@plt>
 1436ada:	e9 f4 f6 ff ff       	jmp    14361d3 <PemRVecAuxScalar::process_instr()@@Base+0x153>
 1436adf:	90                   	nop
 1436ae0:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1436ae7:	48 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%rax
 1436aee:	48 8d 35 93 93 34 00 	lea    0x349393(%rip),%rsi        # 177fe88 <_fini@@Base+0x29164>
 1436af5:	48 8b 15 1c 6b 74 00 	mov    0x746b1c(%rip),%rdx        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 1436afc:	48 8b 8d 78 fd ff ff 	mov    -0x288(%rbp),%rcx
 1436b03:	45 31 c9             	xor    %r9d,%r9d
 1436b06:	4c 8b 85 68 fd ff ff 	mov    -0x298(%rbp),%r8
 1436b0d:	48 8b bd 70 fd ff ff 	mov    -0x290(%rbp),%rdi
 1436b14:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 1436b1b:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
 1436b22:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
 1436b29:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 1436b30:	ba 2f 00 00 00       	mov    $0x2f,%edx
 1436b35:	b9 44 04 00 00       	mov    $0x444,%ecx
 1436b3a:	48 c7 85 a8 fe ff ff 	movq   $0x0,-0x158(%rbp)
 1436b41:	00 00 00 00 
 1436b45:	48 c7 85 b0 fe ff ff 	movq   $0xfa,-0x150(%rbp)
 1436b4c:	fa 00 00 00 
 1436b50:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1436b57:	e8 b4 d1 f6 fe       	call   3a3d10 <fmt::v11::detail::vformat_to(fmt::v11::detail::buffer<char>&, fmt::v11::basic_string_view<char>, fmt::v11::basic_format_args<fmt::v11::context>, fmt::v11::detail::locale_ref)@plt>
 1436b5c:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
 1436b61:	4c 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%r8
 1436b68:	48 83 ec 08          	sub    $0x8,%rsp
 1436b6c:	4c 8b 8d a8 fe ff ff 	mov    -0x158(%rbp),%r9
 1436b73:	b9 02 00 00 00       	mov    $0x2,%ecx
 1436b78:	4c 89 ff             	mov    %r15,%rdi
 1436b7b:	48 8b 56 e8          	mov    -0x18(%rsi),%rdx
 1436b7f:	ff b5 00 fe ff ff    	push   -0x200(%rbp)
 1436b85:	ff b5 f8 fd ff ff    	push   -0x208(%rbp)
 1436b8b:	ff b5 f0 fd ff ff    	push   -0x210(%rbp)
 1436b91:	e8 ba 6d f6 fe       	call   39d950 <spdlog::details::log_msg::log_msg(spdlog::source_loc, fmt::v11::basic_string_view<char>, spdlog::level::level_enum, fmt::v11::basic_string_view<char>)@plt>
 1436b96:	31 c9                	xor    %ecx,%ecx
 1436b98:	48 83 c4 20          	add    $0x20,%rsp
 1436b9c:	80 bd 80 fd ff ff 00 	cmpb   $0x0,-0x280(%rbp)
 1436ba3:	4c 89 fe             	mov    %r15,%rsi
 1436ba6:	4c 89 e7             	mov    %r12,%rdi
 1436ba9:	0f 95 c1             	setne  %cl
 1436bac:	31 d2                	xor    %edx,%edx
 1436bae:	83 bd 88 fd ff ff 02 	cmpl   $0x2,-0x278(%rbp)
 1436bb5:	0f 9e c2             	setle  %dl
 1436bb8:	e8 83 f9 f6 fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 1436bbd:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
 1436bc4:	48 3b bd 78 fd ff ff 	cmp    -0x288(%rbp),%rdi
 1436bcb:	0f 84 50 f8 ff ff    	je     1436421 <PemRVecAuxScalar::process_instr()@@Base+0x3a1>
 1436bd1:	e8 aa 03 f6 fe       	call   396f80 <free@plt>
 1436bd6:	e9 46 f8 ff ff       	jmp    1436421 <PemRVecAuxScalar::process_instr()@@Base+0x3a1>
 1436bdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1436be0:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 1436be7:	e8 b4 dc f4 fe       	call   3848a0 <Isa::name() const@plt>
 1436bec:	3d f2 01 00 00       	cmp    $0x1f2,%eax
 1436bf1:	0f 84 e3 fa ff ff    	je     14366da <PemRVecAuxScalar::process_instr()@@Base+0x65a>
 1436bf7:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
 1436bfe:	e8 9d dc f4 fe       	call   3848a0 <Isa::name() const@plt>
 1436c03:	3d f4 01 00 00       	cmp    $0x1f4,%eax
 1436c08:	0f 84 cc fa ff ff    	je     14366da <PemRVecAuxScalar::process_instr()@@Base+0x65a>
 1436c0e:	48 8b b5 a0 fd ff ff 	mov    -0x260(%rbp),%rsi
 1436c15:	48 89 df             	mov    %rbx,%rdi
 1436c18:	e8 d3 fa f5 fe       	call   3966f0 <PemRVecAuxScalar::exec_instr_latency(std::shared_ptr<Isa> const&)@plt>
 1436c1d:	48 89 df             	mov    %rbx,%rdi
 1436c20:	41 89 c5             	mov    %eax,%r13d
 1436c23:	e8 a8 90 f5 fe       	call   38fcd0 <tm_engine::TmObj::time() const@plt>
 1436c28:	45 89 ec             	mov    %r13d,%r12d
 1436c2b:	bf 38 00 00 00       	mov    $0x38,%edi
 1436c30:	48 c7 85 10 fe ff ff 	movq   $0x0,-0x1f0(%rbp)
 1436c37:	00 00 00 00 
 1436c3b:	49 01 c4             	add    %rax,%r12
 1436c3e:	48 c7 85 18 fe ff ff 	movq   $0x0,-0x1e8(%rbp)
 1436c45:	00 00 00 00 
 1436c49:	e8 12 c6 f5 fe       	call   393260 <operator new(unsigned long)@plt>
 1436c4e:	49 89 c6             	mov    %rax,%r14
 1436c51:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
 1436c58:	00 00 00 
 1436c5b:	48 8b b5 a0 fd ff ff 	mov    -0x260(%rbp),%rsi
 1436c62:	49 89 46 08          	mov    %rax,0x8(%r14)
 1436c66:	48 8b 05 fb b3 74 00 	mov    0x74b3fb(%rip),%rax        # 1b82068 <vtable for std::_Sp_counted_ptr_inplace<Retire_Uop, std::allocator<Retire_Uop>, (__gnu_cxx::_Lock_policy)2>@@Base+0x2cf20>
 1436c6d:	49 8d 7e 10          	lea    0x10(%r14),%rdi
 1436c71:	48 83 c0 10          	add    $0x10,%rax
 1436c75:	49 89 06             	mov    %rax,(%r14)
 1436c78:	e8 63 b8 f6 fe       	call   3a24e0 <std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2>::__shared_ptr(std::__shared_ptr<Isa, (__gnu_cxx::_Lock_policy)2> const&)@plt>
 1436c7d:	49 8b 06             	mov    (%r14),%rax
 1436c80:	4c 89 f7             	mov    %r14,%rdi
 1436c83:	48 8b 35 e6 ba 74 00 	mov    0x74bae6(%rip),%rsi        # 1b82770 <typeinfo for std::_Sp_make_shared_tag@@Base+0x3d918>
 1436c8a:	45 89 6e 20          	mov    %r13d,0x20(%r14)
 1436c8e:	4d 89 66 28          	mov    %r12,0x28(%r14)
 1436c92:	41 c6 46 30 00       	movb   $0x0,0x30(%r14)
 1436c97:	41 c6 46 31 00       	movb   $0x0,0x31(%r14)
 1436c9c:	41 c7 46 34 00 00 00 	movl   $0x0,0x34(%r14)
 1436ca3:	00 
 1436ca4:	4c 89 b5 18 fe ff ff 	mov    %r14,-0x1e8(%rbp)
 1436cab:	ff 50 20             	call   *0x20(%rax)
 1436cae:	48 8d bb a0 00 00 00 	lea    0xa0(%rbx),%rdi
 1436cb5:	4c 89 fe             	mov    %r15,%rsi
 1436cb8:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 1436cbf:	e8 cc f0 f4 fe       	call   385d90 <std::deque<std::shared_ptr<Retire_Uop>, std::allocator<std::shared_ptr<Retire_Uop> > >::push_back(std::shared_ptr<Retire_Uop> const&)@plt>
 1436cc4:	e9 fd fa ff ff       	jmp    14367c6 <PemRVecAuxScalar::process_instr()@@Base+0x746>
 1436cc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1436cd0:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 1436cd5:	48 8b 93 d0 00 00 00 	mov    0xd0(%rbx),%rdx
 1436cdc:	e9 cf fa ff ff       	jmp    14367b0 <PemRVecAuxScalar::process_instr()@@Base+0x730>
 1436ce1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1436ce8:	48 8b 15 29 69 74 00 	mov    0x746929(%rip),%rdx        # 1b7d618 <fmt::v11::basic_memory_buffer<char, 250ul, fmt::v11::detail::allocator<char> >::grow(fmt::v11::detail::buffer<char>&, unsigned long)@@Base+0xe20628>
 1436cef:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1436cf6:	4c 8d a5 a0 fe ff ff 	lea    -0x160(%rbp),%r12
 1436cfd:	48 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%rax
 1436d04:	4c 8d 85 70 fe ff ff 	lea    -0x190(%rbp),%r8
 1436d0b:	48 8d 35 a6 91 34 00 	lea    0x3491a6(%rip),%rsi        # 177feb8 <_fini@@Base+0x29194>
 1436d12:	45 31 c9             	xor    %r9d,%r9d
 1436d15:	b9 44 04 00 00       	mov    $0x444,%ecx
 1436d1a:	4c 89 e7             	mov    %r12,%rdi
 1436d1d:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
 1436d24:	49 8d 54 24 20       	lea    0x20(%r12),%rdx
 1436d29:	48 c7 85 a8 fe ff ff 	movq   $0x0,-0x158(%rbp)
 1436d30:	00 00 00 00 
 1436d34:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 1436d3b:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
 1436d42:	48 89 95 a0 fe ff ff 	mov    %rdx,-0x160(%rbp)
 1436d49:	ba 35 00 00 00       	mov    $0x35,%edx
 1436d4e:	48 c7 85 b0 fe ff ff 	movq   $0xfa,-0x150(%rbp)
 1436d55:	fa 00 00 00 
 1436d59:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1436d60:	e8 ab cf f6 fe       	call   3a3d10 <fmt::v11::detail::vformat_to(fmt::v11::detail::buffer<char>&, fmt::v11::basic_string_view<char>, fmt::v11::basic_format_args<fmt::v11::context>, fmt::v11::detail::locale_ref)@plt>
 1436d65:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 1436d6c:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 1436d73:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
 1436d7a:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 1436d81:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
 1436d88:	48 8b 50 08          	mov    0x8(%rax),%rdx
 1436d8c:	48 8b 4a e8          	mov    -0x18(%rdx),%rcx
 1436d90:	48 89 95 80 fd ff ff 	mov    %rdx,-0x280(%rbp)
 1436d97:	48 89 8d 88 fd ff ff 	mov    %rcx,-0x278(%rbp)
 1436d9e:	e8 3d 9f f4 fe       	call   380ce0 <std::chrono::_V2::system_clock::now()@plt>
 1436da3:	48 8b 95 80 fd ff ff 	mov    -0x280(%rbp),%rdx
 1436daa:	48 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%rcx
 1436db1:	c7 85 20 fe ff ff 02 	movl   $0x2,-0x1e0(%rbp)
 1436db8:	00 00 00 
 1436dbb:	48 89 85 28 fe ff ff 	mov    %rax,-0x1d8(%rbp)
 1436dc2:	48 89 95 10 fe ff ff 	mov    %rdx,-0x1f0(%rbp)
 1436dc9:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
 1436dd0:	48 8d 3d 31 4d 74 00 	lea    0x744d31(%rip),%rdi        # 1b7bb08 <vtable for std::bad_array_new_length@@Base+0x13c48>
 1436dd7:	e8 f4 a3 f6 fe       	call   3a11d0 <__tls_get_addr@plt>
 1436ddc:	80 b8 e8 01 00 00 00 	cmpb   $0x0,0x1e8(%rax)
 1436de3:	0f 84 ef 01 00 00    	je     1436fd8 <PemRVecAuxScalar::process_instr()@@Base+0xf58>
 1436de9:	48 8b 80 f0 01 00 00 	mov    0x1f0(%rax),%rax
 1436df0:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
 1436df7:	48 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%rax
 1436dfe:	31 c9                	xor    %ecx,%ecx
 1436e00:	48 8b bd a8 fd ff ff 	mov    -0x258(%rbp),%rdi
 1436e07:	45 84 f6             	test   %r14b,%r14b
 1436e0a:	4c 89 fe             	mov    %r15,%rsi
 1436e0d:	0f 95 c1             	setne  %cl
 1436e10:	31 d2                	xor    %edx,%edx
 1436e12:	41 83 fd 02          	cmp    $0x2,%r13d
 1436e16:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
 1436e1d:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
 1436e24:	0f 9e c2             	setle  %dl
 1436e27:	48 c7 85 38 fe ff ff 	movq   $0x0,-0x1c8(%rbp)
 1436e2e:	00 00 00 00 
 1436e32:	48 c7 85 40 fe ff ff 	movq   $0x0,-0x1c0(%rbp)
 1436e39:	00 00 00 00 
 1436e3d:	48 c7 85 48 fe ff ff 	movq   $0x0,-0x1b8(%rbp)
 1436e44:	00 00 00 00 
 1436e48:	c7 85 50 fe ff ff 00 	movl   $0x0,-0x1b0(%rbp)
 1436e4f:	00 00 00 
 1436e52:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 1436e59:	00 00 00 00 
 1436e5d:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 1436e64:	e8 d7 f6 f6 fe       	call   3a6540 <spdlog::logger::log_it_(spdlog::details::log_msg const&, bool, bool)@plt>
 1436e69:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
 1436e70:	49 83 c4 20          	add    $0x20,%r12
 1436e74:	4c 39 e7             	cmp    %r12,%rdi
 1436e77:	0f 84 7f f6 ff ff    	je     14364fc <PemRVecAuxScalar::process_instr()@@Base+0x47c>
 1436e7d:	e8 fe 00 f6 fe       	call   396f80 <free@plt>
 1436e82:	e9 75 f6 ff ff       	jmp    14364fc <PemRVecAuxScalar::process_instr()@@Base+0x47c>
 1436e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 1436e8e:	00 00 
 1436e90:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
 1436e97:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
 1436e9e:	48 8b 93 a8 00 00 00 	mov    0xa8(%rbx),%rdx
 1436ea5:	49 89 c6             	mov    %rax,%r14
 1436ea8:	48 29 c8             	sub    %rcx,%rax
 1436eab:	48 c1 f8 03          	sar    $0x3,%rax
 1436eaf:	48 89 d6             	mov    %rdx,%rsi
 1436eb2:	48 29 c6             	sub    %rax,%rsi
 1436eb5:	48 83 fe 01          	cmp    $0x1,%rsi
 1436eb9:	76 7b                	jbe    1436f36 <PemRVecAuxScalar::process_instr()@@Base+0xeb6>
 1436ebb:	bf 00 02 00 00       	mov    $0x200,%edi
 1436ec0:	e8 9b c3 f5 fe       	call   393260 <operator new(unsigned long)@plt>
 1436ec5:	49 89 46 08          	mov    %rax,0x8(%r14)
 1436ec9:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
 1436ed0:	48 8b 93 d0 00 00 00 	mov    0xd0(%rbx),%rdx
 1436ed7:	48 89 02             	mov    %rax,(%rdx)
 1436eda:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
 1436ee1:	48 85 c0             	test   %rax,%rax
 1436ee4:	48 89 42 08          	mov    %rax,0x8(%rdx)
 1436ee8:	74 0f                	je     1436ef9 <PemRVecAuxScalar::process_instr()@@Base+0xe79>
 1436eea:	48 83 3d de d4 74 00 	cmpq   $0x0,0x74d4de(%rip)        # 1b843d0 <__pthread_key_create@GLIBC_2.2.5>
 1436ef1:	00 
 1436ef2:	74 3c                	je     1436f30 <PemRVecAuxScalar::process_instr()@@Base+0xeb0>
 1436ef4:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
 1436ef9:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
 1436f00:	48 8d 50 08          	lea    0x8(%rax),%rdx
 1436f04:	48 8b 40 08          	mov    0x8(%rax),%rax
 1436f08:	48 89 93 e8 00 00 00 	mov    %rdx,0xe8(%rbx)
 1436f0f:	48 8d 90 00 02 00 00 	lea    0x200(%rax),%rdx
 1436f16:	48 89 83 d8 00 00 00 	mov    %rax,0xd8(%rbx)
 1436f1d:	48 89 83 d0 00 00 00 	mov    %rax,0xd0(%rbx)
 1436f24:	48 89 93 e0 00 00 00 	mov    %rdx,0xe0(%rbx)
 1436f2b:	e9 8b f8 ff ff       	jmp    14367bb <PemRVecAuxScalar::process_instr()@@Base+0x73b>
 1436f30:	83 40 08 01          	addl   $0x1,0x8(%rax)
 1436f34:	eb c3                	jmp    1436ef9 <PemRVecAuxScalar::process_instr()@@Base+0xe79>
 1436f36:	48 8b b3 c8 00 00 00 	mov    0xc8(%rbx),%rsi
 1436f3d:	4d 89 f4             	mov    %r14,%r12
 1436f40:	4c 89 f7             	mov    %r14,%rdi
 1436f43:	49 29 f4             	sub    %rsi,%r12
 1436f46:	49 c1 fc 03          	sar    $0x3,%r12
 1436f4a:	4d 8d 6c 24 01       	lea    0x1(%r12),%r13
 1436f4f:	49 83 c4 02          	add    $0x2,%r12
 1436f53:	4b 8d 04 24          	lea    (%r12,%r12,1),%rax
 1436f57:	48 39 c2             	cmp    %rax,%rdx
 1436f5a:	0f 86 d2 00 00 00    	jbe    1437032 <PemRVecAuxScalar::process_instr()@@Base+0xfb2>
 1436f60:	4c 29 e2             	sub    %r12,%rdx
 1436f63:	48 83 c7 08          	add    $0x8,%rdi
 1436f67:	49 c1 e5 03          	shl    $0x3,%r13
 1436f6b:	48 d1 ea             	shr    $1,%rdx
 1436f6e:	4c 8d 24 d1          	lea    (%rcx,%rdx,8),%r12
 1436f72:	48 89 fa             	mov    %rdi,%rdx
 1436f75:	48 29 f2             	sub    %rsi,%rdx
 1436f78:	4c 39 e6             	cmp    %r12,%rsi
 1436f7b:	0f 86 63 01 00 00    	jbe    14370e4 <PemRVecAuxScalar::process_instr()@@Base+0x1064>
 1436f81:	48 39 f7             	cmp    %rsi,%rdi
 1436f84:	74 08                	je     1436f8e <PemRVecAuxScalar::process_instr()@@Base+0xf0e>
 1436f86:	4c 89 e7             	mov    %r12,%rdi
 1436f89:	e8 d2 8e f6 fe       	call   39fe60 <memmove@plt>
 1436f8e:	49 8b 04 24          	mov    (%r12),%rax
 1436f92:	4c 89 a3 c8 00 00 00 	mov    %r12,0xc8(%rbx)
 1436f99:	48 89 83 b8 00 00 00 	mov    %rax,0xb8(%rbx)
 1436fa0:	48 05 00 02 00 00    	add    $0x200,%rax
 1436fa6:	48 89 83 c0 00 00 00 	mov    %rax,0xc0(%rbx)
 1436fad:	4b 8d 44 2c f8       	lea    -0x8(%r12,%r13,1),%rax
 1436fb2:	49 89 c6             	mov    %rax,%r14
 1436fb5:	48 89 83 e8 00 00 00 	mov    %rax,0xe8(%rbx)
 1436fbc:	48 8b 00             	mov    (%rax),%rax
 1436fbf:	48 89 83 d8 00 00 00 	mov    %rax,0xd8(%rbx)
 1436fc6:	48 05 00 02 00 00    	add    $0x200,%rax
 1436fcc:	48 89 83 e0 00 00 00 	mov    %rax,0xe0(%rbx)
 1436fd3:	e9 e3 fe ff ff       	jmp    1436ebb <PemRVecAuxScalar::process_instr()@@Base+0xe3b>
 1436fd8:	48 89 85 88 fd ff ff 	mov    %rax,-0x278(%rbp)
 1436fdf:	bf ba 00 00 00       	mov    $0xba,%edi
 1436fe4:	31 c0                	xor    %eax,%eax
 1436fe6:	e8 15 a0 f4 fe       	call   381000 <syscall@plt>
 1436feb:	48 8b 95 88 fd ff ff 	mov    -0x278(%rbp),%rdx
 1436ff2:	48 89 82 f0 01 00 00 	mov    %rax,0x1f0(%rdx)
 1436ff9:	c6 82 e8 01 00 00 01 	movb   $0x1,0x1e8(%rdx)
 1437000:	e9 eb fd ff ff       	jmp    1436df0 <PemRVecAuxScalar::process_instr()@@Base+0xd70>
 1437005:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 143700c:	bf ba 00 00 00       	mov    $0xba,%edi
 1437011:	31 c0                	xor    %eax,%eax
 1437013:	e8 e8 9f f4 fe       	call   381000 <syscall@plt>
 1437018:	48 8b 95 90 fd ff ff 	mov    -0x270(%rbp),%rdx
 143701f:	48 89 82 f0 01 00 00 	mov    %rax,0x1f0(%rdx)
 1437026:	c6 82 e8 01 00 00 01 	movb   $0x1,0x1e8(%rdx)
 143702d:	e9 15 f9 ff ff       	jmp    1436947 <PemRVecAuxScalar::process_instr()@@Base+0x8c7>
 1437032:	48 85 d2             	test   %rdx,%rdx
 1437035:	0f 84 99 00 00 00    	je     14370d4 <PemRVecAuxScalar::process_instr()@@Base+0x1054>
 143703b:	48 8d 44 12 02       	lea    0x2(%rdx,%rdx,1),%rax
 1437040:	48 89 c1             	mov    %rax,%rcx
 1437043:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 143704a:	48 b8 ff ff ff ff ff 	movabs $0x1fffffffffffffff,%rax
 1437051:	ff ff 1f 
 1437054:	48 39 c1             	cmp    %rax,%rcx
 1437057:	0f 87 c4 00 00 00    	ja     1437121 <PemRVecAuxScalar::process_instr()@@Base+0x10a1>
 143705d:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
 1437064:	48 8d 3c c5 00 00 00 	lea    0x0(,%rax,8),%rdi
 143706b:	00 
 143706c:	e8 ef c1 f5 fe       	call   393260 <operator new(unsigned long)@plt>
 1437071:	49 89 c6             	mov    %rax,%r14
 1437074:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
 143707b:	48 8b b3 c8 00 00 00 	mov    0xc8(%rbx),%rsi
 1437082:	4c 29 e0             	sub    %r12,%rax
 1437085:	48 d1 e8             	shr    $1,%rax
 1437088:	4d 8d 24 c6          	lea    (%r14,%rax,8),%r12
 143708c:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
 1437093:	48 83 c0 08          	add    $0x8,%rax
 1437097:	48 39 f0             	cmp    %rsi,%rax
 143709a:	74 0e                	je     14370aa <PemRVecAuxScalar::process_instr()@@Base+0x102a>
 143709c:	48 29 f0             	sub    %rsi,%rax
 143709f:	4c 89 e7             	mov    %r12,%rdi
 14370a2:	48 89 c2             	mov    %rax,%rdx
 14370a5:	e8 b6 8d f6 fe       	call   39fe60 <memmove@plt>
 14370aa:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
 14370b1:	49 c1 e5 03          	shl    $0x3,%r13
 14370b5:	e8 66 b3 f5 fe       	call   392420 <operator delete(void*)@plt>
 14370ba:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
 14370c1:	4c 89 b3 a0 00 00 00 	mov    %r14,0xa0(%rbx)
 14370c8:	48 89 83 a8 00 00 00 	mov    %rax,0xa8(%rbx)
 14370cf:	e9 ba fe ff ff       	jmp    1436f8e <PemRVecAuxScalar::process_instr()@@Base+0xf0e>
 14370d4:	48 c7 85 a8 fd ff ff 	movq   $0x3,-0x258(%rbp)
 14370db:	03 00 00 00 
 14370df:	e9 79 ff ff ff       	jmp    143705d <PemRVecAuxScalar::process_instr()@@Base+0xfdd>
 14370e4:	48 39 f7             	cmp    %rsi,%rdi
 14370e7:	0f 84 a1 fe ff ff    	je     1436f8e <PemRVecAuxScalar::process_instr()@@Base+0xf0e>
 14370ed:	4c 89 ef             	mov    %r13,%rdi
 14370f0:	48 29 d7             	sub    %rdx,%rdi
 14370f3:	4c 01 e7             	add    %r12,%rdi
 14370f6:	e8 65 8d f6 fe       	call   39fe60 <memmove@plt>
 14370fb:	e9 8e fe ff ff       	jmp    1436f8e <PemRVecAuxScalar::process_instr()@@Base+0xf0e>
