# G1 a1 helper diagnosis — complete

Same capture `npusim_20261114102512_case`; final receipt `G1_HELPER_FINAL_DIAGNOSIS.json`. Original model rc0/TASK_DONE; unchanged native gate rejects. Tee independently preserved all callbacks, with full SHA, framing, ACK and supervisor terminal checks verified in one 24.03-second CPU pass (peak RSS160,292KiB). No new model run, full raw transfer or runtime/frozen edits.

G1 natural key1 uses32AIC only. All32 raw/DB contexts exist. There are1,780,224 uniquely matchable observation pairs and128 end-only ALL/BAR records (four per AIC); no overwritten callbacks, ambiguous groups, repeated identities, same-tick repeats, unsupported texts or invalid intervals. MMAD_MX6144 pairs and FIX_L0C_TO_DST768 pairs are observed. E1 RVEC anomaly families are absent, rather than being silently waived.

G1 keeps its actual legacy suffix mapping: ELF entry/origin0x57a0, SIM base0x40000000, ELF_PC=SIM_PC-0x40000000+0x57a0. Four BAR PCs map to original ELF bytes under that rule; `G1_ELF_PC_BINDING.json` binds actual remote ELF/image hashes and bytes. G2 full-image/origin0 rules were not applied.

Remaining: matching producer ALL/BAR end-only/instant policy is unresolved; native admission remains rejected. Sol owns complete C1 numerical acceptance. Partial trace scope requires root/research decision. No G2 prefix was read or analyzed.

Follow-up: `G1_BAR_COMPLETION_SEMANTICS.json` now proves the pinned model explicitly suppresses BAR start logs and emits ALL/BAR completion only once run units are idle. Original strict gate result remains preserved. A separate INCOMPLETE diagnostic proposal retains128completion instants with no duration plus1780224unique observation spans; implementation/export awaits root/research scope review. No raw reread or model run occurred. RVEC lifetime gaps are unaffected.

Research seq349 scope approved via root. Explicit G1 completion-domain reader committed64c5aaf;18CPU tests including22targeted negative variants passed with real callback/ELF fixtures. One necessary output conversion completed on model1 (PID474529; local session46080). Original uint64 ticks/sequences/offsets remain authoritative; display conversion reads capture KernelInfo1.65GHz, not BOARD1GHz. Full exported JSON accounting passed; the compressed trace was returned and SHA256 verified locally.

Final delivery: `G1_COMPLETION_FINAL_HANDOFF.json`, `g1-completion-observations/observation_receipt.json`, and `g1-completion-observations/trace.json.gz`.1780224spans+128completion instants account for3560576unique callback references across32AIC; each span preserves both endpoints, while BAR has end only and no duration. Output106596914bytes, SHA256 0caf1be634ae0f5811be36dc8e1a52f0f929b39c184f0b6b25cf9c63aec060b5. Overall INCOMPLETE/native_capture_accepted=false; no remaining implementation/export work in this approved G1 scope. Full lifetime/performance questions and any other case remain separate.
