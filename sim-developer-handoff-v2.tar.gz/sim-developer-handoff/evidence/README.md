# 证据入口

- `E1_NUMERICAL_ACCEPTANCE.json`、`G1_NUMERICAL_ACCEPTANCE.json`、`G2_A2_NUMERICAL_ACCEPTANCE.json`：完整数值回执。
- `E1_PACK_CLOSEOUT.json`、`G1_REPRODUCE_CLOSEOUT.json`、`G2_A2_REPRODUCE_CLOSEOUT.json`：三个终态归档、来源与原捕获边界。
- `rv-send-continuation/RV_SEND_EXACT_SAMPLES.json`、`G2_A2_EXACT_CALLBACK_SAMPLES.json`：原回调小样本；同目录 `RV_SEND_NARROW_CHECK_V2.json`、`RV_SEND_INFO_LOG_CLOSEOUT.json` 和 ASM 为对应解释及静态证据。
- `helper/`：helper 反汇编与构造输入的 CPU 回放旁证；后者不是原模型捕获。
- `FIRST_FAILURE_FRAMES.json`：END_LABEL PC 防护的原帧，与 RV_SEND 配对问题分开。
- `CPU_EXPORT_PLAN.json`：E1/G2 原流哈希与有限域范围，计划状态不代表最终状态；最终回执另见 `tools/EXECUTION_CLOSEOUT.json`。

模型、helper 日志与原 strict 失败栈在三个内层 reproduce 档的 terminal-acceptance 下，E1 另有内层诊断小包；精确位置见 [复现说明](../REPRODUCTION.md)。
