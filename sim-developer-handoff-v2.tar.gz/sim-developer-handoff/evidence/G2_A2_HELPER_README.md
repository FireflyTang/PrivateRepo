# G2 a2 strict callback diagnosis — complete

Main receipt: `G2_A2_HELPER_FINAL_DIAGNOSIS.json`. Same capture npusim_20261114105630_case, model PID465141; original rc0/TASK_DONE, unchanged legacy native rejection. Independent tee full SHA/framing/ACK/terminal verification passes. Single12.94GB pass completed in178.95s, peak RSS1,166,224KiB. Only small summaries returned; additional exact samples sought10,382bytes at saved offsets, not another scan.

All96 AIC/AIV0/AIV1 contexts are present. Strict result UNKNOWN:108672missing-endpoint groups,37632ambiguous VLOOP groups,0unsupported/invalid-interval groups. End-start81024 exactly decomposes as GET_BUF47232 + RLS_BUF47232 + DSB192 + BAR192 - RVECLD/RV_SEND6912 - RVECST/RV_SEND6912. Complete raw conservation ledger and per-context/pipe counts are in the receipt.

Actual MMAD_MX6144 and FIX_L0C_TO_DST384 observations pair uniquely. Counts match E1's12288MMAD/1152FIX when added to G1's6144/768, but this is instruction-count evidence only. No performance, full lifetime or wait equivalence follows.

`G2_A2_PC_DIAGNOSIS.json` covers all50problem PC/type/pipe groups and validates each callback opcode against actual loaded image and original ELF bytes. Both origins0: AIC ELF_PC=SourceInstrAddr; AIV ELF_PC=SourceInstrAddr-0x100000. Launch entry13b0/403c is not added. Frozen c35cf1f unchanged.

Pending contract: new G2 GET_BUF/RLS_BUF/DSB end-emitter/completion scope plus RV_SEND/VLOOP lifecycle rules. `G2_A2_COMPLETION_CANDIDATES.json` only proposes targeted classification research using known same-SHA start-exclusion evidence; no G1 classifier was enabled, no new partial export or model run. Sol owns numerical source acceptance. This strict diagnosis is complete.

Final narrow follow-up: `G2_FC_COMPLETION_AND_VLOOP_SEMANTICS.json` closes the matching-model DSB/GET_BUF/RLS_BUF end paths and preserves BAR completion proof.50actual PC/type/pipe groups remain ELF-byte-bound (34FC,16RV). Name-table mapping refutes the previous possible VLOOP link:0x1ef=RV_SMOVI,0x117=RV_VLOOPv2,0x1f6=RV_SJUMPI. RV_SEND/VLOOP lifetime contracts remain unresolved. No raw reread, model run, classifier change or G2 partial export occurred. Documentation commit 76e01bdf9d8958a3c2488202ddd7b42f015af145. The authorized narrow diagnosis is finished; any new export domain remains for root/research scope review.
