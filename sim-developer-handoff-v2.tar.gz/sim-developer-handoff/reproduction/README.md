# 三档复现入口

见 [复现步骤、原始命令和迁移边界](../REPRODUCTION.md)；三个原档和其 manifest 保存在 [reproductions](../reproductions/)。每档需解到不同目录，不能把包含原绝对路径的配置直接视为可迁移运行环境。完整 SDK、模型及大 raw 不在本包内。
