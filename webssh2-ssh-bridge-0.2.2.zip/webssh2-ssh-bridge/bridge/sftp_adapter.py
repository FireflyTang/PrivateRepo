"""Bounded disk cache maps offset-based SFTP handles onto WebSSH2 transfers."""
import asyncio
import datetime
import os
import posixpath
import shlex
import stat
import tempfile
import time
import functools
from contextlib import suppress
from dataclasses import dataclass
import asyncssh
from .webssh2_client import WebSSHClient, WebSSHError
from .exec_adapter import execute
from .logging_setup import event, failure, new_session, session_context


def operation(method):
    @functools.wraps(method)
    async def wrapper(self, *args, **kwargs):
        token = session_context.set(self.session_id)
        started = time.monotonic()
        fields = {'operation': method.__name__}
        if args:
            target = args[0]
            if isinstance(target, (bytes, str)):
                fields['path'] = os.fsdecode(target)
            elif isinstance(target, Handle):
                fields['path'] = target.path
            if method.__name__ in ('read', 'write') and len(args) >= 3:
                fields.update(offset=args[1], bytes=len(args[2]) if isinstance(args[2], bytes) else args[2])
        event('DEBUG', 'sftp.server.operation.start', **fields)
        try:
            result = await method(self, *args, **kwargs)
            event('DEBUG', 'sftp.server.operation.complete', duration_ms=round((time.monotonic()-started)*1000), **fields)
            return result
        except Exception as error:
            if isinstance(error, asyncssh.SFTPError):
                event('WARNING', 'sftp.server.operation.failed', error_type=type(error).__name__, message=str(error), **fields)
            else:
                failure('sftp.server.operation.failed', error, **fields)
            raise
        finally:
            session_context.reset(token)
    return wrapper


def translate(error):
    if isinstance(error, asyncssh.SFTPError):
        return error
    code = getattr(error, 'code', '')
    message = str(error) or type(error).__name__
    if isinstance(error, asyncio.TimeoutError):
        message = 'WebSSH2 operation timed out; completion is unknown'
    if code == 'SFTP_NOT_FOUND' or 'no such file' in message.lower():
        return asyncssh.SFTPNoSuchFile(message)
    if code in ('SFTP_PERMISSION_DENIED', 'SFTP_PATH_FORBIDDEN'):
        return asyncssh.SFTPPermissionDenied(message)
    if code == 'SFTP_ALREADY_EXISTS':
        return asyncssh.SFTPFileAlreadyExists(message)
    return asyncssh.SFTPFailure(message)


def attrs_of(entry):
    kind = {'file': stat.S_IFREG, 'directory': stat.S_IFDIR, 'symlink': stat.S_IFLNK}.get(entry['type'], 0)
    def stamp(key):
        return int(datetime.datetime.fromisoformat(entry[key].replace('Z', '+00:00')).timestamp())
    owner = str(entry.get('owner', ''))
    group = str(entry.get('group', ''))
    return asyncssh.SFTPAttrs(size=entry['size'], permissions=kind | (entry['permissionsOctal'] & 0o7777),
                             uid=int(owner) if owner.isdigit() else None,
                             gid=int(group) if group.isdigit() else None,
                             atime=stamp('accessedAt'), mtime=stamp('modifiedAt'))


@dataclass(eq=False)
class Handle:
    path: str
    file: object
    readable: bool
    writable: bool
    dirty: bool = False
    exclusive: bool = False
    append: bool = False
    attrs: object = None
    mode: object = None


class BridgeSFTP(asyncssh.SFTPServer):
    def __init__(self, channel, config, slots):
        super().__init__(channel)
        self.session_id = new_session('sftp')
        event('INFO', 'sftp.session.start', connection_id=channel.get_extra_info('bridge_connection_id'), peer=channel.get_extra_info('peername'), node=config.node_name)
        self.config, self.slots = config, slots
        self.client = WebSSHClient(config)
        self.ready = False
        self.acquired = False
        self.init_lock = asyncio.Lock()
        self.handles = set()
        self.home = None

    def map_path(self, path):
        # Any inherited filesystem operation MUST NOT reach the bridge host.
        raise asyncssh.SFTPOpUnsupported('Operation is not implemented by the WebSSH2 adapter')

    async def connected(self):
        async with self.init_lock:
            if not self.ready:
                await asyncio.wait_for(self.slots.acquire(), 1)
                self.acquired = True
                try:
                    if self.client.closed:
                        self.client = WebSSHClient(self.config)
                    await self.client.connect()
                    listing = await self.client.list('~')
                    self.home = listing['path']
                    self.ready = True
                except BaseException:
                    await self.client.close()
                    self.slots.release()
                    self.acquired = False
                    raise
        return self.client

    async def path(self, value):
        await self.connected()
        value = os.fsdecode(value)
        if '\x00' in value:
            raise asyncssh.SFTPInvalidFilename('NUL in path')
        if value == '~':
            return self.home
        if value.startswith('~/'):
            value = posixpath.join(self.home, value[2:])
        if not value.startswith('/'):
            value = posixpath.join(self.home, value)
        return posixpath.normpath(value)

    @operation
    async def realpath(self, path):
        try:
            return (await self.path(path)).encode()
        except Exception as error:
            raise translate(error) from error

    @operation
    async def stat(self, path):
        try:
            path = await self.path(path)
            return attrs_of(await self.client.stat(path))
        except Exception as error:
            raise translate(error) from error

    @operation
    async def lstat(self, path):
        return await self.stat(path)

    async def scandir(self, path):
        try:
            path = await self.path(path)
            listing = await self.client.list(path)
            for entry in listing['entries']:
                yield asyncssh.SFTPName(entry['name'].encode(), attrs=attrs_of(entry))
        except Exception as error:
            raise translate(error) from error

    @operation
    async def open(self, path, pflags, attrs):
        handle = None
        try:
            path = await self.path(path)
            if len(self.handles) >= self.config.max_handles:
                raise asyncssh.SFTPFailure('Cached handle limit exceeded')
            writable = bool(pflags & asyncssh.FXF_WRITE)
            existing = None
            try:
                existing = await self.client.stat(path)
            except WebSSHError as error:
                if getattr(error, 'code', '') != 'SFTP_NOT_FOUND' and 'no such file' not in str(error).lower():
                    raise
            if existing:
                if existing['type'] != 'file':
                    raise asyncssh.SFTPOpUnsupported('Cached handles support regular files only')
                if pflags & asyncssh.FXF_EXCL and pflags & asyncssh.FXF_CREAT:
                    raise asyncssh.SFTPFileAlreadyExists(path)
            elif not pflags & asyncssh.FXF_CREAT:
                raise asyncssh.SFTPNoSuchFile(path)
            handle = Handle(path, tempfile.TemporaryFile(buffering=0), bool(pflags & asyncssh.FXF_READ), writable,
                            dirty=writable and (existing is None or bool(pflags & asyncssh.FXF_TRUNC)),
                            exclusive=bool(pflags & asyncssh.FXF_EXCL), append=bool(pflags & asyncssh.FXF_APPEND),
                            attrs=attrs_of(existing) if existing else asyncssh.SFTPAttrs(permissions=stat.S_IFREG | 0o644),
                            mode=(existing['permissionsOctal'] & 0o7777) if existing else attrs.permissions)
            if existing and not pflags & asyncssh.FXF_TRUNC:
                await self.client.download(path, handle.file)
            self.handles.add(handle)
            event('INFO', 'sftp.handle.open', path=path, readable=handle.readable, writable=writable, active_handles=len(self.handles))
            return handle
        except Exception as error:
            if handle:
                handle.file.close()
            raise translate(error) from error

    @operation
    async def read(self, handle, offset, size):
        if not handle.readable:
            raise asyncssh.SFTPPermissionDenied('Handle is not readable')
        handle.file.seek(offset)
        return handle.file.read(min(size, 1024 * 1024))

    @operation
    async def write(self, handle, offset, data):
        if not handle.writable:
            raise asyncssh.SFTPPermissionDenied('Handle is not writable')
        if handle.append:
            handle.file.seek(0, 2)
            offset = handle.file.tell()
        if offset + len(data) > self.config.max_file:
            raise asyncssh.SFTPFailure('Bridge file size limit exceeded')
        handle.file.seek(offset)
        handle.file.write(data)
        handle.dirty = True
        return len(data)

    async def fstat(self, handle):
        import copy
        attrs = copy.copy(handle.attrs)
        attrs.size = os.fstat(handle.file.fileno()).st_size
        return attrs

    @operation
    async def close(self, handle):
        try:
            if self._chan.is_closing():
                return
            event('INFO', 'sftp.handle.close', path=handle.path, dirty=handle.dirty)
            if handle.dirty:
                size = os.fstat(handle.file.fileno()).st_size
                await self.client.upload(handle.path, handle.file, size, overwrite=not handle.exclusive)
                # Upstream completion does not guarantee fsync. Re-download and hash
                # before reporting SFTP CLOSE success, detecting truncation/corruption.
                if self.config.verify_upload:
                    await self.verify(handle)
            if handle.writable and handle.mode is not None:
                await self.shell('chmod %o %s' % (handle.mode & 0o7777, shlex.quote(handle.path)))
        except Exception as error:
            raise translate(error) from error
        finally:
            handle.file.close()
            self.handles.discard(handle)

    async def verify(self, handle):
        import hashlib
        def digest(file):
            result = hashlib.sha256()
            for chunk in iter(lambda: file.read(65536), b''):
                result.update(chunk)
            return result.digest()
        with tempfile.TemporaryFile(buffering=0) as verify:
            await self.client.download(handle.path, verify)
            handle.file.seek(0)
            if digest(handle.file) != digest(verify):
                raise WebSSHError('Remote upload SHA-256 verification failed')
        event('INFO', 'sftp.upload.verified', path=handle.path, algorithm='sha256')

    @operation
    async def mkdir(self, path, attrs):
        try:
            await self.client.mkdir(await self.path(path), (attrs.permissions if attrs.permissions is not None else 0o755) & 0o7777)
        except Exception as error:
            raise translate(error) from error

    @operation
    async def remove(self, path):
        try:
            path = await self.path(path)
            entry = await self.client.stat(path)
            if entry['type'] == 'directory':
                raise asyncssh.SFTPFailure('Use rmdir for directories')
            await self.client.delete(path)
        except Exception as error:
            raise translate(error) from error

    @operation
    async def rmdir(self, path):
        # Upstream delete may recursively remove empty/nonempty directories;
        # use Unix rmdir over the WebSSH2 command channel for exact semantics.
        await self.shell('rmdir ' + shlex.quote(await self.path(path)))

    async def shell(self, command):
        try:
            async with WebSSHClient(self.config) as client:
                output = bytearray()
                async def collect(data):
                    if len(output) < 65536:
                        output.extend(data)
                code = await asyncio.wait_for(execute(client, command, collect), self.config.timeout)
                if code:
                    raise asyncssh.SFTPFailure(output.decode(errors='replace').strip() or 'Remote operation failed')
        except Exception as error:
            raise translate(error) from error

    @operation
    async def rename(self, oldpath, newpath):
        old, new = await self.path(oldpath), await self.path(newpath)
        # POSIX test + mv has a race; the adapter assumes no concurrent external writer.
        await self.shell('if [ -e {n} ] || [ -L {n} ]; then exit 1; fi; mv {o} {n}'.format(
            o=shlex.quote(old), n=shlex.quote(new)))

    @operation
    async def posix_rename(self, oldpath, newpath):
        old, new = await self.path(oldpath), await self.path(newpath)
        await self.shell('if [ -d {n} ]; then exit 1; fi; mv -f {o} {n}'.format(
            o=shlex.quote(old), n=shlex.quote(new)))

    @operation
    async def setstat(self, path, attrs):
        path = await self.path(path)
        if attrs.uid is not None or attrs.gid is not None or attrs.atime is not None or attrs.mtime is not None or attrs.size is not None:
            raise asyncssh.SFTPOpUnsupported('Bridge supports chmod only; timestamp/chown/truncate not implemented')
        if attrs.permissions is not None:
            await self.shell('chmod %o %s' % (attrs.permissions & 0o7777, shlex.quote(path)))

    @operation
    async def fsetstat(self, handle, attrs):
        if attrs.uid is not None or attrs.gid is not None or attrs.atime is not None or attrs.mtime is not None:
            raise asyncssh.SFTPOpUnsupported('Timestamp and ownership changes are not implemented')
        if not handle.writable:
            raise asyncssh.SFTPPermissionDenied('Handle is not writable')
        if attrs.size is not None:
            if attrs.size > self.config.max_file:
                raise asyncssh.SFTPFailure('Bridge file size limit exceeded')
            handle.file.truncate(attrs.size)
            handle.dirty = True
        if attrs.permissions is not None:
            handle.mode = attrs.permissions
            handle.attrs.permissions = attrs.permissions

    @operation
    async def fsync(self, handle):
        raise asyncssh.SFTPOpUnsupported('Durable remote fsync is unavailable')

    @operation
    async def readlink(self, path):
        raise asyncssh.SFTPOpUnsupported('readlink is not implemented')

    async def exit(self):
        # Disconnected clients never commit dirty cached handles.
        event('INFO', 'sftp.session.closed', unclosed_handles=len(self.handles))
        for handle in self.handles:
            handle.file.close()
        self.handles.clear()
        await self.client.close()
        if self.acquired:
            self.slots.release()
            self.acquired = False

        if not self._chan.is_closing():
            self._chan.exit(0)
