"""Periodic website Cookie refresh: one plain POST to a fixed URL, never proxied."""
import asyncio
import aiohttp
from .logging_setup import event, failure, header_map, register_secret


class CookieRefreshError(Exception):
    pass


def cookie_from_headers(headers):
    """Join every Set-Cookie response header into one Cookie request line."""
    pairs = []
    for header in headers.getall('Set-Cookie', []):
        pair = header.split(';', 1)[0].strip()
        if pair and '=' in pair:
            pairs.append(pair)
    if not pairs:
        raise CookieRefreshError('Cookie endpoint sent no usable Set-Cookie header')
    return '; '.join(pairs)


def merge_cookie(current, refreshed):
    """Overlay only the pairs the endpoint rotated; keep the rest as baseline.

    The static webssh.cookie usually carries every cookie the site expects
    (the full browser line, e.g. a portal session plus webssh2.sid); a refresh
    endpoint returns just the rotating pairs, so replacing the whole line
    would silently drop the others.
    """
    if not current:
        return refreshed
    def pairs(line):
        return [part.strip() for part in line.split(';') if part.strip()]
    rotated = {pair.split('=', 1)[0] for pair in pairs(refreshed)}
    kept = [pair for pair in pairs(current) if pair.split('=', 1)[0] not in rotated]
    return '; '.join(kept + pairs(refreshed))


async def fetch_cookie(config):
    settings = config.cookie_refresh
    trace = config.log_settings['http_trace']
    # trust_env=False keeps HTTP_PROXY/HTTPS_PROXY/ALL_PROXY environment
    # variables out of this request; no proxy is ever passed explicitly.
    session = aiohttp.ClientSession(trust_env=False,
            connector=aiohttp.TCPConnector(ssl=config.tls_verify),
            timeout=aiohttp.ClientTimeout(total=settings['timeout_seconds']))
    try:
        headers = {'Content-Type': settings['content_type']}
        # Rotation endpoints need the current Cookie to extend the session.
        current = config.cookie().strip()
        if current:
            headers['Cookie'] = current
        if trace:
            event('DEBUG', 'cookie.refresh.request', method='POST', url=settings['url'],
                  headers=headers, body=settings['body'])
        async with session.post(settings['url'], data=settings['body'].encode(),
                                headers=headers) as response:
            trace_fields = {'status': response.status, 'headers': header_map(response.headers)}
            if not 200 <= response.status < 300:
                if trace:
                    event('DEBUG', 'cookie.refresh.response', **trace_fields,
                          body=(await response.read())[:512].decode('utf-8', 'replace'))
                raise CookieRefreshError('Cookie endpoint returned HTTP %s' % response.status)
            cookie = cookie_from_headers(response.headers)
            if trace:
                event('DEBUG', 'cookie.refresh.response', **trace_fields, cookie=cookie,
                      body=(await response.read())[:512].decode('utf-8', 'replace'))
    finally:
        await session.close()
    register_secret(cookie)
    for part in cookie.split(';'):
        if '=' in part:
            register_secret(part.split('=', 1)[1].strip())
    return cookie


async def refresh_loop(config):
    settings = config.cookie_refresh
    while True:
        delay = settings['retry_seconds']
        try:
            refreshed = await fetch_cookie(config)
            cookie = merge_cookie(config.cookie(), refreshed)
            config.cookie_override = cookie
            register_secret(cookie)
            event('INFO', 'cookie.refreshed', pairs=len(cookie.split(';')), length=len(cookie), cookie=cookie)
            delay = settings['interval_seconds']
        except asyncio.CancelledError:
            raise
        except Exception as error:
            # Keep serving with the previous Cookie; retry shortly.
            failure('cookie.refresh.failed', error)
        await asyncio.sleep(delay)
