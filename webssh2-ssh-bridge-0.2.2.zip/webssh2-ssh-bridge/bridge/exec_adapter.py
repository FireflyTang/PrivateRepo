"""Streaming command wrapper over a fresh WebSSH2 PTY; stderr is merged."""
import asyncio
import re
import secrets
import shlex
import time
import hashlib
from .logging_setup import event, failure
from .webssh2_client import WebSSHError


async def execute(client, command, output):
    started, size = time.monotonic(), 0
    event('INFO', 'exec.start', client_id=client.client_id, command_bytes=len(command.encode()),
          command_sha256=hashlib.sha256(command.encode()).hexdigest(),
          **({'command': command} if client.config.log_settings['command_text'] else {}))
    async def counted(data):
        nonlocal size
        size += len(data)
        await output(data)
    try:
        code = await _execute(client, command, counted)
        event('INFO', 'exec.complete', client_id=client.client_id, exit_code=code, output_bytes=size,
              duration_ms=round((time.monotonic()-started)*1000))
        return code
    except BaseException as error:
        failure('exec.failed', error, client_id=client.client_id, output_bytes=size,
                duration_ms=round((time.monotonic()-started)*1000))
        raise


async def _execute(client, command, output):
    token = secrets.token_hex(24)
    ready = b'\x1e' + token.encode() + b'R\x1f'
    begin = b'\x1e' + token.encode() + b'B\x1f'
    end_prefix = b'\x1e' + token.encode() + b'E:'
    await client.terminal()
    # Wait for the actual shell before sending setup (terminal event has no ack).
    await asyncio.wait_for(client.receive(), client.config.bootstrap_timeout)
    await client.emit('data', "stty -echo -icanon -opost; printf '\\036" + token + "R\\037'\n")
    buf = b''
    async def handshake():
        nonlocal buf
        while ready not in buf:
            buf = (buf + await client.receive())[-65536:]
    await asyncio.wait_for(handshake(), client.config.bootstrap_timeout)
    event('DEBUG', 'exec.bootstrap.ready', client_id=client.client_id)
    # Marker bytes are produced by printf, never present literally in echoed input.
    script = ("printf '\\036" + token + "B\\037'; "
              "sh -c " + shlex.quote(command) + " </dev/null; __bridge_rc=$?; "
              "printf '\\036" + token + "E:%d\\037' \"$__bridge_rc\"\n")
    await client.emit('data', script)
    buf = b''
    while begin not in buf:
        buf += await client.receive()
        if len(buf) > 65536:
            raise WebSSHError('Command start marker not received')
    buf = buf.split(begin, 1)[1]
    pattern = re.compile(re.escape(end_prefix) + rb'([0-9]{1,3})\x1f')
    keep = len(end_prefix) + 5
    while True:
        match = pattern.search(buf)
        if match:
            await output(buf[:match.start()])
            return int(match.group(1))
        if len(buf) > keep:
            await output(buf[:-keep])
            buf = buf[-keep:]
        buf += await client.receive()
