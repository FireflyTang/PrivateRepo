"""Small OS adapters used by the Windows/Linux Python runtime."""
import os
import signal


def is_windows():
    return os.name == 'nt'


def private_path(path):
    # Windows permissions come from the file/directory ACL, not Unix mode bits.
    if not is_windows():
        path.chmod(0o600)


def private_fd(fd):
    if not is_windows() and hasattr(os, 'fchmod'):
        os.fchmod(fd, 0o600)


def check_private_path(path):
    return is_windows() or not path.stat().st_mode & 0o077


def install_stop_handlers(loop, stopped):
    """signal.signal works with Windows ProactorEventLoop as well as Unix loops."""
    previous = {}
    def stop(signum, frame):
        loop.call_soon_threadsafe(stopped.set)
    for name in ('SIGINT', 'SIGTERM', 'SIGBREAK'):
        signum = getattr(signal, name, None)
        if signum is None:
            continue
        try:
            original = signal.getsignal(signum)
            if original is None:
                continue
            signal.signal(signum, stop)
            previous[signum] = original
        except (ValueError, OSError):
            # Embedded runtimes may execute outside the main thread. Task
            # cancellation remains available there; CLI runs on the main thread.
            continue
    def restore():
        for signum, original in previous.items():
            signal.signal(signum, original)
    return restore
