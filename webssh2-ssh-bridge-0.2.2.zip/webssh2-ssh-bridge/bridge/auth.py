from pathlib import Path
import os
import asyncssh
from .platform_support import private_fd


def private_write(path: Path, data: bytes):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    import tempfile
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '-', dir=str(path.parent))
    try:
        private_fd(fd)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def ensure_key(path: Path):
    if not path.exists():
        key = asyncssh.generate_private_key('ssh-ed25519')
        private_write(path, key.export_private_key('openssh'))
        private_write(Path(str(path) + '.pub'), key.export_public_key('openssh'))
