"""Read-only HTTP GET proxy: forwards requests to the WebSSH2 origin with the live Cookie."""
import asyncio
import time
import aiohttp
from aiohttp import web
from .logging_setup import event, failure, header_map
from .platform_support import is_windows

# Hop-by-hop headers belong to a single connection and are never forwarded.
# Set-Cookie is dropped too: leaking the website session to proxy clients
# would give them permanent credentials, not just one response.
HOP_HEADERS = frozenset(('connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization',
                         'te', 'trailer', 'transfer-encoding', 'upgrade', 'set-cookie'))


async def start_http_proxy(config):
    """Serve GET {host:port}/{path} -> GET {webssh.url}/{path} carrying the site Cookie."""
    settings = config.http_proxy
    # trust_env=False keeps HTTP_PROXY/HTTPS_PROXY/ALL_PROXY environment
    # variables out of upstream requests; no proxy is ever passed explicitly.
    # auto_decompress=False makes this a byte-transparent pipe, so compressed
    # bodies and Range semantics survive unchanged. total=None allows long
    # streaming downloads; only connect and per-read stalls are bounded.
    upstream = aiohttp.ClientSession(trust_env=False, auto_decompress=False,
            connector=aiohttp.TCPConnector(ssl=config.tls_verify),
            timeout=aiohttp.ClientTimeout(total=None, connect=settings['timeout_seconds'],
                                          sock_read=settings['timeout_seconds']))

    async def close_upstream(application):
        await upstream.close()

    async def forward(request):
        started = time.monotonic()
        path = request.path  # logged without query: queries may carry tokens
        trace = config.log_settings['http_trace']
        answer = None
        try:
            # Cookie is read per request, so a background refresh applies to
            # the very next request. Only Range is taken from the client;
            # other client headers are never forwarded upstream.
            headers = {**config.headers, 'Cookie': config.cookie()}
            if 'Range' in request.headers:
                headers['Range'] = request.headers['Range']
            if trace:
                event('DEBUG', 'httpproxy.upstream.request', method='GET',
                      url=config.url + request.path_qs, headers=headers)
            async with upstream.get(config.url + request.path_qs, headers=headers,
                                    allow_redirects=False) as response:
                if trace:
                    event('DEBUG', 'httpproxy.upstream.response', status=response.status,
                          headers=header_map(response.headers))
                answer = web.StreamResponse(status=response.status, reason=response.reason)
                for key, value in response.headers.items():
                    if key.lower() not in HOP_HEADERS:
                        answer.headers.add(key, value)
                await answer.prepare(request)
                forwarded = 0
                async for chunk in response.content.iter_chunked(65536):
                    await answer.write(chunk)
                    forwarded += len(chunk)
                await answer.write_eof()
                event('INFO', 'httpproxy.request.complete', path=path, status=response.status,
                      bytes=forwarded, duration_ms=round((time.monotonic() - started) * 1000))
                return answer
        except Exception as error:
            failure('httpproxy.request.failed', error, path=path,
                    duration_ms=round((time.monotonic() - started) * 1000))
            if answer is not None:
                # Headers are already on the wire; abort the transfer so the
                # client sees a truncated response instead of a silent one.
                answer.force_close()
                return answer
            status = 504 if isinstance(error, asyncio.TimeoutError) else 502
            return web.Response(status=status, text='bridge: upstream request failed\n')

    application = web.Application()
    application.router.add_get('/{path:.*}', forward, allow_head=False)
    application.on_cleanup.append(close_upstream)
    runner = web.AppRunner(application, access_log=None)
    await runner.setup()
    try:
        site = web.TCPSite(runner, settings['host'], settings['port'],
                           reuse_address=not is_windows())
        await site.start()
    except BaseException:
        await runner.cleanup()
        raise
    event('INFO', 'httpproxy.listening', host=settings['host'], port=settings['port'], origin=config.url)
    return runner
