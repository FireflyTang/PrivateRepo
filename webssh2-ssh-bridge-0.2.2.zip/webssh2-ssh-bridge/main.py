"""Run with: python main.py. Configuration is read from ./config.json beside this file."""
import asyncio
from pathlib import Path
from bridge.config import ConfigError
from bridge.main import main


if __name__ == '__main__':
    try:
        asyncio.run(main(default_config=str(Path(__file__).with_name('config.json'))))
    except KeyboardInterrupt:
        pass
    except ConfigError as error:
        raise SystemExit('Configuration error: ' + str(error)) from None
