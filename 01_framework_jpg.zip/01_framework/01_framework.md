# MegaMoE：baseline 与去重的时间怎样拼起来

## 1. 先认清几个角色和符号

本文讨论 W8A8、启用预取且带共享专家的 MegaMoE 路径。baseline 指基线方案；去重指 Dispatch 与 Combine 均启用去重的方案。

一个 token 可以理解为一行待处理的数据。路由决定它交给哪些专家；routed expert 是按路由选中的专家，shared expert 是共享专家。

| 名称 | 在这里做什么 |
|---|---|
| AIC，也叫 Cube 核 | 做矩阵乘法：GMM1 是专家的第一层，GMM2 是第二层 |
| AIV0 | 做 ACTQ，即 GMM1 后的激活与量化，把结果准备成 GMM2 可用的输入 |
| AIV1 | 主要做 Dispatch 和 Combine，负责计算前后的数据搬运与处理 |
| ROUTE_SEND | 处理并发送路由下标等信息，让各卡知道需要哪些 token |
| Dispatch | 按路由搬运 token 数据，供 GMM1 计算 |
| Combine | 处理专家输出并送回需要它的卡；去重路径还会合并可合并的结果 |
| Unpermute | 将返回的专家结果按原 token 顺序重排，并完成输出合并 |

最基本的数据关系是：Dispatch 送来输入 → AIC 做 GMM1 → AIV0 做 ACTQ → AIC 做 GMM2 → AIV1 做 Combine → Unpermute 整理输出。不同数据块可以同时走在这条链的不同位置，因此总时间不能简单地把所有阶段耗时相加。下面“矩形”（tile）就是流水图里的一块任务，“一波”（wave）是调度中一起安排的一批块。“密排”指在忽略短衔接后，连续执行这些块，不再额外加入依赖等待。

本文建立从 ROUTE_SEND 开始到 Unpermute 结束的时间模型，用来比较 baseline 与去重。模块的块数和单块耗时作为输入，下面逐段说明怎样拼成总时间；暂不展开 shape 到块数、MAC 或字节数到单块耗时的计算。所有时刻统一以 ROUTE_SEND 开始为零点，更早的准备和 Unpermute 之后的清理不计入本次范围。因此，本文的总时间是这个明确区间的模型值，不直接等同于完整 kernel 的测量耗时。这是一套待校准、待验证的拼接框架；模块成本和关键假设都核实后，才能据此判断实际切换收益。

| 符号 | 含义 |
|---|---|
| $p$ | 方案下标，$b$ 表示 baseline，$d$ 表示去重 |
| $s$ | 模块或矩形类型，例如 GMM1、GMM2、Dispatch、Combine |
| $x$ | 计数范围，例如 middle、tail、back；不是另一类工作 |
| $N_{s,x,p}$ | 方案 $p$ 的一个核在范围 $x$ 内，要处理多少个 $s$ 类块 |
| $T_{s,\mathrm{block},p}$ | 方案 $p$ 中，一个 $s$ 类块的耗时 |
| $T_{\mathrm{RouteSend}}$ | 路由发送阶段的耗时，两种方案先共用 |
| $T_{\mathrm{SharedGMM1,end},p}$ | shared GMM1 相对零点的结束时刻；不直接等同于它自身的耗时 |
| $T_{\mathrm{sync,in}}$ | 输入同步的耗时：AIV1 卡内集合、卡间同步、再次卡内集合；不包含 count/epoch 发送和 prepass |
| $T_{\mathrm{prepass}}$ | AIV1 在进入首段 Dispatch 前完成的 prepass 耗时 |
| $T_{\mathrm{Dispatch,first},p}$ | 首段 Dispatch 启动后，让第一个目标 GMM1 可以启动所需的时间，本版只计必要的数据供给 |
| $T_{\mathrm{startup},p}$ | 尾段 Dispatch 启动后，传输到足以启动目标 GMM1 所需的时间；不是可忽略的短衔接 |
| $T_{\mathrm{Unpermute},p}$ | Unpermute 实际重排、合并和读写的耗时，不含等待 |
| $T_{\mathrm{head},p},T_{\mathrm{middle},p},T_{\mathrm{tail},p}$ | 头部、中间和尾部各自的时间长度 |
| $T_p$ | 方案 $p$ 从 ROUTE_SEND 到 Unpermute 结束的总时间 |
| $\Delta T$ | 去重耗时减 baseline 耗时；负值表示去重更快 |

各段串行工作采用同一写法：先数块，再乘单块时间：

$$
T_{x,p}=\sum_s N_{s,x,p}T_{s,\mathrm{block},p}.
$$

这只是统一的记账方式，不表示所有模块可以同时相加。串行的部分相加，并行的分支比较谁更晚。不同形状的块可以作为不同的 $s$，不要求满块和尾块耗时相同。

图中箭头表示执行先后或数据依赖，框的宽度不代表耗时；并行分支只有汇合后才能继续。

## 2. 先把不同卡、不同核的快慢差异放到一边

实际运行时，各卡、各核分到的数据不一定一样，调度也会让有些核先跑、有些核后跑。逐核追这些差异，模型会很复杂。

**这里先采用三个整体假设：**

- 每个同类核分到的数据量一样，所有卡、所有核按相同进度推进。例如，同一轮 GMM2 在各 AIC 上同时开始、同时结束。这里不是说 AIC 与 AIV 做同一种工作，而是同一类工作没有卡间、核间快慢差。
- 本文只讨论 baseline 为通信 bound（通信受限）、去重后为计算 bound（计算受限）的场景。baseline 中间段沿 AIV1 的 Dispatch／Combine 计时，去重中间段沿 Cube 计时；分类不保证轨道完全没有等待，密排仍是单独采用的近似。
- 块间短间隔、通知和零碎收尾先忽略，主要计算和数据传输仍计时。

所以，后面用一个核的时间就能代表同类核的时间。这是为了简化建模，并不表示真实流水也完全同步。bound 只描述中间阶段，不能直接决定最后是谁拖尾。

**块数的计法：**每个专家的数据按矩形切块，不够一块也要占一个块，所以块数向上取整。比如每块最多 256 行，300 行要分成两块，分别处理 256 行和 44 行。两块各要多久可以分别给出，本框架不强行规定它们耗时相同。块数取整不等于有效数据就变成了 512 行。

## 3. 总体思路：分三段计时，再相减看收益

我们先分别算出 baseline 和去重的总时间，再用去重减 baseline，判断是否值得切换。每个方案都拆成**头部、中间、尾部**三段；两方案的切分点不同，但统计范围相同，都是从 ROUTE_SEND 开始到 Unpermute 结束。

### 3.1 两个切分点在哪里

| 方案 | 头部 | 中间 | 尾部 |
|---|---|---|---|
| baseline（通信 bound） | ROUTE_SEND 开始 → 首个 Combine 开始 | 首个 Combine 开始 → 最后一波 Dispatch 开始 | 最后一波 Dispatch 开始 → Unpermute 结束 |
| 去重（计算 bound） | ROUTE_SEND 开始 → 首个 routed GMM1 开始 | 首个 routed GMM1 开始 → shared GMM2 结束 | shared GMM2 结束 → Unpermute 结束 |

头部解决“主流水什么时候能开始”；中间沿主导轨道累计密排工作；尾部比较剩余计算与通信谁更晚，再加 Unpermute 的实际处理时间。去重尾部若通信已经被 Cube 覆盖，就只剩 Unpermute；若没有覆盖，只补超出 Cube 的部分。

**流程总览：先沿图看一遍，再逐段计时**

![MegaMoE 流程总览：baseline 通信 bound 与去重计算 bound 的分段及换算参考点](images/overview.jpg)

图中每个示例从上到下依次是 AIC、AIV0、AIV1。蓝色是 GMM1，绿色是 GMM2，紫色是 ACTQ，红色是 Dispatch，黄色是 Combine，橙色是 prepass。`W0` 到 `W4` 表示第 0 到第 4 波，框表示这一波的工作，不一定只有一个矩形。上面两条是 baseline，下面两条是去重；每种方案各画了 GMM2 往后排一波与不后移的顺序，具体调度在 4.2 节解释。

按编号读，三段就是 **1 → 2 → 3 → 5**：

| 标记 | baseline（上两条） | 去重（下两条） |
|---|---|---|
| **1：计时起点** | ROUTE_SEND 开始 | ROUTE_SEND 开始，后续输入准备里多了 prepass |
| **2：头部结束** | 首个 Combine 开始，接下来沿 AIV1 累计通信 | 首个 routed GMM1 开始，接下来沿 AIC 累计计算 |
| **3：中间结束** | 最后一波 Dispatch 开始；从这里向后推算剩余 Cube 与 Combine | shared GMM2 结束；计算已计完，只补通信超出它的部分 |
| **4：尾部换算参考点** | 从标记 3 开始换算，不另设标记 4；黑箭头表示由最后 Dispatch 的输入供给推到最后 GMM1 的启动 | 橙色 4 标出回推用的 GMM2 结束位置，再由它推对应 Combine；它在中间段内，不是尾部起点 |
| **5：计时终点** | Unpermute 结束 | Unpermute 结束 |

图里很直观的一点是：AIV1 搬输入时 AIC 可以在计算，AIV0 的 ACTQ 也穿插其中，所以不能把三条轨道的框全部串起来相加。尾部的黑箭头则帮助我们在计算与通信之间换算；能否按密排继续推，要依赖后文的“组间密排”和“前面不积压”假设。去重的 Combine 还要满足对应专家的输出就绪条件，不能把示意箭头理解成任意一个 GMM2 矩形结束都能触发 Combine。

这是一张调度示意图，不是等比例的实测流水；各示例的 shape 不全相同，不能直接用框宽比较收益。图中保留了实际存在的同步和 AIV0 末尾 Combine，是否单独计时仍按正文假设处理。

### 3.2 每段分别建模，总时间相加

串行工作相加，并行分支取较晚者。各段内部已经处理依赖关系，三段在时间上顺次相接，所以：

$$
\begin{aligned}
T_b&=T_{\mathrm{head},b}+T_{\mathrm{middle},b}+T_{\mathrm{tail},b},\\
T_d&=T_{\mathrm{head},d}+T_{\mathrm{middle},d}+T_{\mathrm{tail},d}.
\end{aligned}
$$

baseline 的最后一波 Dispatch 留给尾部，不再计入中间；去重尾部回推到 GMM2 只是为了定位 Combine 的就绪点，不会把已计过的 Cube 工作再加一遍。

这套切分要求 baseline 的首个 Combine 不晚于最后 Dispatch 开始。若顺序相反，应重新选择边界，不能得到负的中间时间。起点不积压、后续供给及时及 AIV0 覆盖条件不成立时，也需要修正对应分支，后面会逐块说明。

### 3.3 两方案相减，判断去重收益

$$
\Delta T=T_d-T_b.
$$

$\Delta T<0$ 表示模型预测去重更快，$\Delta T>0$ 表示 baseline 更快；接近零时，要结合预测误差判断。分段是为了把各项成本算清楚，最终判断依据是总时间之差，不能把某一段的差单独当作总收益。

下面先说明头部、尾部的依赖与换算，再累计中间工作。第 7 节给出一阶段简化版本及其三项收益公式，第 8 节据此拆解需要分析的量。

## 4. 头部：什么时候能开始主流水

### 4.1 baseline：先定位首个 routed GMM1

**先看实际分工。** 当前 W8A8、带 shared expert 的路径中，三个角色同时推进：

| 角色 | 头部在做什么 | 后续交给谁 |
|---|---|---|
| AIC | 先做 shared GMM1，再进入 routed GMM1 | GMM1 输出交给 AIV0 做 ACTQ |
| AIV0 | 做 shared GMM1 对应的激活量化，随后处理 routed GMM1 的输出 | ACTQ 输出供 AIC 做 GMM2 |
| AIV1 | ROUTE_SEND 发送路由下标，随后发送 count/epoch、做输入同步，再准备并执行 Dispatch | Dispatch 把 routed GMM1 的输入搬到可用位置 |

#### 4.1.1 实际分工与阶段边界

**头部的实际阶段边界。** ROUTE_SEND 打点结束后，AIV1 还要发送各专家命中的数量（count），并带上本轮执行的标记（epoch），之后才进入输入同步。因此，ROUTE_SEND 与输入同步之间并不是一段纯空隙，也不能把这段发送直接算进输入同步。输入同步依次包含 AIV1 的卡内集合、卡间通知与等待、再次卡内集合，并不是让 AIC、AIV0、AIV1 全部停下来集合。

同步完成也不等于接收侧已经读到了本轮 count：后续使用这些数量前，还要检查它们携带的 epoch，必要时继续等待。这是实际的数据就绪检查。下面把这些边界说清楚，但本版先不单独计算 count/epoch 发送和这项额外等待。

**图 1：头部三条轨道怎样配合**

![头部：AIC、AIV0 与输入供给共同决定 GMM1 启动](images/figure_1.jpg)

图中三个条件共同决定启动：AIC 做完 shared GMM1、Dispatch 输入够用，以及 AIV0 释放相关缓冲并满足同步条件。图按当前简化省略了 count/epoch 发送，以及同步后检查 count 就绪时可能发生的等待。

#### 4.1.2 启动条件与计时

首个 routed GMM1 需要 AIC 完成 shared GMM1、AIV1 送够输入，还要满足 AIV0 相关的缓冲复用／同步条件。AIV0 正在处理 shared 激活量化时，可能尚未释放首块 GMM1 所需的输出缓冲，从而使 AIC 等待。Dispatch 不必整波搬完，目标块的输入够用即可。

用 $T_{\mathrm{AIV0,ready},p}$ 表示 AIV0 不再阻塞首个 routed GMM1 的时刻，同样相对 ROUTE_SEND 开始计时。这里只把它作为输入，不展开缓冲和同步细节，也不直接把它等同于全部 shared ACTQ 的结束时刻。

**本块的简化假设：**

- 暂时忽略 ROUTE_SEND 之后、输入同步之前的 count/epoch 发送耗时，也忽略同步后检查 count 就绪时的额外等待。它们实际存在，这里只是先不计时；没有把它们并入 $T_{\mathrm{RouteSend}}$ 或 $T_{\mathrm{sync,in}}$。baseline 和去重共用这项近似。

**据此计时。** 三个条件取最晚就绪的位置，不把并行工作相加：

$$
T_{\mathrm{GMM1,first,start},b}
=\max\left(
T_{\mathrm{SharedGMM1,end},b},
T_{\mathrm{AIV0,ready},b},
T_{\mathrm{RouteSend}}+T_{\mathrm{sync,in}}+T_{\mathrm{Dispatch,first},b}
\right).
$$

这里先得到“首个 routed GMM1 开始”的中间位置，下一节继续推到首个 Combine，作为 baseline 头部的终点。

### 4.2 baseline 通信 bound：继续找到首个 Combine

**先看首个 GMM1 之后的执行关系。** AIC 产生 GMM1 输出，AIV0 对它做 ACTQ，AIC 再用 ACTQ 的结果做 GMM2；AIV1 拿到 GMM2 输出才能 Combine。但 AIV1 也要做 Dispatch，即使 GMM2 已完成，它也不能把手头未完成的 Dispatch 丢下就开始 Combine。

所以这里要分别找两个位置：**首个 Combine 所需的 GMM2 何时完成，AIV1 何时做完排在它前面的 Dispatch。** 两者较晚的那个，就是首个 Combine 的开始。下面分开计算这两个位置，不把中间整段时间当成一个不透明的参数。

**本块的简化假设：**

- 沿用 4.1 节的首个 GMM1 启动假设。
- ACTQ 与 Cube 工作重叠并及时供给，从首个 GMM1 到首个 GMM2 按 Cube 密排计时，不单独增加 ACTQ 耗时或等待。

#### 4.2.1 Cube：对应的 GMM2 何时完成

**直接沿 Cube 往后算。** 本版假设 ACTQ 在 AIV0 上与 Cube 工作重叠，并能及时供给 GMM2，因此不再逐块推 ACTQ 的完成时刻，也不额外加入 ACTQ 等待。需要累计的只有首个 GMM2 之前安排了多少 GMM1，以及这个 GMM2 自身的计算时间。

**再看 AIC 何时轮到这个 GMM2。** 一波就是调度中安排的一批数据块。当前代码有两种计算顺序：

**图 2：同样的工作，GMM2 安排的位置不同**

![GMM2 往后排一波，是为了让 AIC 少等 ACTQ](images/figure_2.jpg)

这里只画 AIC 的执行顺序，ACTQ 在 AIV0 上配合供给。

“滞后”指主动把同一波的 GMM2 往后安排，不是说这块 GMM2 本身算得更慢。这样 AIC 可以在 AIV0 做第 1 波 ACTQ 时先算第 2 波 GMM1，减少等 ACTQ 的时间；代价是首个 GMM2 和对应 Combine 往后移，末尾也会多留一波 GMM2 要完成。这里展示的是有足够多波时的顺序，只有一波时直接在收尾阶段完成它的 GMM2。

因此，算首个 Combine 何时开始，要先按调度数出首个 GMM2 前有多少 GMM1 块。把这个数记为 $N_{\mathrm{GMM1,beforeFirstGMM2},b}$，直接得到首个 GMM2 的结束位置：

$$
T_{\mathrm{GMM2,first,end},b}
=T_{\mathrm{GMM1,first,start},b}
+N_{\mathrm{GMM1,beforeFirstGMM2},b}T_{\mathrm{GMM1,block},b}
+T_{\mathrm{GMM2,block},b}.
$$

不滞后时，累计首波 GMM1；滞后一波且至少有两波时，累计前两波 GMM1。只有一波时只累计现有的这一波。这里保留了 GMM2 对 ACTQ 输出的真实依赖，只是假设这项依赖不会让 Cube 额外停下来。

#### 4.2.2 AIV1：何时做完前置 Dispatch

**另一边看 AIV1。** 沿用上面的头部近似，忽略 count/epoch 发送和额外就绪等待后，累计路由发送、输入同步，再加排在首个 Combine 之前的 Dispatch：

$$
T_{\mathrm{AIV1,firstCombine,available},b}
=T_{\mathrm{RouteSend}}+T_{\mathrm{sync,in}}
+N_{\mathrm{Dispatch,beforeFirstCombine},b}T_{\mathrm{Dispatch,block},b}.
$$

这里计的是首个 Combine 前需要完成的 Dispatch，不只是让首个 GMM1 开始的那一点数据。因此不能用 $T_{\mathrm{Dispatch,first},b}$ 直接替代。

#### 4.2.3 合并两个条件

两边都到齐，首个 Combine 才能开始。通信 bound 的头部就在这里结束：

$$
T_{\mathrm{head},b}=T_{\mathrm{Combine,first,start},b}
=\max\left(T_{\mathrm{GMM2,first,end},b},
T_{\mathrm{AIV1,firstCombine,available},b}\right).
$$

上面的块数由实际调度规则决定，不能默认“一个 GMM1 + 一个 ACTQ + 一个 GMM2”就一定对应首个 Combine。

### 4.3 去重：输入准备里多了一段 prepass

#### 4.3.1 执行关系与假设

**执行关系。** AIC 仍做 shared GMM1，AIV0 仍做相应激活量化。变化在 AIV1：同样经过路由下标发送、count/epoch 发送和输入同步，随后做 prepass，整理去重所需的描述信息，再进入 Dispatch。prepass 在 AIV1 这条路径上，可以和 AIC 的 shared GMM1 重叠。

**图 3：prepass 放在哪里**

![去重头部：prepass 只加在 AIV1 的准备路径上](images/figure_3.jpg)

prepass 只延长图中的 AIV1 准备路径。图聚焦它与 shared GMM1 的重叠关系；AIV0 的缓冲就绪条件在下式中另行保留。图中同样省略 count/epoch 发送及后续就绪检查等待。

**本块的简化假设：**

- 沿用 4.1 节暂不计 count/epoch 发送与额外就绪等待的近似；AIV0 的启动限制保留在公式中。
- 按所有核同步推进的理想情况，用一个核的 prepass 时间代表这一段，不另加核间进度差。

#### 4.3.2 合并三条路径的就绪条件

**据此计时。** prepass 只加在 AIV1 的输入准备路径中，再与 AIC、AIV0 的就绪位置一起取 max：

$$
\begin{aligned}
T_{\mathrm{head},d}=\max\Big(&T_{\mathrm{SharedGMM1,end},d},T_{\mathrm{AIV0,ready},d},\\
&T_{\mathrm{RouteSend}}+T_{\mathrm{sync,in}}
+T_{\mathrm{prepass}}+T_{\mathrm{Dispatch,first},d}\Big).
\end{aligned}
$$

shared GMM1 足够长时，可以遮住一部分甚至全部 prepass 时间，所以不能把完整 prepass 直接加到整个 kernel 时间上。prepass 内部搬运已算在自身耗时中，不再计入 Dispatch。

## 5. 尾部：两条分支怎样汇合

### 5.1 依赖关系与两个关键假设

#### 5.1.1 收尾分工与换算依赖

先看三个角色各自怎样收尾：AIC 做完剩余 routed GMM2，再完成 shared GMM2；AIV0 处理最后的 ACTQ，去重时还可能参与末专家的特殊 Combine；AIV1 完成最后的 Dispatch 和 Combine，然后进入输出同步。Unpermute 要消费这些输出，所以这些分支的结束位置会影响它何时能继续做主体。

GMM2 与 Combine 之间有直接的数据依赖：AIC 产出结果，AIV1 才能处理它。Dispatch 与 GMM1 则是反方向的数据依赖：AIV1 先送输入，AIC 才能计算。后面的“换算”就是利用这两种依赖，从已知的一条轨道找到另一条轨道的起点。

#### 5.1.2 两个关键假设：起点不积压，后续不断供

依赖关系告诉我们数据什么时候就绪，但还不能保证另一条轨道能立刻开工、之后一直做下去。当前公式要靠下面两个假设，才能把“数据就绪时间 + 剩余工作耗时”换算成另一条轨道的结束时间。它们同时适用于计算 bound 和通信 bound，是尾部模型接下来优先验证的两点。

| 关键假设 | 去重：从专家 GMM2 输出就绪换算到 Combine | baseline：从 Dispatch 换算到 Cube |
|---|---|---|
| **换算起点没有前序积压** | 对应专家的全部 GMM2 输出就绪时，AIV1 已做完前面的 Dispatch、Combine，能立即接手对应 Combine | Dispatch 送够目标 GMM1 的首块输入时，AIC 已做完前面的计算，能立即启动目标 GMM1 |
| **换算后持续供给，组间密排** | 前一组 Combine 做完时，下一组需要的 GMM2 输出已就绪，可以接着做 | 剩余 Cube 工作推进时，Dispatch 和 ACTQ 持续及时供给，不因后续输入未就绪而出现组间等待 |

第一条管“能不能按时开始”，第二条管“开始后能不能连续推进”。两者互相独立；所有卡、所有同类核同步推进，也不能自动保证这两条成立。组内密排当前仍保留，不论是否慢一拍，主模型也都先保留组间密排。

#### 5.1.3 假设不成立时怎样修正

假设不成立时，分别补下面的等待：

- **起点有积压：** 开始时间取“数据就绪”和“前序工作结束”的较晚者。
- **组间断供：** 本组开始时间取“前组结束”和“本组输入就绪”的较晚者，再加本组耗时。

去重分支的具体修正见下文。baseline 若 Cube 中途等输入，也按同一原则补等待，不能只加计算块耗时。

这里说的是尾部换算的关键结构性假设，并不是全部误差来源。矩形数、单块耗时、核间进度不均衡，以及后面暂时忽略的 AIV0 独立拖尾、尾部同步等，仍需分别核实；仅凭 middle 的 bound 分类，不能证明上述两个假设成立。

去重的中间终点是 shared GMM2 结束；baseline 的中间终点是最后一波 Dispatch 开始。这两个位置都等于各自的 $T_{\mathrm{head}}+T_{\mathrm{middle}}$，中间段的块数计时在第 6 节给出。

### 5.2 Unpermute 怎样与前面的工作汇合

#### 5.2.1 提前执行与等待怎样处理

**为什么还要看 Unpermute 的等待？** Unpermute 做的是把专家结果放回原 token 顺序并合并成输出；它需要 routed 专家的结果，也需要 shared 专家的结果。执行过程中可以先处理已经就绪的部分，不一定一开始就等到所有结果齐全。

在此前观察到的一些流水中，最终最晚完成的轨道往往先处理少量数据，随后等待 shared GMM2，等结果到齐后才继续处理大部分数据。这里说的“提前处理的一小段”，就是那部分与其他工作重叠的实际计算，不是一个额外的固定阶段。

为了避免逐段跟踪哪些 token 已就绪，本版暂不扣除这点提前重叠的时间：把 Unpermute 的全部实际处理时间放在两条业务分支都结束之后。$T_{\mathrm{Unpermute},p}$ 只包含重排、合并及必要读写，不包含等待。这样会舍去提前处理带来的重叠收益；如果某个场景提前完成了很多工作，这个近似就需要调整。它是依据已有观察作的简化，不是说所有场景都只提前处理一点。

#### 5.2.2 尾部汇合的共同近似


- AIV0 的收尾被 AIC 或 AIV1 覆盖，暂不独立计时；去重时还要满足末专家特殊 Combine 不独立拖尾。
- 忽略 Unpermute 提前执行的重叠收益，把全部实际处理时间放在两条业务分支结束之后。
- 暂时忽略业务结束后剩余的卡内、卡间同步时间。业务汇合点取 shared GMM2 与 AIV1 业务结束的较晚者，作为 Unpermute 启动的模型近似，不等同于流水中 UNPERMUTE 矩形的实际起点。

此前也考虑过 AIC、AIV0、AIV1 三项取 max 的模型；它需要独立追踪最后 ACTQ，以及去重末专家的特殊 Combine，较为复杂，当前先采用两分支近似。若 AIV0 独立拖尾，需要恢复第三条分支。

### 5.3 baseline：从最后 Dispatch 开始换算

#### 5.3.1 起点、依赖与假设

**换算原理。** 通信 bound 时，中间沿 AIV1 累计，所以先知道最后一波 Dispatch 何时开始。AIV1 搬出足够的数据后，AIC 就可以启动目标 GMM1；随后 AIV0 做 ACTQ，AIC 消费其输出做 GMM2，最后完成 shared GMM2。与此同时，AIV1 继续完成这一波 Dispatch 和后续 Combine。两条路从同一个 Dispatch 起点出发，因此可以分别累计，再比较谁结束得晚。

**图 4：通信 bound，从最后 Dispatch 开始向两条轨道推算**

![通信 bound：从最后 Dispatch 开始，分别向后推](images/figure_4.jpg)

上下两条路都从 Dispatch 开始计时。上面的首块传输与下面的 Dispatch 是同一搬运过程的两个观察位置，不是额外搬一次；最后取 max，不把两条路相加。图中省略 AIV0 的 ACTQ，仍要求它及时供给 GMM2。

**本块的简化假设：**

- 目标 GMM1 拿到首块输入时，Cube 前序工作已经完成。
- 此后 Dispatch 与 ACTQ 持续供给，剩余 Cube 工作无长空洞；剩余 AIV1 工作也密排。
- 汇合采用第 5.2 节的共同近似：忽略 AIV0 独立拖尾、Unpermute 提前处理的重叠收益和尾部额外同步耗时。

#### 5.3.2 Cube 分支：首块传输加剩余计算

最后 Dispatch 启动后，只需先供给首个目标 GMM1 所需的数据，就可以开始算，不必等整波搬完。启动延迟之后，依次完成剩余 GMM1、routed GMM2、shared GMM2：

$$
\begin{aligned}
T_{\mathrm{Cube,tail},b}={}&T_{\mathrm{startup},b}
+N_{\mathrm{GMM1,tail},b}T_{\mathrm{GMM1,block},b}\\
&+N_{\mathrm{GMM2,tail},b}T_{\mathrm{GMM2,block},b}
+N_{\mathrm{SharedGMM2,tail},b}T_{\mathrm{SharedGMM2,block},b}
\end{aligned}
$$

这里的 $T_{\mathrm{startup},b}$ 是真实的首块输入传输时间，可以由所需数据量和有效带宽估算；它保留在公式中，不能随短衔接一起删掉。它只要求目标 GMM1 的首块输入够用，不要求整波 Dispatch 搬完。

这里的块数由理想同步下的调度决定，不能把最后 Dispatch 开始时尚未完成的前序 Cube 工作悄悄省略。本段采用的条件是：目标 GMM1 启动时，前序工作已完成；不满足就需要增加相应剩余工作。

#### 5.3.3 AIV1 分支：最后 Dispatch 加剩余 Combine

**通信 bound 以通信轨道密排为前提**：先完成最后一波 Dispatch，再连续处理剩余 Combine，不再逐组检查是否等待 GMM2，当前也不加入组间等待修正。总 wave 数充足时，不慢一拍剩最后两波 Combine，慢一拍剩最后三波；不足时只计实际存在的波。两／三波指工作范围，不是两／三个矩形。

它的持续时间为：

$$
\begin{aligned}
T_{\mathrm{AIV1,tail},b}={}&
N_{\mathrm{Dispatch,tail},b}T_{\mathrm{Dispatch,block},b}
+N_{\mathrm{Combine,tail},b}T_{\mathrm{Combine,block},b} .
\end{aligned}
$$

#### 5.3.4 两条分支汇合

两段都从最后 Dispatch 开始计时，所以可以直接比较持续时间。较晚的一条决定业务汇合点：

$$
T_{\mathrm{tail},b}
=\max\left(T_{\mathrm{Cube,tail},b},T_{\mathrm{AIV1,tail},b}\right)
+T_{\mathrm{Unpermute},b}.
$$

通信 bound 也可能最后等 Cube；这个 $\max$ 不能仅凭 middle 的分类删掉。

### 5.4 去重：按专家就绪换算 Combine

#### 5.4.1 专家级依赖与假设

**与 baseline 的实际区别。** AIC 仍负责 GMM2，AIV1 仍负责 Combine，但去重 Combine 要等对应专家的全部 GMM2 输出就绪，再处理该核分到的专家行。因此回推时要找到“这个专家全部算完”，而不是任意一个 GMM2 矩形完成。AIV0 除了 ACTQ，还可能参与末专家的特殊 Combine。

**换算原理。** 从 shared GMM2 结束往回找到选定专家的就绪位置，再从那里往后累计 AIV1 剩余专家的 Combine 时间。这里利用的是 GMM2 输出供给 Combine 的依赖，计数按完整专家处理段进行。

**本块的简化假设：**

- 计算 bound 的换算起点上 AIV1 没有前序积压；Combine 组内、组间均密排，无论是否慢一拍。
- 参考点到 shared GMM2 结束的剩余 Cube 工作密排。
- 采用第 5.2 节的汇合近似；AIV0 覆盖条件还包括去重末专家的特殊 Combine。

#### 5.4.2 选择换算点，确定剩余分组

去重从最后一波 GMM1 后的第一组 GMM2 换算。不慢一拍时，这组是最后一波；慢一拍且至少有两波时，这组是倒数第二波，后面还有最后一波。只有一波时只计现有的一波。参考点取该组首个对应 Combine 专家的**全部 GMM2 输出完成**，取本卡参与 AIC 的最晚完成时刻；不取单个 AIC 的首个矩形末尾。专家跨 wave 时，必须按完整专家就绪的位置归属，不能在 wave 边界提前消费。

分组按完整专家就绪的位置划分：跨 wave 的专家只计入全部输出就绪的那一组，不能在两组中重复计数。若某个 wave 没有可完成的专家，它不形成一个非空 Combine 组；下面两组公式只适用于确有两组剩余工作，只有一组时使用一组公式。专家到组、以及各核行段的具体计数仍是待补齐的输入，不能仅凭 wave 数就认定已经确定。

#### 5.4.3 按密排累计 Combine

令 $T_{\mathrm{ready},j,d}$ 为第 $j$ 组首个对应专家的就绪时间，$T_{\mathrm{Combine},j,d}$ 为该组各专家分给参考 AIV1 的 Combine 服务时间之和。由 Cube 结束位置减去相应剩余计算时间得到 $T_{\mathrm{ready},j,d}$。记首个就绪点之后的剩余 Cube 时间为：

$$
T_{\mathrm{back},d}=T_{\mathrm{SharedGMM2,end},d}-T_{\mathrm{ready},1,d}.
$$

只有一组剩余工作时（包括不慢一拍的情况）：

$$
T_{\mathrm{AIV1,end},d}=T_{\mathrm{ready},1,d}+T_{\mathrm{Combine},1,d}.
$$

慢一拍且有两组非空剩余工作时：

$$
T_{\mathrm{AIV1,end},d}=T_{\mathrm{ready},1,d}+T_{\mathrm{Combine},1,d}+T_{\mathrm{Combine},2,d}.
$$

#### 5.4.4 组间密排不成立时的修正

如果组间密排不成立，改为 $T_{\mathrm{AIV1,end},d}=\max(T_{\mathrm{ready},1,d}+T_{\mathrm{Combine},1,d},T_{\mathrm{ready},2,d})+T_{\mathrm{Combine},2,d}$。例如末组只剩末专家，$T_{\mathrm{ready},2,d}$ 就是末专家全部 GMM2 完成时刻。当前主模型不加这一等待；只有放弃组间密排假设时才使用该修正。组内仍沿用密排假设，专家级换算点和行段工作量与 shape 的统一计数尚需展开，不直接套 baseline 的 tile 数。

本版只采用去重计算 bound 分支；专家级分组和行段计数仍需单独给出。

若末专家特殊 Combine 独立拖尾，就需要恢复 AIV0 分支。

#### 5.4.5 尾部只补超过 Cube 的部分

中间段已算到 shared GMM2 结束，因此尾部为：

$$
\begin{aligned}
T_{\mathrm{tail},d}
={}&\max\left(0,T_{\mathrm{AIV1,end},d}-T_{\mathrm{SharedGMM2,end},d}\right)\\
&+T_{\mathrm{Unpermute},d}.
\end{aligned}
$$

## 6. 中间：在头尾之间累计密排工作

### 6.1 baseline 通信 bound：沿 AIV1 推进

**执行关系。** AIV1 在同一轨道上依次执行 Dispatch 和 Combine，AIC 与 AIV0 在它们之间完成 GMM 和 ACTQ。既然这次沿 AIV1 计时，就累计它实际要做的两类工作；Cube 和 ACTQ 不再整段加一遍，但如果供给太慢，AIV1 仍可能等它们。

**本块的简化假设：**

- AIV1 上 Dispatch 与 Combine 密排推进，无额外长等待。

这套切段适用于首个 Combine 不晚于最后一波 Dispatch 开始的情况；这是区间有效的条件。为了给尾部两条分支选同一个起点，我们把中间段停在**最后一波 Dispatch 开始**：

$$
\begin{aligned}
T_{\mathrm{middle},b}={}&
N_{\mathrm{Dispatch,middle},b}T_{\mathrm{Dispatch,block},b}
+N_{\mathrm{Combine,middle},b}T_{\mathrm{Combine,block},b}
\end{aligned}
$$

这两个块数只覆盖“首个 Combine 开始，到最后 Dispatch 开始之前”的区间。头部已完成的 Dispatch 不再计入，最后一波 Dispatch 留给尾部：

$$
T_{\mathrm{Dispatch,last,start},b}=T_{\mathrm{head},b}+T_{\mathrm{middle},b}.
$$

### 6.2 去重：仍按 Cube 密排

**执行关系。** 去重改变输入整理与 Combine 处理方式；每个专家需要完成的 GMM 乘加工作仍然存在。AIC 负责这些 GMM，AIV0 做 ACTQ，AIV1 走去重后的 Dispatch／Combine 路径。

**本块的简化假设：**

- 去重按计算 bound 建模，Cube 密排，Dispatch 与 ACTQ 及时供给。
- 暂不把去重路径引起的供给节奏变化算成额外 Cube 等待。

变化主要在 prepass 和通信路径；有效 MAC 相同不自动代表单块耗时相同，两方案的 Cube 参数仍分别保留。中间段仍按三类 Cube 块相加：

$$
\begin{aligned}
T_{\mathrm{middle},d}={}&
N_{\mathrm{GMM1,middle},d}T_{\mathrm{GMM1,block},d}
+N_{\mathrm{GMM2,middle},d}T_{\mathrm{GMM2,block},d}\\
&+N_{\mathrm{SharedGMM2,middle},d}T_{\mathrm{SharedGMM2,block},d}
\end{aligned}
$$

所以：

$$
T_{\mathrm{SharedGMM2,end},d}=T_{\mathrm{head},d}+T_{\mathrm{middle},d}.
$$

Cube 块耗时按对应 shape 给出；Dispatch、Combine 和 Unpermute 的参数分别保留。

## 7. 一阶段简化版本

前面保留完整的拼接框架，第一阶段先选一个较小的切入口：**baseline 为通信 bound，去重后为计算 bound**。暂时不处理两条尾部分支的交叉拖尾，先把主要成本算出来，再逐步恢复完整框架。

### 7.1 简化范围与假设

- baseline 以最后 Combine 结束作为业务结束位置，随后直接加 Unpermute；去重以 shared GMM2 结束作为业务结束位置，随后直接加 Unpermute。这是额外的尾部近似，不是 middle 的 bound 分类自动保证的结论。
- baseline 的 shared GMM1 完全盖住首个 Combine 之前的所有 Dispatch。首个 routed GMM1 紧接 shared GMM1 开始，首个 Combine 只需等对应 GMM2 输出就绪。
- 去重头部的 $T_{\mathrm{Dispatch,first},d}$ 暂时忽略，输入准备只计 ROUTE_SEND、输入同步和 prepass。
- 两方案头部均假设 AIV0 的缓冲复用／同步条件已及时满足，不额外推迟首个 routed GMM1，因此本节从头部 max 中去掉 $T_{\mathrm{AIV0,ready},p}$。
- AIV0 负责 ACTQ（激活量化），本版假设它及时准备好 GMM2 输入，不让 AIC 额外等待；不是把 ACTQ 工作删掉。继续采用理想同步、密排及忽略尾部同步的近似。

### 7.2 需要累计的三个时间段

下面三个中间量把当前要比较的工作范围说清楚：

| 符号 | 时间范围 |
|---|---|
| $T_{\mathrm{Cube},d}$ | 去重从首个 routed GMM1 开始到 shared GMM2 结束的密排计算时间 |
| $T_{\mathrm{FirstCombine},b}$ | baseline 从首个 routed GMM1 开始到首个 Combine 开始的时间长度，不是绝对时刻 |
| $T_{\mathrm{Comm},b}$ | baseline 从首个 Combine 开始到最后 Combine 结束的密排时间，包含其间的 Dispatch 和 Combine |

在本节的覆盖假设下，baseline 的首个 Combine 不再受前置 Dispatch 限制，所以：

$$
T_{\mathrm{FirstCombine},b}
=N_{\mathrm{GMM1,beforeFirstGMM2},b}T_{\mathrm{GMM1,block},b}
+T_{\mathrm{GMM2,block},b}.
$$

不慢一拍时累计首波 GMM1；慢一拍时累计前两波，只有一波时只计一波。最后再加首个对应 GMM2 的耗时。若块大小不同，按各块实际耗时求和。

### 7.3 两方案总时间与收益

用 $T_{\mathrm{SharedGMM1,end}}$ 表示 shared GMM1 的结束位置，两个方案分别得到：

$$
T_b=T_{\mathrm{SharedGMM1,end}}
+T_{\mathrm{FirstCombine},b}+T_{\mathrm{Comm},b}
+T_{\mathrm{Unpermute},b}.
$$

$$
\begin{aligned}
T_d={}&\max\left(T_{\mathrm{SharedGMM1,end}},
T_{\mathrm{RouteSend}}+T_{\mathrm{sync,in}}+T_{\mathrm{prepass}}\right)\\
&+T_{\mathrm{Cube},d}+T_{\mathrm{Unpermute},d}.
\end{aligned}
$$

按去重减 baseline 作差，第一阶段直接使用下面这个三项式：

$$
\boxed{
\begin{aligned}
\Delta T={}&
\underbrace{\max\left(0,
T_{\mathrm{RouteSend}}+T_{\mathrm{sync,in}}+T_{\mathrm{prepass}}
-T_{\mathrm{SharedGMM1,end}}\right)}_{\text{去重头部未被 shared GMM1 覆盖的额外等待}}\\[6pt]
&+\underbrace{T_{\mathrm{Cube},d}-T_{\mathrm{FirstCombine},b}-T_{\mathrm{Comm},b}}_{\text{主流水耗时差：去重计算减基线启动及通信}}\\[6pt]
&+\underbrace{T_{\mathrm{Unpermute},d}-T_{\mathrm{Unpermute},b}}_{\text{输出整理耗时差}}.
\end{aligned}}
$$

$\Delta T<0$ 表示模型预测去重更快，$\Delta T>0$ 表示 baseline 更快；接近零时需结合模型误差判断。$T_{\mathrm{Comm},b}$ 只覆盖首个 Combine 开始到最后 Combine 结束，首个 Combine 之前的 Dispatch 已假设被 shared GMM1 覆盖，不再重复累计。

## 8. 按三项差值拆解需要分析的量

优先补齐下面的输入，直接代入第 7 节的简化式。表里的时间范围与公式一致；ROUTE_SEND 和输入同步先用常数，其余逐步建模。

| 对应差值 | 要分析的量 | 工作类型 | 第一版处理方式 |
|---|---|---|---|
| 头部额外等待 | $T_{\mathrm{RouteSend}}$ | 计算 + 跨卡通信 | **假设为常数**，先不展开 shape 依赖 |
| 头部额外等待 | $T_{\mathrm{sync,in}}$ | 同步／控制 | **假设为常数**，先不展开 shape 依赖 |
| 头部额外等待 | $T_{\mathrm{prepass}}$ | 计算，含本卡元数据处理 | 给出每核工作量和耗时 |
| 头部额外等待 | $T_{\mathrm{SharedGMM1,end}}$ | shared GMM1 计算及其开始偏移 | 两方案共用，作为覆盖输入准备的结束位置 |
| 主流水耗时差 | $T_{\mathrm{Cube},d}$ | 计算 | 累计全部 routed GMM1、GMM2 与 shared GMM2，不含已在头部处理的 shared GMM1 |
| 主流水耗时差 | $T_{\mathrm{FirstCombine},b}$ | 计算 | 在 Dispatch 已被覆盖、AIV0 及时供给的假设下，累计首个 GMM2 之前的 GMM1，再加首个 GMM2 的时间 |
| 主流水耗时差 | $T_{\mathrm{Comm},b}$ | Dispatch／Combine 的跨卡通信及相关处理 | 只累计首个 Combine 开始到最后 Combine 结束的工作，按密排计时 |
| 输出整理耗时差 | $T_{\mathrm{Unpermute},d}-T_{\mathrm{Unpermute},b}$ | 计算，含本卡搬运 | 两方案分别给出实际处理耗时，再相减；不默认相等 |

第一版忽略去重首批 Dispatch 的启动供给时间，也不单独预测去重最后 Combine 是否晚于 shared GMM2；这两项都属于第 7 节明确采用的简化。后续需要恢复时，再使用完整框架。
