"""One private JSON5 configuration. Relative paths resolve beside that file."""
import copy
import json
import json5
import os
from pathlib import Path
from urllib.parse import urlsplit
from .auth import private_write
from .platform_support import check_private_path


ROOT = Path(__file__).resolve().parents[1]
EVENTS = set(('authentication data ssherror connection-error disconnect sftp-status terminal resize '
              'sftp-directory sftp-stat-result sftp-operation-result sftp-upload-ready sftp-upload-ack '
              'sftp-download-ready sftp-download-chunk sftp-complete sftp-error sftp-list sftp-stat '
              'sftp-mkdir sftp-delete sftp-upload-start sftp-upload-chunk sftp-upload-cancel '
              'sftp-download-start sftp-download-cancel').split())


class ConfigError(ValueError):
    pass


def config_path(path=None):
    return Path(path or os.getenv('BRIDGE_CONFIG', ROOT / '.state/config.json5')).expanduser().resolve()


DEFAULTS = {'version': 1,
 'state_directory': '.',
 'ssh': {'host': '0.0.0.0',
          'port': 2222,
          'username': 'root',
         'password': '',
         'authorized_keys': 'client_key.pub',
         'host_key': 'host_key',
         'max_sessions': 8,
         'login_timeout_seconds': 15},
  'webssh': {'url': 'http://127.0.0.1:8080',
             'entry_path': '/ssh/host/',
             'device_id': '',
             'socketio_path': '/ssh/socket.io/',
            'namespace': '/',
            'transports': ['websocket'],
            'cookie': '',
            'headers': {},
            'tls_verify': True,
            'http_timeout_seconds': 20,
            'connect_timeout_seconds': 15,
            'operation_timeout_seconds': 30,
            'exec_timeout_seconds': 120,
            'bootstrap_timeout_seconds': 15,
            'events': {},
            'query': {},
            'auth': {},
         'entry_method': 'GET',
         'entry_query': {},
         'entry_form': {},
         'cookie_refresh': {'url': '',
                            'body': '',
                            'content_type': 'text/plain',
                            'session_path': '',
                            'interval_seconds': 21600,
                            'timeout_seconds': 20,
                            'retry_seconds': 60}},
 'files': {'max_bytes': 3355443200,
           'max_handles_per_session': 16,
           'upload_chunk_bytes': 32768,
           'verify_upload_sha256': True},
 'http_proxy': {'enabled': False,
                'host': '0.0.0.0',
                'port': 8088,
                'timeout_seconds': 30},
 'logging': {'level': 'INFO',
             'directory': 'logs',
             'max_bytes': 5242880,
             'backup_count': 3,
             'console': True,
             'protocol_events': False,
              'redact_secrets': False,
              'command_text': True,
              'terminal_data': False,
              'http_trace': False},
 'demo': {'bind_host': '127.0.0.1',
          'gateway_port': 8080,
          'webssh2_port': 3000,
          'target_port': 2200,
          'website_user': 'demo',
          'website_password': 'demo-pass',
          'target_user': 'root',
          'target_password': 'mock-root-pass',
          'cookie_ttl_seconds': 28800,
          'workspace': 'workspace',
          'target_host_key': 'native_host_key',
          'webssh2_source': 'webssh2',
          'webssh2_host': '127.0.0.1',
          'target_host': '127.0.0.1'}}


def defaults():
    return copy.deepcopy(DEFAULTS)


def _merge(base, updates, prefix=''):
    if not isinstance(updates, dict):
        raise ConfigError('Expected an object at ' + (prefix or 'root'))
    for key, value in updates.items():
        name = prefix + key
        if key not in base:
            raise ConfigError('Unknown configuration field: ' + name)
        if name in ('webssh.headers', 'webssh.events', 'webssh.query', 'webssh.entry_query', 'webssh.entry_form'):
            if not isinstance(value, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in value.items()):
                raise ConfigError(name + ' must be a string-to-string object')
            base[key] = value
        elif name == 'webssh.auth':
            if not isinstance(value, dict):
                raise ConfigError('webssh.auth must be an object')
            base[key] = value
        elif isinstance(base[key], dict):
            _merge(base[key], value, name + '.')
        else:
            expected = type(base[key])
            if expected is int:
                valid = isinstance(value, (int, float)) and not isinstance(value, bool)
            else:
                valid = isinstance(value, expected)
            if not valid:
                raise ConfigError('Invalid type at ' + name)
            base[key] = value
    return base


def read_document(path):
    try:
        if not check_private_path(path):
            raise ConfigError('Private config must have mode 0600: ' + str(path))
        with path.open(encoding='utf-8-sig') as stream:
            return json5.load(stream)
    except ConfigError:
        raise
    except UnicodeDecodeError:
        raise ConfigError('Config must be UTF-8 encoded JSON5') from None
    except ValueError as error:
        raise ConfigError('Invalid JSON5: ' + str(error)) from None
    except OSError as error:
        raise ConfigError('Cannot read config: ' + str(path)) from error


def validate(document):
    data = _merge(defaults(), copy.deepcopy(document))
    if data['version'] != 1:
        raise ConfigError('Unsupported config version')
    for section, fields in {'ssh': ['port', 'max_sessions', 'login_timeout_seconds'],
                            'webssh': ['http_timeout_seconds', 'connect_timeout_seconds', 'operation_timeout_seconds', 'exec_timeout_seconds', 'bootstrap_timeout_seconds'],
                            'files': ['max_bytes', 'max_handles_per_session', 'upload_chunk_bytes'],
                            'http_proxy': ['port', 'timeout_seconds'],
                            'logging': ['max_bytes'],
                            'demo': ['gateway_port', 'webssh2_port', 'target_port', 'cookie_ttl_seconds']}.items():
        for key in fields:
            if data[section][key] <= 0:
                raise ConfigError(section + '.' + key + ' must be positive')
    for section, key in [('ssh', 'port'), ('demo', 'gateway_port'), ('demo', 'webssh2_port'), ('demo', 'target_port'), ('http_proxy', 'port')]:
        if not isinstance(data[section][key], int) or data[section][key] > 65535:
            raise ConfigError(section + '.' + key + ' must be a valid TCP port')
    for section, key in [('ssh', 'max_sessions'), ('files', 'max_bytes'), ('files', 'max_handles_per_session'),
                         ('files', 'upload_chunk_bytes'), ('logging', 'max_bytes'), ('logging', 'backup_count')]:
        if not isinstance(data[section][key], int):
            raise ConfigError(section + '.' + key + ' must be an integer')
    if data['logging']['backup_count'] < 1:
        raise ConfigError('logging.backup_count must be at least 1')
    if data['logging']['level'].upper() not in ('DEBUG', 'INFO', 'WARNING', 'ERROR'):
        raise ConfigError('logging.level must be DEBUG/INFO/WARNING/ERROR')
    url = urlsplit(data['webssh']['url'])
    if url.scheme not in ('http', 'https') or not url.hostname or url.username or url.query or url.fragment or url.path not in ('', '/'):
        raise ConfigError('webssh.url must be an http(s) origin without credentials, path, or query')
    for key in ('entry_path', 'socketio_path', 'namespace'):
        if not data['webssh'][key].startswith('/'):
            raise ConfigError('webssh.' + key + ' must begin with /')
    refresh = data['webssh']['cookie_refresh']
    for key in ('interval_seconds', 'timeout_seconds', 'retry_seconds'):
        if isinstance(refresh[key], bool) or not isinstance(refresh[key], (int, float)) or refresh[key] <= 0:
            raise ConfigError('webssh.cookie_refresh.' + key + ' must be positive')
    if refresh['url']:
        refresh_url = urlsplit(refresh['url'])
        if refresh_url.scheme not in ('http', 'https') or not refresh_url.hostname or refresh_url.username or refresh_url.fragment:
            raise ConfigError('webssh.cookie_refresh.url must be an http(s) URL without credentials')
    if not refresh['content_type'] or any(character in refresh['content_type'] for character in '\r\n'):
        raise ConfigError('webssh.cookie_refresh.content_type must be one header value')
    if refresh['session_path'] and not refresh['session_path'].startswith('/'):
        raise ConfigError('webssh.cookie_refresh.session_path must begin with /')
    if not data['http_proxy']['host'] or any(character in data['http_proxy']['host'] for character in ' \t\r\n'):
        raise ConfigError('http_proxy.host must be one listen address without whitespace')
    if data['webssh']['entry_method'] not in ('GET', 'POST'):
        raise ConfigError('webssh.entry_method must be GET or POST')
    if set(data['webssh']['query']) & {'sid', 'EIO', 'transport', 't'}:
        raise ConfigError('Do not configure dynamic Socket.IO sid/EIO/transport/t query fields')
    transports = data['webssh']['transports']
    if not transports or not all(value in ('websocket', 'polling') for value in transports):
        raise ConfigError('webssh.transports supports websocket/polling only')
    for key, value in data['webssh']['headers'].items():
        if key.lower() in ('cookie', 'host', 'connection', 'upgrade'):
            raise ConfigError('Reserved header; use webssh.cookie for Cookie')
        if not key or any(c in key + value for c in '\r\n'):
            raise ConfigError('Invalid webssh header')
    if any(c in data['webssh']['cookie'] for c in '\r\n'):
        raise ConfigError('webssh.cookie must be one header line')
    if set(data['webssh']['events']) - EVENTS or any(not value for value in data['webssh']['events'].values()):
        raise ConfigError('Unknown or empty webssh event mapping')
    if not data['ssh']['username']:
        raise ConfigError('ssh.username cannot be empty')
    return data


def save_document(path, document):
    validate(document)
    private_write(path, (json.dumps(document, ensure_ascii=False, indent=2) + '\n').encode())


def initialize(path=None):
    path = config_path(path)
    if not path.exists():
        document = defaults()
        # One-time migration; old secrets are never printed or copied into examples.
        for old, section, key in [('ssh_password', 'ssh', 'password'), ('cookie.txt', 'webssh', 'cookie')]:
            legacy = path.parent / old
            if legacy.exists():
                document[section][key] = legacy.read_text(encoding='utf-8').strip()
        save_document(path, document)
    return path


class Config:
    def __init__(self, path=None):
        self.path = config_path(path)
        self.document = validate(read_document(self.path))
        self.base = self.path.parent
        self.state = self.resolve(self.document['state_directory'])
        ssh, web, files, logs = (self.document[name] for name in ('ssh', 'webssh', 'files', 'logging'))
        self.http_proxy = self.document['http_proxy']
        self.host, self.port, self.username = ssh['host'], ssh['port'], ssh['username']
        self.password = ssh['password']
        self.authorized_keys, self.host_key = self.resolve(ssh['authorized_keys']), self.resolve(ssh['host_key'])
        self.max_sessions, self.login_timeout = ssh['max_sessions'], ssh['login_timeout_seconds']
        self.url, self.entry_path, self.device_id = web['url'].rstrip('/'), web['entry_path'], web['device_id']
        self.socket_path, self.namespace = web['socketio_path'].strip('/'), web['namespace']
        self.transports, self.headers, self.tls_verify = web['transports'], web['headers'], web['tls_verify']
        self.http_timeout, self.connect_timeout = web['http_timeout_seconds'], web['connect_timeout_seconds']
        self.operation_timeout, self.timeout, self.bootstrap_timeout = web['operation_timeout_seconds'], web['exec_timeout_seconds'], web['bootstrap_timeout_seconds']
        self.events, self.cookie_refresh = web['events'], web['cookie_refresh']
        # Refreshed cookies are shared with per-node views through this dict.
        self._cookie_state = {'override': None}
        self.query, self.socket_auth = web['query'], web['auth']
        self.entry_method, self.entry_query, self.entry_form = web['entry_method'], web['entry_query'], web['entry_form']
        self.max_file, self.max_handles = files['max_bytes'], files['max_handles_per_session']
        self.upload_chunk, self.verify_upload = files['upload_chunk_bytes'], files['verify_upload_sha256']
        self.log_directory = self.resolve(logs['directory'])
        self.log_settings, self.demo = logs, self.document['demo']

    def resolve(self, path):
        return (self.base / Path(path).expanduser()).resolve()

    @property
    def cookie_override(self):
        return self._cookie_state['override']

    @cookie_override.setter
    def cookie_override(self, value):
        self._cookie_state['override'] = value

    def cookie(self):
        # Cookie is the only hot-reloaded field; never replay existing commands.
        # The refreshed override wins for every node view sharing this state.
        if self.cookie_override is not None:
            return self.cookie_override
        return validate(read_document(self.path))['webssh']['cookie']
