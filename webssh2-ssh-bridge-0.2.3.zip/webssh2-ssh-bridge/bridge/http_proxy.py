"""HTTP proxy for the WebSSH2 origin with the live Cookie: GET plus JSON-POST."""
import asyncio
import json
import time
import aiohttp
from aiohttp import web
from .logging_setup import event, failure, header_map
from .platform_support import is_windows

# Hop-by-hop headers are per-connection; Set-Cookie would leak the website
# session to proxy clients, so it is never forwarded downstream either.
HOP_HEADERS = frozenset(('connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization',
                         'te', 'trailer', 'transfer-encoding', 'upgrade', 'set-cookie'))


def inject_device_id(config, content_type, raw):
    """Rewrite a JSON request body carrying the configured deviceId.

    Returns the new bytes, or None when the body must pass through unchanged
    (device_id unconfigured, non-JSON content type, malformed JSON, or a
    non-object JSON document).
    """
    device_id = config.device_id
    if not device_id or not content_type or 'json' not in content_type.lower():
        return None
    try:
        document = json.loads(raw.decode('utf-8')) if raw else {}
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(document, dict):
        return None
    document['deviceId'] = device_id
    return json.dumps(document, ensure_ascii=False).encode('utf-8')


async def start_http_proxy(config):
    """Serve GET {host:port}/{path} -> GET {webssh.url}/{path} carrying the site Cookie."""
    settings = config.http_proxy
    # trust_env=False keeps HTTP_PROXY/HTTPS_PROXY/ALL_PROXY environment
    # variables out of upstream requests; no proxy is ever passed explicitly.
    # auto_decompress=False makes this a byte-transparent pipe, so compressed
    # bodies and Range semantics survive unchanged. total=None allows long
    # streaming downloads; only connect and per-read stalls are bounded.
    upstream = aiohttp.ClientSession(trust_env=False, auto_decompress=False,
            connector=aiohttp.TCPConnector(ssl=config.tls_verify),
            timeout=aiohttp.ClientTimeout(total=None, connect=settings['timeout_seconds'],
                                          sock_read=settings['timeout_seconds']))

    async def close_upstream(application):
        await upstream.close()

    async def forward(request):
        started = time.monotonic()
        path = request.path  # logged without query: queries may carry tokens
        trace = config.log_settings['http_trace']
        answer = None
        try:
            # Cookie is read per request, so a background refresh applies to
            # the very next request. Only Range is taken from the client;
            # other client headers are never forwarded upstream.
            headers = {**config.headers, 'Cookie': config.cookie()}
            if 'Range' in request.headers:
                headers['Range'] = request.headers['Range']
            method, data = request.method, None
            if method == 'POST':
                # Inject the configured deviceId into JSON bodies; anything
                # else passes through byte-for-byte with its Content-Type.
                raw = await request.read()
                rewritten = inject_device_id(config, request.headers.get('Content-Type'), raw)
                data = rewritten if rewritten is not None else raw
                content_type = request.headers.get('Content-Type')
                if content_type:
                    headers['Content-Type'] = content_type
            if trace:
                event('DEBUG', 'httpproxy.upstream.request', method=method,
                      url=config.url + request.path_qs, headers=headers,
                      body=data[:512].decode('utf-8', 'replace') if data else '')
            async with upstream.request(method, config.url + request.path_qs, headers=headers,
                                        data=data, allow_redirects=False) as response:
                if trace:
                    event('DEBUG', 'httpproxy.upstream.response', status=response.status,
                          headers=header_map(response.headers))
                answer = web.StreamResponse(status=response.status, reason=response.reason)
                for key, value in response.headers.items():
                    if key.lower() not in HOP_HEADERS:
                        answer.headers.add(key, value)
                await answer.prepare(request)
                forwarded = 0
                async for chunk in response.content.iter_chunked(65536):
                    await answer.write(chunk)
                    forwarded += len(chunk)
                await answer.write_eof()
                event('INFO', 'httpproxy.request.complete', method=method, path=path, status=response.status,
                      bytes=forwarded, duration_ms=round((time.monotonic() - started) * 1000))
                return answer
        except Exception as error:
            failure('httpproxy.request.failed', error, path=path,
                    duration_ms=round((time.monotonic() - started) * 1000))
            if answer is not None:
                # Headers are already on the wire; abort the transfer so the
                # client sees a truncated response instead of a silent one.
                answer.force_close()
                return answer
            status = 504 if isinstance(error, asyncio.TimeoutError) else 502
            return web.Response(status=status, text='bridge: upstream request failed\n')

    application = web.Application()
    application.router.add_get('/{path:.*}', forward, allow_head=False)
    application.router.add_post('/{path:.*}', forward)
    application.on_cleanup.append(close_upstream)
    runner = web.AppRunner(application, access_log=None)
    await runner.setup()
    try:
        site = web.TCPSite(runner, settings['host'], settings['port'],
                           reuse_address=not is_windows())
        await site.start()
    except BaseException:
        await runner.cleanup()
        raise
    event('INFO', 'httpproxy.listening', host=settings['host'], port=settings['port'], origin=config.url)
    return runner
