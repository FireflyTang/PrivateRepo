"""Structured, rotating diagnostics with configurable redaction and byte tracing."""
import contextvars
import datetime
import json
import logging
import logging.handlers
import os
import re
import traceback
import uuid
from .platform_support import private_fd

session_context = contextvars.ContextVar('bridge_session_id', default=None)
_secrets = set()


def register_secret(value):
    # Substring redaction with very short patterns corrupts unrelated log
    # text (a cookie value like "fresh" or "en" would mangle event names,
    # paths and messages). Real session tokens are far longer than this.
    if isinstance(value, str) and len(value) >= 8:
        _secrets.add(value)


def register_config(config):
    for value in [config.password, config.device_id, config.document['webssh']['cookie'],
                  config.document['webssh']['cookie_refresh']['body'],
                  config.demo['website_password'], config.demo['target_password']]:
        register_secret(value)
    def strings(value):
        if isinstance(value, dict):
            for item in value.values():
                strings(item)
        elif isinstance(value, (list, tuple)):
            for item in value:
                strings(item)
        elif isinstance(value, str):
            register_secret(value)
    for mapping in (config.headers, config.query, config.socket_auth, config.entry_form):
        strings(mapping)
    for part in config.document['webssh']['cookie'].split(';'):
        if '=' in part:
            register_secret(part.split('=', 1)[1].strip())


def header_map(headers):
    """HTTP headers as a JSON-friendly mapping; repeated names become lists."""
    result = {}
    for key in set(headers.keys()):
        values = headers.getall(key)
        result[key] = values[0] if len(values) == 1 else values
    return result


def redact(value):
    if isinstance(value, dict):
        return {key: ('[REDACTED]' if re.search(r'password|cookie|authorization|secret|token', str(key), re.I) else redact(item)) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [redact(item) for item in value]
    if isinstance(value, str):
        for secret in sorted(_secrets, key=len, reverse=True):
            value = value.replace(secret, '[REDACTED]')
        # Strip query strings from error URLs (may contain session IDs/tokens).
        value = re.sub(r'(https?|wss?)://([^\s?]+)\?[^\s\'\"]+', r'\1://\2?[REDACTED]', value)
        return value
    return value


def new_session(kind):
    value = kind + '-' + uuid.uuid4().hex[:16]
    session_context.set(value)
    return value


def event(level, name, **fields):
    logging.getLogger('bridge.events').log(getattr(logging, level.upper()), name,
                                         extra={'event_name': name, 'fields': fields, 'session_id': session_context.get()})


def failure(name, error, **fields):
    import asyncio
    if isinstance(error, asyncio.CancelledError):
        event('WARNING', name, error_type='CancelledError', message='Operation cancelled', **fields)
        return
    event('ERROR', name, error_type=type(error).__name__, error_code=getattr(error, 'code', None),
          message=str(error), traceback=''.join(traceback.format_exception(type(error), error, error.__traceback__)), **fields)


def _event_document(record):
    document = {'time': datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds'),
                'level': record.levelname, 'logger': record.name,
                'event': getattr(record, 'event_name', record.getMessage()),
                'session_id': getattr(record, 'session_id', session_context.get())}
    document.update(getattr(record, 'fields', {}))
    return document


class JSONFormatter(logging.Formatter):
    def __init__(self, redact_secrets=True):
        super().__init__()
        self.redact_secrets = redact_secrets

    def format(self, record):
        document = _event_document(record)
        if record.exc_info:
            document['traceback'] = self.formatException(record.exc_info)
        return json.dumps(redact(document) if self.redact_secrets else document, ensure_ascii=False, default=str)


class PlainFormatter(logging.Formatter):
    """Human-readable single line per event: time, level, event, field=value."""

    def __init__(self, redact_secrets=True):
        super().__init__()
        self.redact_secrets = redact_secrets

    @staticmethod
    def _show(value):
        # Plain scalars stay unquoted; anything with whitespace or quotes
        # falls back to JSON so the value stays one unambiguous token.
        if isinstance(value, str) and value and not any(character in value for character in ' \t"'):
            return value
        return json.dumps(value, ensure_ascii=False, default=str)

    def format(self, record):
        document = _event_document(record)
        if record.exc_info:
            document['traceback'] = self.formatException(record.exc_info)
        if self.redact_secrets:
            document = redact(document)
        parts = []
        for key, value in document.items():
            if key in ('time', 'level', 'logger', 'event', 'session_id', 'traceback') or value is None:
                continue
            parts.append('%s=%s' % (key, self._show(value)))
        line = '%s %-7s %s' % (datetime.datetime.fromtimestamp(record.created).strftime('%Y-%m-%d %H:%M:%S'),
                               document['level'], document['event'])
        if document.get('session_id'):
            line += ' [' + str(document['session_id']) + ']'
        if parts:
            line += ' ' + ' '.join(parts)
        if document.get('traceback'):
            line += '\n' + '\n'.join('    ' + text for text in str(document['traceback']).splitlines())
        return line


class PrivateRotatingHandler(logging.handlers.RotatingFileHandler):
    def _open(self):
        fd = os.open(self.baseFilename, os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
        private_fd(fd)
        return os.fdopen(fd, 'a', encoding='utf-8')


def configure_logging(config, component='bridge'):
    register_config(config)
    config.log_directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
        handler.close()
    redact_secrets = config.log_settings['redact_secrets']
    settings = config.log_settings
    # Humans read bridge.log and the console; machines keep the JSONL form.
    machine = PrivateRotatingHandler(str(config.log_directory / (component + '.jsonl')),
                                     maxBytes=settings['max_bytes'], backupCount=settings['backup_count'])
    machine.setFormatter(JSONFormatter(redact_secrets=redact_secrets))
    root.addHandler(machine)
    human = PrivateRotatingHandler(str(config.log_directory / (component + '.log')),
                                   maxBytes=settings['max_bytes'], backupCount=settings['backup_count'])
    human.setFormatter(PlainFormatter(redact_secrets=redact_secrets))
    root.addHandler(human)
    if settings['console']:
        console = logging.StreamHandler()
        console.setFormatter(PlainFormatter(redact_secrets=redact_secrets))
        root.addHandler(console)
    root.setLevel(settings['level'].upper())
    # Use our explicit JSON protocol/terminal tracing switches instead of the
    # third-party libraries' uncontrolled payload DEBUG output.
    for name in ('asyncssh', 'socketio', 'engineio', 'aiohttp'):
        logging.getLogger(name).setLevel(logging.WARNING)
    event('INFO', 'logging.ready', component=component, log_level=settings['level'])
