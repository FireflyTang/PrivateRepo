"""Periodic website Cookie refresh: mint the WebSSH2 session, then one plain login POST."""
import asyncio
import aiohttp
from .logging_setup import event, failure, header_map, register_secret


class CookieRefreshError(Exception):
    pass


def cookie_pairs_from_headers(headers):
    """Every Set-Cookie response header as a name=value pair; may be empty."""
    pairs = []
    for header in headers.getall('Set-Cookie', []):
        pair = header.split(';', 1)[0].strip()
        if pair and '=' in pair:
            pairs.append(pair)
    return pairs


def cookie_from_headers(headers):
    """Join every Set-Cookie response header into one Cookie request line."""
    pairs = cookie_pairs_from_headers(headers)
    if not pairs:
        raise CookieRefreshError('Cookie endpoint sent no usable Set-Cookie header')
    return '; '.join(pairs)


def merge_cookie(current, refreshed):
    """Overlay only the pairs the endpoint rotated; keep the rest as baseline.

    The static webssh.cookie usually carries every cookie the site expects
    (the full browser line, e.g. a portal session plus webssh2.sid); a refresh
    endpoint returns just the rotating pairs, so replacing the whole line
    would silently drop the others.
    """
    if not current:
        return refreshed
    def pairs(line):
        return [part.strip() for part in line.split(';') if part.strip()]
    rotated = {pair.split('=', 1)[0] for pair in pairs(refreshed)}
    kept = [pair for pair in pairs(current) if pair.split('=', 1)[0] not in rotated]
    return '; '.join(kept + pairs(refreshed))


async def fetch_cookie(config):
    settings = config.cookie_refresh
    trace = config.log_settings['http_trace']
    # trust_env=False keeps HTTP_PROXY/HTTPS_PROXY/ALL_PROXY environment
    # variables out of these requests; no proxy is ever passed explicitly.
    session = aiohttp.ClientSession(trust_env=False,
            connector=aiohttp.TCPConnector(ssl=config.tls_verify),
            timeout=aiohttp.ClientTimeout(total=settings['timeout_seconds']))
    try:
        current = config.cookie().strip()
        minted = []
        if settings['session_path']:
            # Opt-in two-step chain: GET the configured page (typically the
            # login page) to mint the WebSSH2 session Cookie — the login
            # response never returns it, and the login page hands one out
            # even to anonymous visitors. A live sid is reused silently; a
            # dead or missing one is replaced by this Set-Cookie.
            headers = dict(config.headers)
            if current:
                headers['Cookie'] = current
            mint_url = config.url + settings['session_path']
            async with session.get(mint_url, headers=headers, allow_redirects=False) as page:
                minted = cookie_pairs_from_headers(page.headers)
                await page.read()
                if trace:
                    event('DEBUG', 'cookie.refresh.session', method='GET', url=mint_url,
                          request_headers=headers, status=page.status,
                          response_headers=header_map(page.headers))
        # The plain login POST. With the chain enabled, carrying the freshly
        # minted sid lets the site write the SSH credentials into the very
        # session the terminal connections will reference; a minted value
        # replaces any dead baseline one with the same name.
        login_headers = {'Content-Type': settings['content_type']}
        effective = merge_cookie(current, '; '.join(minted)) if minted else current
        if effective:
            login_headers['Cookie'] = effective
        if trace:
            event('DEBUG', 'cookie.refresh.request', method='POST', url=settings['url'],
                  headers=login_headers, body=settings['body'])
        async with session.post(settings['url'], data=settings['body'].encode(),
                                headers=login_headers) as response:
            trace_fields = {'status': response.status, 'headers': header_map(response.headers)}
            if not 200 <= response.status < 300:
                if trace:
                    event('DEBUG', 'cookie.refresh.response', **trace_fields,
                          body=(await response.read())[:512].decode('utf-8', 'replace'))
                raise CookieRefreshError('Cookie endpoint returned HTTP %s' % response.status)
            rotated = cookie_pairs_from_headers(response.headers)
            if not rotated:
                raise CookieRefreshError('Cookie endpoint sent no usable Set-Cookie header')
            if trace:
                event('DEBUG', 'cookie.refresh.response', **trace_fields, cookie='; '.join(rotated),
                      body=(await response.read())[:512].decode('utf-8', 'replace'))
    finally:
        await session.close()
    refreshed = '; '.join(minted + rotated)
    register_secret(refreshed)
    for part in refreshed.split(';'):
        if '=' in part:
            register_secret(part.split('=', 1)[1].strip())
    return refreshed


async def refresh_loop(config):
    settings = config.cookie_refresh
    while True:
        delay = settings['retry_seconds']
        try:
            refreshed = await fetch_cookie(config)
            cookie = merge_cookie(config.cookie(), refreshed)
            config.cookie_override = cookie
            register_secret(cookie)
            event('INFO', 'cookie.refreshed', pairs=len(cookie.split(';')), length=len(cookie), cookie=cookie)
            delay = settings['interval_seconds']
        except asyncio.CancelledError:
            raise
        except Exception as error:
            # Keep serving with the previous Cookie; retry shortly.
            failure('cookie.refresh.failed', error)
        await asyncio.sleep(delay)
