# WebSSH2 SSH Bridge

一个 Python 项目。入口是 `main.py`，所有设置放在旁边的 `config.json`。
把网站中的 WebSSH2 转为可从其他机器访问的标准 SSH/SCP/SFTP 服务。

## 启动

需要 Python 3.9+，支持原生 Windows、Linux，也可在 macOS 运行。

```sh
pip install -r requirements.txt
# 编辑 config.json
python main.py
```

Windows 可使用 `py main.py`，Linux 可使用 `python3 main.py`。
保持进程运行；Ctrl+C 停止。无需 Shell 管理脚本、Docker 或 Node。
日志写入 `logs/bridge.jsonl` 并自动轮转。主机密钥等运行文件自动生成在 `.state/`。

## 配置

最主要的字段：

| 字段 | 填什么 |
|---|---|
| ssh.host | SSH 监听地址，默认 0.0.0.0（所有网卡）；127.0.0.1 仅本机 |
| ssh.nodes | 监听节点列表，必填非空；每项 {"name": 名称, "port": 端口, "entry_path": 终端路径}，三个字段均必填且名称/端口唯一。各端口共用登录认证与并发上限 |
| ssh.username / password | Agent 登录桥接服务的用户名、密码；空密码关闭密码认证 |
| ssh.authorized_keys | 可选的普通 OpenSSH 公钥列表文件 |
| webssh.url | 终端服务器 origin，例如 https://terminal.example |
| webssh.socketio_path | Socket.IO 路径，例如 /ssh/socket.io/ |
| webssh.cookie | 已登录浏览器实际发送的 Cookie 值，不含 Cookie: 前缀 |
| webssh.cookie_refresh.url / body | 配置后默认每 6 小时向该 URL 发明文 POST，从 Set-Cookie 响应头自动刷新 Cookie（绕过 HTTP_PROXY 等环境代理）；url 留空则只用上面的静态 Cookie |
| webssh.headers | 必要的 Origin、Referer 等请求头 |
| webssh.namespace | 通常为 /，有自定义 namespace 时按抓包填写 |
| webssh.query / auth | 站点握手需要的额外参数；通常留空 |
| webssh.exec_timeout_seconds | 命令超时，默认 120 秒 |
| files.max_bytes | 单文件大小上限，默认约 3.1 GiB（3355443200 字节） |
| http_proxy.enabled / host / port | GET 代理端口，默认关闭；开启后监听 0.0.0.0:8088，把收到的 GET 原样转发到 webssh.url 同路径并带上 Cookie |
| http_proxy.timeout_seconds | 代理上游连接/读空闲超时，默认 30 秒；不限总时长，响应流式转发 |
| logging.level | INFO 或 DEBUG |
| logging.redact_secrets | 默认 false，按用户要求保留日志原文 |
| logging.command_text | 默认 true，记录完整命令 |

相对文件路径以 config.json 所在目录为基准。Unix 系统首次启动会将配置文件权限设为 0600；Windows 使用文件/目录的 ACL 权限，不检查 Unix mode 位。
Cookie 在新会话中自动重新读取；配置了 cookie_refresh.url 时由后台任务定时刷新并优先生效，其他配置修改后重启 Python 进程。
多节点（ssh.nodes）时每个节点对应一个本地 SSH 端口（name 用于日志中标识节点），各端口共用同一套登录认证与并发上限。
发布包没有私人密码、Cookie 或密钥，需要填写自己的设置。

## 从网页获取接入信息

1. 正常登录网站并打开终端，在浏览器 F12 → Network 中找到 WS 请求；必要时刷新页面。
2. 如果终端在 iframe 内，查看 iframe src 或 Document 请求，找到真正的终端页面地址，不使用外层门户地址。
3. 假设 WS Request URL 为：

   `wss://terminal.example/apps/ssh/socket.io/?EIO=4&transport=websocket&sid=临时值`

   则 `webssh.url` 填 `https://terminal.example`，`socketio_path` 填 `/apps/ssh/socket.io/`。
   `sid`、`EIO`、`transport`、`t` 由客户端管理，不复制到 query。
4. 将 WS Request Headers 中的完整 Cookie 值填入 `webssh.cookie`；必要的 Origin/Referer 放入 headers。
5. 将实际终端页面的路径填入对应节点的 entry_path（ssh.nodes）。需要页面 query 或 POST 初始化时，使用 entry_query、entry_method、entry_form。
6. 当前支持 Engine.IO 4 / Socket.IO 协议。普通 WebSocket 或 EIO=3 不能直接套用；事件名可通过 events 改名，消息结构不同需要适配代码。

## Agent 使用

在 Agent 机器连接桥接机器的可达 IP：

```sh
ssh -p 2222 root@桥接机器IP 'whoami; pwd'
scp -P 2222 ./code.py root@桥接机器IP:/远端路径/code.py
sftp -P 2222 root@桥接机器IP
```

开启 http_proxy 后，Agent 可不携带 Cookie 直接 GET 站点上受登录保护的资源：

```sh
curl http://桥接机器IP:8088/xxx/yyy
```

支持公钥和密码；只使用密码时按 SSH 提示输入已配置的密码。

命令 stdout/stderr 合并，exec stdin 为 /dev/null；复杂脚本先上传再执行。
每次命令是独立 shell，使用 `cd /目录 && 命令`。退出码正常传回，超时或断线后不要盲目重放有副作用的操作。
SCP 使用现代默认 SFTP 模式，不使用 -O 或 -p。文件上传在 CLOSE 时提交，默认重下载校验 SHA-256。
不支持端口转发、SFTP 符号链接/所有权/时间戳保留或 fsync。

已通过本地官方 WebSSH2 链路测试；真实内网仍需比对实际认证和协议。

桥接器本身不依赖 fcntl、本机 PTY 或本机 Unix 命令；Windows 和 Linux 使用同一套 Python 代码。
WebSSH2 后面的目标 shell 仍需支持 POSIX sh/stty；这与桥接器运行在 Windows 还是 Linux 无关。
同一监听地址/端口只能启动一个服务实例，重复启动会返回端口占用错误。

config.json 使用 UTF-8 编码，兼容 Windows 编辑器保存的 UTF-8 BOM。
