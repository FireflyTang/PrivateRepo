"""Periodic website Cookie refresh: one plain POST to a fixed URL, never proxied."""
import asyncio
import aiohttp
from .logging_setup import event, failure, register_secret


class CookieRefreshError(Exception):
    pass


def cookie_from_headers(headers):
    """Join every Set-Cookie response header into one Cookie request line."""
    pairs = []
    for header in headers.getall('Set-Cookie', []):
        pair = header.split(';', 1)[0].strip()
        if pair and '=' in pair:
            pairs.append(pair)
    if not pairs:
        raise CookieRefreshError('Cookie endpoint sent no usable Set-Cookie header')
    return '; '.join(pairs)


async def fetch_cookie(config):
    settings = config.cookie_refresh
    # trust_env=False keeps HTTP_PROXY/HTTPS_PROXY/ALL_PROXY environment
    # variables out of this request; no proxy is ever passed explicitly.
    session = aiohttp.ClientSession(trust_env=False,
            connector=aiohttp.TCPConnector(ssl=config.tls_verify),
            timeout=aiohttp.ClientTimeout(total=settings['timeout_seconds']))
    try:
        async with session.post(settings['url'], data=settings['body'].encode(),
                                headers={'Content-Type': settings['content_type']}) as response:
            if not 200 <= response.status < 300:
                raise CookieRefreshError('Cookie endpoint returned HTTP %s' % response.status)
            cookie = cookie_from_headers(response.headers)
    finally:
        await session.close()
    register_secret(cookie)
    for part in cookie.split(';'):
        if '=' in part:
            register_secret(part.split('=', 1)[1].strip())
    return cookie


async def refresh_loop(config):
    settings = config.cookie_refresh
    while True:
        delay = settings['retry_seconds']
        try:
            cookie = await fetch_cookie(config)
            config.cookie_override = cookie
            event('INFO', 'cookie.refreshed', pairs=len(cookie.split(';')), length=len(cookie))
            delay = settings['interval_seconds']
        except asyncio.CancelledError:
            raise
        except Exception as error:
            # Keep serving with the previous Cookie; retry shortly.
            failure('cookie.refresh.failed', error)
        await asyncio.sleep(delay)
