import argparse
import asyncio
import os
from pathlib import Path
from .config import Config
from .cookie_refresh import refresh_loop
from .http_proxy import start_http_proxy
from .logging_setup import configure_logging, event, failure
from .platform_support import private_path, install_stop_handlers
from .ssh_server import serve


async def main(default_config=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=default_config)
    args = parser.parse_args()
    if default_config is not None:
        path = Path(args.config)
        if path.exists():
            private_path(path)
    config = Config(args.config)
    configure_logging(config)
    config.state.mkdir(parents=True, exist_ok=True, mode=0o700)
    stopped = asyncio.Event()
    restore_handlers = install_stop_handlers(asyncio.get_running_loop(), stopped)
    metadata_owned = False
    refresh_task = None
    proxy_runner = None
    try:
        # The OS listener enforces one server per address/port. No platform-
        # specific file locking is required; crashing releases the socket too.
        server = await serve(config)
        metadata_owned = True
        (config.state / 'bridge.pid').write_text(str(os.getpid()))
        (config.state / 'bridge.ready').write_text(str(os.getpid()))
        if config.http_proxy['enabled']:
            proxy_runner = await start_http_proxy(config)
        if config.cookie_refresh['url']:
            refresh_task = asyncio.create_task(refresh_loop(config))
            event('INFO', 'cookie.refresh.enabled', url=config.cookie_refresh['url'],
                  interval_seconds=config.cookie_refresh['interval_seconds'],
                  retry_seconds=config.cookie_refresh['retry_seconds'])
        async with server:
            while not stopped.is_set():
                # A periodic timer also allows Python to dispatch console
                # signals promptly with Windows' Proactor event loop.
                try:
                    await asyncio.wait_for(stopped.wait(), timeout=.5)
                except asyncio.TimeoutError:
                    pass
    except Exception as error:
        failure('bridge.failed', error)
        raise SystemExit('Bridge failed; see private diagnostic log') from None
    finally:
        if refresh_task is not None:
            refresh_task.cancel()
            await asyncio.gather(refresh_task, return_exceptions=True)
        if proxy_runner is not None:
            await proxy_runner.cleanup()
        if metadata_owned:
            (config.state / 'bridge.pid').unlink(missing_ok=True)
            (config.state / 'bridge.ready').unlink(missing_ok=True)
        restore_handlers()
        event('INFO', 'bridge.stopped')


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
