import asyncio
import hmac
import time
import uuid
from .logging_setup import event, failure, new_session
from contextlib import suppress
import asyncssh
from .auth import ensure_key
from .platform_support import is_windows
from .webssh2_client import WebSSHClient, WebSSHError
from .exec_adapter import execute

class BridgeAuth(asyncssh.SSHServer):
    def __init__(self, config):
        self.config = config
        self.peer_address = '127.0.0.1'
        self.connection_id = 'conn-' + uuid.uuid4().hex[:16]
        self.connection = None
        self.auth_method = None

    def connection_made(self, connection):
        self.connection = connection
        connection.set_extra_info(bridge_connection_id=self.connection_id)
        peer = connection.get_extra_info('peername')
        if peer:
            self.peer_address = peer[0]
        event('INFO', 'ssh.connection.open', connection_id=self.connection_id, peer=self.peer_address)

    def connection_lost(self, error):
        event('INFO', 'ssh.connection.closed', connection_id=self.connection_id, peer=self.peer_address, error_type=type(error).__name__ if error else None)

    def auth_completed(self):
        event('INFO', 'ssh.auth.success', connection_id=self.connection_id, peer=self.peer_address, username=self.connection.get_extra_info('username'), method=self.auth_method)

    def begin_auth(self, username):
        return True

    def public_key_auth_supported(self):
        return True

    def validate_public_key(self, username, key):
        if username != self.config.username:
            return False
        try:
            keys = asyncssh.read_authorized_keys(str(self.config.authorized_keys))
            accepted = keys.validate(key, self.peer_address, self.peer_address) is not None
            if accepted:
                self.auth_method = 'publickey'
            else:
                event('DEBUG', 'ssh.auth.key.rejected', connection_id=self.connection_id, peer=self.peer_address, fingerprint=key.get_fingerprint())
            return accepted
        except (OSError, ValueError):
            return False

    def password_auth_supported(self):
        return bool(self.config.password)

    def validate_password(self, username, password):
        accepted = username == self.config.username and bool(self.config.password) and hmac.compare_digest(password.encode(), self.config.password.encode())
        if accepted:
            self.auth_method = 'password'
        else:
            event('WARNING', 'ssh.auth.rejected', connection_id=self.connection_id, peer=self.peer_address, method='password')
        return accepted


async def handle_process(process, config, slots):
    new_session('exec' if process.command else 'shell')
    started = time.monotonic()
    event('INFO', 'ssh.session.start', connection_id=process.get_extra_info('bridge_connection_id'), peer=process.get_extra_info('peername'), mode='exec' if process.command else 'shell')
    tasks = []
    client = WebSSHClient(config)
    acquired = False
    try:
        # Fail quickly under load, rather than queuing commands indefinitely.
        await asyncio.wait_for(slots.acquire(), 1)
        acquired = True
        await client.connect()
        if process.command:
            if len(process.command.encode()) > 65536:
                raise WebSSHError('Command exceeds 64 KiB limit')
            async def output(data):
                process.stdout.write(data)
                await process.stdout.drain()
            async def stdin_guard():
                try:
                    data = await process.stdin.read(1)
                    if data:
                        raise WebSSHError('Bridge exec stdin is unsupported; upload a script/file with scp first')
                    await asyncio.Future()
                except asyncssh.SignalReceived as signal_event:
                    event('WARNING', 'ssh.signal.received', signal=signal_event.signal)
                    await client.emit('data', '\x03')
                    raise WebSSHError('Command interrupted by signal ' + signal_event.signal)
                except asyncssh.BreakReceived:
                    await client.emit('data', '\x03')
                    raise WebSSHError('Command interrupted')
            tasks = [asyncio.create_task(execute(client, process.command, output)),
                     asyncio.create_task(stdin_guard()), asyncio.create_task(process.wait_closed())]
            done, _ = await asyncio.wait(tasks, timeout=config.timeout, return_when=asyncio.FIRST_COMPLETED)
            if not done:
                with suppress(Exception):
                    await client.emit('data', '\x03')
                raise asyncio.TimeoutError()
            if tasks[0] in done:
                process.exit(tasks[0].result())
            elif tasks[1] in done:
                tasks[1].result()
            # A closed client channel needs no further exit reply.
        else:
            cols, rows, _, _ = process.get_terminal_size()
            await client.terminal(process.get_terminal_type() or 'xterm-256color', cols or 80, rows or 24)
            process.stdout.write(await asyncio.wait_for(client.receive(), config.bootstrap_timeout))
            await process.stdout.drain()
            import codecs
            decoder = codecs.getincrementaldecoder('utf-8')('strict')
            async def downstream():
                while True:
                    process.stdout.write(await client.receive())
                    await process.stdout.drain()
            async def upstream():
                while True:
                    try:
                        data = await process.stdin.read(32768)
                        if not data:
                            return
                        # WebSSH2 terminal input is text; file bytes use SFTP.
                        await client.emit('data', decoder.decode(data))
                    except asyncssh.TerminalSizeChanged as resize_event:
                        event('DEBUG', 'ssh.terminal.resize', cols=resize_event.width, rows=resize_event.height)
                        await client.emit('resize', {'cols': resize_event.width, 'rows': resize_event.height})
                    except asyncssh.SignalReceived:
                        await client.emit('data', '\x03')
            tasks = [asyncio.create_task(downstream()), asyncio.create_task(upstream()),
                     asyncio.create_task(process.wait_closed())]
            done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                task.result()
            process.exit(0)
    except asyncio.TimeoutError:
        event('WARNING', 'ssh.session.timeout', timeout_seconds=config.timeout)
        process.stderr.write(b'bridge: timeout; command completion is unknown\n')
        process.exit(124)
    except (Exception,) as error:
        failure('ssh.session.failed', error)
        with suppress(Exception):
            process.stderr.write(('bridge: ' + str(error) + '\n').encode())
            process.exit(255)
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        await client.close()
        if acquired:
            slots.release()
        event('INFO', 'ssh.session.closed', duration_ms=round((time.monotonic()-started)*1000))


class ServerGroup:
    """Every node listener closes together so main() can await one object."""

    def __init__(self, servers):
        self.servers = list(servers)

    async def close(self):
        for server in self.servers:
            server.close()
        for server in self.servers:
            await server.wait_closed()

    async def wait_closed(self):
        for server in self.servers:
            await server.wait_closed()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()


async def serve(config):
    from .sftp_adapter import BridgeSFTP
    ensure_key(config.host_key)
    slots = asyncio.Semaphore(config.max_sessions)
    servers = []
    for port, entry_path in config.nodes:
        node_config = config.for_node(port, entry_path)
        servers.append(await asyncssh.listen(config.host, port, reuse_address=not is_windows(),
            server_factory=lambda: BridgeAuth(config), server_host_keys=[str(config.host_key)],
            process_factory=lambda process, cfg=node_config: handle_process(process, cfg, slots),
            encoding=None,
            sftp_factory=lambda channel, cfg=node_config: BridgeSFTP(channel, cfg, slots),
            login_timeout=config.login_timeout, allow_scp=False))
        event('INFO', 'ssh.listening', host=config.host, port=port, entry_path=entry_path,
              username=config.username, password_enabled=bool(config.password), config_file=str(config.path))
    return ServerGroup(servers)
