# 连接资料与首次配置

此包对应的已部署入口：

| 字段 | 交付时值 |
|---|---|
| Host / alias | webssh |
| HostName | 7.249.59.47 |
| Port | 2222 |
| SSH User | root |
| 认证 | 公钥或用户提供的密码 |
| 实际后端 | 当前 demo 为 macOS 普通账户；真实网站接入后以 uname/id/pwd 为准 |

此 IP 在桥接机器上已验证，但尚不能证明接收 ZIP 的 Agent 机器网络可达。IP/网络变化时以用户给的新地址为准。

`assets/ssh-config.example` 是当前部署的 OpenSSH 配置示例；合并进 Agent 机器的 `~/.ssh/config`，不要覆盖已有其他 Host 配置。
`assets/known_hosts.example` 包含当前桥接器的公开主机密钥，可复制为 `~/.ssh/webssh_known_hosts`。
主机密钥不是登录公钥，也不是私钥；它用于确认桥接服务身份。
如果换了 IP，同步修改配置和 known_hosts 中的地址；如果主机密钥变更，向服务维护者核对后更新。

公钥认证：Agent 私钥留在 Agent 机器，对应 `.pub` 由桥接器管理员加入 authorized_keys。
密码认证：用户提供密码，交互 OpenSSH 可直接输入；无人值守调用可使用附带 helper。
没有凭据时说明缺少的连接资料，不生成密码、不复制桥接机器的私钥。

连接验证：

```sh
ssh -o ConnectTimeout=10 webssh 'whoami; pwd'
ssh webssh 'printf hello; exit 42'
```

第二条预期 stdout 为 hello，SSH 命令本身退出码为 42。执行工具直接读取退出码即可，不要用后续 echo 的成功状态替代。

当前桥接器保留完整命令和原始错误日志。此包不需要也不包含服务端 Cookie/config.json。
