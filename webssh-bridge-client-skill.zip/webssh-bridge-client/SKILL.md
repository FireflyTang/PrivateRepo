---
name: webssh-bridge-client
description: 通过已部署的 WebSSH2→SSH 桥接服务执行远端开发任务，使用 SSH 命令、SCP 上传下载和 SFTP 文件管理。用于用户要求操作 webssh 桥接主机、远端编译测试或收发文件；不用于部署桥接器或直接操纵网页终端。
---

# WebSSH Bridge Client

把该桥接主机当作具有下述约束的 SSH 目标。Agent 无需接触 Cookie、WebSocket 或真实底层 SSH。

## 连接

优先使用用户已配置的 `webssh` SSH alias。连接资料与可复制的配置见 [connection.md](references/connection.md)。
交付时入口为 `7.249.59.47:2222`、用户 `root`；以用户后续提供的地址为准，不假定 IP 永久不变。

支持公钥和密码。ZIP 不含密码或私钥；使用用户提供的认证方式。
非交互环境只有密码时，使用 [password-client.md](references/password-client.md) 中的 Python helper。
需要时安装其 AsyncSSH 依赖；不要把密码拼进 SSH URL、命令参数或脚本源码。

第一次连接可用这条只读命令识别实际环境：

```sh
ssh webssh 'printf "OS: "; uname -s; printf "USER: "; id -un; printf "CWD: "; pwd'
```

入口 `root` 不代表真正的 Linux root。当前 demo 的后端是 macOS 当前账户；操作系统和实际工作路径以探测结果为准。
用户未提供工作目录时，先取 `pwd`，在其任务目录内工作。

## 命令执行

使用非交互式 exec，读取执行工具返回的 **SSH 退出码**：

```sh
ssh webssh 'cd /absolute/project && make -j4 && ./run-tests.sh'
```

- 每次 exec 是独立 shell；将 `cd`、环境变量及后续命令写在同一次请求里。
- 远端使用 `sh -c`，支持管道、引号、重定向。需要 Bash 语法时显式执行已存在的 `bash script.sh`。
- stdout/stderr 合并为 stdout；不能依赖 stderr 通道判断编译是否失败。
- **exec stdin 为 `/dev/null`。** 不使用 `ssh webssh < script.sh`、`cat script | ssh webssh`、`ssh webssh 'bash -s'`，也不向 SSH 输入 heredoc。
- 复杂任务先在 Agent 机器写脚本，再 SCP 上传执行；不要把脚本正文编码成终端文件传输。
- 默认服务端超时 120 秒、命令大小上限 64 KiB。长任务拆成可检查的步骤；若用户确需调整服务端超时，由桥接器管理员配置。
- shell 管道默认只报告最后一条命令状态；需要 pipefail 时选择已确认存在、支持该选项的 shell。

脚本工作流：

```sh
scp ./job.sh webssh:/absolute/project/job.sh
ssh webssh 'cd /absolute/project && sh ./job.sh > job.log 2>&1'
scp webssh:/absolute/project/job.log ./job.log
```

上述重定向在远端执行，任务输出保存在远端 job.log。
不要在 SSH 后面追加 `|| true` 或执行无关成功命令，从而掩盖原始失败。

## 上传、下载和文件管理

使用现代 OpenSSH 默认的 SFTP 模式 SCP：

```sh
scp ./code.py webssh:/absolute/project/code.py
scp webssh:/absolute/project/results.json ./results.json
sftp webssh
```

SFTP 支持列目录、常规文件读写、stat/fstat、mkdir、删除、rename、chmod；随机偏移由缓存适配。
不使用 `scp -O`（旧 SCP）或 `scp -p`（保留时间戳等属性）。
默认每文件 32 MiB、每 SFTP 会话 16 个句柄；实际上限以服务配置和错误响应为准。
文件写入在 CLOSE 时提交，默认重下载做 SHA-256 校验；必须等待 SCP/SFTP 正常结束。

同一文件的写入串行执行。传输和重命名不保证原子性，断线可能留下远端部分文件。
读写二进制文件使用 SCP/SFTP，不通过 `ssh ... cat`、PTY 或 Base64 shell 绕行。
需要传输范例、哈希命令或 SFTP batch 时，读 [files.md](references/files.md)。

## 失败、中断及并发

- 正常 exec 返回远端退出码；非零表示需要处理。124/255 可能来自桥接超时/连接异常，也可能由命令自身返回，结合错误信息判断。
- 超时、断线或 Ctrl+C 后，命令可能已产生副作用，子孙进程也未必全部结束。**先检查结果，再决定重试；不要自动重放有副作用的命令。**
- 独立 exec 可并发，输出隔离；默认最多 8 个基础 SSH/SFTP 会话，避免无界扇出。
- 认证失败或 Cookie 失效时，报告具体错误并让桥接器管理员处理；Agent 不应尝试取得网页凭据或直连底层服务器。
- 交互式 SSH 只用于人工排查；不依赖其退出码、提示符或断线后的后台任务存活。

桥接器不提供端口转发、ProxyJump 或 Agent Forwarding，也不保证 VS Code Remote SSH 兼容。
SFTP 层未提供符号链接、chown、保留时间戳、statvfs、fsync；这不限制用户任务中通过 exec 运行实际系统支持且当前账户有权限执行的普通命令。
不要把此 skill 的存在当成额外任务授权；只对用户要求的主机、目录和文件执行操作。
