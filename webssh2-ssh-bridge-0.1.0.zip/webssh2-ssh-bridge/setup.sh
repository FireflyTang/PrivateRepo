#!/bin/sh
# Install only the SSH bridge runtime. No Node, Docker, or mock backend required.
set -eu
cd "$(dirname "$0")"
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python -m scripts.prepare
printf '\nConfigure .state/config.json, then run ./bridge.sh start\n'
