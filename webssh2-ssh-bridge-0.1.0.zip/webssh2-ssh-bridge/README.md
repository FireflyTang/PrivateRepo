# WebSSH2 → SSH Bridge

把已有网站里的 WebSSH2 终端和文件传输转换为标准 SSH/SCP/SFTP 服务。
Agent 在另一台机器上，只需连接桥接机器的 TCP 2222，无需处理网页、Cookie 或 Socket.IO。

版本：`0.1.0`。运行环境：macOS / Linux、Python 3.9+。仅运行桥接服务无需 Node 或 Docker。

## 安装与启动

解压工具包后进入目录：

```sh
./setup.sh
# 编辑 .state/config.json，配置上游站点并设置 SSH 登录方式
.venv/bin/python -m scripts.config set-password
.venv/bin/python -m scripts.config set-ws-url
.venv/bin/python -m scripts.config set-cookie
.venv/bin/python -m scripts.config check
.venv/bin/python -m scripts.diagnose --auth-only
./bridge.sh start
./bridge.sh status
```

`./bridge.sh restart` 应用配置修改，`./bridge.sh stop` 停止服务。
不带参数的 `./bridge.sh` 在前台运行，Ctrl+C 停止。新安装不会预置私人密码、Cookie 或密钥。
工具包内包含源码、脚本、配置模板、文档、测试和 Agent skill；Python 依赖按 requirements.txt 安装。

## 可选本地联调环境

无需连接真实网站即可验证完整链路：

```sh
./scripts/setup-native.sh   # 额外需要 Node.js 22+、npm、git
./mock.sh start
./mock.sh status
./mock.sh restart
./mock.sh stop
```

网页 <http://127.0.0.1:8080>，默认测试账号 `demo / demo-pass`；SSH 默认 `0.0.0.0:2222`。
本地测试后端使用当前 macOS/Linux 账户，工作目录 `.state/workspace`，不是沙箱。
`root` 是桥接入口用户名，不提升系统权限。官方 WebSSH2 固定为 v5.2.1，
Git revision `9d63f9b34118c4c77061934f09bdc19b8dacdd23`。

切换到真实网站前先停止本地联调环境，避免占用同一 SSH 端口。
旧版 `demo.sh` 保留为 mock.sh 的兼容入口；内部 demo 配置块、PID/日志文件名保持兼容。

## 唯一配置文件

所有可调设置都在 **`.state/config.json`**，权限 0600。包括：
SSH 监听和账号密码、公钥路径、网站 Cookie、HTTP 入口、Socket.IO 路径/namespace、请求头、
query/auth 参数、超时、文件限制、日志及 mock 设置。
密钥本身、日志、传输缓存是独立运行文件，不是额外配置。

```sh
.venv/bin/python -m scripts.config check
.venv/bin/python -m scripts.config show          # 配置预览隐藏凭据；不影响日志设置
.venv/bin/python -m scripts.config set-password  # 隐藏输入，写入 ssh.password
.venv/bin/python -m scripts.config set-cookie    # 隐藏输入，写入 webssh.cookie
.venv/bin/python -m scripts.config set-ws-url    # 粘贴 Network 中的 WS Request URL，自动提取部分设置
```

可通过 ssh.password 启用密码认证，也支持公钥认证；当前安装实例已启用密码。重启 SSH 服务应用密码等设置；
Cookie 在每次新上游会话重新读取，无须重启。旧的 `.env` 和环境变量字段不再使用；
唯一环境选项 `BRIDGE_CONFIG` 用于指定配置文件，也可用 `--config /absolute/path/config.json`。
所有相对路径以配置文件所在目录为基准。

字段说明见 [configuration](docs/configuration.md)。新环境模板为 [config.example.json](config.example.json)。

## 从另一台机器使用

这台机器当前网卡地址曾验证为 `7.249.59.47`；使用 Agent 机器实际可达的桥接机 IP。

```sh
ssh -p 2222 root@7.249.59.47
```

按提示输入已配置密码。也可把 Agent 机器的普通 OpenSSH 公钥加入配置中 `ssh.authorized_keys` 指向的文件，
一行一个公钥。私钥留在 Agent 机器。公钥授权文件无需重启即可生效。

在 Agent 机器的 `~/.ssh/config` 配置：

```sshconfig
Host webssh
    HostName 7.249.59.47
    Port 2222
    User root
    IdentityFile ~/.ssh/webssh_bridge_key
```

密码登录可省略 IdentityFile。然后：

```sh
ssh webssh 'whoami; pwd'
ssh webssh 'echo hello; exit 42'
echo $?  # 42
scp ./code.py webssh:code.py
sftp webssh
```

本机试用可使用生成的配置：`ssh -F .state/ssh_config webssh 'whoami; pwd'`。
两台机器需有可达路由且防火墙允许 TCP 2222。桥接器不配置公网路由或 NAT。

## 如何接入网页里嵌入的终端

不能只看外层网页 URL，也不能把普通 WebSocket 和 Socket.IO 当作同一协议。

1. 正常登录网站，在终端可用后打开浏览器开发者工具 **Network**。
2. 找出 iframe 的实际页面地址和终端的 WS 请求。
3. 记录 WS Request URL、Cookie/Origin、Engine.IO 版本，以及 Messages 中的认证/终端/文件事件。
4. 用 `scripts.config set-ws-url` 提取 origin、Socket.IO path、稳定 query；补齐入口、namespace、Cookie。
5. 用诊断命令验证，再启动单独的 `bridge.sh`。

**完整逐步操作、抓取示例和配置映射见 [真实网站接入指南](docs/real-site-onboarding.md)。**
它包含 iframe 跨域、Cookie、401/302/404、EIO=3、namespace 和原生 WebSocket 等常见问题。

```sh
.venv/bin/python -m scripts.diagnose --auth-only
.venv/bin/python -m scripts.diagnose
.venv/bin/python -m scripts.diagnose --command 'printf hello; exit 42'
```

默认诊断只连接、认证和列目录，不自动执行命令。`--command` 显式指定的命令会实际运行。
真实内网尚未接入；事件改名可配置，消息结构或认证流程不同仍需调整协议适配层。

## 日志与调试

当前按用户要求**关闭脱敏**，记录原始错误和完整命令，设置为 `logging.redact_secrets=false`、
`logging.command_text=true`。日志是 JSON Lines，默认每文件 5 MiB、保留 3 份轮转，文件权限 0600。

```sh
tail -f .state/logs/bridge.jsonl
# 查看指定会话
rg 'exec-某个会话ID' .state/logs/bridge.jsonl
```

- `bridge.jsonl`：SSH 连接/认证、session_id、WebSSH2 连接、HTTP 状态、命令退出码/字节数/耗时、SFTP 操作和错误堆栈。
- `gateway.jsonl`：mock 网站登录、HTTP/WS 请求路径、状态、耗时及网关异常。
- `demo.jsonl` / `target.jsonl`：组件 PID、启停、后端监听和启动异常。
- `diagnose.jsonl`：独立诊断过程。
- `.state/service-1.log`：未修改的官方 Node WebSSH2 自身日志；其他 service 日志保存各组件控制台输出。

细节追踪：配置 `logging.level="DEBUG"` 和 `logging.protocol_events=true` 后重启。
终端逐帧字节追踪另开 `logging.terminal_data=true`，以 Base64 记录收发数据，便于检查 ANSI/协议边界。
配置及日志都只保存在桥接机器。

## 测试与限制

先启动本地联调环境，再执行 `.venv/bin/python -m pytest -q`。详见 [测试记录](docs/test-results.md)。

exec 的 stdout/stderr 合并，stdin 为 `/dev/null`，脚本先 scp 上传再执行。
SFTP 使用官方文件事件和有界本地磁盘缓存；默认上限 32 MiB，上传 CLOSE 后下载校验 SHA-256。
符号链接、保留时间戳/所有权、fsync、legacy SCP 和端口转发未实现。
更多语义边界见 [limitations](docs/limitations.md) 和 [Agent 规范](docs/agent-usage.md)。

## 可选 Compose

本机没有 Docker，容器启动仍未验收。Compose 拓扑已提供，配置从同一 JSON 自动生成，
不要手工修改 `.state/compose.config.json` 或 `compose.generated.json`。

```sh
.venv/bin/python -m scripts.compose up -d --build linux webssh2 gateway
.venv/bin/python -m scripts.login --demo
.venv/bin/python -m scripts.compose --profile bridge up -d --build bridge
.venv/bin/python -m scripts.compose --profile bridge down
```

bridge 与 linux 不在同一网络，底层 SSH 不发布端口。容器配置中的路径需在挂载的 `/state` 中可用；
默认相对路径可以直接使用。官方镜像固定 `ghcr.io/billchurch/webssh2:5.2.1`。

## 发布打包

源码由 Git 管理，发布 ZIP 从已提交的 HEAD 导出，不包含私有配置、密钥、Cookie、日志和依赖目录。

```sh
.venv/bin/python -m scripts.package_release
```

输出为 `dist/webssh2-ssh-bridge-<VERSION>.zip`；ZIP 中包含 Agent skill，位于 `skills/webssh-bridge-client`。
本机的 `.state/config.json` 留在本机；新机器从模板初始化并重新配置网站会话及 SSH 登录方式。
