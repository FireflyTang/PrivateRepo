#!/bin/sh
# Compatibility alias. The supported local-test entry point is mock.sh.
set -eu
cd "$(dirname "$0")"
exec ./mock.sh "$@"
