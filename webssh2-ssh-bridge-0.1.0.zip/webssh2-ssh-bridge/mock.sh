#!/bin/sh
# Manage the optional local WebSSH2 integration-test environment.
set -eu
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  ./scripts/setup-native.sh
fi
exec .venv/bin/python -m scripts.demo_control "$@"
