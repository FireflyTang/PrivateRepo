"""Render optional Compose deployment from the same private JSON configuration."""
import copy
import json
import os
import subprocess
import sys
from bridge.config import Config, ROOT, save_document
from bridge.auth import private_write


def render(config):
    spec = json.loads((ROOT / 'compose.yaml').read_text())
    demo = config.demo
    derived = copy.deepcopy(config.document)
    derived['state_directory'] = '.'
    derived['ssh']['host'] = '0.0.0.0'
    derived['webssh']['url'] = 'http://gateway:%s' % demo['gateway_port']
    derived['demo'].update(bind_host='0.0.0.0', webssh2_host='webssh2', target_host='linux', webssh2_port=2222, target_port=22)
    config_dir = config.path.parent
    save_document(config_dir / 'compose.config.json', derived)
    services = spec['services']
    mount = str(config_dir) + ':/state'
    for name in ('gateway', 'bridge'):
        services[name]['volumes'] = [mount]
        services[name]['environment'] = {'BRIDGE_CONFIG': '/state/compose.config.json'}
        services[name]['build'] = str(ROOT)
    services['linux']['build'] = str(ROOT / 'mock/linux')
    services['linux']['volumes'].append(str(config_dir) + ':/config:ro')
    services['webssh2']['environment'].update(
        WEBSSH2_USER_NAME=demo['target_user'], WEBSSH2_USER_PASSWORD=demo['target_password'],
        WEBSSH2_SSH_SFTP_MAX_FILE_SIZE=str(config.max_file))
    services['gateway']['ports'] = ['127.0.0.1:%s:%s' % (demo['gateway_port'], demo['gateway_port'])]
    services['bridge']['ports'] = ['%s:%s:%s' % (config.host, config.port, config.port)]
    destination = config_dir / 'compose.generated.json'
    private_write(destination, (json.dumps(spec, indent=2) + '\n').encode())
    return destination


if __name__ == '__main__':
    config = Config()
    destination = render(config)
    if sys.argv[1:] == ['render']:
        print('Generated private deployment:', destination)
    else:
        raise SystemExit(subprocess.call(['docker', 'compose', '-f', str(destination), *sys.argv[1:]], cwd=ROOT))
