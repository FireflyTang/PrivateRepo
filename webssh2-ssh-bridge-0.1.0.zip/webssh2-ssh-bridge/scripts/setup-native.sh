#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
python3 -m venv .venv
.venv/bin/pip install -r requirements-dev.txt
.venv/bin/python -m scripts.prepare
source_dir=$(.venv/bin/python -c 'from bridge.config import Config; c=Config(); print(c.resolve(c.demo["webssh2_source"]))')
mkdir -p "$(dirname "$source_dir")"
if [ ! -d "$source_dir" ]; then
  git clone --depth 1 --branch webssh2-server-v5.2.1 https://github.com/billchurch/webssh2.git "$source_dir"
fi
actual=$(git -C "$source_dir" rev-parse HEAD)
[ "$actual" = '9d63f9b34118c4c77061934f09bdc19b8dacdd23' ] || { echo 'Unexpected WebSSH2 revision'; exit 1; }
(cd "$source_dir" && npm ci --no-audit --no-fund && npm run build)
.venv/bin/python -m scripts.prepare
