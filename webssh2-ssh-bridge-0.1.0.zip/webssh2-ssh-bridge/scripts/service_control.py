import argparse
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
from bridge.config import Config, ROOT, initialize


def main(component='demo'):
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['run', 'start', 'stop', 'restart', 'status'], default='run', nargs='?')
    parser.add_argument('--config', default=None)
    args = parser.parse_args()
    config = Config(initialize(args.config))
    identity = 'scripts/native-demo.py' if component == 'demo' else '-m bridge.main'
    label = 'Mock environment' if component == 'demo' else 'Bridge'
    os.chdir(ROOT)
    config.state.mkdir(parents=True, exist_ok=True, mode=0o700)
    pid_file = config.state / (component + '.pid')
    pid = None
    try:
        candidate = int(pid_file.read_text())
        command = subprocess.check_output(['ps', '-p', str(candidate), '-o', 'command='], text=True).strip()
        if identity in command:
            pid = candidate
    except (OSError, ValueError, subprocess.CalledProcessError):
        pass
    if args.action == 'status':
        print('Running (PID %s)' % pid if pid else 'Stopped')
        print('Configuration:', config.path)
        print('SSH: %s:%s' % (config.host, config.port))
        print('Logs:', config.log_directory)
        return
    if args.action in ('stop', 'restart'):
        if pid:
            os.kill(pid, signal.SIGTERM)
            for attempt in range(200):
                if not pid_file.exists():
                    break
                time.sleep(.1)
            else:
                raise SystemExit('Stop is taking longer than expected; inspect private logs')
            print(label + ' stopped')
        else:
            print(label + ' is not running')
        if args.action == 'stop':
            return
        pid = None
    if pid:
        raise SystemExit(label + ' is already running (PID %s)' % pid)
    if component == 'demo' and not (config.resolve(config.demo['webssh2_source']) / 'dist/index.js').exists():
        raise SystemExit('Official WebSSH2 is not built. Run ./scripts/setup-native.sh')
    from .prepare import main as prepare
    prepare(config.path)
    env = {**os.environ, 'BRIDGE_CONFIG': str(config.path)}
    argv = [sys.executable, str(ROOT / 'scripts/native-demo.py')] if component == 'demo' else [sys.executable, '-m', 'bridge.main']
    if args.action == 'run':
        os.execve(sys.executable, argv, env)
    log_path = config.state / (component + '.log')
    fd = os.open(log_path, os.O_APPEND | os.O_CREAT | os.O_WRONLY, 0o600)
    os.fchmod(fd, 0o600)
    with os.fdopen(fd, 'ab', buffering=0) as log:
        child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                 env=env, start_new_session=True)
    for attempt in range(100):
        if child.poll() is not None:
            raise SystemExit('Startup failed; inspect ' + str(log_path))
        try:
            # The ready marker is written only after the mock Cookie refresh.
            marker = config.state / (component + '.ready')
            if marker.exists() and marker.read_text().strip() == str(child.pid):
                print(label + ' started (PID %s)' % child.pid)
                print('Website/upstream:', config.url)
                print('SSH: %s:%s; user: %s' % (config.host, config.port, config.username))
                print('Logs:', config.log_directory)
                return
        except OSError:
            pass
        time.sleep(.1)
    raise SystemExit('Startup still in progress; inspect ' + str(log_path))


if __name__ == '__main__':
    main()
