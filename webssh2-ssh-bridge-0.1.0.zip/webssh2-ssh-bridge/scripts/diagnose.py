"""Staged upstream probe; executes a command only with explicit --command."""
import argparse
import asyncio
import json
from . import config as config_cli
from bridge.config import Config
from bridge.webssh2_client import WebSSHClient
from bridge.exec_adapter import execute
from bridge.logging_setup import configure_logging, event, failure, new_session


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=None)
    parser.add_argument('--command', default=None, help='Optional explicit command; otherwise auth and SFTP list only')
    parser.add_argument('--auth-only', action='store_true', help='Do not require file-browser support')
    args = parser.parse_args()
    config = Config(args.config)
    configure_logging(config, 'diagnose')
    new_session('diagnose')
    try:
        async with WebSSHClient(config) as client:
            print('[OK] HTTP entry, Socket.IO, and WebSSH2 authentication')
            if not args.auth_only:
                listing = await client.list('~')
                print('[OK] SFTP list:', listing['path'], '; entries:', len(listing['entries']))
                print('SFTP limits:', json.dumps(client.sftp_config, ensure_ascii=False))
            if args.command:
                async def output(data):
                    print(data.decode(errors='replace'), end='', flush=True)
                code = await asyncio.wait_for(execute(client, args.command, output), config.timeout)
                print('\n[RESULT] Exit code:', code)
                return code
        return 0
    except Exception as error:
        failure('diagnose.failed', error)
        print('[FAILED]', type(error).__name__, str(error))
        print('See:', config.log_directory / 'diagnose.jsonl')
        return 1


if __name__ == '__main__':
    raise SystemExit(asyncio.run(main()))
