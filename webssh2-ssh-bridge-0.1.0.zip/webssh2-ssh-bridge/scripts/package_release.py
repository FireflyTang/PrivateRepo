"""Export a committed source release with Git, excluding all ignored runtime data."""
import argparse
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default=None)
    args = parser.parse_args()
    version = (ROOT / 'VERSION').read_text().strip()
    output = Path(args.output).expanduser().absolute() if args.output else ROOT / 'dist' / ('webssh2-ssh-bridge-%s.zip' % version)
    if subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=normal'], cwd=ROOT):
        raise SystemExit('Commit tracked/source changes before packaging a release')
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    output.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['git', 'archive', '--format=zip', '--prefix=webssh2-ssh-bridge/',
                    '--output=' + str(output), commit], cwd=ROOT, check=True)
    with zipfile.ZipFile(output) as package:
        if package.testzip() is not None:
            raise SystemExit('ZIP integrity verification failed')
        for name in package.namelist():
            parts = Path(name).parts[1:]
            if any(part in ('.git', '.state', '.venv', '.pytest_cache', '__pycache__', 'dist', '.DS_Store') for part in parts):
                raise SystemExit('Runtime file unexpectedly included: ' + name)
    print('Version:', version)
    print('Commit:', commit)
    print('ZIP:', output)
    print('Bytes:', output.stat().st_size)


if __name__ == '__main__':
    main()
