from .service_control import main

if __name__ == '__main__':
    main('demo')
