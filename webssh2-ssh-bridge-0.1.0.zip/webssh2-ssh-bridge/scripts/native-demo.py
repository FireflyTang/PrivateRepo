"""Run the configured local stack without containers; all settings come from JSON."""
import argparse
import asyncio
import fcntl
import os
import signal
import subprocess
import sys
from pathlib import Path
import aiohttp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from bridge.config import Config
from bridge.logging_setup import configure_logging, event, failure
from scripts.prepare import main as prepare


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=None)
    args = parser.parse_args()
    os.chdir(ROOT)
    if args.config:
        os.environ['BRIDGE_CONFIG'] = str(Path(args.config).resolve())
    prepare()
    config = Config()
    state, demo = config.state, config.demo
    expected = 'http://%s:%s' % (demo['bind_host'], demo['gateway_port'])
    if config.url != expected:
        raise SystemExit('native-demo requires webssh.url=' + expected + '; use bridge.sh for real sites')
    configure_logging(config, 'demo')
    lock = open(state / 'demo.lock', 'w')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit('Local test environment is already running')
    stopped = asyncio.Event()
    asyncio.get_running_loop().add_signal_handler(signal.SIGTERM, stopped.set)
    # Official Node WebSSH2 receives derived environment, with JSON as the single source.
    common = {**os.environ, 'BRIDGE_CONFIG': str(config.path)}
    common.pop('DEBUG', None)  # Third-party payload DEBUG traces are not safe diagnostics.
    node_env = {**common, 'WEBSSH2_LISTEN_IP': demo['bind_host'], 'WEBSSH2_LISTEN_PORT': str(demo['webssh2_port']),
                'WEBSSH2_SSH_HOST': demo['target_host'], 'WEBSSH2_SSH_PORT': str(demo['target_port']),
                'WEBSSH2_USER_NAME': demo['target_user'], 'WEBSSH2_USER_PASSWORD': demo['target_password'],
                'WEBSSH2_SSH_SFTP_ENABLED': 'true', 'WEBSSH2_SSH_HOSTKEY_ENABLED': 'false',
                'WEBSSH2_SSH_SFTP_MAX_FILE_SIZE': str(config.max_file)}
    commands = [('target', [sys.executable, 'scripts/native_target.py'], ROOT, common),
                ('webssh2', ['node', 'dist/index.js'], config.resolve(demo['webssh2_source']), node_env),
                ('gateway', [sys.executable, 'mock/login-gateway/main.py'], ROOT, common),
                ('bridge', [sys.executable, '-m', 'bridge.main'], ROOT, common)]
    children, logs = [], []
    try:
        (state / 'demo.pid').write_text(str(os.getpid()))
        for index, (name, argv, cwd, env) in enumerate(commands):
            log = open(state / ('service-%d.log' % index), 'wb', buffering=0)
            os.chmod(log.name, 0o600)
            logs.append(log)
            child = subprocess.Popen(argv, cwd=cwd, env=env, stdout=log, stderr=log, start_new_session=True)
            children.append(child)
            event('INFO', 'demo.service.started', component=name, pid=child.pid)
        async with aiohttp.ClientSession() as session:
            for attempt in range(60):
                if any(child.poll() is not None for child in children):
                    raise RuntimeError('A service exited; see service logs')
                try:
                    async with session.get('http://%s:%s/ssh' % (demo['bind_host'], demo['webssh2_port'])) as response:
                        if response.status == 200:
                            break
                except aiohttp.ClientError:
                    pass
                await asyncio.sleep(.5)
            else:
                raise RuntimeError('WebSSH2 did not become ready')
        subprocess.run([sys.executable, '-m', 'scripts.login', '--demo'], check=True, env=common)
        (state / 'demo.ready').write_text(str(os.getpid()))
        event('INFO', 'demo.ready', website=config.url, ssh_host=config.host, ssh_port=config.port, config_file=str(config.path))
        print('\nLocal test environment ready: %s\nSSH: %s:%s; user: %s\nPrivate config: %s\nLogs: %s\n'
              'Uses current macOS account. Ctrl+C stops services.' %
              (config.url, config.host, config.port, config.username, config.path, config.log_directory), flush=True)
        while not stopped.is_set():
            if any(child.poll() is not None for child in children):
                raise RuntimeError('A service exited; see service logs')
            await asyncio.sleep(1)
    except Exception as error:
        failure('demo.failed', error)
        raise SystemExit('Local test environment failed; see private logs') from None
    finally:
        for child in children:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
        for child in children:
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        for log in logs:
            log.close()
        (state / 'demo.pid').unlink(missing_ok=True)
        (state / 'demo.ready').unlink(missing_ok=True)
        lock.close()
        event('INFO', 'demo.stopped')


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
