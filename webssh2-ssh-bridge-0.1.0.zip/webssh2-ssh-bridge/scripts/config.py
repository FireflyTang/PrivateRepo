"""Manage the single private config without exposing secrets on the command line."""
import argparse
import getpass
import json
from bridge.config import Config, config_path, initialize, read_document, save_document, validate
from bridge.logging_setup import redact, register_config


def parse_ws_url(value):
    from urllib.parse import urlsplit, parse_qs
    from bridge.config import ConfigError
    parsed = urlsplit(value.strip())
    if parsed.scheme not in ('ws', 'wss', 'http', 'https') or not parsed.hostname or parsed.username:
        raise ConfigError('Expected a WebSocket Request URL without embedded credentials')
    query = parse_qs(parsed.query, keep_blank_values=True)
    if query.get('EIO', ['4']) != ['4']:
        raise ConfigError('This adapter supports Engine.IO 4; EIO=3 needs a separate adapter')
    stable = {key: values[0] for key, values in query.items() if key not in ('sid', 'EIO', 'transport', 't')}
    if any(len(values) > 1 for values in query.values()):
        raise ConfigError('Repeated query fields need manual protocol adaptation')
    transports = query.get('transport', ['websocket'])
    if transports[0] not in ('websocket', 'polling'):
        raise ConfigError('Unknown transport')
    return {'url': ('https://' if parsed.scheme in ('wss', 'https') else 'http://') + parsed.netloc,
            'socketio_path': parsed.path or '/socket.io/', 'query': stable, 'transports': transports}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=None)
    parser.add_argument('action', choices=['init', 'check', 'show', 'set-cookie', 'set-password', 'set-ws-url'])
    args = parser.parse_args()
    path = config_path(args.config)
    if args.action == 'init':
        initialize(path)
        print('Private config:', path)
        return
    config = Config(path)
    register_config(config)
    if args.action == 'set-ws-url':
        value = getpass.getpass('WebSocket Request URL: ')
        document = read_document(path)
        document.setdefault('webssh', {}).update(parse_ws_url(value))
        save_document(path, document)
        print('Updated webssh origin/path/query. Check entry_path, namespace and Cookie separately.')
    elif args.action in ('set-cookie', 'set-password'):
        section, key = ('webssh', 'cookie') if args.action == 'set-cookie' else ('ssh', 'password')
        value = getpass.getpass('Cookie header value: ' if key == 'cookie' else 'SSH password (empty disables password login): ')
        document = read_document(path)
        document.setdefault(section, {})[key] = value
        save_document(path, document)
        print('Updated', section + '.' + key, 'in', path)
        print('New upstream sessions reload Cookie automatically.' if key == 'cookie' else 'Restart bridge to apply password changes.')
    elif args.action == 'show':
        print(json.dumps(redact(config.document), ensure_ascii=False, indent=2))
    else:
        print('Configuration valid:', path)
        print('SSH listener: %s:%s; user: %s; password enabled: %s' % (config.host, config.port, config.username, bool(config.password)))
        print('WebSSH2: %s%s; Socket.IO: /%s/; namespace: %s' % (config.url, config.entry_path, config.socket_path, config.namespace))
        print('Cookie configured:', bool(config.cookie()))
        print('Logs:', config.log_directory)


if __name__ == '__main__':
    main()
