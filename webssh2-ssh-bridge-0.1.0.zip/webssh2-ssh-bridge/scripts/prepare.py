from bridge.auth import ensure_key, private_write
from bridge.config import Config, initialize


def main(path=None):
    config = Config(initialize(path))
    config.state.mkdir(exist_ok=True, parents=True, mode=0o700)
    config.state.chmod(0o700)
    ensure_key(config.state / 'client_key')
    ensure_key(config.host_key)
    if not config.authorized_keys.exists():
        private_write(config.authorized_keys, (config.state / 'client_key.pub').read_bytes())
    ssh = f'''Host webssh
    HostName 127.0.0.1
    Port {config.port}
    User {config.username}
    IdentityFile {config.state}/client_key
    IdentitiesOnly yes
    UserKnownHostsFile {config.state}/known_hosts
    StrictHostKeyChecking accept-new
'''
    private_write(config.state / 'ssh_config', ssh.encode())
    print('Private configuration:', config.path)
    print('SSH client configuration:', config.state / 'ssh_config')


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=None)
    main(parser.parse_args().config)
