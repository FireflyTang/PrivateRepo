"""Development fallback ONLY: current macOS user shell, not Linux/root isolation."""
import asyncio
import errno
import fcntl
import os
import pty
import signal
import struct
import termios
from pathlib import Path
import asyncssh
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from bridge.config import Config
from bridge.logging_setup import configure_logging, event, failure

CONFIG = Config()
STATE = CONFIG.state
WORKSPACE = CONFIG.resolve(CONFIG.demo['workspace'])


class TargetAuth(asyncssh.SSHServer):
    def begin_auth(self, username):
        return True

    def password_auth_supported(self):
        return True

    def validate_password(self, username, password):
        return username == CONFIG.demo['target_user'] and __import__('hmac').compare_digest(password, CONFIG.demo['target_password'])


async def shell(process):
    master, slave = pty.openpty()
    cols, rows, _, _ = process.get_terminal_size()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack('HHHH', rows or 24, cols or 80, 0, 0))
    def setup():
        os.setsid()
        fcntl.ioctl(0, termios.TIOCSCTTY, 0)
    env = {**os.environ, 'TERM': process.get_terminal_type() or 'xterm-256color', 'PS1': 'mock-target$ '}
    args = ['/bin/bash', '--noprofile', '--norc']
    args += ['-c', process.command] if process.command else ['-i']
    child = await asyncio.create_subprocess_exec(*args, stdin=slave, stdout=slave, stderr=slave,
                  cwd=str(WORKSPACE), env=env, preexec_fn=setup)
    os.close(slave)
    os.set_blocking(master, False)
    loop = asyncio.get_running_loop()
    chunks = asyncio.Queue()
    def readable():
        try:
            data = os.read(master, 65536)
        except OSError as error:
            if error.errno == errno.EAGAIN:
                return
            data = b''
        if not data:
            loop.remove_reader(master)
        chunks.put_nowait(data)
    loop.add_reader(master, readable)
    async def output():
        while True:
            data = await chunks.get()
            if not data:
                return
            process.stdout.write(data)
            await process.stdout.drain()
    async def input_data():
        while True:
            try:
                data = await process.stdin.read(32768)
                if not data:
                    return
                view = memoryview(data)
                while view:
                    try:
                        n = os.write(master, view)
                        view = view[n:]
                    except BlockingIOError:
                        await asyncio.sleep(.005)
            except asyncssh.TerminalSizeChanged as event:
                fcntl.ioctl(master, termios.TIOCSWINSZ, struct.pack('HHHH', event.height, event.width, 0, 0))
            except asyncssh.SignalReceived:
                os.write(master, b'\x03')
    tasks = [asyncio.create_task(output()), asyncio.create_task(input_data())]
    try:
        done, _ = await asyncio.wait([*tasks, asyncio.create_task(child.wait())], return_when=asyncio.FIRST_COMPLETED)
        # An input EOF/disconnect should close the backend too.
        if child.returncode is None:
            try:
                os.killpg(child.pid, signal.SIGHUP)
            except ProcessLookupError:
                pass
        await child.wait()
        await asyncio.wait_for(tasks[0], 2)
        process.exit(child.returncode if child.returncode >= 0 else 128 - child.returncode)
    except (OSError, asyncio.TimeoutError, asyncssh.Error):
        pass
    finally:
        loop.remove_reader(master)
        os.close(master)
        for task in tasks:
            task.cancel()
        if child.returncode is None:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        await child.wait()
        await asyncio.gather(*tasks, return_exceptions=True)


async def main():
    configure_logging(CONFIG, 'target')
    STATE.mkdir(exist_ok=True)
    WORKSPACE.mkdir(parents=True, exist_ok=True)
    key = CONFIG.resolve(CONFIG.demo['target_host_key'])
    if not key.exists():
        key.write_bytes(asyncssh.generate_private_key('ssh-ed25519').export_private_key())
        key.chmod(0o600)
    os.chdir(WORKSPACE)
    async with asyncssh.listen(CONFIG.demo['bind_host'], CONFIG.demo['target_port'], server_factory=TargetAuth, reuse_address=True,
                  server_host_keys=[str(key)], process_factory=shell, encoding=None,
                  sftp_factory=asyncssh.SFTPServer):
        event('INFO', 'target.listening', host=CONFIG.demo['bind_host'], port=CONFIG.demo['target_port'], workspace=str(WORKSPACE), actual_uid=os.getuid())
        await asyncio.Future()


if __name__ == '__main__':
    asyncio.run(main())
