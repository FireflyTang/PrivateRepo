"""Mock login writes the website Cookie into the single private configuration."""
import argparse
import asyncio
import getpass
import aiohttp
from bridge.config import Config, read_document, save_document


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=None)
    parser.add_argument('--demo', action='store_true', help='Use configured local mock credentials')
    args = parser.parse_args()
    config = Config(args.config)
    password = config.demo['website_password'] if args.demo else getpass.getpass('Website password: ')
    async with aiohttp.ClientSession() as session:
        async with session.post(config.url + '/login', data={'username': config.demo['website_user'], 'password': password}, allow_redirects=False) as response:
            if response.status != 302 or 'demo_session' not in response.cookies:
                raise SystemExit('Website login failed (HTTP %s)' % response.status)
            document = read_document(config.path)
            document['webssh']['cookie'] = 'demo_session=' + response.cookies['demo_session'].value
            save_document(config.path, document)
            print('Cookie updated privately in', config.path)


if __name__ == '__main__':
    asyncio.run(main())
