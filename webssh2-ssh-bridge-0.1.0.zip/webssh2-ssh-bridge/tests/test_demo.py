"""Integration tests against RUNNING native-demo or Compose stack; no mocks."""
import asyncio
import hashlib
import os
from pathlib import Path
import shlex
import subprocess
import tempfile
import uuid
import aiohttp
import asyncssh
import pytest
from bridge.config import Config
from bridge.webssh2_client import WebSSHClient, WebSSHError
from bridge.ssh_server import serve

ROOT = Path(__file__).resolve().parents[1]
SSH_CONFIG = str(ROOT / '.state/ssh_config')


def ssh(command, **kwargs):
    return subprocess.run(['ssh', '-F', SSH_CONFIG, '-o', 'LogLevel=ERROR', 'webssh', command],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, **kwargs)


@pytest.mark.parametrize('command,expected,code', [
    ('printf hello', b'hello', 0),
    ('exit 42', b'', 42),
    ('false', b'', 1),
    ("printf '%s\\n' 'a b' | tr a-z A-Z", b'A B\n', 0),
    ("printf '\\344\\270\\255\\346\\226\\207'", '中文'.encode(), 0),
    ('printf err >&2; exit 7', b'err', 7),
    ('printf "line1\\nline2\\n"', b'line1\nline2\n', 0),
    ('printf "marker-like: END:0\\n"; exit 3', b'marker-like: END:0\n', 3),
])
def test_exec(command, expected, code):
    result = ssh(command, stdin=subprocess.DEVNULL)
    assert result.returncode == code, result.stderr
    assert result.stdout == expected


def test_long_output():
    result = ssh("head -c 2097152 /dev/zero | tr '\\000' x", stdin=subprocess.DEVNULL)
    assert result.returncode == 0, result.stderr
    assert result.stdout == b'x' * 2097152


@pytest.mark.asyncio
async def test_concurrent_exec():
    async def run(i):
        process = await asyncio.create_subprocess_exec('ssh', '-F', SSH_CONFIG, '-o', 'LogLevel=ERROR', 'webssh',
                   'sleep 0.1; printf session-%d; exit %d' % (i, i),
                   stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        out, err = await asyncio.wait_for(process.communicate(), 20)
        assert out == ('session-%d' % i).encode(), err
        assert process.returncode == i
    await asyncio.gather(*(run(i) for i in range(4)))


@pytest.mark.asyncio
async def test_website_auth():
    async with aiohttp.ClientSession() as session:
        async with session.get('http://127.0.0.1:8080/ssh/host/', allow_redirects=False) as response:
            assert response.status in (302, 401)
        async with session.post('http://127.0.0.1:8080/login', data={'username':'demo','password':'wrong'}, allow_redirects=False) as response:
            assert response.status == 401


@pytest.mark.asyncio
async def test_bad_cookie(tmp_path):
    config = Config()
    config.cookie_override = 'demo_session=expired'
    with pytest.raises(WebSSHError, match='authentication failed|expired'):
        async with WebSSHClient(config):
            pytest.fail('Invalid Cookie accepted')


@pytest.mark.asyncio
async def test_native_file_protocol():
    async with WebSSHClient(Config()) as client:
        home = (await client.list('~'))['path']
        path = home + '/protocol-' + uuid.uuid4().hex + '.bin'
        data = os.urandom(131073)
        try:
            with tempfile.TemporaryFile() as file:
                file.write(data)
                await client.upload(path, file, len(data), overwrite=False)
            with tempfile.TemporaryFile() as file:
                await client.download(path, file)
                assert hashlib.sha256(file.read()).digest() == hashlib.sha256(data).digest()
        finally:
            await client.delete(path)


def test_openssh_scp(tmp_path):
    home = ssh('pwd', stdin=subprocess.DEVNULL).stdout.decode().strip()
    remote = home + '/scp-' + uuid.uuid4().hex + '.bin'
    source, dest = tmp_path / 'source.bin', tmp_path / 'dest.bin'
    source.write_bytes(os.urandom(1048833))
    try:
        for args in ([str(source), 'webssh:' + remote], ['webssh:' + remote, str(dest)]):
            result = subprocess.run(['scp', '-F', SSH_CONFIG, '-o', 'LogLevel=ERROR', *args], capture_output=True, timeout=30)
            assert result.returncode == 0, result.stderr
            assert b'unsupported' not in result.stderr.lower(), result.stderr
        assert hashlib.sha256(source.read_bytes()).digest() == hashlib.sha256(dest.read_bytes()).digest()
    finally:
        ssh('rm -f ' + shlex.quote(remote), stdin=subprocess.DEVNULL)


@pytest.mark.asyncio
async def test_sftp_operations(tmp_path):
    async with asyncssh.connect('127.0.0.1', port=2222, username='root', client_keys=[str(ROOT / '.state/client_key')], known_hosts=None) as conn:
        async with conn.start_sftp_client() as sftp:
            home = await sftp.realpath('.')
            folder = home + '/sftp-' + uuid.uuid4().hex
            await sftp.mkdir(folder)
            try:
                async with sftp.open(folder + '/offset.bin', 'wb') as file:
                    await file.write(b'world', offset=5)
                    await file.write(b'hello', offset=0)
                    assert (await file.stat()).size == 10
                async with sftp.open(folder + '/offset.bin', 'rb') as file:
                    assert await file.read() == b'helloworld'
                await sftp.rename(folder + '/offset.bin', folder + '/renamed.bin')
                assert 'renamed.bin' in await sftp.listdir(folder)
                assert (await sftp.stat(folder + '/renamed.bin')).size == 10
                with pytest.raises(asyncssh.SFTPError):
                    await sftp.rmdir(folder)
                await sftp.remove(folder + '/renamed.bin')
                with pytest.raises(asyncssh.SFTPNoSuchFile):
                    await sftp.stat(folder + '/missing')
            finally:
                await sftp.rmdir(folder)


@pytest.mark.asyncio
async def test_zero_byte_and_overwrite():
    async with asyncssh.connect('127.0.0.1', port=2222, username='root', client_keys=[str(ROOT / '.state/client_key')], known_hosts=None) as conn:
        async with conn.start_sftp_client() as sftp:
            path = (await sftp.realpath('.')) + '/empty-' + uuid.uuid4().hex
            try:
                async with sftp.open(path, 'wb') as file:
                    await file.write(b'old data')
                async with sftp.open(path, 'wb'):
                    pass
                assert (await sftp.stat(path)).size == 0
                async with sftp.open(path, 'rb') as file:
                    assert await file.read() == b''
            finally:
                await sftp.remove(path)


@pytest.mark.asyncio
async def test_timeout_and_stdin():
    config = Config()
    config.port = 2223
    config.timeout = 0.5
    server = await serve(config)
    async with server:
        async with asyncssh.connect('127.0.0.1', port=2223, username='root', client_keys=[str(ROOT / '.state/client_key')], known_hosts=None) as conn:
            result = await asyncio.wait_for(conn.run('sleep 30'), 10)
            assert result.exit_status == 124
            assert 'completion is unknown' in result.stderr
            result = await conn.run('cat', input='input is unsupported')
            assert result.exit_status == 255
            assert 'stdin is unsupported' in result.stderr


@pytest.mark.asyncio
async def test_signal():
    async with asyncssh.connect('127.0.0.1', port=2222, username='root', client_keys=[str(ROOT / '.state/client_key')], known_hosts=None) as conn:
        proc = await conn.create_process('sleep 30')
        await asyncio.sleep(.2)
        proc.send_signal('INT')
        result = await asyncio.wait_for(proc.wait(), 10)
        assert result.exit_status != 0


@pytest.mark.asyncio
async def test_interactive_shell():
    async with asyncssh.connect('127.0.0.1', port=2222, username='root', client_keys=[str(ROOT / '.state/client_key')], known_hosts=None) as conn:
        proc = await conn.create_process(term_type='xterm', term_size=(100, 30))
        proc.change_terminal_size(120, 40)
        proc.stdin.write('printf INTERACTIVE_OK\\n\n')
        output = ''
        while 'INTERACTIVE_OK' not in output:
            output += await asyncio.wait_for(proc.stdout.read(4096), 10)
        # Disable echo before a second command, so observed output proves execution.
        proc.stdin.write("stty -echo; printf '\\nREADY_INTERACTIVE\\n'; exit\n")
        output += await asyncio.wait_for(proc.stdout.read(), 10)
        assert 'READY_INTERACTIVE' in output


@pytest.mark.asyncio
async def test_local_auth_rejected():
    key = asyncssh.generate_private_key('ssh-ed25519')
    with pytest.raises(asyncssh.PermissionDenied):
        await asyncssh.connect('127.0.0.1', port=2222, username='root', client_keys=[key], known_hosts=None, agent_path=None)


@pytest.mark.asyncio
async def test_disconnect_then_fresh_session():
    from bridge.exec_adapter import execute
    async def discard(data):
        pass
    async with WebSSHClient(Config()) as client:
        running = asyncio.create_task(execute(client, 'sleep 30', discard))
        await asyncio.sleep(.1)
        await client.sio.disconnect()
        with pytest.raises(WebSSHError):
            await asyncio.wait_for(running, 5)
    async with WebSSHClient(Config()) as client:
        assert await asyncio.wait_for(execute(client, 'exit 9', discard), 10) == 9


@pytest.mark.asyncio
async def test_aborted_cached_upload():
    conn = await asyncssh.connect('127.0.0.1', port=2222, username='root', client_keys=[str(ROOT / '.state/client_key')], known_hosts=None)
    sftp = await conn.start_sftp_client()
    path = (await sftp.realpath('.')) + '/abort-' + uuid.uuid4().hex
    file = await sftp.open(path, 'wb')
    await file.write(b'uncommitted data')
    conn.abort()
    await conn.wait_closed()
    await asyncio.sleep(.1)
    result = ssh('test ! -e ' + shlex.quote(path), stdin=subprocess.DEVNULL)
    assert result.returncode == 0


def test_openssh_sftp_batch(tmp_path):
    name = 'cli-' + uuid.uuid4().hex
    source = tmp_path / 'input.bin'
    dest = tmp_path / 'output.bin'
    source.write_bytes(os.urandom(33001))
    batch = tmp_path / 'batch.txt'
    batch.write_text('mkdir {n}\nput {s} {n}/a.bin\nrename {n}/a.bin {n}/b.bin\nls {n}\nget {n}/b.bin {d}\nrm {n}/b.bin\nrmdir {n}\n'.format(n=name, s=source, d=dest))
    result = subprocess.run(['sftp', '-F', SSH_CONFIG, '-o', 'LogLevel=ERROR', '-b', str(batch), 'webssh'], capture_output=True, timeout=30)
    assert result.returncode == 0, result.stderr
    assert hashlib.sha256(source.read_bytes()).digest() == hashlib.sha256(dest.read_bytes()).digest()


@pytest.mark.asyncio
async def test_password_login_and_sftp():
    config = Config()
    if not config.password:
        pytest.skip('Password authentication is disabled in the active configuration')
    async with asyncssh.connect('127.0.0.1', port=2222, username=config.username,
             password=config.password, client_keys=[], agent_path=None, preferred_auth='password', known_hosts=None) as conn:
        result = await conn.run('printf PASSWORD_ONLY_OK; exit 42')
        assert result.stdout == 'PASSWORD_ONLY_OK'
        assert result.exit_status == 42
        async with conn.start_sftp_client() as sftp:
            assert await sftp.realpath('.')
    with pytest.raises(asyncssh.PermissionDenied):
        await asyncssh.connect('127.0.0.1', port=2222, username=config.username,
             password='wrong-password-test', client_keys=[], agent_path=None, preferred_auth='password', known_hosts=None)


def test_correlated_log_has_command_and_status():
    result = ssh('printf LOG_CORRELATION_TEST; exit 37', stdin=subprocess.DEVNULL)
    assert result.returncode == 37
    import json
    lines = [json.loads(line) for line in (Config().log_directory / 'bridge.jsonl').read_text().splitlines()]
    started = [item for item in lines if item['event'] == 'exec.start' and item.get('command') == 'printf LOG_CORRELATION_TEST; exit 37']
    assert started
    session_id = started[-1]['session_id']
    completed = [item for item in lines if item['event'] == 'exec.complete' and item['session_id'] == session_id]
    assert completed[-1]['exit_code'] == 37
    assert completed[-1]['output_bytes'] == len(b'LOG_CORRELATION_TEST')


@pytest.mark.asyncio
async def test_standalone_service_custom_config(tmp_path):
    from bridge.config import save_document
    active = Config()
    import copy
    document = copy.deepcopy(active.document)
    document['state_directory'] = str(tmp_path / 'runtime')
    document['ssh'].update(host='127.0.0.1', port=2225, username='configured-user',
                           authorized_keys=str(active.authorized_keys), host_key=str(active.host_key))
    document['logging'].update(directory=str(tmp_path / 'logs'), console=False)
    config_file = tmp_path / 'config.json'
    save_document(config_file, document)
    args = [str(ROOT / 'bridge.sh')]
    try:
        result = subprocess.run([*args, 'start', '--config', str(config_file)], capture_output=True, timeout=15)
        assert result.returncode == 0, result.stderr
        async with asyncssh.connect('127.0.0.1', port=2225, username='configured-user',
                  client_keys=[str(ROOT / '.state/client_key')], known_hosts=None) as conn:
            result = await conn.run('printf STANDALONE_OK; exit 7')
            assert result.exit_status == 7
            assert result.stdout == 'STANDALONE_OK'
    finally:
        result = subprocess.run([*args, 'stop', '--config', str(config_file)], capture_output=True, timeout=25)
        assert result.returncode == 0, result.stderr
