import io
import json
import logging
import os
from pathlib import Path
import pytest
from bridge.config import Config, ConfigError, defaults, save_document, validate
from bridge.logging_setup import JSONFormatter, PrivateRotatingHandler, register_secret
from scripts.config import parse_ws_url


def private_config(tmp_path):
    path = tmp_path / 'config.json'
    save_document(path, defaults())
    return path


def test_config_paths_and_cookie_reload(tmp_path):
    path = private_config(tmp_path)
    config = Config(path)
    assert config.authorized_keys == tmp_path / 'client_key.pub'
    document = defaults()
    document['webssh']['cookie'] = 'site=new-cookie-value'
    save_document(path, document)
    assert config.cookie() == 'site=new-cookie-value'
    assert (path.stat().st_mode & 0o777) == 0o600


@pytest.mark.parametrize('section,key,value', [
    ('ssh', 'port', 70000), ('ssh', 'port', True), ('files', 'max_bytes', -1),
    ('logging', 'level', 'invalid'), ('webssh', 'url', 'wss://host/socket.io'),
    ('webssh', 'headers', {'Cookie': 'wrong place'}),
    ('webssh', 'cookie', 'cookie=x\nHeader: injection'),
    ('webssh', 'query', {'sid': 'do-not-replay'}),
    ('webssh', 'events', {'typo-event': 'custom'}),
    ('webssh', 'transports', ['invalid'])
])
def test_invalid_config(section, key, value):
    document = defaults()
    document[section][key] = value
    with pytest.raises(ConfigError):
        validate(document)


def test_unknown_fields_and_file_permissions(tmp_path):
    document = defaults()
    document['ssh']['post'] = 2222
    with pytest.raises(ConfigError, match='Unknown'):
        validate(document)
    path = private_config(tmp_path)
    path.chmod(0o644)
    with pytest.raises(ConfigError, match='0600'):
        Config(path)


def test_ws_url_mapping():
    config = parse_ws_url('wss://host.example:8443/apps/ssh/socket.io/?EIO=4&transport=websocket&sid=temporary&t=123&channel=abc')
    assert config['url'] == 'https://host.example:8443'
    assert config['socketio_path'] == '/apps/ssh/socket.io/'
    assert config['query'] == {'channel': 'abc'}
    assert config['transports'] == ['websocket']
    with pytest.raises(ConfigError, match='Engine.IO 4'):
        parse_ws_url('wss://host/socket.io/?EIO=3')


@pytest.mark.parametrize('redact', [True, False])
def test_raw_and_redacted_log_modes(redact):
    register_secret('unit-secret-credential')
    record = logging.LogRecord('test', logging.ERROR, __file__, 1, 'failure', (), None)
    record.fields = {'password': 'unit-secret-credential', 'message': 'failure: unit-secret-credential'}
    output = JSONFormatter(redact_secrets=redact).format(record)
    assert ('unit-secret-credential' in output) is not redact
    assert json.loads(output)['level'] == 'ERROR'


def test_log_rotation_is_private(tmp_path):
    path = tmp_path / 'test.jsonl'
    handler = PrivateRotatingHandler(str(path), maxBytes=300, backupCount=2)
    handler.setFormatter(JSONFormatter(redact_secrets=False))
    logger = logging.getLogger('rotation-test')
    logger.setLevel(logging.INFO)
    logger.propagate = False
    logger.addHandler(handler)
    try:
        for index in range(20):
            logger.info('number-%d-%s', index, 'x'*30)
    finally:
        handler.close()
        logger.removeHandler(handler)
    files = list(tmp_path.glob('test.jsonl*'))
    assert len(files) == 3
    for file in files:
        assert (file.stat().st_mode & 0o777) == 0o600
        for line in file.read_text().splitlines():
            json.loads(line)


def test_compose_uses_single_config(tmp_path):
    from scripts.compose import render
    path = private_config(tmp_path)
    config = Config(path)
    generated = render(config)
    spec = json.loads(generated.read_text())
    assert set(spec['services']['bridge']['environment']) == {'BRIDGE_CONFIG'}
    assert 'target' not in spec['services']['bridge']['networks']
    assert (generated.stat().st_mode & 0o777) == 0o600
    assert Config(tmp_path / 'compose.config.json').url == 'http://gateway:8080'


@pytest.mark.asyncio
async def test_custom_socketio_options(tmp_path):
    """Exercise actual Socket.IO transport with renamed events and custom namespace."""
    import socketio
    from aiohttp import web
    from bridge.webssh2_client import WebSSHClient
    sio = socketio.AsyncServer(async_mode='aiohttp', cors_allowed_origins=['https://portal.example'])
    app = web.Application()
    sio.attach(app, socketio_path='nested/socket.io')
    observed = {}
    async def entry(request):
        observed['query'] = dict(request.query)
        observed['cookie'] = request.headers.get('Cookie')
        response = web.Response(text='terminal')
        response.set_cookie('server_session', 'session-from-entry')
        return response
    app.router.add_get('/nested/terminal', entry)
    @sio.on('connect', namespace='/custom')
    async def connect(sid, environ, auth):
        observed['socket_cookie'] = environ.get('HTTP_COOKIE', '')
        observed['origin'] = environ.get('HTTP_ORIGIN')
        observed['auth'] = auth
        observed['socket_query'] = environ.get('QUERY_STRING', '')
        await sio.emit('custom-auth', {'action':'auth_result','success':True}, to=sid, namespace='/custom')
    @sio.on('custom-list', namespace='/custom')
    async def listing(sid, payload):
        await sio.emit('custom-directory', {'path':'/fixture','entries':[]}, to=sid, namespace='/custom')
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, '127.0.0.1', 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    document = defaults()
    document['webssh'].update(url='http://127.0.0.1:%s' % port, entry_path='/nested/terminal',
        socketio_path='/nested/socket.io/', namespace='/custom', cookie='website=valid',
        headers={'Origin':'https://portal.example'}, entry_query={'machine':'123'},
        query={'channel':'abc'}, auth={'ticket':'fixture-ticket'},
        events={'authentication':'custom-auth','sftp-list':'custom-list','sftp-directory':'custom-directory'})
    path = tmp_path / 'custom.json'
    save_document(path, document)
    try:
        async with WebSSHClient(Config(path)) as client:
            assert (await client.list('~'))['path'] == '/fixture'
        assert observed['query'] == {'machine':'123'}
        assert observed['origin'] == 'https://portal.example'
        assert observed['auth'] == {'ticket':'fixture-ticket'}
        assert 'channel=abc' in observed['socket_query']
        assert 'website=valid' in observed['socket_cookie']
        assert 'server_session=session-from-entry' in observed['socket_cookie']
    finally:
        await sio.shutdown()
        await runner.cleanup()
