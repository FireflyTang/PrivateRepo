# 工具能力与限制

- native 模式使用当前 macOS 账户。底层测试 SSH 监听 loopback:2200，官方 WebSSH2 监听 loopback:3000，网关 loopback:8080；桥接器为 0.0.0.0:2222（公钥与配置的密码认证），可供其他机器访问。
  无网络隔离；桥接代码没有底层目标地址/凭据和 SSH 客户端，测试路径严格经过 WebSSH2。
  Compose 方案让 bridge 与 linux 处在不同网络，且 linux 不发布端口。当前机器未安装 Docker，Compose 尚未运行验收。
- exec stdout/stderr 合并、无 stdin 流、带远端 PTY。常规文本命令支持；二进制内容使用 SFTP。
  远端输出受 PTY/isatty 行为影响。命令最长 64 KiB。不保证 shell 提示符完全不在交互关闭时出现。
- 交互式 SSH 无可靠远端退出码事件；exec 有包装退出码。中断/超时/断线不会报告 exec 成功，
  但不保证全部子孙进程终止，不保证回滚。
- 文件上限 32 MiB；每 SFTP 会话至多 16 个磁盘缓存句柄，最多 8 个基础 SSH/SFTP 会话。
  元数据补充操作会临时建立额外的 WebSSH2 连接。下载事件队列未做严格内存背压，按每文件大小设上界。
- 缓存上传不是原子提交，网络故障可能留下远端部分文件。CLOSE 成功表示内容校验通过，不表示磁盘 fsync。
  同文件多客户端写入可能相互覆盖。rename 的不覆盖检查和 mv 之间有竞态，当前适配器要求没有外部并发写入者。
- chmod 支持；保留时间戳、chown、符号链接操作、statvfs、fsync、legacy SCP 尚未实现，返回明确错误。
  realpath 是基于远端 cwd 的词法规范化，不解析符号链接；lstat 受官方 stat 协议语义影响。
- Mock Cookie 有效期 8 小时，重启网关后需重新登录；native-demo 启动时会自动保存新的 demo Cookie。
  已有传输断线后不自动续传；修复 Cookie 后重新提交新会话。网页 Cookie 与桥接器 Cookie 可分别登录。
- 测试账号、后端密码仅供本地模拟。Cookie/密码统一保存在 `.state/config.json`，密钥为独立运行文件，权限 0600，均不入库。日志按用户要求关闭脱敏，完整命令和原始错误可见。
