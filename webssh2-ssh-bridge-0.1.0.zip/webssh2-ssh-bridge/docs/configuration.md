# 单文件配置说明

实际文件：`.state/config.json`（0600）；模板：仓库根目录 `config.example.json`。
`./scripts/setup-native.sh` 或 `scripts.config init` 创建实际文件。首次创建会迁移旧版 Cookie/密码文件。
之后只有 JSON 是配置源，不再读取旧的 cookie.txt、ssh_password 或 `.env`。

相对文件路径按 JSON 文件所在目录解析：默认配置在 `.state`，`"host_key":"host_key"` 即 `.state/host_key`。
缺少的字段使用模板默认值；未知字段、类型错误、无效端口、换行 Cookie 等会在启动前报错。
JSON 不支持注释。保存后先运行 `python -m scripts.config check` 校验。

## 顶层与 SSH

| 字段 | 说明 |
|---|---|
| version | 当前必须为 1 |
| state_directory | PID、控制台文件、demo 客户端密钥等运行文件目录 |
| ssh.host / port | 对外 SSH 监听地址与端口。0.0.0.0 面向所有 IPv4 网卡；127.0.0.1 仅本机 |
| ssh.username | SSH 入口用户名，不决定后端实际身份 |
| ssh.password | 密码认证；空字符串关闭。CLI `set-password` 隐藏输入并写入 |
| ssh.authorized_keys | 普通 OpenSSH 公钥列表文件，每行一个公钥；不依赖私钥复制 |
| ssh.host_key | SSH 服务主机私钥路径，缺失时生成，重启保持稳定 |
| ssh.max_sessions | 同时运行的基础 SSH/SFTP 上游会话上限 |
| ssh.login_timeout_seconds | 本地 SSH 认证超时 |

## WebSSH2

| 字段 | 说明 / 获取位置 |
|---|---|
| webssh.url | 实际终端服务的 HTTP origin，仅 scheme://host:port。由 wss:// 转为 https://，ws:// 转为 http:// |
| webssh.entry_path | 实际终端页面路径，不一定是外层门户。来自 iframe src 或 Network 的 Document 请求 |
| webssh.entry_method | GET（默认）或 POST。需要 POST 初始化会话的站点按实测设置 |
| webssh.entry_query | 页面初始化所需的 query 字段，字符串字典 |
| webssh.entry_form | POST 初始化表单字段，字符串字典；GET 时不使用 |
| webssh.socketio_path | WS Request URL 中 `?` 前的 pathname，例如 /apps/ssh/socket.io/ |
| webssh.namespace | Socket.IO namespace，通常 /；从连接帧或前端 io(...) 读取，不能当作 path |
| webssh.transports | ["websocket"] 或 ["polling", "websocket"]，按网络环境和抓包设置 |
| webssh.cookie | 请求 Headers 中完整 Cookie 值，不含 `Cookie:` 前缀。CLI `set-cookie` 更新 |
| webssh.headers | 附加 HTTP/WS 请求头，例如 Origin、Referer、Authorization。不要在此重复写 Cookie |
| webssh.query | Socket.IO 握手所需的稳定 query，例如 channel/ticket。禁止复制 sid/EIO/transport/t |
| webssh.auth | Socket.IO CONNECT 的 auth 对象，例如 {"token":"..."}，仅在站点确实需要时使用 |
| webssh.tls_verify | 默认 true，使用系统可信 HTTPS 验证。自签 CA 可通过运行环境配置可信证书 |
| webssh.http_timeout_seconds | HTTP 页面初始化总超时 |
| webssh.connect_timeout_seconds | Socket.IO 建连与上游认证超时 |
| webssh.operation_timeout_seconds | SFTP 等待单次响应/下一传输事件的超时 |
| webssh.exec_timeout_seconds | 命令运行总超时，返回 124 且完成状态未知 |
| webssh.bootstrap_timeout_seconds | 新 shell 初始响应与包装握手超时 |
| webssh.events | 事件名映射。例如 {"data":"terminal:data"}；只改名，不转换消息结构 |

Cookie 每次新建 WebSSH2 会话都会从 JSON 重新读取；其他设置修改后重启对应服务。
Socket.IO query/auth token 如果过期，需要更新 JSON 并重启桥接器。
外层网站自动登录通常无法只靠路径配置复现；当前真实网站模式由用户正常登录后提供 Cookie。

## 文件与日志

| 字段 | 说明 |
|---|---|
| files.max_bytes | 单文件大小上限，默认 32 MiB |
| files.max_handles_per_session | 每 SFTP 会话同时打开的缓存句柄上限，默认 16 |
| files.upload_chunk_bytes | 上传块大小，实际取与服务端上限的较小值（适配器目前最大 32 KiB） |
| files.verify_upload_sha256 | true：上传完成后重下载校验；false：只检查协议传输长度 |
| logging.level | DEBUG / INFO / WARNING / ERROR |
| logging.directory | 日志目录，相对 JSON 目录，默认 logs |
| logging.max_bytes / backup_count | 每份 JSONL 大小与轮转备份数，默认 5 MiB / 3 |
| logging.console | 同时向 stderr 输出 JSON 日志 |
| logging.redact_secrets | 当前用户要求 false，保留原始信息；true 可恢复凭据遮盖 |
| logging.command_text | 当前为 true，记录完整命令；false 时保留命令哈希和长度 |
| logging.protocol_events | DEBUG 下记录 Socket.IO 事件名、字段名和块序号等 |
| logging.terminal_data | DEBUG 下逐帧记录终端字节（Base64），默认 false |

命令日志的 `exec.start` 与 `exec.complete` 共用 session_id/client_id。
ERROR 包含 error_type、message 和 traceback；取消操作标为 WARNING。
SFTP 缺失文件等业务错误标为 WARNING，未实现操作会明确返回客户端。
文件内容通过 SFTP 二进制通道传输；protocol_events 记录元数据，不逐字记录文件块。

## Demo

`demo` 块仅供模拟环境启动，真实网站桥接器不会用它连接底层 SSH。

| 字段 | 说明 |
|---|---|
| demo.bind_host | 模拟网关、官方 WebSSH2 与本地测试后端的监听地址，默认 loopback |
| demo.gateway_port / webssh2_port / target_port | 三个模拟服务端口 |
| demo.webssh2_host / target_host | 网关访问 WebSSH2、官方 WebSSH2 访问后端的地址 |
| demo.website_user / website_password | 本地网页登录账号 |
| demo.target_user / target_password | 官方 WebSSH2 访问测试后端使用的模拟凭据 |
| demo.cookie_ttl_seconds | Mock 网站 Cookie 有效时间 |
| demo.workspace | 本地测试 shell 的初始目录 |
| demo.target_host_key | 本地测试 SSH 后端的主机密钥 |
| demo.webssh2_source | 已编译的官方固定版本源码目录 |

node 官方程序需要的环境变量由启动器从 JSON 派生，无需单独维护。
只有 `BRIDGE_CONFIG` 环境变量用于定位 JSON 文件。容器部署文件也是由同一 JSON 自动生成的运行产物。
