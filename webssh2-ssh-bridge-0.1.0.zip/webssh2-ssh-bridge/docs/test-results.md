# 实测记录 — 2026-10-29

环境：macOS arm64、Python 3.9.6、Node 22.23.3、官方 WebSSH2 v5.2.1
（固定 revision 9d63f9b34118c4c77061934f09bdc19b8dacdd23）。
底层使用当前 macOS 用户 kylin1993，无 Docker、无虚拟机、无提权。

## 自动集成测试

在完整运行的 native-demo 上执行：

```sh
.venv/bin/python -m pytest -q --tb=short
```

最终结果：**23 passed**。原始本地输出保存于 `.state/test-results.txt`。

覆盖：

- 命令成功、exit 42、false、管道、引号、换行、UTF-8、stderr 合并、类似标记的普通输出。
- 2 MiB 连续输出完整返回，4 条并发命令输出和退出码隔离。
- 无效网站登录、失效 Cookie、错误 SSH 公钥拒绝。
- 独立 WebSSH2 客户端通过官方 SFTP 事件往返 131,073 字节随机二进制。
- OpenSSH scp 往返 1,048,833 字节随机二进制，SHA-256 一致，命令退出码为 0，无 unsupported 提示。
- OpenSSH sftp batch：mkdir、put、rename、ls、get、rm、rmdir，哈希一致。
- SFTP 随机偏移写入、fstat、读取、stat、rename、目录增删、非空目录拒绝删除、缺失文件错误。
- 零字节文件、覆盖截断。
- 命令超时返回 124，未支持的 exec stdin 返回 255，INT 中断不误报成功。
- 交互式 shell 与窗口调整。
- WebSSH2 断线使当前命令失败；新建会话可再次正确返回退出码。
- 未 CLOSE 的缓存上传断开连接后不提交远端文件。

## 浏览器人工流程（通过 UI 自动化实测）

1. 打开 http://127.0.0.1:8080，输入 demo / demo-pass。
2. 自动进入官方 WebSSH2，状态 Connected，无需第二次输入 SSH 凭据。
3. 网页执行 whoami/pwd，输出当前账户和 `.state/workspace`。
4. Menu → File Browser，列目录成功。
5. 使用官方 Upload files 上传 `browser-proof.bin`，65,792 字节，显示 Complete。
6. 点击 Download，将文件下载到本机 Downloads，显示 Complete。
7. 原文件、远端文件、浏览器下载文件 SHA-256 均为：

```
120c518a83325c66464701a6ee080302f332bc768ea3f60473b209f1bfb091df
```

截图见 `demo.png`。官方客户端的下载进度显示 `0 B / 64.3 KB`，但完成状态与实际落盘内容均已验证，
这属于原客户端显示行为。

## 启停与 Agent 工作流

- `./demo.sh start` 后独立 SSH 命令返回 BACKGROUND_OK。
- `./demo.sh stop` 后确认 2200、3000、8080、2222 四个服务端口全部停止。
- 再次 start 后恢复可用。
- 上传 hello.py → SSH 执行并重定向到 result.txt → scp 下载，得到 `hello from Agent`。

## 未验收

Compose 的真正 Linux/OpenSSH root 后端未运行（本机未安装 Docker）。
真实内网网站尚未连接，实际 Cookie/认证/Socket.IO/SFTP 事件仍需比对。
未宣称兼容所有 SSH/SFTP 客户端；功能限制见 limitations.md。

## 网络 SSH 入口验证

根据后续要求，native-demo 的 SSH 入口已改为 `0.0.0.0:2222`，
网页和底层后端仍仅监听 loopback。使用 OpenSSH 经本机网卡地址
`7.249.59.47:2222` 完成公钥认证和命令执行，输出 `NETWORK_SSH_OK` 和当前用户名。
修改后 23 项集成测试再次全部通过。尚未从用户的另一台机器发起连接；
跨机器可达性与该机器的公钥授权仍需在用户环境确认。

## 单文件配置与诊断日志升级

最终执行 `.venv/bin/python -m pytest -q --tb=short`：**44 passed in 3.16s**。
原有真实 WebSSH2 链路测试继续通过，新增测试覆盖：

- 单一私有 JSON、相对路径解析、Cookie 新会话热更新、文件 0600。
- 配置字段名/类型/端口/URL/header/transport/query/事件映射校验。
- WS URL 自动提取与 sid/t 等动态参数剔除，EIO=3 明确拒绝。
- 日志原文/脱敏切换、JSON 有效性、轮转大小/份数与备份权限。
- 密码限定认证成功、错误密码拒绝，密码会话执行命令并使用 SFTP。
- 日志中的完整命令、session_id、退出码及输出字节数相互对应。
- 独立 bridge.sh 使用另一 JSON 配置、不同端口及用户名启动，真实命令返回正确输出/退出码，然后正常停止。
- Compose 配置从同一 JSON 渲染，私有派生文件 0600、bridge 不在 target 网络；容器仍未启动。
- 单独的真实 Socket.IO 测试服务验证自定义 namespace、代理前缀、事件改名、Origin、query/auth、页面初始化 Cookie；
  此项是协议客户端选项测试，不冒充真实内网站点验证。

当前按用户要求 `logging.redact_secrets=false`、`logging.command_text=true`。
实际配置 `.state/config.json`；旧版 cookie.txt/ssh_password 已移除。
独立诊断实际通过 HTTP、Socket.IO、认证和文件列表，并执行指定命令准确返回 42。
真实内网仍待提供实际协议后验证。
