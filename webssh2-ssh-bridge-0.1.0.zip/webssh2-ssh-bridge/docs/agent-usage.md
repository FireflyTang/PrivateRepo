# Agent 使用规范

在仓库根目录使用 `.state/ssh_config`，无需改动全局 `~/.ssh/config`：

```sh
ssh -F .state/ssh_config webssh 'pwd; whoami'
scp -F .state/ssh_config ./example.py webssh:example.py
ssh -F .state/ssh_config webssh 'python3 example.py'
scp -F .state/ssh_config webssh:result.json ./result.json
sftp -F .state/ssh_config webssh
```

当前 native 模式初始目录是本项目的 `.state/workspace`，权限为当前 macOS 用户。
这不是沙箱，命令能够访问该用户有权限访问的文件。入口 `root` 只是桥接登录名。

- 每次 exec 是独立会话；用 `cd /absolute/path && command`，不要依赖前次会话的 cwd 或环境。
- exec 使用远端 `sh -c`，支持管道、重定向、引号及退出码。stdout/stderr 合并到 stdout。
- exec 的 stdin 是 `/dev/null`。上传脚本后执行；不要使用 `cat file | ssh`、heredoc 向 SSH 喂脚本。
- 默认命令超时 120 秒，超时返回 124；协议、认证和连接失败返回 255。均不代表命令没有副作用。
- 文件使用现代 OpenSSH 默认的 scp（SFTP）；不用 `scp -O` 或 `scp -p`。
- 文件上限 32 MiB，本地磁盘缓存，写入在 CLOSE 时提交并重新下载校验 SHA-256。
- 同一文件不要并发写入。下载是快照，未关闭的上传不保证对其他会话可见。
- 不要求后台任务断线存活，不支持端口转发和 Agent Forwarding。
- 日常操作推荐 exec；交互式 `ssh -F .state/ssh_config webssh` 用于人工诊断。
