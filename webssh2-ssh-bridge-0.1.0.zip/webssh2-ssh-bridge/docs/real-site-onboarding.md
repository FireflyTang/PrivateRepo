# 接入网页中嵌入的 WebSSH2

目标：桥接机器使用用户已有的网页会话，经网站协议访问终端；Agent 机器只使用标准 SSH。
桥接机器必须能访问内网站点，Agent 机器必须能访问桥接机器 TCP 2222。
当前客户端支持 Engine.IO 4 / Socket.IO 3、4 服务端及已验证的 WebSSH2 v5.2.1 协议。

## 1. 从已经可用的浏览器会话获取信息

使用 Chrome/Edge 举例：正常登录网站并打开终端，在终端界面按 F12，进入 Network。
开启 Preserve log，然后刷新终端页面或重新打开终端，使页面请求和握手出现在列表里。

### 找到 iframe 页面

外层可能是 `https://portal.example/workspace/123`，实际 iframe 却是：

```
https://terminal.example/apps/ssh/host/?machine=123
```

在 Elements 搜索 iframe，查看 src；或者在 Network 的 Doc/Document 请求里找到终端页面。
不要假设 iframe 与外层页面同域。如果用脚本创建终端而无 iframe，直接跟随 Network 的请求和 Initiator。
需要记录实际终端页面完整地址、访问方法，以及必要的 query/表单。

对应设置：

```json
{
  "webssh": {
    "url": "https://terminal.example",
    "entry_path": "/apps/ssh/host/",
    "entry_query": {"machine": "123"}
  }
}
```

以上是局部示例；在已有 config.json 中修改相应字段，不要覆盖其他配置。

### 找到真正的 WebSocket 请求

切换 Network 的 WS 过滤器，选择随终端打开的连接。在 Headers → General 找 Request URL，例如：

```
wss://terminal.example/apps/ssh/socket.io/?EIO=4&transport=websocket&sid=abc&t=123&machine=123
```

如果 WS 列表为空，也检查 Fetch/XHR 中包含 `socket.io` 和 `transport=polling` 的请求。
有些代理只允许 polling；这时 transports 应为 ["polling"] 或 ["polling","websocket"]。

最方便的方法：运行以下命令，在隐藏输入提示中粘贴完整 Request URL：

```sh
.venv/bin/python -m scripts.config set-ws-url
```

它提取 origin、socketio_path、transport 和稳定 query，并剔除动态字段。
上述 URL 映射为：

```json
{
  "webssh": {
    "url": "https://terminal.example",
    "socketio_path": "/apps/ssh/socket.io/",
    "transports": ["websocket"],
    "query": {"machine": "123"}
  }
}
```

`sid` 是 Engine.IO 每次握手生成的会话 ID，不可重用；EIO、transport、时间戳 t 由客户端库管理。
query 中的短期 ticket/token 如果必要可以保存，但过期后必须更新；它不是永久地址。
WS 的 path 与 Socket.IO namespace 是不同概念，不能互相替换。[Socket.IO 客户端选项](https://socket.io/docs/v4/client-options/)

### Cookie 和请求头

在同一 WS 请求的 **Request Headers** 中找到 Cookie。复制它的完整值：

```
site_session=...; webssh2.sid=...; other=...
```

运行 `python -m scripts.config set-cookie`，只粘贴值，不含 `Cookie:` 前缀。
HttpOnly Cookie 无法通过 document.cookie 读取；Network 请求头能反映实际发送给终端域名的 Cookie。
Application → Cookies 可以辅助查看终端域的 Cookie，但不能只复制外层门户域的 Cookie。

如果 Request Headers 还有必需的 Origin/Referer/Authorization，则填入 `webssh.headers`：

```json
{
  "webssh": {
    "headers": {
      "Origin": "https://portal.example",
      "Referer": "https://portal.example/workspace/123"
    }
  }
}
```

不要复制 Host、Connection、Upgrade、Sec-WebSocket-Key 或 Sec-WebSocket-Accept；它们由 HTTP/WS 客户端生成。
如果站点在握手后的 CONNECT 帧中发送 auth，例如 token，则填 `webssh.auth`，而不是随意添加到 Cookie。

本项目默认先访问 entry_path 初始化 WebSSH2 session，再携带 Cookie 建立 Socket.IO。
若 iframe 是通过 POST 初始化会话，按 Network 把 entry_method 设为 POST 并提供 entry_form。
如果必须执行额外的业务 API、JS 签名、CSRF 流程或登录交互，当前配置不能自动模拟，需适配认证流程。

## 2. 在 Messages 中确认协议

选择 WS 请求的 Messages，观察正常登录、输入一条命令、打开文件管理器、上传小测试文件时的帧。
常见 Socket.IO/Engine.IO 内容：

```
0{"sid":"...", ...}                       Engine.IO 握手（直接 WS 连接时可见）
40                                       默认 namespace 的 Socket.IO 连接
40/custom,{...}                          自定义 namespace
42["authentication",{"action":"auth_result","success":true}]
42["terminal",{"term":"xterm-256color","cols":80,"rows":24}]
42["data","ls\n"]
42["sftp-list",{"path":"~"}]
```

`42` 是协议前缀，不属于事件名。二进制事件可能显示 `451-...` 后跟 Binary Message。
默认 namespace 填 `/`；自定义例如 `/custom` 需要与实际帧一致。

需要确认：

- 认证事件是否有 auth_result，以及服务器是否自动获得了远端凭据。
- 终端输入和输出事件名、payload 是字符串、二进制还是对象。
- terminal/resize 的字段名。
- SFTP list/upload/download/start/chunk/complete/error 的事件与字段。
- SFTP 是否独立绑定同一个已认证会话，是否允许并发建立新会话。

若只是 `data` 改名为 `terminal:data`，可以设置 `webssh.events={"data":"terminal:data"}`。
若变成 `{type:"terminal",payload:{...}}` 或消息字段不同，需要修改 webssh2_client.py 的转换逻辑，不能靠改名解决。
如果 URL 是 EIO=3，当前库不兼容，需要另做旧版协议适配，set-ws-url 会明确拒绝。
如果只是普通 WebSocket、自定义 JSON 协议或其他 webssh 项目，也不能直接使用本 Socket.IO 适配器。
仅看到 xterm CSS 并不能证明服务端协议。

## 3. 分阶段验证

先停止模拟环境，再修改实际 JSON：

```sh
./mock.sh stop
.venv/bin/python -m scripts.config check
.venv/bin/python -m scripts.diagnose --auth-only
.venv/bin/python -m scripts.diagnose
.venv/bin/python -m scripts.diagnose --command 'printf hello; exit 42'
echo $?  # 最后一条应为 42
./bridge.sh start
```

native-demo 会检查上游是否指向自己的本地 mock 网关，避免向真实站点发送 mock 登录表单。
真实站点请使用 bridge.sh。Cookie 更新后新会话自动读取；其他设置修改后 `./bridge.sh restart`。

## 4. 根据日志定位

| 日志 / 现象 | 优先检查 |
|---|---|
| upstream.http.result 为 302 | 页面重定向到登录；Cookie、实际 iframe 入口或初始化流程 |
| HTTP 401/403 | Cookie 过期/域名错误、Origin、Authorization 或权限 |
| HTTP 404 | entry_path 不正确，或外层路由和 iframe 路由混淆 |
| HTTP 200，Socket.IO 404 | socketio_path 与代理前缀 |
| WS 400 / namespace 错误 | Engine.IO 版本、namespace、transport、query/auth |
| authentication.request_auth | 网站未在该会话提供 SSH 凭据，可能缺少初始化接口 |
| 上游已认证但 terminal 没输出 | terminal/data 事件、payload 和 shell 初始化 |
| SFTP_NOT_ENABLED | 该站点会话未开启文件功能，或使用不同上传下载 API |
| SFTP 超时 | 事件名/字段、传输完成事件、站点文件大小/速率限制 |
| exec 超时且无结束状态 | 包装命令被终端环境改变、父 shell 退出或连接中断 |

`logging.level="DEBUG"` + `protocol_events=true` 可以观察事件名/字段/块序号；
`terminal_data=true` 可查看终端帧的 Base64 原始字节。当前用户选择 `redact_secrets=false`，日志保留原始错误。

需要进一步适配时，最有用的材料是实际 iframe URL、WS URL、EIO 版本、认证/终端/SFTP 各一组事件及对应操作说明。
Cookie 直接留在本机配置中即可。此指南描述的是采集与映射方法；尚未宣称真实内网已兼容。

Network 中 Headers/Messages 的操作参考 [Chrome 官方 Network 文档](https://developer.chrome.com/docs/devtools/network/reference#messages)。
