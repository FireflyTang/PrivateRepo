# 已验证协议与待验证假设

基线：官方 WebSSH2 server v5.2.1，Git revision
`9d63f9b34118c4c77061934f09bdc19b8dacdd23`，其 lockfile 使用 webssh2_client 5.4.2。
源码位于 `.state/webssh2`（setup 从官方获取，不入库、不修改）。

## 认证和终端

1. Mock 网关 `POST /login` 验证网站账号，设置 HttpOnly、SameSite=Strict 的 demo_session Cookie。
2. 网关保护 HTTP 与 WebSocket，过滤外部 Authorization/Cookie，向内部 WebSSH2 注入模拟 Linux 的 Basic Auth。
3. GET `/ssh/host/` 触发官方认证中间件并建立 `webssh2.sid`。`/ssh` 根路由使用手工认证，不能替代它。
4. 客户端携带网站 Cookie 和新获得的 WebSSH2 sid，连接 `/ssh/socket.io/`，Engine.IO 4 / Socket.IO 4 服务端（Python Socket.IO 5 客户端）。
5. `authentication {action:'auth_result',success:true}` 后可独立使用 SFTP，不必启动 terminal。
6. `terminal {term,cols,rows}` 开 shell；`data` 双向流；`resize {cols,rows}`。

证据：官方 `app/routes/routes-v2.ts`、`app/socket/adapters/service-socket-authentication.ts`、
`service-socket-terminal.ts`、`app/types/contracts/v1/sftp.ts`。
不要依赖旧 WEBSOCKET-API 文档中 Socket.IO 2 的描述，以上述固定版本源码和测试为准。

## Exec

当前接入的 service adapter 的 `exec` 实现只发送 stdout/stderr 的 `data`，未发送退出码；
且其底层 exec 缓冲、限制输出。因此桥接器使用新建 PTY shell 和包装协议，保证流式转发。

等待初始 shell 数据后执行 `stty -echo -icanon -opost`，通过随机 192-bit token 的 READY 握手确认。
随后发送 BEGIN 标记、`sh -c <quoted command> </dev/null`、捕获 `$?` 并发送 END+退出码。
标记使用 RS/US 控制字符，发送给 shell 的命令只包含 printf 转义形式，避免命令回显触发标记。
解析器跨包保留尾部，并在 END 前先输出完整剩余内容。

命令在子 shell 执行，`exit 42` 不会跳过父包装器。断线/缺失标记/超时一律失败。
恶意命令如果主动检查父进程和协议 token，能够伪造协议；这不是面向恶意远端的可信执行证明。
改变终端属性、直接操作 tty、杀死父包装 shell 的命令不在当前适配器保证范围。

## SFTP

- 原生：`sftp-list/stat/mkdir/delete` → `sftp-directory/stat-result/operation-result`。
- 上传：`sftp-upload-start {remotePath,fileName,fileSize,overwrite}` → upload-ready（服务端生成 transferId）。
  连续 `sftp-upload-chunk {transferId,chunkIndex,data:base64,isLast}` → upload-ack，再 complete。
  这里 Base64 属于官方文件协议，不经过终端。
- 下载：`sftp-download-start {remotePath}` → download-ready、binary download-chunk、complete。
- 一个客户端内串行操作，避免缺少 request ID 的响应串流；不同 SSH 会话使用不同客户端。
- SFTP 随机偏移写入本地临时文件，CLOSE 时上传并重新下载校验；下载缓存后支持随机读取。
- v5.2.1 的零字节下载流未发送 complete：适配器读取 ready 的 fileSize=0 后取消流，
  通过独立 WebSSH2 shell 检查文件可读性，返回空内容。未修改官方服务端。
- 官方事件不含 rename/chmod：使用独立 WebSSH2 shell 的 Unix mv/chmod/rmdir 补齐这些元数据操作。
  文件内容仍只通过原生 SFTP 事件传输。
- 未实现的路径操作由 `map_path` 阻断，不会回落到桥接机器的本地文件系统。

## 真实内网待验证

实际版本、入口路径、sid 获取方式、Cookie 属性、WebSocket Origin、认证事件、终端事件、文件事件，
以及网关是否允许同时建立多个独立远端会话。不能将本地测试通过等同于真实内网兼容。
已有会话断开后不自动重放命令或上传，以免重复副作用；下一次会话会重新读取统一 JSON 配置中的 webssh.cookie。

配置入口现为 `.state/config.json`，仅 BRIDGE_CONFIG 可选择其他文件；字段与浏览器采集步骤见 configuration.md / real-site-onboarding.md。
