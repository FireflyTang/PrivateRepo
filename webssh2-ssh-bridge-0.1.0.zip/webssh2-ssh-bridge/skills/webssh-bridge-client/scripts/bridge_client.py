#!/usr/bin/env python3
"""Optional SSH/SFTP client for password-only noninteractive Agents."""
import argparse
import asyncio
import getpass
import os
import sys
from pathlib import Path


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True)
    parser.add_argument('--port', type=int, default=2222)
    parser.add_argument('--user', default='root')
    parser.add_argument('--identity', action='append', default=[])
    parser.add_argument('--known-hosts', help='Pinned OpenSSH known_hosts file; default uses normal AsyncSSH configuration')
    parser.add_argument('--password-env', default='WEBSSH_PASSWORD', help='Environment variable name; never the password value')
    parser.add_argument('--ask-password', action='store_true')
    parser.add_argument('--timeout', type=float, default=180, help='Client timeout, seconds; does not change bridge timeout')
    sub = parser.add_subparsers(dest='action', required=True)
    execute = sub.add_parser('exec')
    execute.add_argument('command')
    for action in ('put', 'get'):
        transfer = sub.add_parser(action)
        transfer.add_argument('source')
        transfer.add_argument('destination')
    return parser.parse_args()


async def run(args):
    try:
        import asyncssh
    except ImportError:
        print('Install helper dependency: python3 -m pip install asyncssh==2.21.1', file=sys.stderr)
        return 255
    password = os.getenv(args.password_env)
    if args.ask_password:
        password = getpass.getpass('SSH password: ')
    options = {'host': args.host, 'port': args.port, 'username': args.user, 'connect_timeout': 10}
    if args.known_hosts:
        options['known_hosts'] = str(Path(args.known_hosts).expanduser())
    if password is not None:
        options['password'] = password
        if not args.identity:
            options.update(client_keys=[], agent_path=None, preferred_auth='password')
    if args.identity:
        options['client_keys'] = [str(Path(path).expanduser()) for path in args.identity]
    try:
        async with asyncssh.connect(**options) as conn:
            if args.action == 'exec':
                result = await conn.run(args.command, timeout=args.timeout, check=False)
                sys.stdout.write(result.stdout)
                sys.stderr.write(result.stderr)
                if result.exit_status is None or result.exit_status < 0:
                    print('No reliable exit status received; command may have run.', file=sys.stderr)
                    return 255
                return result.exit_status
            async def transfer():
                async with conn.start_sftp_client() as sftp:
                    if args.action == 'put':
                        await sftp.put(args.source, args.destination, preserve=False, sparse=False)
                    else:
                        await sftp.get(args.source, args.destination, preserve=False, sparse=False)
            await asyncio.wait_for(transfer(), args.timeout)
            print('Transfer completed:', args.source, '->', args.destination)
            return 0
    except (asyncio.TimeoutError, asyncssh.TimeoutError):
        print('Client timeout; remote completion is unknown. Inspect state before retrying.', file=sys.stderr)
        return 124
    except (asyncssh.Error, OSError, ValueError) as error:
        print(type(error).__name__ + ': ' + str(error), file=sys.stderr)
        print('No automatic retry was performed.', file=sys.stderr)
        return 255


if __name__ == '__main__':
    raise SystemExit(asyncio.run(run(arguments())))
