# 文件操作范例

使用任务实际绝对路径；下列 /absolute/project 是示意，不代表目标主机存在该目录。
文件名若含空格或特殊字符，应针对本地 shell、远端 shell/SFTP 各层正确引用。

## SFTP batch

在 Agent 本地创建 batch 文件（本地写文件不受远端 exec stdin 限制）：

```text
mkdir /absolute/project/run-unique
put ./input.bin /absolute/project/run-unique/input.bin
ls /absolute/project/run-unique
rename /absolute/project/run-unique/input.bin /absolute/project/run-unique/ready.bin
get /absolute/project/run-unique/ready.bin ./output.bin
```

然后执行 `sftp -b ./batch.txt webssh`。OpenSSH 的 batch 适合已配置公钥等非交互认证。
只有密码且没有可用的交互输入时，用 Python helper 完成 put/get；其余元数据可用 exec 执行普通 Unix 命令。
不要擅自清理用户原有目录；只清理此次任务创建的临时内容。

## 完整性校验

本地用可用的 SHA-256 工具计算 input.bin，远端可按实际系统选择：

```sh
ssh webssh 'if command -v sha256sum >/dev/null 2>&1; then sha256sum /absolute/project/input.bin; else shasum -a 256 /absolute/project/input.bin; fi'
```

比较哈希值。默认桥接器会在上传 CLOSE 时自行做内容校验；客户端额外校验可用于重要交付物或排查问题。
下载可比较本地哈希与这条远端命令结果。

## 语义边界

- 缓存中的写入不保证立即对其他会话可见；必须成功 CLOSE。
- 正常 CLOSE 不表示磁盘 fsync；传输不是原子提交。
- 不同客户端同时写同一路径可能覆盖。用任务专属目录/临时名称并串行提交。
- 中断上传可能留部分远端文件；先检查现状，再按任务要求重新传输。
- SFTP 属性/操作接口不支持保留时间戳、所有权和符号链接；工具返回 unsupported 时应调整调用，不伪造成功。
- 大于配置上限的文件会报错，不自动用终端编码传输规避限制。
