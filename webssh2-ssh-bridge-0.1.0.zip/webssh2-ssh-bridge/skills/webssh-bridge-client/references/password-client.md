# 非交互密码客户端

OpenSSH/SCP/SFTP 是优先接口。Agent 运行环境无法输入密码且只有密码认证时，可用随包的
`scripts/bridge_client.py`；它通过标准 SSH/SFTP 连接桥接服务，不访问网页或底层 SSH。

依赖：Python 3.9+ 和 `asyncssh==2.21.1`。按当前运行环境安装到可用虚拟环境即可。
此 helper 已用桥接器实际验证 exec 的 42 退出码和二进制 put/get。

通过运行环境的密钥/凭据机制注入 `WEBSSH_PASSWORD`。交互式 shell 也可隐藏读取：

```sh
read -r -s -p 'SSH password: ' WEBSSH_PASSWORD
export WEBSSH_PASSWORD
printf '\n'
```

上例适用于 Bash，不适用于所有 shell。Agent 已有环境变量时不重复请求密码。
`--password-env` 参数填变量名，不填密码值。交互用户可选 `--ask-password`。

以当前 skill 目录为工作目录：

```sh
python3 scripts/bridge_client.py --host 7.249.59.47 --known-hosts assets/known_hosts.example exec 'printf hello; exit 42'
python3 scripts/bridge_client.py --host 7.249.59.47 --known-hosts assets/known_hosts.example put ./input.bin /absolute/project/input.bin
python3 scripts/bridge_client.py --host 7.249.59.47 --known-hosts assets/known_hosts.example get /absolute/project/result.bin ./result.bin
```

需要公钥时可传 `--identity ~/.ssh/webssh_bridge_key`；不传时可使用默认 SSH 配置/agent。
主机密钥验证保持开启；未匹配时核对连接地址和服务端主机密钥，不能以禁用验证处理。

helper 将远端输出写到本地 stdout/stderr，并原样返回有效的远端退出码。
它不提供 exec stdin、端口转发、自动重放或断点续传。
默认客户端超时 180 秒，通常长于默认服务端 120 秒；`--timeout` 只影响客户端等待。
超时返回 124、SSH/SFTP/网络故障返回 255，也可能与远端命令自己返回的这些值相同。

helper 显式关闭 sparse 稀疏文件扩展，仅使用桥接器已支持的普通文件 SFTP 读写。
