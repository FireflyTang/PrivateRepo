# 更新记录

## 0.1.0 — 2026-10-29

首次工具版本。

- WebSSH2 Cookie/Socket.IO 客户端与标准 SSH/SFTP 服务。
- 公钥、密码认证，独立命令会话与可靠退出状态，交互式终端。
- SCP/SFTP 文件传输、缓存偏移读写、上传 SHA-256 校验及元数据适配。
- 单一私有 JSON 配置、配置检查、WS URL 提取与分阶段连接诊断。
- JSONL 会话日志、轮转、完整命令和可配置的原文/脱敏、协议及终端追踪。
- 独立桥接服务入口 bridge.sh、安装入口 setup.sh，以及可选本地联调环境 mock.sh。
- Agent skill 与密码认证客户端脚本。

真实内网适配与未实现的 SSH/SFTP 语义仍以 docs/limitations.md 为准。
