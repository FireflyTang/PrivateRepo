"""Cookie-protected reverse proxy. Only this mock layer knows Linux credentials."""
import asyncio
import hmac
import os
import secrets
import time
from aiohttp import web, ClientSession, WSMsgType, DummyCookieJar

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from bridge.config import Config
from bridge.logging_setup import configure_logging, event, failure, register_secret
CONFIG = Config()
UPSTREAM = 'http://%s:%s' % (CONFIG.demo['webssh2_host'], CONFIG.demo['webssh2_port'])
USER, PASSWORD = CONFIG.demo['website_user'], CONFIG.demo['website_password']
SSH_USER, SSH_PASSWORD = CONFIG.demo['target_user'], CONFIG.demo['target_password']
TTL = CONFIG.demo['cookie_ttl_seconds']
sessions = {}
HOP = {'host', 'connection', 'upgrade', 'content-length', 'transfer-encoding',
       'keep-alive', 'proxy-authenticate', 'proxy-authorization', 'te', 'trailer',
       'authorization', 'cookie', 'accept-encoding'}
PAGE = '''<!doctype html><html lang="zh"><meta charset="utf-8"><title>WebSSH2 本地演示</title>
<style>body{font:17px system-ui;max-width:520px;margin:12vh auto;background:#f4f6f8;color:#172334}form{display:grid;gap:16px;background:white;padding:32px;border-radius:12px}input,button{font:inherit;padding:12px}button{background:#1356bb;color:white;border:0;border-radius:6px}small{line-height:1.7}</style>
<h1>WebSSH2 本地演示</h1><p>登录后进入官方 WebSSH2 终端和文件管理器。</p>
<form method="post" action="/login"><label>网站账号</label><input name="username" value="demo" autocomplete="username" required>
<label>网站密码</label><input type="password" name="password" autocomplete="current-password" required>
<button>登录并打开终端</button><small>本地测试默认账号：demo / demo-pass<br>此页面使用网站 Cookie；远端 SSH 认证由模拟环境配置。</small></form></html>'''


async def login(request):
    if request.method == 'GET':
        return web.Response(text=PAGE, content_type='text/html')
    data = await request.post()
    if not (hmac.compare_digest(str(data.get('username', '')), USER) and
            hmac.compare_digest(str(data.get('password', '')), PASSWORD)):
        event('WARNING', 'gateway.login.rejected', peer=request.remote)
        return web.Response(status=401, text='Invalid website credentials')
    event('INFO', 'gateway.login.success', peer=request.remote)
    token = secrets.token_urlsafe(32)
    register_secret(token)
    sessions[token] = time.monotonic() + TTL
    response = web.HTTPFound('/ssh/host/')
    response.set_cookie('demo_session', token, httponly=True, samesite='Strict', max_age=TTL)
    return response


async def proxy(request):
    token = request.cookies.get('demo_session', '')
    if sessions.get(token, 0) < time.monotonic():
        if request.path in ('/', '/ssh', '/ssh/host/') and request.headers.get('Upgrade', '').lower() != 'websocket':
            raise web.HTTPFound('/login')
        return web.Response(status=401, text='Website session expired; log in again')
    if request.path in ('/', '/ssh'):
        raise web.HTTPFound('/ssh/host/')
    # Strip all client credentials and insert mock backend authentication.
    headers = {k: v for k, v in request.headers.items() if k.lower() not in HOP}
    headers['Authorization'] = request.app['basic']
    # WebSSH2's session cookie is forwarded too, but website Cookie never reaches it.
    upstream_cookies = {k: v for k, v in request.cookies.items() if k != 'demo_session'}
    headers['Cookie'] = '; '.join(k + '=' + v for k, v in upstream_cookies.items())
    client = request.app['client']
    url = UPSTREAM + request.rel_url.path_qs
    if request.headers.get('Upgrade', '').lower() == 'websocket':
        async with client.ws_connect(url, headers=headers, max_msg_size=8*1024*1024) as upstream:
            downstream = web.WebSocketResponse(max_msg_size=8*1024*1024)
            await downstream.prepare(request)
            async def relay(source, target):
                async for message in source:
                    if time.monotonic() > sessions.get(token, 0):
                        break
                    if message.type == WSMsgType.TEXT:
                        await target.send_str(message.data)
                    elif message.type == WSMsgType.BINARY:
                        await target.send_bytes(message.data)
                await target.close()
            tasks = [asyncio.create_task(relay(downstream, upstream)), asyncio.create_task(relay(upstream, downstream))]
            try:
                await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            finally:
                for task in tasks:
                    task.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)
            return downstream
    async with client.request(request.method, url, headers=headers,
                              data=await request.read(), allow_redirects=False) as upstream:
        response = web.Response(status=upstream.status, body=await upstream.read())
        for key, value in upstream.headers.items():
            if key.lower() not in HOP:
                response.headers.add(key, value)
        return response


async def startup(app):
    import base64
    app['basic'] = 'Basic ' + base64.b64encode(f'{SSH_USER}:{SSH_PASSWORD}'.encode()).decode()
    register_secret(app['basic'])
    app['client'] = ClientSession(auto_decompress=False, cookie_jar=DummyCookieJar())


async def cleanup(app):
    await app['client'].close()


@web.middleware
async def diagnostics(request, handler):
    started = time.monotonic()
    try:
        response = await handler(request)
        status = response.status
    except web.HTTPException as error:
        status = error.status
        raise
    except Exception as error:
        status = 500
        failure('gateway.request.failed', error, method=request.method, path=request.path, peer=request.remote)
        return web.Response(status=502, text='Gateway upstream failed; see private logs')
    finally:
        event('INFO', 'gateway.request.complete', method=request.method, path=request.path,
              status=locals().get('status'), peer=request.remote,
              duration_ms=round((time.monotonic()-started)*1000))
    return response


app = web.Application(client_max_size=8*1024*1024, middlewares=[diagnostics])
app.router.add_route('*', '/login', login)
app.router.add_route('*', '/{path:.*}', proxy)
app.on_startup.append(startup)
app.on_cleanup.append(cleanup)
if __name__ == '__main__':
    configure_logging(CONFIG, 'gateway')
    web.run_app(app, host=CONFIG.demo['bind_host'], port=CONFIG.demo['gateway_port'], access_log=None, print=None)
