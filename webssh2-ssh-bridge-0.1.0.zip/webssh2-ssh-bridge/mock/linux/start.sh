#!/bin/sh
set -eu
config=/config/compose.config.json
user=$(jq -r '.demo.target_user' "$config")
password=$(jq -r '.demo.target_password' "$config")
case "$user" in ''|*[!a-zA-Z0-9_-]*) echo 'Invalid configured target username'; exit 1;; esac
id "$user" >/dev/null 2>&1 || useradd -m -s /bin/bash "$user"
printf '%s:%s\n' "$user" "$password" | chpasswd
unset password
ssh-keygen -A
exec /usr/sbin/sshd -D -e
