"""One private JSON configuration. Relative paths resolve beside that file."""
import copy
import json
import os
from pathlib import Path
from urllib.parse import urlsplit
from .auth import private_write

ROOT = Path(__file__).resolve().parents[1]
EVENTS = set(('authentication data ssherror connection-error disconnect sftp-status terminal resize '
              'sftp-directory sftp-stat-result sftp-operation-result sftp-upload-ready sftp-upload-ack '
              'sftp-download-ready sftp-download-chunk sftp-complete sftp-error sftp-list sftp-stat '
              'sftp-mkdir sftp-delete sftp-upload-start sftp-upload-chunk sftp-upload-cancel '
              'sftp-download-start sftp-download-cancel').split())


class ConfigError(ValueError):
    pass


def config_path(path=None):
    return Path(path or os.getenv('BRIDGE_CONFIG', ROOT / '.state/config.json')).expanduser().resolve()


def defaults():
    return json.loads((ROOT / 'config.example.json').read_text())


def _merge(base, updates, prefix=''):
    if not isinstance(updates, dict):
        raise ConfigError('Expected an object at ' + (prefix or 'root'))
    for key, value in updates.items():
        name = prefix + key
        if key not in base:
            raise ConfigError('Unknown configuration field: ' + name)
        if name in ('webssh.headers', 'webssh.events', 'webssh.query', 'webssh.entry_query', 'webssh.entry_form'):
            if not isinstance(value, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in value.items()):
                raise ConfigError(name + ' must be a string-to-string object')
            base[key] = value
        elif name == 'webssh.auth':
            if not isinstance(value, dict):
                raise ConfigError('webssh.auth must be an object')
            base[key] = value
        elif isinstance(base[key], dict):
            _merge(base[key], value, name + '.')
        else:
            expected = type(base[key])
            if expected is int:
                valid = isinstance(value, (int, float)) and not isinstance(value, bool)
            else:
                valid = isinstance(value, expected)
            if not valid:
                raise ConfigError('Invalid type at ' + name)
            base[key] = value
    return base


def read_document(path):
    try:
        if path.stat().st_mode & 0o077:
            raise ConfigError('Private config must have mode 0600: ' + str(path))
        with path.open() as stream:
            document = json.load(stream)
    except json.JSONDecodeError as error:
        raise ConfigError('Invalid JSON at line %d column %d' % (error.lineno, error.colno)) from None
    except OSError as error:
        raise ConfigError('Cannot read config: ' + str(path)) from error
    return document


def validate(document):
    data = _merge(defaults(), copy.deepcopy(document))
    if data['version'] != 1:
        raise ConfigError('Unsupported config version')
    for section, fields in {'ssh': ['port', 'max_sessions', 'login_timeout_seconds'],
                            'webssh': ['http_timeout_seconds', 'connect_timeout_seconds', 'operation_timeout_seconds', 'exec_timeout_seconds', 'bootstrap_timeout_seconds'],
                            'files': ['max_bytes', 'max_handles_per_session', 'upload_chunk_bytes'],
                            'logging': ['max_bytes'],
                            'demo': ['gateway_port', 'webssh2_port', 'target_port', 'cookie_ttl_seconds']}.items():
        for key in fields:
            if data[section][key] <= 0:
                raise ConfigError(section + '.' + key + ' must be positive')
    for section, key in [('ssh', 'port'), ('demo', 'gateway_port'), ('demo', 'webssh2_port'), ('demo', 'target_port')]:
        if not isinstance(data[section][key], int) or data[section][key] > 65535:
            raise ConfigError(section + '.' + key + ' must be a valid TCP port')
    for section, key in [('ssh', 'max_sessions'), ('files', 'max_bytes'), ('files', 'max_handles_per_session'),
                         ('files', 'upload_chunk_bytes'), ('logging', 'max_bytes'), ('logging', 'backup_count')]:
        if not isinstance(data[section][key], int):
            raise ConfigError(section + '.' + key + ' must be an integer')
    if data['logging']['backup_count'] < 1:
        raise ConfigError('logging.backup_count must be at least 1')
    if data['logging']['level'].upper() not in ('DEBUG', 'INFO', 'WARNING', 'ERROR'):
        raise ConfigError('logging.level must be DEBUG/INFO/WARNING/ERROR')
    url = urlsplit(data['webssh']['url'])
    if url.scheme not in ('http', 'https') or not url.hostname or url.username or url.query or url.fragment or url.path not in ('', '/'):
        raise ConfigError('webssh.url must be an http(s) origin without credentials, path, or query')
    for key in ('entry_path', 'socketio_path', 'namespace'):
        if not data['webssh'][key].startswith('/'):
            raise ConfigError('webssh.' + key + ' must begin with /')
    if data['webssh']['entry_method'] not in ('GET', 'POST'):
        raise ConfigError('webssh.entry_method must be GET or POST')
    if set(data['webssh']['query']) & {'sid', 'EIO', 'transport', 't'}:
        raise ConfigError('Do not configure dynamic Socket.IO sid/EIO/transport/t query fields')
    transports = data['webssh']['transports']
    if not transports or not all(value in ('websocket', 'polling') for value in transports):
        raise ConfigError('webssh.transports supports websocket/polling only')
    for key, value in data['webssh']['headers'].items():
        if key.lower() in ('cookie', 'host', 'connection', 'upgrade'):
            raise ConfigError('Reserved header; use webssh.cookie for Cookie')
        if not key or any(c in key + value for c in '\r\n'):
            raise ConfigError('Invalid webssh header')
    if any(c in data['webssh']['cookie'] for c in '\r\n'):
        raise ConfigError('webssh.cookie must be one header line')
    if set(data['webssh']['events']) - EVENTS or any(not value for value in data['webssh']['events'].values()):
        raise ConfigError('Unknown or empty webssh event mapping')
    if not data['ssh']['username']:
        raise ConfigError('ssh.username cannot be empty')
    return data


def save_document(path, document):
    validate(document)
    private_write(path, (json.dumps(document, ensure_ascii=False, indent=2) + '\n').encode())


def initialize(path=None):
    path = config_path(path)
    if not path.exists():
        document = defaults()
        # One-time migration; old secrets are never printed or copied into examples.
        for old, section, key in [('ssh_password', 'ssh', 'password'), ('cookie.txt', 'webssh', 'cookie')]:
            legacy = path.parent / old
            if legacy.exists():
                document[section][key] = legacy.read_text().strip()
        save_document(path, document)
    return path


class Config:
    def __init__(self, path=None):
        self.path = config_path(path)
        self.document = validate(read_document(self.path))
        self.base = self.path.parent
        self.state = self.resolve(self.document['state_directory'])
        ssh, web, files, logs = (self.document[name] for name in ('ssh', 'webssh', 'files', 'logging'))
        self.host, self.port, self.username = ssh['host'], ssh['port'], ssh['username']
        self.password = ssh['password']
        self.authorized_keys, self.host_key = self.resolve(ssh['authorized_keys']), self.resolve(ssh['host_key'])
        self.max_sessions, self.login_timeout = ssh['max_sessions'], ssh['login_timeout_seconds']
        self.url, self.entry_path = web['url'].rstrip('/'), web['entry_path']
        self.socket_path, self.namespace = web['socketio_path'].strip('/'), web['namespace']
        self.transports, self.headers, self.tls_verify = web['transports'], web['headers'], web['tls_verify']
        self.http_timeout, self.connect_timeout = web['http_timeout_seconds'], web['connect_timeout_seconds']
        self.operation_timeout, self.timeout, self.bootstrap_timeout = web['operation_timeout_seconds'], web['exec_timeout_seconds'], web['bootstrap_timeout_seconds']
        self.events, self.cookie_override = web['events'], None
        self.query, self.socket_auth = web['query'], web['auth']
        self.entry_method, self.entry_query, self.entry_form = web['entry_method'], web['entry_query'], web['entry_form']
        self.max_file, self.max_handles = files['max_bytes'], files['max_handles_per_session']
        self.upload_chunk, self.verify_upload = files['upload_chunk_bytes'], files['verify_upload_sha256']
        self.log_directory = self.resolve(logs['directory'])
        self.log_settings, self.demo = logs, self.document['demo']

    def resolve(self, path):
        return (self.base / Path(path).expanduser()).resolve()

    def cookie(self):
        # Cookie is the only hot-reloaded field; never replay existing commands.
        if self.cookie_override is not None:
            return self.cookie_override
        return validate(read_document(self.path))['webssh']['cookie']
